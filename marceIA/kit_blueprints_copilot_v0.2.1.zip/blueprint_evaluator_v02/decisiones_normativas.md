# Decisiones y aclaraciones autorizadas

- **CN-001**: DOMINIO PRODUCTOR: hijo condicional por escenario; escenario 2 lo permite pero no lo exige, escenario 1 y 3 exigen hijo según las secciones específicas.
- **CN-002**: componenteServicioGestionado.md título corregido: Servicio gestionado.
- **CN-003**: componenteServicioGestionado.md: la oración sobre API privada MCI debe referirse a servicio MCI.
- **CN-004**: Aliases: APIBase.md => componenteApiBase.md; APIPrivada.md => componenteApiPrivada.md; APIPartnerPublica.md => componenteApiPartnerPublica.md; XXXXXXX => capasDespliegue.md.
- **CN-005**: Command con respuesta requiere dos señales (envío y recepción); sin respuesta requiere una (envío o recepción). No inferir el subtipo únicamente del rótulo Command.
- **CN-006**: componenteEventoSinRespuesta.md: suscripción, triángulo sin relleno apunta a señal recepción.
- **CN-007**: Versión vMAJOR.MINOR.PATCH: MAJOR >= 1, incluyendo v1.0.0.
- **CN-008 (RESUELTO)**: modelosLectura.md Política: debe estar acompañada de al menos UNO de los cinco tipos de comando admitidos (sistema automatizado, usuario, consulta, sistema o subproceso). No se exige tener los cinco. La asociación no supone línea directa: el estándar prohíbe conectores desde la política.

Las reglas no resueltas reciben No Verificable por conflicto normativo, no una interpretación inventada.
