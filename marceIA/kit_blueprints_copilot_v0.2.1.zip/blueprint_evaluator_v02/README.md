# Kit Evaluador Blueprint v0.2.1

- `INSTRUCCIONES_AGENTE.md`: comportamiento del agente, autoridad, evaluación SVG.
- `normativa_consolidada/`: 17 documentos, con aclaraciones aceptadas incorporadas o antepuestas.
- `normativa_original/`: 17 documentos intactos para auditoría.
- `decisiones_normativas.md`: aclaraciones y pendientes.
- `prompt_original_extraido.txt`: contenido textual del PROMPT.docx.
- `INSTRUCCIONES_AGENTE_SOLO_TEXTO.txt`: alternativa autocontenida para plataformas que admiten un único texto.

No se incluyen imágenes PNG en el paquete liviano; siguen en el ZIP original. Las imágenes complementan la interpretación visual y deben adjuntarse individualmente cuando la plataforma lo permita. El SVG exportado ya contiene vectores y estilos propios.

IMPORTANTE: este kit es un prototipo revisable, no una norma aprobada ni un agente desplegado. La protección persistente requiere permisos corporativos reales.

Actualización v0.2.1: regla de Política corregida (uno o más de cinco tipos de comando). `normativa_original/` no se modifica.
