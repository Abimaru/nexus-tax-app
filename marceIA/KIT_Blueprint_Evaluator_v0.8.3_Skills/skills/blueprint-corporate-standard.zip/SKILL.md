---
name: blueprint-corporate-standard
description: "Consulta y aplica la normativa corporativa consolidada v0.8.3 para evaluar Blueprints Lucidchart por escenario, API, servicios, contenedores, BPMN, modelos, eventos y conexiones; identifica conflictos, evidencia insuficiente y trazabilidad."
---
# Blueprint Corporate Standard — v0.8.3

Esta Skill contiene **la normativa consolidada íntegra** en `references/NORMATIVA_BLUEPRINTS_CONSOLIDADA_v0.8.3.md`. Ese archivo es el único texto normativo de esta Skill y no debe sustituirse por un resumen memorizado.

## Procedimiento obligatorio

1. Antes del dictamen, **abre y consulta el archivo de referencia** y verifica que su versión sea 0.8.3. La existencia de un nombre de archivo en el ZIP no garantiza que Agent Builder exponga el contenido en ejecución.
2. Lee las definiciones D-01 a D-08 y luego solo las secciones aplicables al escenario y a los componentes realmente inventariados.
3. Para cada requisito, anota capítulo y encabezado normativo, componente/ID, evidencia y estado. No inventes un ID de regla; usa identificadores propios de informe como `H-01`, diferenciándolos de la norma.
4. E1 exige servicio principal en el productor; E2 exige servicio principal gestionado en INTEGRACIÓN; E3 exige servicio externo al hijo azul conectado directamente al Inicio dentro del hijo.
5. Capas MCI: aplicación individual a API/servicio cuando cada uno es MCI. Si no lo es, No Aplica.
6. Verifica la leyenda NOTACIÓN como no operativa; color global SVG no prueba color por instancia; la ausencia de prueba se marca No Verificable.
7. Si hay conflicto de disposiciones, reporta `No Verificable por conflicto normativo` con ambos fragmentos y solicita decisión humana, sin modificar el estándar.
8. Si **no puedes abrir** el archivo de referencia, dilo claramente y solicita `NORMATIVA_BLUEPRINTS_CONSOLIDADA_v0.8.3.md` como adjunto. En ese caso **no afirmes** haber aplicado la Skill normativa completa.

La normativa adjunta por el analista al chat tiene prioridad práctica como evidencia accesible cuando no se puede consultar la referencia empaquetada. No hay consultas a Azure ni a servicios externos.
