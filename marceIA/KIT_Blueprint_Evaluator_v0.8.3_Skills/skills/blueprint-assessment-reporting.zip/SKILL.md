---
name: blueprint-assessment-reporting
description: Generar informe arquitectónico de siete secciones y tabla ejecutiva coherente a partir de resultados trazables.
---
# blueprint-assessment-reporting

## Procedimiento
1. Consumir primero el análisis estructural y la matriz normativa; no inventar reglas omitidas.
2. Presentar tabla resumen: objeto/ID, ubicación, rol, entradas/salidas, observación, estado **de cumplimiento** y evidencia, distinguiendo verificabilidad y conformidad.
3. Siete secciones obligatorias: 1 Resumen Ejecutivo; 2 Componentes Identificados; 3 Matriz de Cumplimiento; 4 Hallazgos y Evidencias; 5 Brechas Detectadas; 6 Recomendaciones Priorizadas; 7 Conclusión General.
4. Explicitar conteos (APIs modeladas, candidatas consumidas, servicios principales e invocados, eventos, conexiones) y definiciones; nunca equiparar UMLClassBlock con API consumida sin prueba.
5. Informe requiere ID por hallazgo, regla vigente, efecto, explicación y recomendación accionable. Indicar cobertura de evaluación y cumplimiento verificable como métricas distintas con fórmulas explícitas.
6. No emitir aprobación arquitectónica institucional. Registrar fuentes faltantes e incertidumbre.
**Salida:** informe apto para copiar a Confluence, tabla reproducible y sección de limitaciones.


## Integración operativa v0.8.3

La normativa vigente se obtiene preferentemente desde la habilidad `blueprint-corporate-standard` si el agente puede leer su archivo `references/NORMATIVA_BLUEPRINTS_CONSOLIDADA_v0.8.3.md`; si no, emplear el archivo normativo adjunto en la conversación. No asumir acceso a archivos internos de otra Skill. Verificar la disponibilidad de las reglas antes de emitir dictamen. El escenario declarado selecciona qué reglas probar; una contradicción con las evidencias se registra, nunca se corrige silenciosamente. No confundir colores globales con colores por instancia.
