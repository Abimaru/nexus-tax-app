# Blueprint Evaluator v0.5.1

**Variante de la v0.5.0**: los tres adjuntos se entregan simultáneamente; no requiere un segundo mensaje para JSON.

## Configurar el agente
Copiar el contenido de `INSTRUCCIONES_AGENT_BUILDER_v0.5.1.txt` como **reemplazo completo** de las instrucciones anteriores.

## Tres adjuntos en CADA chat de evaluación
1. JSON original de Lucidchart.
2. PDF o PNG o SVG renombrado TXT (una sola representación visual por prueba).
3. `ESTANDAR_BLUEPRINTS_INTEGRADO_v0.5.1.pdf` (normativa + catálogo).

El PDF contiene 60 páginas textuales y 76 páginas de catálogo visual, total 136. Sus marcadores permiten ir a cada parte. Los índices CV conservan las páginas **relativas al catálogo**, no al PDF fusionado; página global = página CV + 60.

Conservar el Markdown fuente solo para mantenimiento y control normativo; no adjuntarlo como cuarto archivo.

Las reglas técnicas de los 17 Markdown no se han reemplazado; solo cambió el protocolo metodológico para evaluación simultánea. Las capacidades de Copilot sobre PDF extenso y SVG/TXT deben comprobarse empíricamente.
