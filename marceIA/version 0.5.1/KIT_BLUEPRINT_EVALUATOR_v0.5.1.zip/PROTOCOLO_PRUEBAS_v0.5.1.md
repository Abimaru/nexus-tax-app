# Pruebas controladas v0.5.1

**Objetivo:** comparar JSON+PNG, JSON+PDF, JSON+TXT, usando un mismo estándar integrado.

1. Reemplazar INSTRUCCIONES del agente por `INSTRUCCIONES_AGENT_BUILDER_v0.5.1.txt`.
2. Abrir un chat NUEVO por combinación. Adjuntar a la vez: JSON del blueprint, versión visual PNG/PDF/TXT de la **misma operación**, y `ESTANDAR_BLUEPRINTS_INTEGRADO_v0.5.1.pdf`.
3. Pedir admisión y confirmación de cinco parámetros. Responderlos sin sugerirle clasificación si se quiere medir su deducción; registrar su propuesta inicial.
4. Pedir inventario independiente J, inventario V, conciliación y luego dictamen. Guardar el primer informe SIN correcciones previas.
5. Registrar PASS/FAIL/NO VERIFICABLE en la matriz; conservar respuesta textual y observaciones.
6. Para cada escenario repetir formatos en chats independientes. Comparar mismos criterios y regla por regla, no solo porcentajes.

## Riesgos
- Un PDF normativo grande puede sufrir recuperación parcial: exigir citas de regla y figura usada.
- El JSON puede incluir múltiples páginas; delimitar operación.
- La colorimetría exacta necesita extracción instrumental; el PDF ayuda a comparación, pero no certifica HEX.
- Si Copilot no lee el PDF integrado completo, no afirmar evaluación exhaustiva.
- Todo esto es una prueba con documentos corporativos en un entorno autorizado: no publicar fuentes a Internet.
