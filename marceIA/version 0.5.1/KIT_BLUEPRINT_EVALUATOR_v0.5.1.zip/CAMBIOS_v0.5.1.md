# Cambios v0.5.1 frente a v0.5.0

- Sustituido flujo secuencial (visual y luego JSON) por flujo simultáneo con los tres documentos.
- Fusionados PDF textual de normativa y PDF visual; se conservan láminas originales.
- Anexo metodológico ajustado a inventarios JSON y visual independientes, seguidos de conciliación.
- Reglas arquitectónicas técnicas heredadas sin modificaciones de fondo.
- Guía de referencias CV: páginas del catálogo vs páginas globales de PDF integrado.
- Matriz 3 escenarios × 3 formatos, 9 casos.
- Los cambios permanentes de normativa no están autorizados desde el chat.
