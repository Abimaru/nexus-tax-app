# Camino evolutivo: JSON de Lucidchart a evidencia estructurada

## Propósito
Transformar el JSON completo de Lucidchart en un artefacto compacto por página/operación que preserve semántica y relaciones SIN obligar a Copilot a interpretar todas las páginas mezcladas. No pretende sustituir el control visual.

## Fases
1. **Descubrimiento del esquema:** inventariar pages, `items.shapes`, `items.lines`, `textAreas`, coordenadas, colores, referencias y clases técnicas; diferenciar datos existentes y desconocidos. Validar con los 3 JSON/diagramas antes de codificar heurísticas globales.
2. **Selección:** elegir explícitamente página del blueprint y operación (p.ej. `retrieveTransactionSummary`). Excluir `NOTACIÓN`, BDD y otras operaciones del inventario funcional, sin perder evidencia auxiliar.
3. **Extracción:** registrar por objeto ID original, clase, etiqueta/textAreas, página, bounding box, fill/stroke, conexiones explícitas y orden. Mantener citas técnicas basadas en page ID / shape ID.
4. **Modelo intermedio:** normalizar entidades `container`, `layer`, `api`, `service`, `activity`, `policy`, `gateway`, `exception`, `model`, `edge`, `unknown`. Clasificar con reglas documentadas y confianza; no inventar relaciones cuando faltan conectores.
5. **Vinculación espacial:** contención geométrica, transformaciones y jerarquía con tolerancias; separar dominios principales, contenedores hijo y capas MCI. Validar visualmente muestras, no asumir que mismas clases significan mismo concepto.
6. **Exportación:** generar UN artefacto legible (`BLUEPRINT_EVIDENCIA.md` o `.json`) por operación con inventario, grafo, propiedades y referencias al JSON original. También generar un PDF/PNG solo para cotejo visual en desarrollo.
7. **Pruebas de regresión:** golden dataset con anotación humana (E1/E2, NEPA, capa composición, nombres servicio, políticas, 4 tipos de excepciones, comando, conexiones). Comparar falsos positivos/negativos.
8. **Integración 3 archivos:** A=EVIDENCIA_ESTRUCTURADA de un solo escenario; B=normativa MD; C=catálogo visual PDF. Si el chat permite PDF de blueprint como A, compararlo manualmente en pruebas aparte; para comparación automática multimodal habría que integrar visualización en A sin perder semántica.

## Condiciones de éxito
- Identificar E1 cuando solo existe API en INTEGRACIÓN conectada con servicio no gestionado del productor; E2 solamente ante servicio gestionado real en INTEGRACIÓN.
- Asociar NEPA al contenedor padre y NOMBRE SERVICIO al hijo.
- Reconocer `Capa de Arquitectura - composicion` como capa válida.
- No contabilizar leyenda ni páginas BDD como elementos funcionales.
- Enumerar actividades, políticas, compuertas, excepciones e inicio/fin con evidencia identificable.
- Registrar desconocidos y atributos ausentes como tal, sin inventarlos.

## Límite
Una exportación JSON puede no contener toda la semántica de conexiones ni equivalencia completa a la representación gráfica. Las afirmaciones visuales sin atributos explícitos deben mantenerse No Verificable hasta su cotejo.
