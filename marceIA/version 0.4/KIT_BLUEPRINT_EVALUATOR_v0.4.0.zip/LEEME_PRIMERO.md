# Blueprint Evaluator v0.4.0 — paquete de prueba

## Respuestas a las preguntas
**¿Sumar el punto 8 a las instrucciones anteriores?** NO. Sustituye íntegramente las instrucciones antiguas por `INSTRUCCIONES_AGENT_BUILDER_v0.4.0.txt`. Ya incorpora ese criterio y las verificaciones previas.

**¿Checklist?** Sí: después de una prueba fresca por formato, marca PASS/FAIL/NO PROBADO, adjunta el resultado de la primera respuesta de Copilot y compáralo con el esperado. El checklist es de regresión, no reemplaza análisis arquitectónico humano.

**¿Qué va en instrucciones vs MD?** Instrucciones = flujo/preguntas/seguridad de resultados. MD = reglas normativas y referencias visuales. No metas 17 Markdown en campo de instrucciones.

## Uso (límite de 3 archivos)
1. En Agent Builder, pegar el contenido del TXT de instrucciones v0.4.0.
2. Abrir chat nuevo e indicar los cinco parámetros de contexto (o responder las preguntas que hace el agente).
3. Adjuntar exactamente A=PDF/PNG/JSON/TXT blueprint, B=MD normativa v0.4.0, C=PDF catálogo v0.4.0.
4. Primero confirmar recepción, legibilidad y alcance; después autorizar informe completo.
5. Probar cada formato en un chat distinto; conservar primera respuesta.

## Gobierno
La normativa del MD es el lineamiento de cada evaluación. Al adjuntarlo por chat, otros usuarios podrían sustituirlo por un documento diferente: las instrucciones NO pueden garantizar autenticidad ni impedirlo técnicamente. Validar nombre, versión y opcionalmente SHA256 con un mecanismo externo bajo administración autorizada. La línea base permanente requerirá una fuente controlada por la organización.

## Nota
No se han certificado resultados de Copilot v0.4.0. Documentación interna: no publicar públicamente sin autorización.
