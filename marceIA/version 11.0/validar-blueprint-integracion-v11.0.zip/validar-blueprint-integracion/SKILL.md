---
name: validar-blueprint-integracion
description: Valida blueprints de integración en JSON, identifica E1/E2/E3 y evalúa el catálogo v11.0 de 41 reglas con estados, evidencia, métricas y recomendaciones. Usar cuando el usuario solicite validar, revisar, analizar o clasificar un blueprint.
---
# Validador de blueprints de integración v11.0

1. Leer una vez `references/MANIFEST.md`, `references/00-procedimiento.md` y los siete catálogos normativos.
2. Confirmar que el inventario contiene exactamente 41 IDs únicos.
3. Analizar evidencia silenciosamente; no adoptar diagnósticos derivados como autoridad.
4. Formular un único bloque de preguntas indispensables y continuar tras la respuesta.
5. Determinar E1/E2/E3 sin pedir al usuario que elija escenario.
6. Evaluar siempre las 41 reglas; usar No aplica para poblaciones ajenas.
7. No inferir asociaciones, propietarios, conexiones, nombres o MCI.
8. Entregar escenario, evidencia estructural, CSV de 41 filas, conteos, métricas, detalle por estado y recomendaciones.
9. Verificar que CSV, métricas, resumen y detalle coincidan y que la suma de estados sea 41.
