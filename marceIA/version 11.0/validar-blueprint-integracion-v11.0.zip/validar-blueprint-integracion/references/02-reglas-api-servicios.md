# Reglas Api Servicios - v11.0

## API-001 - Nombramiento y versión de API

**Resumen oficial:** Valida el nombre, producto/capacidad y versión de la API.

**Aplica a:** API principal e invocadas

**Criterio:** Nombre específico, no genérico, con la estructura y versión aprobadas.

**Evidencia mínima:** Secciones textuales completas.

- **Cumple:** evidencia suficiente y criterio satisfecho.
- **No cumple:** Nombre o versión fuera del patrón.
- **No verificable:** Texto parcial o clasificación API no certificada.
- **No aplica:** Fuera de la población evaluable.

## API-002 - Operación de API

**Resumen oficial:** Valida que la operación de la API sea obligatoria y específica.

**Aplica a:** API principal e invocadas

**Criterio:** La operación no puede ser vacía, genérica ni de plantilla.

**Evidencia mínima:** Segunda sección u operación certificada.

- **Cumple:** evidencia suficiente y criterio satisfecho.
- **No cumple:** Operación ausente o genérica con exportación completa.
- **No verificable:** Sección incompleta o asociación no certificada.
- **No aplica:** Fuera de la población evaluable.

## API-003 - Tipo y modelo de servicio de API

**Resumen oficial:** Valida tipo de exposición y modelo en la tercera sección.

**Aplica a:** API principal e invocadas

**Criterio:** Tipo private/public/partner y modelo deben estar declarados; no reclasificar automáticamente como servicio si faltan.

**Evidencia mínima:** Tercera sección y señales estructurales.

- **Cumple:** evidencia suficiente y criterio satisfecho.
- **No cumple:** API certificada con tipo/modelo ausente o inválido.
- **No verificable:** Clasificación API/servicio o tipo no certificado.
- **No aplica:** Fuera de la población evaluable.

## API-004 - Detalle de despliegue de API

**Resumen oficial:** Valida Capa y Flujo según tipo de API y MCI.

**Aplica a:** API principal

**Criterio:** Private MCI: Capa y Flujo; partner MCI: Capa; public: no aplican.

**Evidencia mínima:** Tipo, MCI y asociaciones de Capa/Flujo.

- **Cumple:** evidencia suficiente y criterio satisfecho.
- **No cumple:** Falta detalle obligatorio o existe detalle no permitido.
- **No verificable:** Tipo, MCI o asociación no certificados.
- **No aplica:** Fuera de la población evaluable.

## SRV-001 - Nombramiento y versión opcional de servicio

**Resumen oficial:** Valida el nombre específico y la versión opcional del servicio.

**Aplica a:** Servicios principal e invocados

**Criterio:** Puede iniciar por ms; admite -, _ o espacios. Si hay versión, V/v y tres segmentos.

**Evidencia mínima:** Primera sección completa.

- **Cumple:** evidencia suficiente y criterio satisfecho.
- **No cumple:** Nombre genérico o versión presente con formato inválido.
- **No verificable:** Clasificación o texto no certificados.
- **No aplica:** Fuera de la población evaluable.

## SRV-002 - Operación del servicio

**Resumen oficial:** Valida operación obligatoria, específica y en camelCase.

**Aplica a:** Servicios principal e invocados

**Criterio:** No deducir operación del nombre.

**Evidencia mínima:** Segunda sección completa.

- **Cumple:** evidencia suficiente y criterio satisfecho.
- **No cumple:** Operación ausente, genérica o fuera de camelCase.
- **No verificable:** Sección incompleta o servicio no certificado.
- **No aplica:** Fuera de la población evaluable.

## SRV-003 - Modelo de servicio

**Resumen oficial:** Valida el modelo obligatorio del servicio.

**Aplica a:** Servicios principal e invocados

**Criterio:** Valores permitidos: entidad, utilidad o tarea; el servicio no tiene tipo API.

**Evidencia mínima:** Tercera sección completa.

- **Cumple:** evidencia suficiente y criterio satisfecho.
- **No cumple:** Modelo ausente o fuera del catálogo.
- **No verificable:** Clasificación API/servicio no certificada.
- **No aplica:** Fuera de la población evaluable.

