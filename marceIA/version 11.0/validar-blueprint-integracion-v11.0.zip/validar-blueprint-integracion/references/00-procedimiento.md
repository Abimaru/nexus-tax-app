# Procedimiento de validación - v11.0

## Precedencia de evidencia

1. Componentes, textos, jerarquía y conexiones originales.
2. Asociaciones explícitas y cobertura.
3. Diagnósticos derivados del exportador solo como advertencia.

No usar un diagnóstico derivado para contradecir evidencia cruda coherente.

## Estados

- Cumple: evidencia suficiente y coherente.
- No cumple: evidencia completa demuestra infracción.
- No verificable: evidencia ausente, parcial, ambigua o contradictoria.
- No aplica: fuera de población.

## Flujo

1. Cargar JSON y verificar cobertura.
2. Inventariar componentes por nombre funcional; usar IDs solo para desambiguar.
3. Resolver E1/E2/E3 por componente principal, BPMNEvent, hijo y padre directo. No usar MCI, Capa o Flujo para elegir escenario.
4. Formular un único bloque de preguntas solo para datos declarativos indispensables como MCI/tipo cuando cambien aplicabilidad. No preguntar nombres, conexiones o asociaciones gráficas.
5. Evaluar exactamente 41 reglas, una fila por ID.
6. Aplicar independencia: una relación se evalúa una sola vez en su familia propietaria.
7. Entregar CSV completo, métricas, detalle y recomendaciones.

## Escenarios

- E1: API principal en INTEGRACIÓN, fuera del hijo; hijo en dominio productor; API None -> BPMNEvent Arrow.
- E2: API principal e hijo separados dentro de INTEGRACIÓN; API None -> BPMNEvent Arrow.
- E3: servicio principal e hijo separados en dominio productor; servicio None -> BPMNEvent Arrow.

No exigir subtipo Inicio; basta BPMNEvent certificado. Si Capa o Flujo aparecen como padre directo del hijo, escenario No verificable; no saltar automáticamente al abuelo.

## Conexiones

- CircleOpen y Generalization: CircleOpen es origen y Generalization destino.
- Escenario: None en API/servicio y Arrow en BPMNEvent.
- Comando-API: COM-002.
- Comando-servicio: COM-003.
- Comando-gestor: COM-004.
- Gestor-servicio: MQ-005.
- Evento-BPMNEvent: EVT-008.

## Modelos

API y servicio principales requieren entrada y salida. Invocados sin evidencia suficiente quedan No verificable, no No cumple. Los modelos internos del hijo son válidos sin propietario individual y no acreditan automáticamente modelos de componentes.

## Métricas

- Cumplimiento = Cumple / (Cumple + No cumple).
- Cobertura = (Cumple + No cumple) / (Cumple + No cumple + No verificable).
- No aplica no entra en denominadores.
