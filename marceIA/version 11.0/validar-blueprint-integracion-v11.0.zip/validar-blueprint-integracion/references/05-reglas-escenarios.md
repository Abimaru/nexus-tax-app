# Reglas Escenarios - v11.0

## E1-001 - Estructura integral E1

**Resumen oficial:** Valida API en INTEGRACIÓN conectada al hijo del dominio productor.

**Aplica a:** Escenario E1

**Criterio:** Solo API principal, fuera del hijo; hijo en dominio productor; API None -> BPMNEvent Arrow.

**Evidencia mínima:** API, hijo, padre directo, BPMNEvent y extremos.

- **Cumple:** evidencia suficiente y criterio satisfecho.
- **No cumple:** La estructura certificada contradice E1.
- **No verificable:** Algún participante, relación o cobertura no certificado.
- **No aplica:** Escenario certificado E2 o E3.

## E2-001 - Estructura integral E2

**Resumen oficial:** Valida API e hijo separados dentro de INTEGRACIÓN.

**Aplica a:** Escenario E2

**Criterio:** Solo API principal, fuera del hijo; ambos en INTEGRACIÓN; API None -> BPMNEvent Arrow.

**Evidencia mínima:** API, hijo, padre directo, BPMNEvent y extremos.

- **Cumple:** evidencia suficiente y criterio satisfecho.
- **No cumple:** La estructura certificada contradice E2.
- **No verificable:** Algún participante, relación o cobertura no certificado.
- **No aplica:** Escenario certificado E1 o E3.

## E3-001 - Estructura integral E3

**Resumen oficial:** Valida servicio principal e hijo separados en dominio productor.

**Aplica a:** Escenario E3

**Criterio:** Solo servicio principal, fuera del hijo; ambos en dominio productor; servicio None -> BPMNEvent Arrow.

**Evidencia mínima:** Servicio, hijo, padre directo, BPMNEvent y extremos.

- **Cumple:** evidencia suficiente y criterio satisfecho.
- **No cumple:** La estructura certificada contradice E3.
- **No verificable:** Algún participante, relación o cobertura no certificado.
- **No aplica:** Escenario certificado E1 o E2.

