# Catálogo optimizado v0.5.4

Reemplaza únicamente el PDF de conocimiento por `ESTANDAR_BLUEPRINTS_INTEGRADO_DEPURADO_v0.5.4.pdf`. Mantén instrucciones Agent Builder v0.5.2. Normativa técnica v0.5.3 sin cambios, con referencias de figura y página actualizadas.

Para probar: JSON + PDF/PNG/TXT del blueprint + PDF integrado depurado.

Lee `AUDITORIA_IMAGENES_v0.5.4.md` para conocer las imágenes retiradas y la tabla completa de correspondencias.
