# Auditoría de imágenes y referencias — v0.5.4

- Normativa técnica: v0.5.3 sin modificación.
- Figuras originales: 73.
- Figuras conservadas con referencia: 69.
- Figuras excluidas sin referencia: 4.
- Páginas PDF anterior: 122.
- Páginas PDF optimizado: 117.
- Páginas normativas preservadas: 46.
- Se mantiene el ID CV histórico y se remite a la página física del PDF optimizado.

## Figuras excluidas
- CV-015: CapaDespliegueServicio.png
- CV-034: EjemploHerencia.png
- CV-039: EjemploModeloLecturaModeloSalida.png
- CV-068: ModeloLecturaModeloSalida.png

## Índice verificado
| ID | Nombre original | Página física nueva |
|---|---|---:|
| CV-001 | Anotación.png | 47 |
| CV-002 | Anotaciónenchufe.png | 48 |
| CV-003 | APIBase.png | 49 |
| CV-004 | APIExternaMCI.png | 50 |
| CV-005 | APIPrivadaConServInt.png | 51 |
| CV-006 | APIPrivadaConsumida.png | 52 |
| CV-007 | APIPrivadaDominioPropio.png | 53 |
| CV-008 | APIPrivadaSinServInt.png | 54 |
| CV-009 | CapaDespliegueAPIInterna.png | 55 |
| CV-010 | CapaDespliegueAPIPartner.png | 56 |
| CV-011 | CapaDespliegueeventoConRespuesta.png | 57 |
| CV-012 | CapaDespliegueeventoSinRespuesta.png | 58 |
| CV-013 | CapaDespliegueGestorColas.png | 59 |
| CV-014 | CapaDespliegueGestorColasFederado.png | 60 |
| CV-016 | CapaDespliegueServicioFederado.png | 61 |
| CV-017 | ComandoConsulta.png | 62 |
| CV-018 | ComandoGestorColas.png | 63 |
| CV-019 | ComandoSistema.png | 64 |
| CV-020 | ComandoSistema2.png | 65 |
| CV-021 | ComandoSubproceso.png | 66 |
| CV-022 | ComandoUsuario.png | 67 |
| CV-023 | CompuertaBasadaenEventos.png | 68 |
| CV-024 | CompuertaExclusiva.png | 69 |
| CV-025 | CompuertaParalela.png | 70 |
| CV-026 | CompuertaParalelaBasadaenEventos.png | 71 |
| CV-027 | Concepto.png | 72 |
| CV-028 | Contenedores.png | 73 |
| CV-029 | EjemploBPMCI.png | 74 |
| CV-030 | EjemploCompuertaExclusiva.png | 75 |
| CV-031 | EjemploCompuertaParalela.png | 76 |
| CV-032 | EjemploExcepciondeNegocio(MensajedeExcepción).png | 77 |
| CV-033 | EjemploFlujoMensaje.png | 78 |
| CV-035 | EjemploInicio.png | 79 |
| CV-036 | EjemploInicio2.png | 80 |
| CV-037 | EjemploInicioNoGestionado.png | 81 |
| CV-038 | EjemploModeloFederado.png | 82 |
| CV-040 | EjemploSistemaExterno.png | 83 |
| CV-041 | Equivalencias.png | 84 |
| CV-042 | EscenarioIntegracion1.png | 85 |
| CV-043 | EscenarioIntegracion2.png | 86 |
| CV-044 | EscenarioIntegracion3.png | 87 |
| CV-045 | EventoConRespuesta.png | 88 |
| CV-046 | EventoConRespuestaEnvio.png | 89 |
| CV-047 | EventoConRespuestaRecepcion.png | 90 |
| CV-048 | EventoMensajeGestorColas.png | 91 |
| CV-049 | EventoSinRespuesta.png | 92 |
| CV-050 | EventoSinRespuestaEnvio.png | 93 |
| CV-051 | EventoSinRespuestaRecepcion.png | 94 |
| CV-052 | EventoTipoDominio.png | 95 |
| CV-053 | EventoTipoExcepcion.png | 96 |
| CV-054 | EventoTipoMensajeEnvio.png | 97 |
| CV-055 | EventoTipoMensajeRecepcion.png | 98 |
| CV-056 | EventoTipoSeñalEnvio.png | 99 |
| CV-057 | EventoTipoSeñalRecepcion.png | 100 |
| CV-058 | ExcepciondeNegocio(MensajedeExcepción).png | 101 |
| CV-059 | Fin.png | 102 |
| CV-060 | FlujoMensaje.png | 103 |
| CV-061 | GestorColasAGestorColas.png | 104 |
| CV-062 | GestorColasServicioNoGestionado.png | 105 |
| CV-063 | GestordeColas-QueueManager(MQ).png | 106 |
| CV-064 | Herencia.png | 107 |
| CV-065 | Inicio.png | 108 |
| CV-066 | InteracciónAPI.png | 109 |
| CV-067 | ModeloEntrada.png | 110 |
| CV-069 | ModeloSalida.png | 111 |
| CV-070 | Pendientes.png | 112 |
| CV-071 | SistemaExterno.png | 113 |
| CV-072 | SPR.png | 114 |
| CV-073 | TransformacióndeMensajería.png | 115 |

Las figuras excluidas permanecen en los paquetes anteriores y pueden reincorporarse si se añaden referencias normativas.
