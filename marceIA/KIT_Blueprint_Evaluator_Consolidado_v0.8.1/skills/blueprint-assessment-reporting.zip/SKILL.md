---
name: blueprint-assessment-reporting
description: Generar informe arquitectónico de siete secciones y tabla ejecutiva coherente a partir de resultados trazables.
---

# blueprint-assessment-reporting

## Procedimiento
1. Consumir primero el análisis estructural y la matriz normativa; no inventar reglas omitidas.
2. Presentar tabla resumen: objeto/ID, ubicación, rol, entradas/salidas, observación, estado **de cumplimiento** y evidencia, distinguiendo verificabilidad y conformidad.
3. Siete secciones obligatorias: 1 Resumen Ejecutivo; 2 Componentes Identificados; 3 Matriz de Cumplimiento; 4 Hallazgos y Evidencias; 5 Brechas Detectadas; 6 Recomendaciones Priorizadas; 7 Conclusión General.
4. Explicitar conteos (APIs modeladas, candidatas consumidas, servicios principales e invocados, eventos, conexiones) y definiciones; nunca equiparar UMLClassBlock con API consumida sin prueba.
5. Informe requiere ID por hallazgo, regla vigente, efecto, explicación y recomendación accionable. Indicar cobertura de evaluación y cumplimiento verificable como métricas distintas con fórmulas explícitas.
6. No emitir aprobación arquitectónica institucional. Registrar fuentes faltantes e incertidumbre.
**Salida:** informe apto para copiar a Confluence, tabla reproducible y sección de limitaciones.
