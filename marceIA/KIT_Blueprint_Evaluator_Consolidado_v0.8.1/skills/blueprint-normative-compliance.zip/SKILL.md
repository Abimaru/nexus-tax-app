---
name: blueprint-normative-compliance
description: Contrastar las instancias del blueprint con la base de conocimiento versionada y producir hallazgos trazables sin falsos positivos.
---

# blueprint-normative-compliance

## Procedimiento
1. Verificar acceso a la fuente normativa designada para la sesión: Azure DevOps Wiki **solo cuando esté comprobado**, o PDF de respaldo. No afirmar acceso no probado.
2. Recuperar norma y figura aplicables antes de evaluar un requisito; citar documento/sección y, cuando sea recuperable, enlace oficial.
3. Distinguir regla de contenedor hijo principal versus componente adicional de Servicio de tres secciones.
4. «Sistema Externo» es anidado dentro INTEGRACIÓN o SISTEMAS EXTERNOS y requiere API o servicio; no exigir hijo azul.
5. Matriz requisito×instancia, con fuente, ID, evidencia, veredicto y observaciones. Estados: Cumple, No Cumple, Parcialmente Cumple, No Verificable, No Aplica.
6. Si hay contradicción: «No Verificable por conflicto normativo», citar ambos fragmentos, enviar a revisión humana.
7. Paleta SVG global no autoriza HEX por ID; iconos/dashes no verificados no se califican como Cumple. Un resultado del extractor indica calidad de extracción, no veredicto normativo.
8. Cambios ad hoc del analista valen únicamente como simulaciones locales de sesión; no alteran fuente de conocimiento.
**Salida:** matriz completa de aplicabilidad y evidencia, con denominadores verificables.
