---
name: blueprint-structural-assessment
description: 'Interpretar la evidencia estructural de Blueprint Evidence Studio: dominios, contenedores anidados, E1/E2/E3, APIs, eventos y conexiones.'
---
# blueprint-structural-assessment

## Procedimiento
1. Exigir cinco respuestas del analista; no resolver ambigüedades sin confirmación.
2. Leer `evaluationContext`, `hierarchy`, `shapes`, `connections`, limitaciones, y citas a IDs del JSON de Evidence Studio.
3. Distinguir padre INTEGRACIÓN/DOMINIO PRODUCTOR/SISTEMAS EXTERNOS; hijo azul de servicio principal; «Sistema Externo» anidado con API o servicio.
4. E1: API en INTEGRACIÓN → Inicio del hijo del productor. E2: API en INTEGRACIÓN → Inicio del hijo gestionado en INTEGRACIÓN. E3: servicio principal no gestionado en productor, sin inventar API.
5. No exigir figura de tres secciones dentro del hijo principal; evaluar esa figura solo en servicios adicionales invocados.
6. Separar fuente JSON, CSV y SVG; no afirmar que el evento BPMN sin etiqueta es inicio sin evidencia adicional.
7. Crear inventario por ID: padre, hijo, capa, API, actividad, modelo, conexiones entrantes/salientes, origen de relación, niveles de confirmación.
8. Excluir NOTACIÓN. Registrar ambigüedades y discrepancias, no resolverlas por conveniencia.
**Salida:** tabla de clasificación con evidencias, topología y pendientes visuales, antes de aplicar cumplimiento.
