# Control de cambios v0.5.0

- Se **reemplazan** las instrucciones de Agent Builder v0.4.0 por las v0.5.0; NO anexarlas.
- Los 17 MD normativos siguen íntegros. Se agrega un anexo **METODOLÓGICO**, no nuevas obligaciones, a la cabecera de normativa v0.5.0.
- El PDF visual v0.4.0 se reutiliza sin modificación para permitir comparar iteraciones y ahorrar nueva validación visual.
- Flujo en dos etapas: visual (3 adjuntos) -> JSON (mensaje siguiente) -> conciliación y único informe final.
- Se añaden: prueba de límite por mensaje/conversación, clasificación cromática e iconográfica conservadora, filtrado de leyenda y BDD, reglas de conteo.
- Pendiente normativo para revisión humana: la categoría de comandos con verbos «validar» en contextos Consulta vs Sistema Automatizado. NO se crea excepción oficial.
- En caso de que Copilot no acepte nuevos adjuntos tras usar tres, el protocolo falla en capacidad de entrada: registrar ese hecho, sin inventar evidencia.
