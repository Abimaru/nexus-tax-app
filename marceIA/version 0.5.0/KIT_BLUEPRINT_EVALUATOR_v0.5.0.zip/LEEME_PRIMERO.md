# Blueprint Evaluator v0.5.0 — inicio rápido

1. En Agent Builder **REEMPLAZAR**, no sumar, el campo Instrucciones con `INSTRUCCIONES_AGENT_BUILDER_v0.5.0.txt`.
2. Chat nuevo para cada una de las 9 pruebas de la matriz. Primer envío: (A) blueprint PDF/PNG/TXT, (B) MD normativa v0.5.0, (C) catálogo visual PDF v0.4.0.
3. Confirmar los cinco parámetros cuando el agente los pregunte. No aceptar un informe final todavía.
4. Cuando solicite evidencia estructurada, subir el JSON de Lucidchart en un **mensaje posterior del mismo chat**. Si Copilot lo impide, documentar el límite. No retirar la normativa ni afirmar que el JSON se ha leído.
5. Solicitar informe conciliado y copiar los resultados a la matriz CSV.

El protocolo de lectura introducido al MD **NO crea reglas**; está junto a ellas para esquivar el límite de instrucciones, pero no está garantizado que Copilot lo lea o lo trate como instrucciones de mayor prioridad. Validar esa conducta con las pruebas.

El PDF visual se mantiene igual que en v0.4.0 para una comparación justa. El kit incluye únicamente documentación interna: no publicarla en servidores web públicos sin autorización corporativa.
