# Reglas Gestores Colas - v11.8.2

### MQ-001 - Identificación y nombramiento del gestor de colas
  
**Resumen oficial:** Valida que toda figura certificada como gestor de colas tenga un nombre específico y detecta candidatos pendientes de clasificación por su figura y texto.  
**Aplica a:** Figuras cuyo tipo Lucidchart esté certificado como UMLActiveClassBlock y figuras distintas de UMLActiveClassBlock y BPMNActivity cuyo nombre completo contenga una expresión indicativa de gestor de colas.  
**Criterio:** Toda figura UMLActiveClassBlock se considera un gestor de colas y debe tener un nombre visible, funcional y específico que permita identificarlo. No se admiten nombres ausentes, vacíos, genéricos ni textos de plantilla. No se exige un formato particular, idioma, versión, prefijo, capitalización ni estructura de palabras.
Tras eliminar espacios iniciales y finales, normalizar espacios repetidos e ignorar mayúsculas, minúsculas y tildes, se consideran nombres genéricos cuando constituyan el nombre completo: cola, colas, gestor de cola, gestor de colas, gestores de cola, gestores de colas y sin nombre. Estas expresiones no vuelven genérico un nombre específico que contenga información adicional funcional, como “Gestor de colas de pagos”. Las palabras aisladas gestor o gestores no identifican por sí solas un candidato.
Una figura distinta de UMLActiveClassBlock y de BPMNActivity cuyo nombre completo contenga cola, colas, gestor de cola, gestor de colas, gestores de cola o gestores de colas se considera únicamente candidata pendiente de clasificación. El texto no certifica que sea un gestor de colas ni permite reemplazar el tipo Lucidchart o architecturalType entregado por la evidencia.
La regla evalúa exclusivamente la identificación y el nombramiento del gestor de colas. Su ubicación se evalúa mediante CNT y EXT; su Capa de Despliegue mediante MQ-002; y sus conexiones mediante COM o MQ según corresponda.  
**Evidencia mínima:** Tipo Lucidchart certificado como UMLActiveClassBlock y texto completo del nombre visible; para candidatos, tipo de figura certificado como diferente de BPMNActivity, texto completo y ausencia de certificación como UMLActiveClassBlock. La clasificación como gestor no debe inferirse únicamente por texto, ubicación, conexiones o cercanía.
- **Cumple:** Todas las figuras UMLActiveClassBlock tienen un nombre visible, funcional, específico y diferente de los nombres genéricos o textos de plantilla, y no existen candidatos pendientes de clasificación.
- **No cumple:** Existe al menos una figura UMLActiveClassBlock cuyo nombre está ausente, vacío, compuesto únicamente por espacios, coincide completamente con un nombre genérico o corresponde a un texto de plantilla.
- **No verificable:** No existe un incumplimiento certificado, pero hay una figura distinta de BPMNActivity cuyo texto la señala como candidata a gestor y no puede certificarse como UMLActiveClassBlock; no puede certificarse el tipo de figura; el texto no está disponible o está incompleto; o la información no permite determinar si el nombre es específico, genérico o de plantilla. Prioridad de estados: apartado 8 de `00-procedimiento.md`.
- **No aplica:** La página no contiene figuras certificadas como UMLActiveClassBlock ni figuras candidatas pendientes de clasificación como gestores de colas.
### MQ-002 - Capa de Despliegue del gestor de colas

**Resumen oficial:** Valida que todo gestor de colas ubicado en INTEGRACIÓN tenga asociada una Capa de Despliegue MCI o Federada.

**Aplica a:** Gestores de colas ubicados en el nivel padre de INTEGRACIÓN.

**Criterio:** Todo gestor de colas ubicado en INTEGRACIÓN debe tener asociada una Capa de Despliegue, que puede corresponder a una de las siguientes modalidades:

- **MCI:** debe estar representada por una Capa de Arquitectura y un Flujo Transaccional asociados inequívocamente al gestor.
- **Federada:** debe estar representada mediante el valor exacto `Federado` (figura `architecturalType: FEDERADO`, asociada al gestor por una entrada `modality: FEDERADO` en `deploymentAssociations`); en esta modalidad no se exigen Capa de Arquitectura ni Flujo Transaccional.

La modalidad debe poder determinarse inequívocamente y sus elementos deben pertenecer al gestor de colas evaluado. La asociación no puede establecerse únicamente por cercanía, alineación, superposición o ubicación dentro del mismo contenedor.

Cuando el gestor esté ubicado fuera de INTEGRACIÓN, esta regla no exige ni evalúa una Capa de Despliegue. La ubicación permitida del gestor se evalúa mediante las reglas CNT y EXT. El nombramiento de la Capa de Arquitectura y del Flujo Transaccional existentes se evalúa mediante CA-001 y FT-001.

**Evidencia mínima:** Identificación certificada del gestor mediante el tipo `UMLActiveClassBlock`, ubicación certificada en el nivel padre de INTEGRACIÓN y evidencia completa de la modalidad de Capa de Despliegue. Para MCI se requieren una Capa de Arquitectura y un Flujo Transaccional inequívocamente asociados al gestor. Para Federada se requiere el valor literal `Federado` inequívocamente asociado al gestor.

- **Cumple:** El gestor está ubicado en el nivel padre de INTEGRACIÓN y tiene asociada una Capa de Despliegue válida: una Capa de Arquitectura y un Flujo Transaccional para la modalidad MCI, o el valor exacto `Federado` para la modalidad Federada.

- **No cumple:** La ubicación del gestor, la modalidad de despliegue y la cobertura de sus elementos están certificadas, y se presenta al menos una de las siguientes situaciones: el gestor ubicado en INTEGRACIÓN no tiene Capa de Despliegue; la modalidad MCI carece de Capa de Arquitectura, Flujo Transaccional o ambos; la modalidad Federada no contiene el valor exacto `Federado`; o los elementos están certificadamente asociados a un componente diferente.

- **No verificable:** No puede certificarse la ubicación del gestor; no puede determinarse si la Capa de Despliegue es MCI o Federada; existen una Capa de Arquitectura, un Flujo Transaccional o un valor `Federado` candidatos, pero no puede demostrarse que pertenezcan al gestor; o la cobertura no permite confirmar la presencia o ausencia de los elementos obligatorios. La cercanía, alineación, superposición o pertenencia al mismo contenedor no constituyen evidencia suficiente de asociación. Prioridad de estados: apartado 8 de `00-procedimiento.md`.

- **No aplica:** El gestor está certificadamente ubicado fuera de INTEGRACIÓN, o la página no contiene gestores de colas ni candidatos pendientes de clasificación como tales.


### MQ-003 - Conexiones del gestor de colas

**Resumen oficial:** Valida las conexiones del gestor de colas con otros gestores, servicios invocados y eventos BPMN de tipo Mensaje.

**Aplica a:** Gestores de colas relacionados con otros gestores de colas, servicios invocados o eventos BPMN candidatos a tipo Mensaje.

**Criterio:** Las conexiones admitidas para un gestor de colas dependen del tipo de participante relacionado:

- Entre dos gestores de colas, la relación debe ser bidireccional. Debe existir una conexión desde el primer gestor hacia el segundo y otra en sentido contrario. En cada conexión, el origen debe utilizar `CircleOpen` y el destino `Generalization`.
- Entre un servicio invocado y un gestor de colas, se admite una relación unidireccional desde el servicio hacia el gestor o una relación bidireccional entre ambos. La conexión desde el servicio hacia el gestor debe utilizar `CircleOpen` en el servicio y `Generalization` en el gestor. Cuando exista la conexión de retorno, debe utilizar `CircleOpen` en el gestor y `Generalization` en el servicio.
- Entre un evento BPMN de tipo Mensaje y un gestor de colas, la relación debe ser unidireccional desde el evento hacia el gestor, con `CircleOpen` en el evento y `Generalization` en el gestor.

La relación con un servicio invocado se evalúa mediante esta regla tanto si el servicio está ubicado directamente en un dominio como si está encapsulado dentro de un sistema externo auxiliar. Las conexiones entre un comando y un gestor de colas se excluyen de esta regla y se evalúan exclusivamente mediante COM-004.

**Evidencia mínima:** Identificación certificada del gestor de colas y del participante relacionado, junto con las conexiones completas, sus sentidos y terminaciones. Para relaciones con servicios debe estar certificada la clasificación del componente como servicio invocado. Si el servicio está encapsulado dentro de un sistema externo auxiliar, debe demostrarse su pertenencia al auxiliar. Para relaciones con eventos BPMN debe certificarse el subtipo Mensaje; la clasificación genérica como `BPMNEvent` no es suficiente.

- **Cumple:** Todas las conexiones evaluadas corresponden a uno de los patrones admitidos: relación bidireccional entre gestores; relación unidireccional desde el servicio hacia el gestor o bidireccional entre ambos; o relación unidireccional desde un evento BPMN de tipo Mensaje hacia el gestor. Cada conexión utiliza `CircleOpen` en el origen y `Generalization` en el destino.

- **No cumple:** Los participantes, sus tipos y la cobertura de las conexiones están certificados, y se presenta al menos una de las siguientes situaciones: falta alguno de los sentidos obligatorios entre dos gestores; una conexión tiene un sentido no permitido; una terminación es incorrecta; existe una conexión de retorno desde el gestor hacia un evento BPMN de tipo Mensaje; la relación servicio-gestor solo existe desde el gestor hacia el servicio; existen conexiones duplicadas para la misma pareja y el mismo sentido; o la conexión termina en un participante certificado que no corresponde al patrón evaluado.

- **No verificable:** No puede certificarse alguno de los participantes; un evento está identificado únicamente como `BPMNEvent` y no puede certificarse como evento de tipo Mensaje; no puede determinarse si el servicio está contenido en un sistema externo auxiliar; la dirección o las terminaciones son indeterminadas, ambiguas o contradictorias; o la cobertura no permite confirmar la presencia o ausencia de las conexiones obligatorias. Prioridad de estados: apartado 8 de `00-procedimiento.md`.

- **No aplica:** La página no contiene gestores de colas relacionados con otros gestores, servicios invocados o eventos BPMN candidatos a tipo Mensaje, ni conexiones pendientes que puedan configurar alguna de estas relaciones.