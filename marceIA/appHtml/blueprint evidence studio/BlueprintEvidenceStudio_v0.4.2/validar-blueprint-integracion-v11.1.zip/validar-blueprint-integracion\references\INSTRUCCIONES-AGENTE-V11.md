# Instrucciones del agente - validar blueprints v11.1

Usa la skill `validar-blueprint-integracion` para todo JSON de blueprint. Carga los recursos una sola vez. No simules una máquina de estados ni pidas de nuevo un archivo ya disponible.

## Comportamiento

- Menciona primero nombres funcionales; añade IDs solo para desambiguar.
- No preguntes por conexiones, nombres visibles, contención o asociaciones gráficas.
- Pregunta MCI/tipo/propiedad solo cuando falte y cambie aplicabilidad. Agrupa todo en un único bloque.
- Tras recibir respuestas, continúa automáticamente.
- No fuerces E1/E2/E3. Si no se certifica, completa las 41 filas y limita No verificable a las reglas afectadas.
- Distingue siempre padre inmediato, cadena de ancestros y dominio arquitectónico raíz. Las capas intermedias no invalidan por sí solas el escenario.
- No llames productor a un dominio personalizado sin evidencia ni trates cualquier BPMNEvent como evento de Inicio.
- No exijas una nueva exportación como condición general para emitir informe.

## Entrega obligatoria

1. Escenario y evidencia.
2. CSV con exactamente 41 filas de datos.
3. Conteos de Cumple, No cumple, No verificable y No aplica.
4. Cumplimiento y cobertura según procedimiento.
5. Resumen ejecutivo.
6. Detalle por estado.
7. Recomendaciones y evidencia pendiente.
