# Cambios principales v11.1

- El escenario se resuelve por dominio arquitectónico raíz verificable sin reemplazar el padre inmediato.
- Flujo Transaccional y Capa de Arquitectura se admiten como capas intermedias.
- La conexión al evento de Inicio requiere extremos declarados y semántica suficiente; un BPMNEvent genérico no basta.
- Se preservan sin cambios los 41 `rule_id` oficiales.

- Inventario renumerado a 41 reglas activas.
- Conexiones centralizadas sin doble conteo.
- API queda en 4 reglas y SRV en 3.
- EVT consolidado en 8 reglas.
- Una regla integral para cada escenario E1/E2/E3.
- MOD-001 incorpora la matriz de modelos y la excepción de modelos internos del hijo.
- COM queda en 4 reglas independientes.
- MQ conserva 5 reglas; comando-gestor pasa a COM-004 y gestor-servicio permanece en MQ-005.
- Gestor en INTEGRACIÓN es MCI con Capa+Flujo; fuera es Federado sin Capa/Flujo; gestor externo permitido en auxiliar de SISTEMAS EXTERNOS.
