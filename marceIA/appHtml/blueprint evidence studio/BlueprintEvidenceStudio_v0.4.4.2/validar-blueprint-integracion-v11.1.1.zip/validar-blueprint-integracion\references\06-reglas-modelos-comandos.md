# Reglas Modelos Comandos - v11.1

## MOD-001 - Modelos de entrada y salida

**Resumen oficial:** Valida modelos obligatorios y asociaciones sin inferir propietarios.

**Aplica a:** API/servicio principal, invocados y eventos

**Criterio:** Principal API/servicio: entrada+salida obligatorias. Invocados: ausencia no verificable. Eventos según Query/Command/Event y p/s. Modelos internos del hijo no requieren propietario individual.

**Evidencia mínima:** Asociaciones explícitas, clasificación y tópicos.

- **Cumple:** evidencia suficiente y criterio satisfecho.
- **No cumple:** Falta modelo obligatorio con componente, asociación y cobertura certificados.
- **No verificable:** Asociación/evidencia insuficiente; invocados sin modelos verificables.
- **No aplica:** Fuera de la población evaluable.

## COM-001 - Nombramiento de comandos

**Resumen oficial:** Valida infinitivo más complemento en comandos certificados.

**Aplica a:** BPMNActivity con relación certificada

**Criterio:** Una actividad conectada con API, servicio o gestor se evalúa una vez; no inferir por clase o semántica.

**Evidencia mínima:** Relación certificada y texto de actividad.

- **Cumple:** evidencia suficiente y criterio satisfecho.
- **No cumple:** Nombre fuera del patrón.
- **No verificable:** Candidato sin relación certificada.
- **No aplica:** No hay comandos certificados ni candidatos.

## COM-002 - Conexión comando con API invocada

**Resumen oficial:** Valida la relación bidireccional comando-API.

**Aplica a:** Comandos y APIs invocadas

**Criterio:** Comando->API y API->comando, CircleOpen origen y Generalization destino.

**Evidencia mínima:** Dos conexiones y clasificaciones.

- **Cumple:** evidencia suficiente y criterio satisfecho.
- **No cumple:** Falta una dirección o extremos incorrectos con cobertura completa.
- **No verificable:** Participantes, dirección o cobertura no certificados.
- **No aplica:** No hay APIs invocadas relacionadas con comandos.

## COM-003 - Conexión comando con servicio invocado

**Resumen oficial:** Valida la relación bidireccional comando-servicio.

**Aplica a:** Comandos y servicios invocados

**Criterio:** Comando->servicio y servicio->comando, CircleOpen origen y Generalization destino.

**Evidencia mínima:** Dos conexiones y clasificaciones.

- **Cumple:** evidencia suficiente y criterio satisfecho.
- **No cumple:** Falta una dirección o extremos incorrectos con cobertura completa.
- **No verificable:** Participantes, dirección o cobertura no certificados.
- **No aplica:** No hay servicios invocados relacionados con comandos.

## COM-004 - Conexión comando con gestor de colas

**Resumen oficial:** Valida la relación comando-gestor sin duplicarla en MQ.

**Aplica a:** Comandos y gestores

**Criterio:** Patrón vigente de comando con gestor, evaluado exclusivamente en COM.

**Evidencia mínima:** Conexiones, extremos y participantes certificados.

- **Cumple:** evidencia suficiente y criterio satisfecho.
- **No cumple:** Patrón incumplido con cobertura completa.
- **No verificable:** Participantes, dirección, extremos o cobertura no certificados.
- **No aplica:** No hay gestores relacionados con comandos.

