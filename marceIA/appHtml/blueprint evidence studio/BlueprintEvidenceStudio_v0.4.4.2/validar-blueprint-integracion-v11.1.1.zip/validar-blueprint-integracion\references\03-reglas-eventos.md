# Reglas Eventos - v11.1

## EVT-001 - Nombramiento y versión del evento

**Resumen oficial:** Valida Nombre Producto - Nombre Capacidad_vX.X.X.

**Aplica a:** Eventos de integración

**Criterio:** Guion entre producto/capacidad, versión obligatoria, V/v equivalentes y guion bajo opcional.

**Evidencia mínima:** Primera sección.

- **Cumple:** evidencia suficiente y criterio satisfecho.
- **No cumple:** Texto completo fuera del patrón.
- **No verificable:** Evento o texto no certificados.
- **No aplica:** Fuera de la población evaluable.

## EVT-002 - Operación del evento

**Resumen oficial:** Valida operación obligatoria, específica y en PascalCase.

**Aplica a:** Eventos de integración

**Criterio:** No deducir de la sección de nombre.

**Evidencia mínima:** Segunda sección.

- **Cumple:** evidencia suficiente y criterio satisfecho.
- **No cumple:** Operación ausente, genérica o fuera de PascalCase.
- **No verificable:** Sección incompleta.
- **No aplica:** Fuera de la población evaluable.

## EVT-003 - Tipo y clasificación del evento

**Resumen oficial:** Valida tipo Aplicacion/Empresarial y clasificación Query/Event/Command.

**Aplica a:** Eventos de integración

**Criterio:** Aceptar equivalencia de tilde en Aplicacion.

**Evidencia mínima:** Tercera sección.

- **Cumple:** evidencia suficiente y criterio satisfecho.
- **No cumple:** Valor ausente o fuera del catálogo.
- **No verificable:** Clasificación no certificada.
- **No aplica:** Fuera de la población evaluable.

## EVT-004 - Detalle de despliegue del evento

**Resumen oficial:** Valida Capa y Flujo del evento propio MCI.

**Aplica a:** Eventos propios

**Criterio:** Propio MCI requiere Capa y Flujo; no MCI no debe tenerlos; externo no aplica.

**Evidencia mínima:** Propiedad, MCI y asociaciones.

- **Cumple:** evidencia suficiente y criterio satisfecho.
- **No cumple:** Falta detalle obligatorio o hay detalle no permitido.
- **No verificable:** Propiedad, MCI o asociación no certificados.
- **No aplica:** Fuera de la población evaluable.

## EVT-005 - Contenedor de tópicos

**Resumen oficial:** Valida un contenedor de tópicos inequívocamente asociado.

**Aplica a:** Eventos de integración

**Criterio:** Aplica siempre a eventos certificados.

**Evidencia mínima:** Contención/asociación estructural.

- **Cumple:** evidencia suficiente y criterio satisfecho.
- **No cumple:** Ausente con cobertura completa.
- **No verificable:** Candidato sin asociación demostrada.
- **No aplica:** Fuera de la población evaluable.

## EVT-006 - Cantidad y roles de tópicos

**Resumen oficial:** Valida p/s según Query, Command o Event.

**Aplica a:** Eventos de integración

**Criterio:** Query p+s; Command p+s, solo p o solo s; Event exactamente p o s.

**Evidencia mínima:** Clasificación y tópicos asociados.

- **Cumple:** evidencia suficiente y criterio satisfecho.
- **No cumple:** Cantidad o combinación inválida.
- **No verificable:** Clasificación o asociación no certificadas.
- **No aplica:** Fuera de la población evaluable.

## EVT-007 - Nombramiento de tópicos

**Resumen oficial:** Valida minúsculas, puntos, prefijo p/s y terminación .vX.

**Aplica a:** Tópicos asociados

**Criterio:** Debe incluir producto y capacidad; código de aplicación opcional; X entero > 0.

**Evidencia mínima:** Texto completo del tópico.

- **Cumple:** evidencia suficiente y criterio satisfecho.
- **No cumple:** Tópico fuera del patrón.
- **No verificable:** Texto o asociación incompletos.
- **No aplica:** Fuera de la población evaluable.

## EVT-008 - Conexiones del evento

**Resumen oficial:** Valida conexiones con BPMNEvent según clasificación y tópicos.

**Aplica a:** Eventos de integración

**Criterio:** Query y Command p+s bidireccionales; p: BPMNEvent->evento; s: evento->BPMNEvent. CircleOpen origen y Generalization destino.

**Evidencia mínima:** Clasificación, tópicos y extremos.

- **Cumple:** evidencia suficiente y criterio satisfecho.
- **No cumple:** Falta dirección obligatoria o extremos incorrectos.
- **No verificable:** Dirección, clasificación, tópicos o cobertura no certificados.
- **No aplica:** Fuera de la población evaluable.

