# Reglas Despliegue - v11.1

## CA-001 - Existencia y nombramiento de Capa

**Resumen oficial:** Valida la Capa obligatoria y su nombre.

**Aplica a:** Componentes con Capa aplicable

**Criterio:** Patrón Capa de Arquitectura - tipo; tipos composicion, experiencia, sistema, minúsculos y sin tilde.

**Evidencia mínima:** Figura y texto completos.

- **Cumple:** evidencia suficiente y criterio satisfecho.
- **No cumple:** Ausente cuando es obligatoria o nombre inválido.
- **No verificable:** Aplicabilidad o cobertura no certificadas.
- **No aplica:** Fuera de la población evaluable.

## CA-002 - Asociación de Capa

**Resumen oficial:** Valida el propietario inequívoco de cada Capa.

**Aplica a:** Capas existentes

**Criterio:** No preguntar ni inferir por proximidad.

**Evidencia mínima:** Asociación estructural exclusiva.

- **Cumple:** evidencia suficiente y criterio satisfecho.
- **No cumple:** Propietario incorrecto certificado.
- **No verificable:** Asociación no demostrada o varios candidatos.
- **No aplica:** No existe figura de Capa.

## FT-001 - Existencia y nombramiento de Flujo

**Resumen oficial:** Valida el Flujo obligatorio y su nombre.

**Aplica a:** Componentes con Flujo aplicable

**Criterio:** Patrón Flujo Transaccional - tipo; monetario, no-monetario, operativo, transversal.

**Evidencia mínima:** Figura y texto completos.

- **Cumple:** evidencia suficiente y criterio satisfecho.
- **No cumple:** Ausente cuando es obligatorio o nombre inválido.
- **No verificable:** Aplicabilidad o cobertura no certificadas.
- **No aplica:** Fuera de la población evaluable.

## FT-002 - Asociación de Flujo

**Resumen oficial:** Valida el propietario inequívoco de cada Flujo.

**Aplica a:** Flujos existentes

**Criterio:** No preguntar ni inferir por proximidad.

**Evidencia mínima:** Asociación estructural exclusiva.

- **Cumple:** evidencia suficiente y criterio satisfecho.
- **No cumple:** Propietario incorrecto certificado.
- **No verificable:** Asociación no demostrada o varios candidatos.
- **No aplica:** No existe figura de Flujo.

