# Reglas Estructura - v11.1

## CNT-001 - Contenedores padre requeridos

**Resumen oficial:** Valida la existencia de los contenedores padre exigidos por el escenario.

**Aplica a:** Blueprint completo

**Criterio:** Deben identificarse INTEGRACIÓN y los demás contenedores padre aplicables al escenario, sin confundir auxiliares o leyendas.

**Evidencia mínima:** Jerarquía estructural y nombres certificados.

- **Cumple:** evidencia suficiente y criterio satisfecho.
- **No cumple:** Falta un contenedor obligatorio con cobertura completa.
- **No verificable:** La jerarquía o el nombre del contenedor no están certificados.
- **No aplica:** Fuera de la población evaluable.

## CNT-002 - Estructura del contenedor hijo

**Resumen oficial:** Valida la presencia o ausencia del hijo según E1, E2 o E3.

**Aplica a:** Contenedor hijo principal

**Criterio:** Evaluar el dominio arquitectónico raíz del hijo mediante una cadena de ancestros verificable. El padre inmediato puede ser Flujo Transaccional, Capa de Arquitectura o dominio. E1/E3 requieren la gestión indicada fuera del dominio productor y E2 bajo INTEGRACIÓN, según el criterio de escenarios v11.1.

**Evidencia mínima:** Padre directo, cadena completa, dominio arquitectónico raíz y escenario certificado.

- **Cumple:** evidencia suficiente y criterio satisfecho.
- **No cumple:** La estructura contradice el escenario certificado.
- **No verificable:** El padre directo o el escenario no pueden certificarse.
- **No aplica:** Fuera de la población evaluable.

## CNT-003 - Contenido permitido en INTEGRACIÓN

**Resumen oficial:** Valida que INTEGRACIÓN contenga solo componentes permitidos.

**Aplica a:** INTEGRACIÓN

**Criterio:** La API principal de E1/E2 y componentes de integración aplicables deben estar en INTEGRACIÓN; no trasladar contenido por proximidad.

**Evidencia mínima:** Contención directa certificada.

- **Cumple:** evidencia suficiente y criterio satisfecho.
- **No cumple:** Existe un componente prohibido o un componente obligatorio está fuera.
- **No verificable:** La contención es parcial o contradictoria.
- **No aplica:** Fuera de la población evaluable.

## CNT-004 - Contenido permitido en dominio productor

**Resumen oficial:** Valida los componentes permitidos en el dominio productor.

**Aplica a:** Dominio productor

**Criterio:** El dominio productor contiene el hijo de E1/E3, el servicio principal de E3 y componentes backend aplicables.

**Evidencia mínima:** Contención directa certificada.

- **Cumple:** evidencia suficiente y criterio satisfecho.
- **No cumple:** Existe ubicación incompatible con el escenario o tipo.
- **No verificable:** Dominio o contención no certificados.
- **No aplica:** Fuera de la población evaluable.

## CNT-005 - Contenido permitido en SISTEMAS EXTERNOS

**Resumen oficial:** Valida el contenido de SISTEMAS EXTERNOS y sus auxiliares.

**Aplica a:** SISTEMAS EXTERNOS

**Criterio:** Solo componentes externos y auxiliares válidos deben aparecer en este contenedor.

**Evidencia mínima:** Jerarquía y clasificación del componente.

- **Cumple:** evidencia suficiente y criterio satisfecho.
- **No cumple:** Componente propio ubicado como externo o contenido no permitido.
- **No verificable:** No se certifica externalidad o contención.
- **No aplica:** Fuera de la población evaluable.

## CNT-006 - Exclusividad de padre directo

**Resumen oficial:** Valida que cada componente tenga un padre directo normativo inequívoco.

**Aplica a:** Componentes evaluables

**Criterio:** No asumir propiedad por cercanía, alineación, ancestro o padre compartido.

**Evidencia mínima:** structuralParent y relaciones de contención coherentes.

- **Cumple:** evidencia suficiente y criterio satisfecho.
- **No cumple:** Dos padres directos incompatibles con cobertura completa.
- **No verificable:** Padres múltiples, parciales o contradictorios.
- **No aplica:** Fuera de la población evaluable.

## EXT-001 - Sistema externo auxiliar válido

**Resumen oficial:** Valida el uso del auxiliar dentro de INTEGRACIÓN o SISTEMAS EXTERNOS.

**Aplica a:** Sistema externo auxiliar

**Criterio:** Puede contener API, servicio, evento o gestor externo cuando corresponda.

**Evidencia mínima:** Padre directo y componentes contenidos.

- **Cumple:** evidencia suficiente y criterio satisfecho.
- **No cumple:** Auxiliar en ubicación no permitida o contenido incompatible.
- **No verificable:** Ubicación o clasificación no certificada.
- **No aplica:** Fuera de la población evaluable.

## EXT-002 - Conexión mediante auxiliar externo

**Resumen oficial:** Reconoce la conexión al auxiliar como sustituto visual del componente contenido.

**Aplica a:** Conexiones a auxiliares

**Criterio:** Con un único candidato compatible puede atribuirse la conexión; con varios, la asociación específica queda no verificable.

**Evidencia mínima:** Extremos, auxiliar y candidatos contenidos.

- **Cumple:** evidencia suficiente y criterio satisfecho.
- **No cumple:** No cumple solo si la comunicación está certificadamente ausente o es incompatible, nunca por terminar en el auxiliar.
- **No verificable:** Varios candidatos compatibles o asociación no demostrada.
- **No aplica:** Fuera de la población evaluable.

## GW-001 - Caminos alternos del gateway

**Resumen oficial:** Valida la coherencia de caminos alternos y conexiones de la compuerta.

**Aplica a:** Gateways BPMN

**Criterio:** No basta identificar la figura; los caminos deben ser coherentes y reconstruibles.

**Evidencia mínima:** Gateway y conexiones de entrada/salida.

- **Cumple:** evidencia suficiente y criterio satisfecho.
- **No cumple:** Caminos incompletos o incoherentes con cobertura completa.
- **No verificable:** No se certifican extremos, direcciones o cobertura.
- **No aplica:** Fuera de la población evaluable.

