---
name: validar-blueprint-integracion
description: Valida blueprints de integración en JSON, identifica E1/E2/E3 y evalúa el catálogo v11.1 de 41 reglas con estados, evidencia, métricas y recomendaciones. Usar cuando el usuario solicite validar, revisar, analizar o clasificar un blueprint.
---
# Validador de blueprints de integración v11.1

1. Leer una vez `references/MANIFEST.md`, `references/00-procedimiento.md` y los siete catálogos normativos.
2. Confirmar que el inventario contiene exactamente 41 IDs únicos.
3. Analizar evidencia silenciosamente; no adoptar diagnósticos derivados como autoridad.
4. Formular un único bloque de preguntas indispensables y continuar tras la respuesta.
5. Determinar E1/E2/E3 por el dominio arquitectónico raíz verificable del hijo y por los extremos declarados, sin pedir al usuario que elija escenario.
6. Evaluar siempre las 41 reglas; usar No aplica para poblaciones ajenas.
7. No inferir asociaciones, propietarios, conexiones, nombres o MCI.
8. Entregar escenario, evidencia estructural, CSV de 41 filas, conteos, métricas, detalle por estado y recomendaciones.
9. Verificar que CSV, métricas, resumen y detalle coincidan y que la suma de estados sea 41.

El padre estructural inmediato y el dominio arquitectónico raíz son hechos distintos. Leer `references/05-reglas-escenarios.md` antes de clasificar: Flujo Transaccional o Capa de Arquitectura pueden ser ancestros intermedios válidos. No convertir un dominio personalizado en productor sin evidencia y no sustituir la conexión exigida al evento de Inicio por la mera existencia de cualquier `BPMNEvent`.

Existe una contradicción normativa pendiente entre E1-001/E3-001/CNT-002 y CNT-004 sobre pertenencia del hijo al dominio productor. Hasta aprobación de la propuesta en `docs/audits/NORMATIVE_CORRECTION_PROPOSAL_v11.1.md`, no inventar una resolución: marcar las reglas afectadas No verificable y explicar el conflicto.
