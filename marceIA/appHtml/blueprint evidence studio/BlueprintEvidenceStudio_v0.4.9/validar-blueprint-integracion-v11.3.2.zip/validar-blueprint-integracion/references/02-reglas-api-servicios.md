# Reglas API y Servicios - v11.3.2

### API-001 - Nombramiento y versión de API

**Resumen oficial:** Valida el nombre y la versión de la primera sección de una API según el dominio arquitectónico en el que se encuentre.

**Aplica a:** Todas las API principales e invocadas con tipo arquitectónico certificado. Cada API de ambos roles se incluye individualmente en la población.

**Criterio:** Para una API ubicada en INTEGRACIÓN, directamente o dentro de un sistema externo auxiliar, la primera sección debe seguir el formato `Nombre Producto - Nombre API vMayor.Menor.Parche`. No debe contener espacios antes de la primera letra. El producto y la API deben tener nombres reales, funcionales, específicos, no genéricos, diferentes de textos de plantilla y escritos en inglés. Cada palabra significativa debe iniciar en mayúscula; los artículos, preposiciones y conjunciones pueden permanecer en minúscula cuando la nomenclatura inglesa lo permita. Debe existir un único guion estructural entre el nombre del producto y el nombre de la API, sin evaluar la cantidad de espacios a su alrededor. La versión debe iniciar con `v` o `V` y contener exactamente tres segmentos numéricos: Mayor mayor o igual que 1, Menor mayor o igual que 0 y Parche mayor o igual que 0.

Para una API ubicada en SISTEMAS EXTERNOS, directamente o dentro de un sistema externo auxiliar, solo se exige que la primera sección contenga un nombre real, funcional, específico, no genérico y diferente de un texto de plantilla. No se evalúan el formato corporativo, el idioma, la capitalización ni la versión. La restricción de ubicación de los auxiliares identificados como EVC, EPC o LDC se evalúa mediante EXT-002.

**Evidencia mínima:** Clasificación certificada del componente como API, texto completo de la primera sección y dominio arquitectónico certificado. Para las API ubicadas en INTEGRACIÓN se requieren el nombre del producto, el nombre de la API, el separador estructural y la versión. Los espacios repetidos y situados en los extremos se normalizan, excepto los espacios anteriores a la primera letra, que constituyen incumplimiento. Los guiones propios de nombres o marcas no se consideran automáticamente separadores estructurales. El idioma no se determina únicamente por siglas, marcas, nombres propios, términos técnicos ni palabras compartidas por varios idiomas.

- **Cumple:** La clasificación y ubicación de la API están certificadas y la primera sección satisface todas las condiciones aplicables. En INTEGRACIÓN cumple el formato completo, y en SISTEMAS EXTERNOS contiene un nombre real, funcional, específico, no genérico y diferente de un texto de plantilla.

- **No cumple:** La clasificación, ubicación y primera sección están certificadas, y se incumple al menos una condición aplicable. En INTEGRACIÓN esto incluye espacios antes de la primera letra, estructura u orden incorrectos, nombre genérico o de plantilla, separador estructural inválido, capitalización incorrecta, idioma diferente del inglés o versión ausente o inválida. En SISTEMAS EXTERNOS esto incluye un nombre ausente, genérico, no funcional o correspondiente a un texto de plantilla.

- **No verificable:** No puede certificarse si el componente es una API; no puede determinarse si está ubicado en INTEGRACIÓN o SISTEMAS EXTERNOS; la primera sección está incompleta; no puede distinguirse el guion estructural de los guiones propios de los nombres; o no puede verificarse razonablemente alguna condición aplicable. Si existe al menos un incumplimiento certificado, prevalece **No cumple** aunque otra condición sea no verificable.

- **No aplica:** La página no contiene API certificadas ni componentes candidatos cuya clasificación como API esté pendiente.

### API-002 - Operación de API

**Resumen oficial:** Valida la operación declarada en la segunda sección de una API según el dominio arquitectónico en el que se encuentre.

**Aplica a:** Todas las API principales e invocadas con tipo arquitectónico certificado. Cada API de ambos roles se incluye individualmente en la población.

**Criterio:** Para una API ubicada en INTEGRACIÓN, directamente o dentro de un sistema externo auxiliar, la segunda sección debe contener únicamente el nombre de la operación expuesta por la API. La operación debe estar escrita en inglés y en formato `camelCase`: debe comenzar con una letra minúscula, contener únicamente letras y números, no incluir espacios, guiones ni guiones bajos, y utilizar una letra mayúscula inicial para cada palabra posterior a la primera cuando el nombre tenga varias palabras.

Para una API ubicada en SISTEMAS EXTERNOS, directamente o dentro de un sistema externo auxiliar, no se exige el idioma inglés ni el formato `camelCase`; la segunda sección debe contener una operación funcional, específica, no genérica y diferente de un texto de plantilla. La presencia de EVC, EPC o LDC en el nombre del auxiliar no modifica la modalidad de nombramiento de la operación; la restricción de ubicación del auxiliar se evalúa mediante EXT-002.

**Evidencia mínima:** Clasificación certificada del componente como API, dominio arquitectónico certificado y texto completo de la segunda sección. Para las API ubicadas en INTEGRACIÓN, el texto debe permitir comprobar que existe una única operación, que está escrita en inglés y que cumple el formato `camelCase`. Para las API ubicadas en SISTEMAS EXTERNOS, el texto debe permitir comprobar que la operación es funcional, específica, no genérica y diferente de un texto de plantilla. La operación no debe deducirse a partir del nombre de la API ni de otra sección.

- **Cumple:** La clasificación y ubicación de la API están certificadas y la segunda sección satisface todas las condiciones aplicables. En INTEGRACIÓN contiene únicamente una operación en inglés y en formato `camelCase`. En SISTEMAS EXTERNOS contiene una operación funcional, específica, no genérica y diferente de un texto de plantilla.

- **No cumple:** La clasificación, ubicación y segunda sección están certificadas y se incumple al menos una condición aplicable. En INTEGRACIÓN esto incluye una operación ausente, genérica, de plantilla, escrita en un idioma diferente del inglés, fuera del formato `camelCase`, acompañada de texto adicional o con más de una operación. En SISTEMAS EXTERNOS esto incluye una operación ausente, genérica, no funcional o correspondiente a un texto de plantilla.

- **No verificable:** No puede certificarse si el componente es una API; no puede determinarse si está ubicado en INTEGRACIÓN o SISTEMAS EXTERNOS; la segunda sección está ausente o incompleta por falta de evidencia; no puede verificarse razonablemente el idioma cuando se exige la validación rigurosa; o cualquier ambigüedad impide determinar si el texto corresponde exactamente a una operación válida. Si existe al menos un incumplimiento certificado, prevalece **No cumple** aunque otra condición sea no verificable.

- **No aplica:** La página no contiene API certificadas ni componentes candidatos cuya clasificación como API esté pendiente.

### API-003 - Tipo y modelo de servicio de API

**Resumen oficial:** Valida el tipo de API y el modelo de servicio declarados en la tercera sección, según el dominio arquitectónico en el que se encuentre la API.

**Aplica a:** Todas las API principales e invocadas con tipo arquitectónico certificado. Cada API de ambos roles se incluye individualmente en la población.

**Criterio:** Para una API ubicada en INTEGRACIÓN, directamente o dentro de un sistema externo auxiliar, la tercera sección debe seguir la estructura `tipo - modelo de servicio`. El valor anterior al guion debe ser exactamente `private`, `public` o `partner`, y el valor posterior debe ser exactamente `entidad`, `utilidad` o `tarea`. Ambos valores deben estar completamente en minúsculas y separados por un único guion estructural. No se admiten abreviaturas, traducciones, mayúsculas ni valores diferentes.

Para una API ubicada en SISTEMAS EXTERNOS, directamente o dentro de un sistema externo auxiliar, no se exige la estructura corporativa, los tipos ni los modelos del catálogo. La tercera sección debe contener información funcional, específica, no genérica y diferente de un texto de plantilla. La presencia de EVC, EPC o LDC en el nombre del auxiliar no modifica esta modalidad; la restricción de ubicación del auxiliar se evalúa mediante EXT-002.

**Evidencia mínima:** Clasificación certificada del componente como API, dominio arquitectónico certificado y texto completo de la tercera sección. Antes de evaluar, se eliminan los espacios iniciales y finales y se normalizan los espacios repetidos como un solo espacio. No se evalúa la cantidad de espacios antes o después del guion. Para las API ubicadas en INTEGRACIÓN debe ser posible identificar inequívocamente el tipo, el guion estructural y el modelo de servicio. Una exposición declarada por el analista puede utilizarse en API-004, pero no sustituye el tipo que debe estar escrito en la tercera sección para API-003.

- **Cumple:** La clasificación y ubicación de la API están certificadas y la tercera sección satisface todas las condiciones aplicables. En INTEGRACIÓN presenta exactamente un tipo permitido y un modelo de servicio permitido, en minúsculas y separados por un único guion estructural. En SISTEMAS EXTERNOS contiene información funcional, específica, no genérica y diferente de un texto de plantilla.

- **No cumple:** La clasificación, ubicación y tercera sección están certificadas y se incumple al menos una condición aplicable. En INTEGRACIÓN esto incluye la ausencia del tipo, del modelo de servicio o del guion estructural; un valor fuera de los catálogos permitidos; el uso de mayúsculas, abreviaturas o traducciones; un orden incorrecto; o más de un guion estructural. La declaración posterior del tipo por parte del analista no corrige este incumplimiento. En SISTEMAS EXTERNOS esto incluye una sección ausente, genérica, no funcional o correspondiente a un texto de plantilla.

- **No verificable:** No puede certificarse si el componente es una API; no puede determinarse si está ubicado en INTEGRACIÓN o en SISTEMAS EXTERNOS; el texto de la tercera sección no está disponible o está incompleto por falta de evidencia; no puede distinguirse inequívocamente el guion estructural de un guion perteneciente a un valor; o cualquier ambigüedad impide evaluar una condición aplicable. Si la sección está disponible y se certifica que falta el tipo, el modelo o el guion, corresponde **No cumple**, no **No verificable**. Si existe al menos un incumplimiento certificado, prevalece **No cumple** aunque otra condición sea no verificable.

- **No aplica:** La página no contiene API certificadas ni componentes candidatos cuya clasificación como API esté pendiente.

### API-004 - Capa de Despliegue de la API principal

**Resumen oficial:** Valida que la API principal declarada como MCI tenga la capa de despliegue requerido según su tipo de exposición.

**Aplica a:** API principal con tipo arquitectónico y rol certificados, declarada como MCI.

**Criterio:** Cuando la API principal está declarada como MCI, la capa de despliegue exigido depende de su tipo de exposición: una API `private` debe tener asociadas una Capa de Arquitectura y un Flujo Transaccional; una API `partner` debe tener asociada una Capa de Arquitectura y no requiere Flujo Transaccional; una API `public` no requiere Capa de Arquitectura ni Flujo Transaccional. Las asociaciones requeridas deben pertenecer inequívocamente a la API principal y no pueden establecerse únicamente por cercanía, alineación, superposición o ubicación dentro del mismo contenedor.

Cuando la API principal está declarada como no MCI, no se exige Capa de Arquitectura, Flujo Transaccional ni la declaración `Federado`. Las API invocadas se excluyen de esta regla, independientemente de su condición MCI o de los elementos de despliegue que presenten.

**Precedencia de asociaciones:** aplicar `00-procedimiento.md` §4.1. Una asociación pendiente, ambigua, en conflicto o con `associatedComponentId: null` es candidata y no demuestra ausencia. Un arreglo vacío en `components[].deploymentAssociations` tampoco demuestra ausencia si `pages[].deploymentAssociations` contiene pares Capa-Flujo pendientes de propietario. Una asociación resuelta con otro componente no demuestra por sí sola que la API principal carezca de despliegue.

**Evidencia mínima:** Identificación certificada de la API principal, tipo de exposición obtenido de la tercera sección o declarado por la analista, condición MCI o no MCI declarada por la analista y asociaciones estructurales suficientes para determinar si la Capa de Arquitectura y el Flujo Transaccional requeridos pertenecen a la API principal. La declaración de la analista determina la exposición o condición MCI cuando corresponda, pero no sustituye la evidencia de asociación de la Capa o del Flujo.

- **Cumple:** La API principal está declarada como MCI, su tipo de exposición está determinado y presenta todo la capa de despliegue exigido: Capa de Arquitectura y Flujo Transaccional para `private`, o Capa de Arquitectura para `partner`. Una API `public` cumple sin necesidad de Capa ni Flujo.

- **No cumple:** La API principal está declarada como MCI, su tipo de exposición y las asociaciones de despliegue están suficientemente certificadas, no existen asociaciones candidatas pendientes que puedan pertenecerle, y falta al menos uno de los elementos obligatorios según su exposición: Capa o Flujo para `private`, o Capa para `partner`.

- **No verificable:** No puede certificarse cuál es la API principal; falta la declaración de su condición MCI cuando esta cambia la aplicabilidad; no puede determinarse su tipo de exposición mediante la tercera sección ni mediante una declaración de la analista; o existe una Capa o un Flujo candidato, pero no puede certificarse que esté asociado a la API principal; la cobertura de las asociaciones es insuficiente. La presencia visual, cercanía o pertenencia al mismo contenedor no constituye evidencia suficiente de asociación.

- **No aplica:** La API principal está declarada como no MCI; el componente corresponde a una API invocada; o la página no contiene una API principal ni candidatos pendientes de identificación para ese rol.

### SRV-001 - Nombramiento del servicio invocado

**Resumen oficial:** Valida que la primera sección de un servicio invocado contenga un nombre diferente de un texto de plantilla y, cuando tenga asociada una Capa de Despliegue, que esté escrito en inglés.

**Aplica a:** Componentes certificados como servicios invocados.

**Criterio:** La primera sección debe contener un nombre visible y diferente de un texto de plantilla. No se exige versión, prefijo, formato, separador, capitalización ni estructura particular.

Cuando el servicio invocado tenga asociada inequívocamente una Capa de Despliegue MCI o Federada, su nombre debe estar escrito en inglés. Cuando se certifique que el servicio no tiene una Capa de Despliegue asociada, el nombre puede estar escrito en inglés o en español.

La asociación con una Capa de Despliegue no puede establecerse únicamente por cercanía, alineación, superposición o pertenencia al mismo contenedor. El nombre no permite por sí solo clasificar el componente como servicio invocado.

**Evidencia mínima:** Clasificación certificada del componente como servicio invocado, texto completo de la primera sección y evidencia estructural suficiente para determinar si tiene asociada una Capa de Despliegue MCI o Federada. Cuando exista una Capa de Despliegue asociada, el texto debe permitir verificar razonablemente que el nombre está escrito en inglés.

No se debe determinar el idioma únicamente a partir de siglas, marcas, nombres propios, términos técnicos o palabras que sean iguales en inglés y español.

- **Cumple:** El componente está certificado como servicio invocado, la primera sección contiene un nombre visible diferente de un texto de plantilla y se satisface la condición aplicable: si tiene una Capa de Despliegue asociada, el nombre está escrito en inglés; si no tiene una Capa de Despliegue asociada, el nombre está escrito en inglés o en español.

- **No cumple:** El componente está certificado como servicio invocado y la primera sección está disponible y completa, pero el nombre está ausente, vacío, compuesto únicamente por espacios o corresponde a un texto de plantilla. También corresponde este estado cuando el servicio tiene asociada inequívocamente una Capa de Despliegue MCI o Federada y su nombre está escrito en un idioma diferente del inglés.

- **No verificable:** No puede determinarse si el componente es una API o un servicio invocado; no puede certificarse su rol como invocado; la primera sección no está disponible o está incompleta por pérdida de evidencia; existe una Capa de Despliegue candidata, pero no puede demostrarse si pertenece al servicio; o se exige inglés y no puede determinarse razonablemente el idioma del nombre. Si existe al menos un incumplimiento certificado, prevalece **No cumple** aunque otro servicio sea no verificable.

- **No aplica:** La página no contiene servicios invocados certificados ni componentes candidatos cuya clasificación como servicio invocado esté pendiente. El hijo principal no hace aplicable esta regla.

### SRV-002 - Operación del servicio invocado

**Resumen oficial:** Valida que la segunda sección de un servicio invocado contenga una operación funcional y específica y, cuando el servicio tenga asociada una Capa de Despliegue, que esté escrita en inglés y en formato `camelCase`.

**Aplica a:** Componentes certificados como servicios invocados.

**Criterio:** La segunda sección debe contener únicamente el nombre de la operación ejecutada por el servicio. La operación debe ser funcional, específica, no genérica y diferente de un texto de plantilla.

Cuando el servicio invocado tenga asociada inequívocamente una Capa de Despliegue MCI o Federada, la operación debe estar escrita en inglés y en formato `camelCase`: debe comenzar con una letra minúscula, contener únicamente letras y números, no incluir espacios, guiones ni guiones bajos, y utilizar una letra mayúscula inicial para cada palabra posterior a la primera cuando el nombre tenga varias palabras.

Cuando se certifique que el servicio invocado no tiene una Capa de Despliegue asociada, la operación puede estar escrita en inglés o en español y no se exige el formato `camelCase`. En todos los casos debe contener una operación funcional, específica y diferente de un texto genérico o de plantilla.

La asociación con una Capa de Despliegue no puede establecerse únicamente por cercanía, alineación, superposición o pertenencia al mismo contenedor. La operación no debe deducirse a partir del nombre del servicio, de su modelo ni de otra sección.

**Evidencia mínima:** Clasificación certificada del componente como servicio invocado, texto completo de la segunda sección y evidencia estructural suficiente para determinar si tiene asociada una Capa de Despliegue MCI o Federada. Cuando exista una Capa de Despliegue asociada, el texto debe permitir comprobar que la operación está escrita en inglés y cumple el formato `camelCase`.

El idioma no debe determinarse únicamente a partir de siglas, marcas, nombres propios, términos técnicos o palabras que sean iguales en inglés y español.

- **Cumple:** El componente está certificado como servicio invocado, la segunda sección contiene únicamente una operación funcional, específica, no genérica y diferente de un texto de plantilla, y se satisface la condición aplicable: si tiene asociada una Capa de Despliegue, la operación está escrita en inglés y en formato `camelCase`; si no tiene Capa de Despliegue asociada, la operación está escrita en inglés o en español y no está sujeta al formato `camelCase`.

- **No cumple:** El componente está certificado como servicio invocado y la segunda sección está disponible y completa, pero la operación está ausente, es genérica, no es funcional, corresponde a un texto de plantilla, contiene más de una operación o incluye texto adicional que impide reconocer una única operación. También corresponde este estado cuando el servicio tiene asociada inequívocamente una Capa de Despliegue MCI o Federada y la operación está escrita en un idioma diferente del inglés o no cumple el formato `camelCase`.

- **No verificable:** No puede determinarse si el componente es una API o un servicio invocado; no puede certificarse su rol como invocado; la segunda sección no está disponible o está incompleta por pérdida de evidencia; existe una Capa de Despliegue candidata, pero no puede demostrarse si pertenece al servicio; se exige la validación rigurosa y no puede determinarse razonablemente el idioma; o existe una ambigüedad que impide establecer si el texto corresponde exactamente a una operación válida. Si existe al menos un incumplimiento certificado, prevalece **No cumple** aunque otro servicio o condición sea no verificable.

- **No aplica:** La página no contiene servicios invocados certificados ni componentes candidatos cuya clasificación como servicio invocado esté pendiente. El hijo principal no hace aplicable esta regla.

### SRV-003 - Modelo del servicio invocado

**Resumen oficial:** Valida que la tercera sección de un servicio invocado declare un modelo de servicio permitido.

**Aplica a:** Componentes certificados como servicios invocados.

**Criterio:** La tercera sección debe declarar obligatoriamente un único modelo de servicio: `entidad`, `utilidad` o `tarea`. Se aceptan diferencias de mayúsculas y minúsculas. No se admiten traducciones, abreviaturas, valores distintos de los permitidos, textos genéricos, textos de plantilla ni información adicional que impida reconocer un único modelo.

La regla se aplica exclusivamente a servicios invocados. El hijo principal representa el servicio principal del escenario y no se evalúa mediante esta regla. La presencia de las palabras `entidad`, `utilidad` o `tarea` no demuestra por sí sola que el componente sea un servicio; su clasificación como servicio invocado debe estar certificada.

**Evidencia mínima:** Clasificación certificada del componente como servicio invocado y texto completo de su tercera sección. Antes de evaluar, se eliminan los espacios iniciales y finales. La evidencia debe permitir reconocer inequívocamente un único modelo perteneciente al catálogo permitido.

- **Cumple:** El componente está certificado como servicio invocado y su tercera sección declara exactamente uno de los modelos permitidos: `entidad`, `utilidad` o `tarea`, independientemente del uso de mayúsculas o minúsculas.

- **No cumple:** El componente está certificado como servicio invocado y la tercera sección está disponible y completa, pero se presenta al menos una de las siguientes situaciones: el modelo está ausente; el valor es diferente de `entidad`, `utilidad` o `tarea`; se utiliza una traducción o abreviatura; se declara más de un modelo; el texto es genérico o de plantilla; o se incluye información adicional que impide reconocer un único modelo permitido.

- **No verificable:** No puede determinarse si el componente es una API o un servicio invocado; no puede certificarse su rol como invocado; la tercera sección no está disponible o está incompleta por pérdida de evidencia; o existe una ambigüedad que impide determinar el modelo declarado. Las palabras `entidad`, `utilidad` o `tarea`, sin evidencia arquitectónica adicional, no permiten clasificar el componente como servicio. Si existe al menos un incumplimiento certificado, prevalece **No cumple** aunque otro servicio o condición sea no verificable.

- **No aplica:** La página no contiene servicios invocados certificados ni componentes candidatos cuya clasificación como servicio invocado esté pendiente. El hijo principal no hace aplicable esta regla.

### SRV-004 - Detalle de despliegue del servicio principal

**Resumen oficial:** Valida que el servicio principal representado por el contenedor hijo tenga asociados una Capa de Arquitectura y un Flujo Transaccional cuando corresponda a los escenarios E1 o E2 y esté declarado como MCI.

**Aplica a:** Contenedor hijo principal de los escenarios E1 y E2, entendido como representación del servicio principal del escenario.

**Criterio:** En los escenarios E1 y E2, cuando el contenedor hijo principal esté declarado como MCI, debe tener asociados una Capa de Arquitectura y un Flujo Transaccional. Ambas figuras deben pertenecer inequívocamente al hijo principal; la asociación no puede establecerse únicamente por cercanía, alineación, superposición o ubicación dentro del mismo contenedor.

Cuando el hijo principal esté declarado como no MCI, no se exigen Capa de Arquitectura, Flujo Transaccional ni la declaración `Federado`. En el escenario E3 no se evalúa la capa de despliegue del hijo principal mediante esta regla. Para esta evaluación, el hijo principal representa el servicio principal del escenario y no se requiere que el JSON lo clasifique adicionalmente como servicio principal. El nombramiento de las figuras existentes se evalúa mediante CA-001 y FT-001.

**Precedencia de asociaciones:** aplicar `00-procedimiento.md` §4.1. Una asociación pendiente, ambigua, en conflicto o con `associatedComponentId: null` es candidata y no demuestra ausencia. Un arreglo vacío en `components[].deploymentAssociations` tampoco demuestra ausencia si `pages[].deploymentAssociations` contiene pares Capa-Flujo pendientes de propietario. Una asociación resuelta con otro componente no demuestra por sí sola que el hijo principal carezca de despliegue.

**Evidencia mínima:** Patrón estructural E1 o E2 determinado, identificación certificada de un único contenedor hijo principal, condición MCI o no MCI declarada por la analista y evidencia estructural suficiente para demostrar la asociación del hijo con una Capa de Arquitectura y un Flujo Transaccional. La declaración MCI determina la aplicabilidad de la obligación, pero no demuestra por sí misma la existencia ni la asociación de las figuras de despliegue.

- **Cumple:** El patrón estructural aplicable es E1 o E2, el hijo principal está declarado como MCI y tiene asociados inequívocamente una Capa de Arquitectura y un Flujo Transaccional.

- **No cumple:** El patrón estructural aplicable es E1 o E2, el hijo principal está declarado como MCI, la cobertura de las figuras de despliegue y sus asociaciones está certificada, no existen asociaciones candidatas pendientes que puedan pertenecerle, y falta la Capa de Arquitectura, el Flujo Transaccional o ambos.

- **No verificable:** No puede determinarse el patrón estructural E1 o E2; no puede identificarse inequívocamente un único contenedor hijo principal; falta la declaración de su condición MCI; la cobertura de las figuras de despliegue es insuficiente; o existen una Capa de Arquitectura o un Flujo Transaccional candidatos, pero no puede demostrarse que pertenezcan al hijo principal. La cercanía, alineación, superposición o ubicación dentro del mismo contenedor no constituyen evidencia suficiente de asociación.

- **No aplica:** El hijo principal de E1 o E2 está declarado como no MCI; el patrón estructural aplicable es E3; o la página no contiene un hijo principal ni candidatos pendientes de identificación para ese rol.
