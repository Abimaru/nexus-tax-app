## MANIFEST - validar-blueprint-integracion

Versión v11.3.0. El catálogo vigente conserva **37 reglas activas y únicas**, incluidas SRV-001 y SRV-002 con su texto definitivo.

### Inventario oficial

Total: **37 reglas activas y únicas**.

| Familia | Cantidad | IDs |
|---|---:|---|
| CNT | 5 | CNT-001, CNT-002, CNT-003, CNT-004, CNT-005 |
| EXT | 2 | EXT-001, EXT-002 |
| GW | 1 | GW-001 |
| API | 4 | API-001, API-002, API-003, API-004 |
| SRV | 4 | SRV-001, SRV-002, SRV-003, SRV-004 |
| EVT | 7 | EVT-001, EVT-002, EVT-003, EVT-004, EVT-005, EVT-006, EVT-007 |
| CA | 1 | CA-001 |
| FT | 1 | FT-001 |
| E1 | 1 | E1-001 |
| E2 | 1 | E2-001 |
| E3 | 1 | E3-001 |
| MOD | 1 | MOD-001 |
| COM | 5 | COM-001, COM-002, COM-003, COM-004, COM-005 |
| MQ | 3 | MQ-001, MQ-002, MQ-003 |

### Estado de revisión

- Cada página seleccionada y evaluable debe producir exactamente 37 resultados, uno por cada ID activo del presente manifiesto. Una página no evaluable (exclusivamente plantilla o leyenda) se informa con su motivo y sin resultados por regla; una página mixta evalúa solo su contenido operativo.
- Contrato compacto soportado: `copilot-factual-v0.4.6.1`.

### Recursos obligatorios

- `00-procedimiento.md`
- `01-reglas-estructura.md`
- `02-reglas-api-servicios.md`
- `03-reglas-eventos.md`
- `04-reglas-despliegue.md`
- `05-reglas-escenarios.md`
- `06-reglas-modelos-comandos.md`
- `07-reglas-gestores-colas.md`

La `SKILL.md`, el procedimiento y los archivos de reglas deben utilizar los mismos 37 IDs activos y la misma numeración.

### Lenguaje normativo vigente

- `Capa de Despliegue` es el concepto general.
- `Capa de Despliegue MCI` se demuestra mediante los elementos exigidos por la regla aplicable, como Capa de Arquitectura y Flujo Transaccional.
- `Capa de Despliegue Federada` se demuestra mediante el valor literal `Federado`.
- `Capa de Arquitectura` y `Flujo Transaccional` son figuras específicas y no deben utilizarse como sinónimos del concepto general.
- El hijo principal representa el servicio principal del escenario; no se exige una segunda clasificación redundante como servicio principal.

### Respuestas humanas autorizadas

- Pregunta obligatoria cuando la API principal esté identificada: si tiene Capa de Despliegue MCI.
- Pregunta obligatoria en E1 o E2 cuando el hijo principal esté identificado: si tiene Capa de Despliegue MCI.
- Pregunta opcional: exposición `private`, `public` o `partner` de la API principal, únicamente cuando falte y sea necesaria para API-004.
- Toda respuesta se registra como `DECLARADO_POR_ANALISTA`, vinculada a la página y al componente.
- Una respuesta humana puede determinar aplicabilidad cuando la regla lo permita, pero no sustituye texto, contención, conexiones, asociaciones gráficas, tipo arquitectónico ni subtipo BPMN.

### Controles obligatorios del catálogo

- El inventario debe contener exactamente 37 IDs activos y únicos.
- Cada ID activo debe producir exactamente un resultado por página evaluable.
- Estados permitidos: `Cumple`, `No cumple`, `No verificable`, `No aplica`.
- No deben reaparecer IDs retirados ni significados históricos asociados a IDs renumerados.
- Los conteos por familia deben sumar 37.
- Los archivos normativos y la salida del agente deben coincidir con este inventario.

### Verificación final

Antes de publicar una nueva versión: verificar que todos los archivos usen los mismos 37 IDs, estados válidos, referencias cruzadas existentes y conteos por familia que sumen 37.
