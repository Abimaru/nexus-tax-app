# CHANGELOG

## v11.3.0

- Conserva 37 reglas activas y únicas.
- Ajusta MQ-001, EXT-001, EXT-002, CNT-001, CNT-002 y MOD-001.
- Alinea CNT-003, CNT-004 y CNT-005 con auxiliares y gestores de colas.
- Refuerza la cobertura de API principal e invocadas en API-001, API-002 y API-003.
- Añade referencias de coherencia en E1-001, E2-001 y E3-001.
- Mantiene “modelo de entrada” y “modelo de salida”; no crea “modelo de lectura” como categoría.
