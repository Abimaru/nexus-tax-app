## Procedimiento de validación - v11.3.2

### 1. Precedencia de evidencia

- Contrato soportado: `copilot-factual-v0.4.6.1`.
- Priorizar evidencia literal: `components[].textAreas`, `customData`, identificadores y `connections`.
- Tratar `structuralParent`, `containerChainIds`, `rootContainer` y `architecturalDomain` como propiedades diferentes.
- Usar `domainRole`, `possibleDomainRoles`, `inference`, `deploymentAssociations` y `scenario` considerando estado, fuente y conflictos.
- Un campo ausente, `null`, candidato, ambiguo o contradictorio no constituye evidencia positiva.
- El agente no infiere `EXTERNAL_SYSTEM` por descarte. Solo usa el dominio que entrega el JSON con su fuente: el Studio puede asignarlo en E1 y E3 por descarte (`roleSource: E1_ELIMINATION` o `E3_ELIMINATION`, `roleStatus: INFERRED_BY_ELIMINATION`) y ese valor se toma tal como viene, indicando su fuente.
- Una declaración de la analista no sustituye texto, contención, conexiones, asociaciones, tipo arquitectónico ni subtipo BPMN.

### 2. Controles previos de integridad

Antes de evaluar una página, comprobar:

- identificadores únicos;
- referencias a componentes existentes;
- contención sin ciclos;
- coherencia entre padre inmediato y cadena de ancestros;
- participantes existentes en las conexiones;
- conflictos y pérdidas registrados en `issues`.

Las inconsistencias del JSON no son incumplimientos arquitectónicos. Las reglas afectadas quedan `No verificable`.

### 3. Subtipos BPMN

La identificación genérica `BPMNEvent` no certifica el subtipo.

- Inicio: E1-001, E2-001 y E3-001.
- Señal de Envío o Recepción: EVT-007.
- Mensaje: MQ-003.

Si el subtipo requerido no puede certificarse, solo las reglas que dependan de él quedan `No verificable`. No inferirlo por texto, posición, cercanía o ubicación.

### 4. Capa de Despliegue

- MCI se demuestra mediante Capa de Arquitectura y Flujo Transaccional cuando la regla aplicable los exija.
- Federada se demuestra mediante el valor literal `Federado`.
- CA-001 valida únicamente el nombre de las Capas de Arquitectura existentes.
- FT-001 valida únicamente el nombre de los Flujos Transaccionales existentes.
- API-004, SRV-004 y MQ-002 validan obligatoriedad y asociación.
- La asociación no se demuestra por cercanía, alineación, superposición ni pertenencia al mismo contenedor.

#### 4.1 Precedencia de asociaciones de despliegue y de tópicos

Para API-004, SRV-004, MQ-002, EVT-004 y EVT-005 (Capa de Tópicos del evento de integración) revisar conjuntamente:

- `components[].deploymentAssociations` del componente evaluado;
- `pages[].deploymentAssociations` de la página;
- grupos y grupos superiores usados para resolver la asociación;
- estado, propietario, conflictos y candidatos.

Interpretar la evidencia en este orden:

1. Una asociación resuelta con el componente demuestra pertenencia.
2. Una asociación resuelta con otro componente demuestra únicamente la pertenencia a ese otro componente.
3. Una asociación pendiente, ambigua, en conflicto o sin propietario es candidata. Incluye `associatedComponentId: null`, `PENDING_NO_COMMON_SUPERIOR_GROUP` y cualquier estado que no certifique inequívocamente el propietario.
4. La ausencia solo queda certificada cuando la cobertura es completa, no hay asociación resuelta con el componente y tampoco existen candidatos que puedan pertenecerle.

Un arreglo vacío en `components[].deploymentAssociations` no demuestra por sí solo ausencia cuando `pages[].deploymentAssociations` contiene pares Capa-Flujo pendientes de propietario. La imposibilidad de demostrar pertenencia no equivale a demostrar ausencia: la declaración MCI hace aplicable la obligación, pero no demuestra la asociación, y una asociación candidata pendiente conduce a `No verificable`, no a `No cumple`, salvo que otra evidencia independiente certifique el incumplimiento. Debe revisarse la página antes de concluir ausencia a partir del arreglo vacío del componente.

### 5. Preguntas a la analista

Las preguntas autorizadas se realizan una sola vez por página evaluable, en un único bloque, después de identificar los componentes y antes de cerrar las reglas dependientes.

Registrar cada respuesta como `DECLARADO_POR_ANALISTA`, vinculada a página, ID, nombre visible, pregunta y respuesta.

#### 5.1 Preguntas obligatorias

La pregunta es obligatoria: el agente no puede omitirla ni suponer la respuesta. Se hace aunque `scenario.status` sea `HIPOTESIS`, porque `HIPOTESIS` describe el escenario y no impide identificar la API principal ni el hijo principal.

Cuando el JSON entregue una API principal (`architecturalType: API` y `role: PRINCIPAL`), preguntar:

> ¿La API principal “[nombre]” (`[id]`) tiene Capa de Despliegue MCI?

Cuando el JSON entregue un único hijo principal (`architecturalType: SERVICIO_HIJO` y `role: HIJO_PRINCIPAL`) en E1 o E2, preguntar:

> ¿El hijo principal “[nombre]” (`[id]`), que representa el servicio principal del escenario, tiene Capa de Despliegue MCI?

Si no hay API principal o hijo principal (`scenario.status: NO_DETERMINADO` o candidatos ambiguos), no se pregunta por ese componente. No evaluar API-004 ni SRV-004 mientras falte la respuesta: quedan `No verificable` por falta de la declaración MCI.

No preguntar por la condición MCI del componente o servicio principal de E3. Tampoco preguntar por un “servicio principal” adicional cuando corresponde al mismo hijo principal: una sola pregunta por ID.

#### 5.2 Pregunta opcional

Preguntar la exposición `private`, `public` o `partner` de la API principal solo cuando:

- no pueda obtenerse de la tercera sección; y
- sea necesaria para API-004.

#### 5.3 Alcance de las respuestas

Las respuestas pueden determinar aplicabilidad, pero no demuestran existencia ni asociación de Capa, Flujo o `Federado`, ni corrigen API-003 u otra regla textual.

No preguntar por candidatos ambiguos ni usar una respuesta para certificar tipo o rol. No reutilizar una respuesta en otra página sin confirmación explícita.

### 6. Precedencia de conexiones

#### Comandos

Toda conexión con comando se evalúa exclusivamente en:

- comando con API: COM-002;
- comando con servicio: COM-003;
- comando con gestor: COM-004;
- comando con auxiliar sin atribución interna inequívoca: COM-005.

Las API y los servicios encapsulados conservan su tipo funcional: se evalúan en COM-002 o COM-003, respectivamente.

#### Gestores de colas

- comando con gestor: COM-004;
- gestor con gestor: MQ-003;
- servicio con gestor: MQ-003;
- BPMNEvent de tipo Mensaje hacia gestor: MQ-003.

Cada conexión se asigna a una sola regla. Si participante o tipo no puede determinarse, la regla afectada queda `No verificable`.

### 7. Flujo por página

- `OPERATIONAL`: evaluable; produce 37 resultados.
- `MIXED`: evaluable; produce 37 resultados excluyendo `legendShapeIds`.
- `TEMPLATE_OR_LEGEND` y `BDD_OR_REQUIREMENTS`: no evaluable; informar página, tipo y motivo.
- `UNRESOLVED`: no emitir dictamen; informar que la página no pudo clasificarse.

Una página no evaluable no genera resultados por regla (ni 37 filas, ni “No aplica” artificiales), conteos ni porcentaje, y no entra en el consolidado del blueprint.

Inventariar componentes, contenedores, conexiones y conflictos. No usar Entidad, Utilidad, Tarea, Private, Public o Partner como evidencia suficiente de tipo arquitectónico.

Determinar, cuando sea posible, E1, E2 o E3 sin confundir patrón estructural con cumplimiento integral. Evaluar cada regla con evidencia propia. Identificar el hijo principal directamente, sin exigir una clasificación redundante como servicio principal. Las condiciones textuales de API-001, API-002 y API-003 (incluida su aplicación según el dominio de la API) son las que define cada una de esas reglas.

Evaluar una vez cada ID activo del catálogo. Entregar por regla: población, evidencia, estado, justificación y dato pendiente.

### 8. Estados

- **Cumple:** toda la obligación aplicable está demostrada.
- **No cumple:** existe al menos un incumplimiento certificado.
- **No verificable:** falta evidencia para confirmar cumplimiento o demostrar incumplimiento.
- **No aplica:** no existe población ni candidatos, o aplica una exclusión expresa.

Prioridad: `No cumple` por incumplimiento certificado; si no lo hay pero queda una condición sin resolver, `No verificable`; si todo está demostrado, `Cumple`; si no hay población ni candidatos, `No aplica`.

Una ausencia solo produce `No cumple` cuando la cobertura demuestra que el elemento obligatorio realmente no existe. Un candidato pendiente impide declarar `No aplica` y puede impedir declarar `No cumple`, según la regla.

### 9. Escenarios independientes

`CONFIRMADO`, `HIPOTESIS` y `NO_DETERMINADO` describen el escenario, no su cumplimiento. Un escenario no confirmado no convierte automáticamente las demás reglas en `No verificable`. La incertidumbre sobre un dato afecta únicamente las reglas que dependen de él. `PROPOSED_CLOSED_CATALOG` no constituye por sí mismo un estándar corporativo.

CNT-001 y CNT-002 pueden resolverse aunque E1-001, E2-001 o E3-001 queden `No verificable` por falta de subtipo Inicio.

### 10. Métrica

`Cumple / (Cumple + No cumple + No verificable) × 100`

Excluir `No aplica`. Si el denominador es cero, informar “no calculable”. Consolidar sumando evaluaciones regla-página; no promediar porcentajes. Cada página evaluable debe producir exactamente 37 IDs únicos, y el total debe coincidir con los IDs activos del catálogo vigente.
