# Reglas Eventos - v11.3.2

### EVT-001 - Nombramiento y versión del evento de integración

**Resumen oficial:** Valida el nombre y la versión declarados en la primera sección de un evento de integración.

**Aplica a:** Componentes certificados como eventos de integración de tipo Aplicación o Empresarial.

**Criterio:** La primera sección debe seguir el formato `Nombre Producto - Nombre Capacidad_vMayor.Menor.Parche`. El nombre del producto y el nombre de la capacidad deben ser reales, funcionales, específicos, no genéricos, diferentes de textos de plantilla y estar escritos en inglés. Cada palabra significativa debe comenzar con letra mayúscula; los artículos, preposiciones y conjunciones pueden permanecer en minúscula cuando la nomenclatura inglesa lo permita.

Debe existir un único guion con función estructural entre el nombre del producto y el nombre de la capacidad. Los guiones que formen parte legítima de nombres propios, marcas o términos compuestos no se consideran automáticamente separadores estructurales. La versión debe estar precedida por un guion bajo, comenzar con `v` o `V` y contener exactamente tres segmentos numéricos: Mayor mayor o igual que 1, Menor mayor o igual que 0 y Parche mayor o igual que 0.

En la primera sección se permiten letras de la `a` a la `z`, en mayúsculas o minúsculas, números del `0` al `9`, espacios entre palabras, punto, guion bajo y guion. No se admiten otros caracteres especiales. La validación completa se aplica a todo evento de integración certificado, incluso cuando esté encapsulado dentro de un sistema externo auxiliar. La ubicación permitida del evento se evalúa en las reglas de contenedores y sistemas externos auxiliares, y no modifica la evaluación de su nomenclatura.

**Evidencia mínima:** Clasificación certificada del componente como evento de integración de tipo Aplicación o Empresarial y texto completo de la primera sección. La evidencia debe permitir identificar inequívocamente el nombre del producto, el guion estructural, el nombre de la capacidad, el guion bajo y la versión. Antes de evaluar, se eliminan los espacios iniciales y finales y se normalizan los espacios repetidos como un solo espacio. No se evalúa la cantidad de espacios alrededor del guion estructural. El idioma no se determina únicamente por siglas, marcas, nombres propios, términos técnicos ni palabras compartidas por varios idiomas.

- **Cumple:** El componente y su dominio están certificados y se satisfacen las condiciones aplicables. En INTEGRACIÓN o DOMINIO PRODUCTOR cumple todas las condiciones estrictas de estructura, especificidad, idioma, capitalización, caracteres permitidos y versión. En SISTEMAS EXTERNOS contiene un nombre visible, funcional, coherente, no genérico y diferente de un texto de plantilla.

- **No cumple:** La clasificación, el dominio y el texto completo están certificados, y se incumple al menos una condición aplicable. En INTEGRACIÓN o DOMINIO PRODUCTOR esto incluye un nombre ausente, genérico, no funcional o de plantilla; producto o capacidad ausentes o en orden incorrecto; idioma diferente del inglés; capitalización incorrecta; ausencia o invalidez del guion estructural; ausencia del guion bajo anterior a la versión; versión ausente o inválida; o caracteres no permitidos. En SISTEMAS EXTERNOS incluye un nombre ausente, incoherente, genérico, no funcional o de plantilla.

- **No verificable:** No puede certificarse que el componente sea un evento de integración de tipo Aplicación o Empresarial; no puede determinarse si está ubicado en INTEGRACIÓN, DOMINIO PRODUCTOR o SISTEMAS EXTERNOS; la primera sección no está disponible o está incompleta por pérdida de evidencia; no puede distinguirse el guion estructural de los guiones propios de nombres o marcas; no puede verificarse razonablemente el idioma; o cualquier ambigüedad impide evaluar alguna condición aplicable. Si existe al menos un incumplimiento certificado, prevalece **No cumple** aunque otra condición sea no verificable.

- **No aplica:** La página no contiene eventos de integración certificados ni componentes candidatos cuya clasificación como evento de integración esté pendiente.

### EVT-002 - Operación del evento de integración

**Resumen oficial:** Valida la operación declarada en la segunda sección de un evento de integración.

**Aplica a:** Componentes certificados como eventos de integración de tipo Aplicación o Empresarial.

**Criterio:** La segunda sección debe contener únicamente el nombre de la operación del evento de integración. La operación debe estar escrita en inglés y en formato `camelCase`: debe comenzar con una letra minúscula, contener únicamente letras y números, no incluir espacios, guiones ni guiones bajos, y utilizar una letra mayúscula inicial para cada palabra posterior a la primera cuando el nombre tenga varias palabras. La operación debe ser funcional, específica, no genérica y diferente de un texto de plantilla.

La validación completa se aplica a los eventos de integración ubicados en INTEGRACIÓN o DOMINIO PRODUCTOR, estén ubicados directamente en el dominio o encapsulados dentro de un sistema externo auxiliar. Para los eventos ubicados en SISTEMAS EXTERNOS no se exige el idioma inglés ni el formato camelCase; la segunda sección debe contener una operación funcional, coherente, específica, no genérica y diferente de un texto de plantilla. La ubicación permitida del evento se evalúa independientemente mediante las reglas CNT.

**Evidencia mínima:** Clasificación certificada del componente como evento de integración de tipo Aplicación o Empresarial y texto completo de la segunda sección. El texto debe permitir comprobar que contiene únicamente una operación, que está escrita en inglés y que cumple el formato `camelCase`. La operación no debe deducirse a partir del nombre del evento, de su clasificación ni de otra sección.

- **Cumple:** El componente está certificado como evento de integración y la segunda sección contiene únicamente una operación funcional, específica, no genérica, diferente de un texto de plantilla, escrita en inglés y en formato `camelCase`.

- **No cumple:** La clasificación del evento y el texto completo de la segunda sección están certificados, y la operación está ausente, es genérica, no es funcional, corresponde a un texto de plantilla, está escrita en un idioma diferente del inglés, no cumple el formato `camelCase`, contiene caracteres no permitidos, incluye texto adicional o contiene más de una operación.

- **No verificable:** No puede certificarse que el componente sea un evento de integración de tipo Aplicación o Empresarial; la segunda sección no está disponible o está incompleta por pérdida de evidencia; no puede verificarse razonablemente el idioma; o existe una ambigüedad que impide determinar si el texto corresponde exactamente a una operación válida. Si existe al menos un incumplimiento certificado, prevalece **No cumple** aunque otra condición sea no verificable.

- **No aplica:** La página no contiene eventos de integración certificados ni componentes candidatos cuya clasificación como evento de integración esté pendiente.

### EVT-003 - Tipo y clasificación del evento de integración

**Resumen oficial:** Valida el tipo y la clasificación declarados en la tercera sección de un evento de integración.

**Aplica a:** Componentes certificados como eventos de integración.

**Criterio:** La tercera sección debe seguir la estructura `Tipo - Clasificacion`. El valor anterior al guion estructural debe ser exactamente `Aplicacion` o `Empresarial`, y el valor posterior debe ser exactamente `Query`, `Command` o `Event`. Ambos valores deben respetar la capitalización indicada: letra inicial en mayúscula y letras restantes en minúscula. Debe existir un único guion con función estructural entre el tipo y la clasificación. No se admiten traducciones, abreviaturas, tildes, diferencias de mayúsculas o minúsculas ni valores distintos de los catálogos permitidos.

La validación completa se aplica a los eventos de integración ubicados en INTEGRACIÓN o DOMINIO PRODUCTOR, estén ubicados directamente en el dominio o encapsulados dentro de un sistema externo auxiliar. Para los eventos ubicados en SISTEMAS EXTERNOS no se exige la estructura ni los valores estrictos del catálogo; la tercera sección debe contener información funcional, coherente, específica, no genérica y diferente de un texto de plantilla. La ubicación permitida del evento se evalúa independientemente mediante las reglas CNT.

**Evidencia mínima:** Clasificación certificada del componente como evento de integración y texto completo de la tercera sección. Antes de evaluar, se eliminan los espacios iniciales y finales y se normalizan los espacios consecutivos como un solo espacio. Se permite cualquier cantidad de espacios alrededor del guion estructural. La evidencia debe permitir identificar inequívocamente el tipo, el guion estructural y la clasificación.

- **Cumple:** El componente y su dominio están certificados y la tercera sección satisface la modalidad aplicable. En INTEGRACIÓN o DOMINIO PRODUCTOR contiene exactamente un tipo y una clasificación permitidos, en el orden y con la capitalización exigidos, separados por un único guion estructural. En SISTEMAS EXTERNOS contiene información funcional, coherente, específica, no genérica y diferente de un texto de plantilla.

- **No cumple:** La clasificación, el dominio y el texto completo están certificados y se incumple una condición aplicable. En INTEGRACIÓN o DOMINIO PRODUCTOR esto incluye ausencia del tipo, la clasificación o el guion estructural; orden incorrecto; más de un guion estructural; valores fuera del catálogo; traducción, abreviatura o tilde; o capitalización incorrecta. En SISTEMAS EXTERNOS incluye una sección ausente, incoherente, genérica, no funcional o de plantilla.

- **No verificable:** No puede certificarse que el componente sea un evento de integración; no puede determinarse si está ubicado en INTEGRACIÓN, DOMINIO PRODUCTOR o SISTEMAS EXTERNOS; la tercera sección no está disponible o está incompleta por pérdida de evidencia; no puede distinguirse inequívocamente el guion estructural de un guion perteneciente a otro texto; o existe una ambigüedad que impide evaluar alguna condición aplicable. Si la sección está disponible y se certifica que falta el tipo, la clasificación o el guion estructural, corresponde **No cumple**, no **No verificable**. Si existe al menos un incumplimiento certificado, prevalece **No cumple** aunque otra condición sea no verificable.

- **No aplica:** La página no contiene eventos de integración certificados ni componentes candidatos cuya clasificación como evento de integración esté pendiente.

### EVT-004 - Capa de Tópicos del evento de integración

**Resumen oficial:** Valida que cada evento de integración tenga asociada una única Capa de Tópicos.

**Aplica a:** Componentes certificados como eventos de integración.

**Criterio:** Todo evento de integración debe tener asociada exactamente una Capa de Tópicos. El nombre de la Capa de Tópicos no afecta al cumplimiento de esta regla. Tampoco se evalúan aquí la cantidad, los roles, el nombramiento ni las conexiones de los tópicos contenidos.

**Precedencia de asociaciones:** aplicar `00-procedimiento.md` §4.1. Una asociación pendiente, ambigua, en conflicto o sin propietario es candidata y no demuestra ausencia; un arreglo vacío en el componente tampoco la demuestra si la página contiene asociaciones candidatas. Mientras exista una candidata que pueda pertenecer al evento, corresponde **No verificable**, salvo que otra evidencia independiente certifique el incumplimiento.

**Evidencia mínima:** Identificación certificada del evento de integración, inventario completo de las Capas de Tópicos y evidencia estructural suficiente para determinar cuántas están asociadas al evento. La asociación no debe inferirse únicamente por cercanía, alineación, superposición o pertenencia al mismo contenedor.

- **Cumple:** Cada evento de integración certificado tiene asociada inequívocamente una única Capa de Tópicos.

- **No cumple:** La cobertura de las Capas de Tópicos y sus asociaciones está certificada, y al menos un evento de integración no tiene ninguna Capa de Tópicos asociada o tiene más de una.

- **No verificable:** No puede certificarse que el componente sea un evento de integración; el inventario o las asociaciones no tienen cobertura suficiente; existen una o más Capas de Tópicos candidatas, pero no puede demostrarse su asociación con el evento; o la asociación es ambigua, parcial o contradictoria. Si se demuestra la ausencia o multiplicidad de Capas de Tópicos para un evento, prevalece **No cumple**.

- **No aplica:** La página no contiene eventos de integración certificados ni componentes candidatos cuya clasificación como evento de integración esté pendiente.

### EVT-005 - Cantidad y roles de tópicos

**Resumen oficial:** Valida la cantidad y los roles de los tópicos contenidos en la Capa de Tópicos de un evento de integración, según su clasificación.

**Aplica a:** Eventos de integración con clasificación certificada como `Query`, `Command` o `Event` y con una única Capa de Tópicos asociada.

**Criterio:** Los tópicos se identifican por su rol como publicación (`p`) o suscripción (`s`). Un evento clasificado como `Query` debe tener exactamente dos tópicos: uno de publicación y uno de suscripción. Un evento clasificado como `Command` debe tener exactamente uno de estos patrones: un tópico de publicación; un tópico de suscripción; o un tópico de publicación y uno de suscripción. Un evento clasificado como `Event` debe tener exactamente un tópico, que puede ser de publicación o de suscripción. La Capa de Tópicos no puede estar vacía. Esta regla evalúa únicamente la cantidad y los roles; el formato completo del nombre de cada tópico se evalúa mediante EVT-006.

**Precedencia de asociaciones:** aplicar `00-procedimiento.md` §4.1. Una asociación pendiente, ambigua, en conflicto o sin propietario es candidata y no demuestra ausencia; un arreglo vacío en el componente tampoco la demuestra si la página contiene asociaciones candidatas. Mientras exista una candidata que pueda pertenecer al evento, corresponde **No verificable**, salvo que otra evidencia independiente certifique el incumplimiento.

**Evidencia mínima:** Clasificación certificada del evento como `Query`, `Command` o `Event`; asociación certificada con una única Capa de Tópicos; inventario completo de los tópicos contenidos en esa capa; y evidencia suficiente para determinar el rol de cada tópico como publicación (`p`) o suscripción (`s`).

- **Cumple:** La Capa de Tópicos contiene la cantidad y combinación exactas exigidas por la clasificación del evento: un tópico `p` y uno `s` para `Query`; un tópico `p`, un tópico `s`, o uno de cada rol para `Command`; o exactamente un tópico `p` o `s` para `Event`.

- **No cumple:** La clasificación, la asociación con la Capa de Tópicos y la cobertura de sus tópicos están certificadas, y la capa está vacía, falta un rol obligatorio, existe una combinación no permitida, la cantidad no corresponde a la clasificación del evento o hay tópicos adicionales a los admitidos.

- **No verificable:** No puede certificarse la clasificación del evento; no puede demostrarse la asociación con la Capa de Tópicos; el inventario de tópicos no tiene cobertura suficiente; no puede determinarse el rol de al menos un tópico; o el evento tiene más de una Capa de Tópicos y no existe una única capa sobre la cual evaluar la cantidad y los roles. Si se demuestra que la única capa está vacía o existe otro incumplimiento certificado, prevalece **No cumple**.

- **No aplica:** La página no contiene eventos de integración certificados ni candidatos pendientes de clasificación. Si existe un evento de integración, pero no tiene una Capa de Tópicos asociada, la ausencia se evalúa en EVT-004 y EVT-005 queda **No verificable**.

### EVT-006 - Nombramiento de tópicos

**Resumen oficial:** Valida que el nombre de cada tópico asociado a un evento de integración cumpla uno de los patrones permitidos.

**Aplica a:** Tópicos contenidos en la Capa de Tópicos asociada a un evento de integración.

**Criterio:** El nombre de cada tópico debe cumplir exactamente uno de los siguientes patrones: `p.producto.capacidad.vX`, `s.producto.capacidad.vX`, `p.producto.capacidad.codigoAplicacion.vX` o `s.producto.capacidad.codigoAplicacion.vX`. El primer segmento debe ser `p` para publicación o `s` para suscripción. Los segmentos `producto` y `capacidad` son obligatorios, mientras que `codigoAplicacion` es opcional y, cuando exista, debe ubicarse después de `capacidad`. El último segmento debe seguir el formato `vX`, donde `v` es minúscula y `X` es un número entero mayor o igual que 1, sin ceros iniciales.

El nombre completo debe estar escrito en minúsculas. Los segmentos `producto`, `capacidad` y `codigoAplicacion` solo pueden contener letras de la `a` a la `z` y números del `0` al `9`; no pueden contener espacios, guiones, guiones bajos ni otros caracteres especiales. Los segmentos deben estar separados exclusivamente mediante puntos y no pueden estar vacíos.

**Evidencia mínima:** Asociación certificada del tópico con la Capa de Tópicos del evento y texto completo de su nombre. La evidencia debe permitir identificar inequívocamente el rol `p` o `s`, los segmentos obligatorios `producto` y `capacidad`, el segmento opcional `codigoAplicacion` cuando exista y la versión final `vX`.

- **Cumple:** Todos los tópicos evaluados cumplen exactamente uno de los cuatro patrones permitidos, están escritos completamente en minúsculas, contienen los segmentos obligatorios en el orden establecido, utilizan únicamente letras y números dentro de cada segmento y terminan con una versión `vX` cuyo número es mayor o igual que 1 y no contiene ceros iniciales.

- **No cumple:** El inventario y los nombres completos de los tópicos están certificados, y al menos un tópico presenta una de las siguientes situaciones: no cumple ninguno de los patrones permitidos; utiliza un prefijo diferente de `p` o `s`; omite `producto`, `capacidad` o la versión; ubica `codigoAplicacion` en una posición incorrecta; contiene segmentos adicionales o vacíos; utiliza mayúsculas, espacios, guiones, guiones bajos u otros caracteres especiales; no separa los segmentos mediante puntos; utiliza una `V` mayúscula; o declara una versión igual a cero, no numérica o con ceros iniciales.

- **No verificable:** No puede demostrarse la asociación del tópico con la Capa de Tópicos del evento; el nombre del tópico no está disponible o está incompleto por pérdida de evidencia; el inventario de tópicos no tiene cobertura suficiente; o existe una ambigüedad que impide separar o interpretar sus segmentos. Si existe al menos un incumplimiento certificado, prevalece **No cumple** aunque otro tópico sea no verificable.

- **No aplica:** No existen tópicos asociados a eventos de integración ni candidatos pendientes de identificación. Si existe un evento de integración, pero falta su Capa de Tópicos o no puede determinarse su contenido, la regla queda **No verificable**, no **No aplica**.

### EVT-007 - Conexiones del evento de integración

**Resumen oficial:** Valida la existencia, el sentido, las terminaciones y el tipo de `BPMNEvent` de las conexiones asociadas a los tópicos de un evento de integración.

**Aplica a:** Eventos de integración con clasificación certificada y tópicos identificados con rol de publicación (`p`) o suscripción (`s`).

**Criterio:** Cada tópico debe tener una conexión acorde con su rol. Un tópico de publicación (`p`) exige una conexión desde un `BPMNEvent` de tipo Señal de Envío hacia el evento de integración, con `CircleOpen` en el origen y `Generalization` en el destino. Un tópico de suscripción (`s`) exige una conexión desde el evento de integración hacia un `BPMNEvent` de tipo Señal de Recepción, con `CircleOpen` en el origen y `Generalization` en el destino.

Para un evento `Query` deben existir las conexiones correspondientes a los tópicos `p` y `s`. Para un evento `Command` se exigen ambas conexiones cuando tenga tópicos `p` y `s`, o únicamente la conexión correspondiente cuando tenga solo `p` o solo `s`. Para un evento `Event` se exige la conexión correspondiente al único tópico `p` o `s`.

La conexión puede terminar directamente en el evento de integración, en su Capa de Tópicos o en una Capa de Despliegue inequívocamente asociada al evento. Cuando se utilice una capa como extremo, debe demostrarse que pertenece al evento de integración.

**Evidencia mínima:** Clasificación certificada del evento de integración; inventario completo de sus tópicos y roles `p` o `s`; identificación certificada del `BPMNEvent` como Señal de Envío o Señal de Recepción, según corresponda; y conexiones completas con participantes, sentido y terminaciones. Cuando una conexión termine en la Capa de Tópicos o en una Capa de Despliegue, debe estar certificada su asociación con el evento.

- **Cumple:** Para cada tópico existe la conexión exigida por su rol. Los tópicos `p` están relacionados con un `BPMNEvent` de tipo Señal de Envío mediante una conexión dirigida hacia el evento, con `CircleOpen` en el origen y `Generalization` en el destino. Los tópicos `s` están relacionados con un `BPMNEvent` de tipo Señal de Recepción mediante una conexión dirigida desde el evento, con `CircleOpen` en el origen y `Generalization` en el destino. Los extremos alternativos utilizados pertenecen inequívocamente al evento.

- **No cumple:** La clasificación, los roles, el tipo de `BPMNEvent` y la cobertura de las conexiones están certificados, y falta una conexión obligatoria, el sentido no corresponde al rol del tópico, el tipo de `BPMNEvent` es incompatible con dicho rol, las terminaciones son incorrectas o la conexión termina en un componente certificado que no representa ni pertenece al evento de integración.

- **No verificable:** No puede certificarse el tipo del `BPMNEvent` como Señal de Envío o Señal de Recepción; no puede determinarse el rol de un tópico; la clasificación del evento es indeterminada; la dirección, las terminaciones o los participantes de una conexión son ambiguos o contradictorios; la cobertura no permite demostrar su existencia o ausencia; o no puede demostrarse que la capa utilizada como extremo pertenece al evento. La identificación genérica de una figura como `BPMNEvent` no es suficiente para declarar cumplimiento. Si existe al menos un incumplimiento certificado, prevalece **No cumple** aunque otra conexión sea no verificable.

- **No aplica:** La página no contiene eventos de integración certificados ni componentes candidatos cuya clasificación como evento de integración esté pendiente. Si existe un evento, pero faltan la Capa de Tópicos, los tópicos, sus roles o el subtipo de los `BPMNEvent`, la regla queda **No verificable**, no **No aplica**.

