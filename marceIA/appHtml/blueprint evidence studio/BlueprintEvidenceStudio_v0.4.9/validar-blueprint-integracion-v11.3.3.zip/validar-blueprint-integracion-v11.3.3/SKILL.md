---
name: validar-blueprint-integracion
description: Valida por página blueprints de integración con el contrato compacto de Evidence Studio y las 37 reglas activas.
---

# Validador de blueprints de integración

Este archivo ordena el trabajo. Qué se evalúa lo define cada regla; cómo se evalúa lo define `references/00-procedimiento.md`. No resumir ni reformular reglas: citar cada una por ID.

### Lectura previa completa

- `references/MANIFEST.md`
- `references/00-procedimiento.md`
- `references/01-reglas-estructura.md` a `references/07-reglas-gestores-colas.md`

### Pasos

1. Validar contrato, páginas seleccionadas, páginas omitidas e integridad.
2. Clasificar cada página conforme al procedimiento. En páginas `MIXED`, excluir `legendShapeIds`. Una página exclusivamente plantilla, leyenda o de requisitos es no evaluable: se informa con su motivo, sin resultados por regla ni porcentaje.
3. Inventariar componentes y determinar, sin inferencias propias, API principal, hijo principal y patrón E1, E2 o E3.
4. Por página, formular en un único bloque, antes de evaluar las reglas dependientes, estas preguntas autorizadas. Las dos de condición MCI son obligatorias aunque `scenario.status` sea `HIPOTESIS`:
   - condición MCI de la API principal certificada;
   - condición MCI del hijo principal certificado, solo en E1 o E2;
   - exposición de la API principal, solo si falta y es necesaria para API-004.
5. No preguntar por la condición MCI del componente o servicio principal de E3. No duplicar la pregunta de servicio principal cuando el hijo representa ese servicio.
6. Registrar cada respuesta como `DECLARADO_POR_ANALISTA`, vinculada al ID exacto y a la página.
7. Emitir exactamente 37 resultados por página evaluable, uno por ID del manifiesto. Por regla: población, evidencia, estado, justificación y dato pendiente.
8. Aplicar la precedencia de asociaciones de despliegue antes de cerrar API-004, SRV-004 o MQ-002.
9. Calcular la métrica y entregar resumen ejecutivo, recomendaciones y limitaciones.

### Reglas de conducta

- No inventar componentes, dominios, asociaciones, conexiones, roles ni subtipos BPMN.
- Un campo ausente, `null`, candidato, ambiguo o contradictorio no es evidencia positiva.
- No pedir archivos o respuestas ya disponibles.
- Una asociación pendiente produce incertidumbre; no convertirla en ausencia certificada.
- Antes de responder: 37 IDs únicos, solo cuatro estados y suma total igual a 37 por página evaluable.
