## Reglas API y Servicios - v11.3.1

> Se mantienen sin cambio normativo API-001, API-002, API-003, SRV-001, SRV-002 y SRV-003 de v11.3.0. Este archivo actualiza API-004 y SRV-004. Para evitar duplicidad, los criterios generales de evidencia, estados y asociaciones se leen junto con `00-procedimiento.md`.

#### API-004 - Capa de Despliegue de la API principal

**Resumen oficial:** Valida que la API principal declarada como MCI tenga la Capa de Despliegue requerida según su exposición.

**Aplica a:** API principal con `architecturalType: API` y `role: PRINCIPAL`, cuya condición MCI o no MCI haya sido declarada por la analista.

**Criterio:** Si la API principal es MCI:

- `private`: requiere Capa de Arquitectura y Flujo Transaccional;
- `partner`: requiere Capa de Arquitectura;
- `public`: no requiere Capa de Arquitectura ni Flujo Transaccional.

Las asociaciones deben pertenecer inequívocamente a la API. No se demuestran por cercanía, alineación, superposición o mismo contenedor.

Si la API es no MCI, no se exigen Capa, Flujo ni `Federado`. Las API invocadas se excluyen.

La condición MCI se pregunta siempre que la API principal esté certificada. La exposición se obtiene de la tercera sección o, si falta y es necesaria, de una declaración autorizada. Estas declaraciones determinan aplicabilidad, pero no demuestran existencia ni asociación.

Aplicar la precedencia de `00-procedimiento.md`: una asociación pendiente, ambigua o con `associatedComponentId: null` es candidata y no demuestra ausencia. Un arreglo vacío en el componente tampoco demuestra ausencia si la página contiene candidatos.

**Evidencia mínima:** API principal certificada; condición MCI declarada; exposición determinada; inventario completo de Capas, Flujos y asociaciones del componente y de la página; evidencia suficiente de pertenencia o ausencia certificada.

- **Cumple:** La API es MCI, su exposición está determinada y presenta todos los elementos exigidos mediante asociaciones resueltas; o es `public`, que no requiere elementos.
- **No cumple:** La API es MCI, la cobertura es completa, no existen candidatos pendientes y falta un elemento obligatorio para `private` o `partner`.
- **No verificable:** No puede certificarse la API principal; falta la declaración MCI; no puede determinarse la exposición; la cobertura es insuficiente; o existe una asociación candidata cuyo propietario no puede resolverse.
- **No aplica:** La API principal está declarada no MCI; el componente es una API invocada; o no existe API principal ni candidatos pendientes para ese rol.

#### SRV-004 - Detalle de despliegue del servicio principal

**Resumen oficial:** Valida que el servicio principal representado por el hijo tenga Capa de Arquitectura y Flujo Transaccional cuando corresponda a E1 o E2 y esté declarado como MCI.

**Aplica a:** Hijo principal certificado de E1 o E2. El hijo representa el servicio principal; no se exige una clasificación redundante como servicio principal.

**Criterio:** Cuando el hijo principal de E1 o E2 sea MCI, debe tener asociados inequívocamente una Capa de Arquitectura y un Flujo Transaccional. Si es no MCI, no se exigen Capa, Flujo ni `Federado`.

La regla no aplica a E3 y no se pregunta por la condición MCI del componente o servicio principal de E3.

La condición MCI del hijo se pregunta obligatoriamente cuando exista un único hijo principal certificado de E1 o E2. La respuesta determina aplicabilidad, pero no demuestra existencia ni asociación.

Aplicar la precedencia de `00-procedimiento.md`: revisar asociaciones del hijo y de la página. Una asociación pendiente, ambigua, en conflicto o con `associatedComponentId: null` es candidata. Mientras pueda pertenecer al hijo, corresponde `No verificable`, no ausencia certificada. Una asociación resuelta con otro componente no demuestra por sí sola que el hijo carezca de despliegue.

**Evidencia mínima:** Patrón E1 o E2; único hijo principal certificado; condición MCI declarada; inventario completo de Capas, Flujos y asociaciones del componente y de la página; evidencia suficiente de pertenencia o ausencia certificada.

- **Cumple:** El hijo de E1 o E2 es MCI y tiene asociados inequívocamente una Capa de Arquitectura y un Flujo Transaccional.
- **No cumple:** El hijo es MCI, la cobertura es completa, no existen candidatos pendientes y falta la Capa, el Flujo o ambos.
- **No verificable:** No puede determinarse E1/E2 o el hijo; falta la declaración MCI; la cobertura es insuficiente; o existe una asociación candidata cuyo propietario no puede resolverse.
- **No aplica:** El hijo de E1/E2 es no MCI; el patrón es E3; o no existe hijo principal ni candidatos pendientes para ese rol.
