# Reglas Escenarios - v11.3.0

### E1-001 - Estructura integral E1

**Resumen oficial:** Valida que el escenario E1 esté conformado por una API principal ubicada en INTEGRACIÓN, un hijo principal ubicado en el DOMINIO PRODUCTOR y una conexión desde la API hacia el evento BPMN de Inicio del hijo.

**Aplica a:** Páginas evaluables con patrón estructural candidato a E1: API principal que consume el servicio representado por el hijo principal ubicado en el DOMINIO PRODUCTOR.

**Criterio:** CNT-001 valida independientemente la existencia de INTEGRACIÓN y DOMINIO PRODUCTOR. El escenario E1 debe tener una API principal ubicada en INTEGRACIÓN y un único hijo principal ubicado en el DOMINIO PRODUCTOR. La API principal debe estar conectada con un evento BPMN de tipo Inicio perteneciente al hijo principal. La conexión debe dirigirse desde la API hacia el evento de Inicio, con terminación `None` en el extremo de la API y `Arrow` en el extremo del evento.

La identificación genérica de una figura como `BPMNEvent` no permite confirmar que corresponda a un evento de Inicio. Mientras el subtipo Inicio no pueda certificarse, esta regla debe evaluarse como **No verificable**, aunque la ubicación de la API principal y del hijo principal estén correctamente demostradas. Esta incertidumbre no afecta por sí sola los resultados independientes de CNT-001, CNT-002, CNT-003 o CNT-004.

**Evidencia mínima:** Identificación certificada de la API principal, identificación certificada de un único hijo principal, dominio arquitectónico efectivo de ambos componentes, identificación certificada de un evento BPMN de tipo Inicio perteneciente al hijo y conexión completa entre la API y dicho evento, con participantes, sentido y terminaciones verificables. No se debe inferir el subtipo Inicio únicamente por la figura genérica, el texto visible, la posición o la ubicación dentro del hijo.

- **Cumple:** La API principal está ubicada en INTEGRACIÓN; existe un único hijo principal ubicado en el DOMINIO PRODUCTOR; se certifica dentro del hijo un evento BPMN de tipo Inicio; y existe una conexión desde la API hacia dicho evento, con terminación `None` en el extremo de la API y `Arrow` en el extremo del evento.

- **No cumple:** La identidad de los participantes, sus dominios, el subtipo Inicio del evento y la cobertura de la conexión están certificados, y se demuestra al menos una de las siguientes situaciones: la API principal no está ubicada en INTEGRACIÓN; el hijo principal no está ubicado en el DOMINIO PRODUCTOR; la API no está conectada con el evento de Inicio del hijo; la conexión tiene el sentido contrario; o sus terminaciones no corresponden a `None` en la API y `Arrow` en el evento.

- **No verificable:** No puede identificarse inequívocamente la API principal o el hijo principal; no puede certificarse el dominio arquitectónico efectivo de alguno de ellos; el evento está identificado únicamente como `BPMNEvent` y no puede certificarse como evento de Inicio; no puede demostrarse que el evento pertenezca al hijo principal; o la existencia, el sentido, las terminaciones o los participantes de la conexión son insuficientes, ambiguos o contradictorios. Si el único dato pendiente es el subtipo Inicio del `BPMNEvent`, la regla permanece **No verificable**, aunque las demás condiciones estén demostradas.

- **No aplica:** Se certifica que el patrón estructural de la página corresponde a E2 o E3 y no existen candidatos pendientes que puedan configurar un escenario E1. Las páginas exclusivamente de plantilla o leyenda también quedan fuera de la población.

### E2-001 - Estructura integral E2

**Resumen oficial:** Valida que el escenario E2 esté conformado por una API principal y un hijo principal ubicados en INTEGRACIÓN, con una conexión desde la API hacia el evento BPMN de Inicio del hijo.

**Aplica a:** Páginas evaluables con patrón estructural candidato a E2: API principal que consume el servicio representado por el hijo principal ubicado en INTEGRACIÓN.

**Criterio:** CNT-001 valida independientemente la existencia de INTEGRACIÓN y de al menos uno entre DOMINIO PRODUCTOR o SISTEMAS EXTERNOS; esta obligación adicional no se duplica en E2-001. El escenario E2 debe tener una API principal y un hijo principal ubicados en INTEGRACIÓN. La API y el hijo deben ser componentes estructuralmente separados. La API principal debe estar conectada con un evento BPMN de tipo Inicio perteneciente al hijo principal. La conexión debe dirigirse desde la API hacia el evento de Inicio, con terminación `None` en el extremo de la API y `Arrow` en el extremo del evento.

La validación del subtipo Inicio se realiza exclusivamente en esta regla para el escenario E2. La identificación genérica de una figura como `BPMNEvent` no permite confirmar esta condición. Mientras el subtipo Inicio no pueda certificarse, la regla queda **No verificable**, sin afectar por sí sola las reglas independientes de dominios, contenedores o contenido.

**Evidencia mínima:** Identificación certificada de la API principal y del hijo principal, dominio arquitectónico efectivo de ambos componentes, evidencia estructural de que son componentes separados, identificación certificada de un evento BPMN de tipo Inicio perteneciente al hijo y conexión completa entre la API y dicho evento, con participantes, sentido y terminaciones verificables. No se debe inferir el subtipo Inicio únicamente por la figura genérica, el texto visible, la posición o la ubicación dentro del hijo.

- **Cumple:** La API principal y el hijo principal están ubicados en INTEGRACIÓN y son componentes estructuralmente separados; se certifica dentro del hijo un evento BPMN de tipo Inicio; y existe una conexión desde la API hacia dicho evento, con terminación `None` en el extremo de la API y `Arrow` en el extremo del evento.

- **No cumple:** La identidad de los participantes, sus dominios, su separación estructural, el subtipo Inicio y la cobertura de la conexión están certificados, y se demuestra al menos una de las siguientes situaciones: la API principal o el hijo principal no están ubicados en INTEGRACIÓN; la API está contenida dentro del hijo; la API no está conectada con el evento de Inicio del hijo; la conexión tiene el sentido contrario; o sus terminaciones no corresponden a `None` en la API y `Arrow` en el evento.

- **No verificable:** No puede identificarse inequívocamente la API principal o el hijo principal; no puede certificarse el dominio arquitectónico efectivo de alguno de ellos; no puede demostrarse que sean componentes estructuralmente separados; el evento está identificado únicamente como `BPMNEvent` y no puede certificarse como evento de Inicio; no puede demostrarse que el evento pertenezca al hijo principal; o la existencia, el sentido, las terminaciones o los participantes de la conexión son insuficientes, ambiguos o contradictorios. Si el único dato pendiente es el subtipo Inicio del `BPMNEvent`, la regla permanece **No verificable**, aunque las demás condiciones estén demostradas.

- **No aplica:** Se certifica que el patrón estructural de la página corresponde a E1 o E3 y no existen candidatos pendientes que puedan configurar un escenario E2. Las páginas exclusivamente de plantilla o leyenda también quedan fuera de la población.

### E3-001 - Estructura integral E3

**Resumen oficial:** Valida que el escenario E3 esté conformado por un componente principal y un hijo principal ubicados en el DOMINIO PRODUCTOR, con una conexión desde el componente principal hacia el evento BPMN de Inicio del hijo.

**Aplica a:** Páginas evaluables con patrón estructural candidato a E3: componente principal que consume el servicio representado por el hijo principal, ambos ubicados en el DOMINIO PRODUCTOR.

**Criterio:** CNT-001 valida independientemente la existencia del DOMINIO PRODUCTOR. El escenario E3 debe tener un componente principal y un hijo principal ubicados en el mismo DOMINIO PRODUCTOR y estructuralmente separados. El componente principal debe estar conectado con un evento BPMN de tipo Inicio perteneciente al hijo principal. La conexión debe dirigirse desde el componente principal hacia el evento de Inicio, con terminación `None` en el extremo del componente principal y `Arrow` en el extremo del evento.

La validación del subtipo Inicio se realiza exclusivamente en esta regla para el escenario E3. La identificación genérica de una figura como `BPMNEvent` no permite confirmar esta condición. Mientras el subtipo Inicio no pueda certificarse, la regla queda **No verificable**, sin afectar por sí sola las reglas independientes de dominios, contenedores o contenido.

**Evidencia mínima:** Identificación certificada del componente principal y del hijo principal, dominio arquitectónico efectivo de ambos componentes, evidencia estructural de que están ubicados en el mismo DOMINIO PRODUCTOR y son componentes separados, identificación certificada de un evento BPMN de tipo Inicio perteneciente al hijo y conexión completa entre el componente principal y dicho evento, con participantes, sentido y terminaciones verificables. No se debe inferir el subtipo Inicio únicamente por la figura genérica, el texto visible, la posición o la ubicación dentro del hijo.

- **Cumple:** El componente principal y el hijo principal están ubicados en el mismo DOMINIO PRODUCTOR y son componentes estructuralmente separados; se certifica dentro del hijo un evento BPMN de tipo Inicio; y existe una conexión desde el componente principal hacia dicho evento, con terminación `None` en el extremo del componente principal y `Arrow` en el extremo del evento.

- **No cumple:** La identidad de los participantes, sus dominios, su separación estructural, el subtipo Inicio y la cobertura de la conexión están certificados, y se demuestra al menos una de las siguientes situaciones: el componente principal o el hijo principal no están ubicados en el DOMINIO PRODUCTOR; pertenecen a dominios productores diferentes; el componente principal está contenido dentro del hijo; no existe conexión con el evento de Inicio del hijo; la conexión tiene el sentido contrario; o sus terminaciones no corresponden a `None` en el componente principal y `Arrow` en el evento.

- **No verificable:** No puede identificarse inequívocamente el componente principal o el hijo principal; no puede certificarse el dominio arquitectónico efectivo de alguno de ellos; no puede demostrarse que estén ubicados en el mismo DOMINIO PRODUCTOR y sean componentes separados; el evento está identificado únicamente como `BPMNEvent` y no puede certificarse como evento de Inicio; no puede demostrarse que el evento pertenezca al hijo principal; o la existencia, el sentido, las terminaciones o los participantes de la conexión son insuficientes, ambiguos o contradictorios. Si el único dato pendiente es el subtipo Inicio del `BPMNEvent`, la regla permanece **No verificable**, aunque las demás condiciones estén demostradas.

- **No aplica:** Se certifica que el patrón estructural de la página corresponde a E1 o E2 y no existen candidatos pendientes que puedan configurar un escenario E3. Las páginas exclusivamente de plantilla o leyenda también quedan fuera de la población.

