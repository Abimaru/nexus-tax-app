# Instrucciones del agente - validar blueprints v11.3.1

Para la Skill `validar-blueprint-integracion` v11.3.1, catálogo de 37 reglas, y Blueprint Evidence Studio 0.4.8 con contrato `copilot-factual-v0.4.6.1`. Estas instrucciones no definen reglas; las reglas, estados, precedencias y métrica están en la Skill.

## Antes de evaluar

- Usar el JSON compacto `-ENRIQUECIDO.json`. El diagnóstico es opcional.
- Verificar contrato, `pages` y `metadata.selectedPageIds`. Si falta alguno, informar y detenerse.
- Evaluar solo páginas seleccionadas y reconocer `metadata.omittedPages`.
- No pedir archivos, exportaciones ni respuestas ya disponibles.

## Páginas

- `OPERATIONAL` o `MIXED`: exactamente 37 resultados. En `MIXED`, excluir `legendShapeIds`.
- `TEMPLATE_OR_LEGEND` o `BDD_OR_REQUIREMENTS`: informar que no es evaluable, sin filas ni porcentaje.
- `UNRESOLVED`: no emitir dictamen.

## Tipo de componente

- Usar `architecturalType` tal como lo entrega el JSON. No corregirlo ni deducirlo por nombre, color, posición o cercanía.
- `architecturalType: null` significa tipo no determinado.
- `role: INVOCADO` identifica API o servicio invocado; `role: PRINCIPAL`, el componente principal certificado.
- `SERVICIO_HIJO` con `role: HIJO_PRINCIPAL` identifica el hijo principal cuando el escenario lo confirma.
- No elegir entre candidatos con `inference.status: AMBIGUOUS`.
- Los marcadores de API omitidos no son evidencia faltante.

## Cómo conversar

- Nombrar primero el componente y usar el ID para desambiguar.
- Formular en un único bloque por página solo estas preguntas:
  1. si la API principal certificada tiene Capa de Despliegue MCI;
  2. si el hijo principal certificado de E1 o E2 tiene Capa de Despliegue MCI;
  3. si falta y API-004 lo necesita, exposición `private`, `public` o `partner`.
- No preguntar por la condición MCI del componente o servicio principal de E3.
- No preguntar dos veces por servicio principal e hijo cuando son el mismo componente.
- Registrar cada respuesta como `DECLARADO_POR_ANALISTA`, vinculada a página e ID.
- No preguntar por tipo, rol, dominio, asociación, evento o subtipo BPMN.

## Cómo leer despliegue

Antes de cerrar API-004, SRV-004 o MQ-002, revisar asociaciones del componente y de la página.

- Asociación resuelta con el componente: demuestra pertenencia.
- Asociación resuelta con otro componente: solo demuestra pertenencia al otro.
- Asociación pendiente, ambigua, en conflicto o sin propietario: candidata; normalmente produce `No verificable`.
- Ausencia: solo cuando la cobertura es completa y no quedan candidatos.

Un arreglo vacío en el componente no demuestra ausencia si la página presenta asociaciones candidatas. Declarar MCI determina aplicabilidad, no asociación.

## Cómo leer la evidencia

- Padre inmediato, ancestros, raíz y dominio arquitectónico son propiedades distintas.
- `HIPOTESIS` y `CONFIRMADO` describen el escenario, no el cumplimiento.
- Un campo ausente, `null`, candidato, ambiguo o contradictorio no es evidencia positiva.
- La analista no sustituye evidencia estructural. Si contradice el JSON, prevalece el JSON y se informa la diferencia.

## Salida

- Estados: Cumple, No cumple, No verificable y No aplica.
- Métrica: `Cumple / (Cumple + No cumple + No verificable) × 100`.
- Por regla: población, evidencia con página y componente, estado, justificación y dato pendiente.
- Procesar una página a la vez.
- Cerrar con resumen ejecutivo, recomendaciones y componentes de tipo no determinado.
- Verificar 37 IDs únicos y suma de estados igual a 37 por página evaluable.
