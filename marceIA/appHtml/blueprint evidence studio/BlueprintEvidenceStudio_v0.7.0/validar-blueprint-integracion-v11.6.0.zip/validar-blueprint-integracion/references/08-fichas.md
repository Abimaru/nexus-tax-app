## Fichas operativas - v11.6.0

Una ficha dice de dónde sale la población de cada regla. No define la regla: el criterio y los estados están en el archivo de la regla, y la prioridad de estados en el apartado 8 de `00-procedimiento.md`.

### Cómo usar una ficha

1. Toma la población de la clave del inventario que indica la ficha.
2. Comprueba si hay candidatos o pendientes (apartado 8 de `00-procedimiento.md`). Con uno solo en la población, el estado es `No verificable`.
3. Lee la regla en su archivo y decide el estado.
4. Escribe una línea: ID, población (ids), evidencia (ids), estado, justificación y dato pendiente.

### Qué no es población

- Un componente con `architecturalType: null` y sin `possibleTypes` no es candidato ni población.
- Un sistema externo auxiliar no es un dominio SISTEMAS EXTERNOS.
- Un componente no cambia de tipo por su nombre, su posición ni su cercanía.

Las claves `inventory.*` son las de `pages[].inventory`.

### Estructura (01-reglas-estructura.md)

**CNT-001.** Población: `contenedoresPadre` y `scenario`. Pendiente: contenedor sin dominio (`possibleDomainRoles`). INTEGRACIÓN repetido es válido.

**CNT-002.** Población: `serviciosHijo` y el contenedor padre que lo contiene (`contenedores`). Pendiente: `scenario.status: NO_DETERMINADO` o varios hijos candidatos.

**CNT-003.** Población: el contenido de los `contenedores` con `domainRole: INTEGRATION` y, si hay hijo, su contenido. `marcadoresApi` están permitidos. Candidato: `candidatos`.

**CNT-004.** Población: el contenido de los `contenedores` con `domainRole: PRODUCER` y, si hay hijo, su contenido. Candidato: `candidatos`.

**CNT-005.** Población: `contenedoresPadre` con `domainRole: EXTERNAL_SYSTEM` y su contenido directo. Si no hay ninguno ni `possibleDomainRoles` que lo incluya: `No aplica`.

**EXT-001.** Población: `sistemasExternosAuxiliares` y su `contiene` en `contenedores`. Candidato: `candidatos`.

**EXT-002.** Población: `sistemasExternosAuxiliares`; su ubicación está en `parentId` y `domainRole` de `contenedores`.

**GW-001.** Población: `compuertas` y sus líneas en `relaciones` (con su `etiqueta`). Pendiente: conexión pendiente con una compuerta.

### API (02-reglas-api-servicios.md)

**API-001, API-002, API-003.** Población: `apis` (principal e invocadas). El texto está en `components[].textAreas` y el dominio en `domainRole`. Candidato: `candidatos` con `API`.

**API-004.** Población: la API con `role: PRINCIPAL`, solo si se declaró MCI. Asociaciones: `deploymentAssociations`. Pendiente: pareja Capa-Flujo sin propietario.

### Servicios (02-reglas-api-servicios.md)

**SRV-001, SRV-002, SRV-003.** Población: `servicios` (sin `serviciosHijo`). Candidato: `candidatos` con `SERVICIO`.

**SRV-004.** Población: `servicios` ubicados en el nivel padre de INTEGRACIÓN, más el hijo si se declaró. Asociaciones: `deploymentAssociations`. Pendiente: pareja Capa-Flujo sin propietario.

**SRV-005.** Población: parejas de `relaciones` entre un servicio y una API, otro servicio, un auxiliar o un evento. No entran las parejas con comando ni con gestor. Pendiente: `conexionesPendientes` con un servicio.

### Eventos de integración (03-reglas-eventos.md)

**EVT-001, EVT-002, EVT-003, EVT-004.** Población: `eventosIntegracion`. Candidato: `candidatos` con `EVENTO_INTEGRACION`. Asociaciones de EVT-004: `deploymentAssociations`.

**EVT-005, EVT-006.** Población: eventos con una única Capa de Tópicos y los tópicos de esa capa (`contenedores`). Candidato: `candidatos` con `EVENTO_INTEGRACION`.

**EVT-007.** Población: parejas de `relaciones` de los tópicos `p` y `s` con BPMNEvent. Pendiente: `conexionesPendientes` con esos eventos.

### Despliegue (04-reglas-despliegue.md)

**CA-001.** Población: `capas`.

**FT-001.** Población: `flujos`.

### Escenarios (05-reglas-escenarios.md)

**E1-001, E2-001, E3-001.** Población: `scenario` (patrón, `mainComponentId`, `mainChildServiceId`, `event`, `connection`). Solo evalúa la regla del patrón identificado; las otras: `No aplica`. Subtipo Inicio: `scenario.event.subtype`. Pendiente: `scenario.status: NO_DETERMINADO` o `alternativeCandidateIds`.

### Modelos y comandos (06-reglas-modelos-comandos.md)

**MOD-001.** Población: `apis` y `servicios`, cada uno con su `modelAssociation` (`entrada` y `salida`), y los eventos de integración de INTEGRACIÓN. Estados del Studio: `EXPLICIT_GROUP` y `BY_COUNT` = asociado; `MISSING_IN_SCOPE` = falta; `AMBIGUOUS` = pendiente. `modelos` lista cada modelo con su estado.

**COM-001.** Población: `comandos`.

**COM-002.** Población: parejas de `relaciones` entre un comando y una API. Pendiente: `conexionesPendientes` con un comando o una API.

**COM-003.** Población: parejas de `relaciones` entre un comando y un servicio. Pendiente: `conexionesPendientes` con un comando o un servicio.

**COM-004.** Población: parejas de `relaciones` entre un comando y un gestor. Pendiente: `conexionesPendientes` con un gestor o `candidatos` con `GESTOR_COLAS`.

**COM-005.** Población: parejas de `relaciones` entre un comando y un auxiliar sin API ni servicio atribuible. Pendiente: `conexionesPendientes` con un auxiliar.

### Gestores de colas (07-reglas-gestores-colas.md)

**MQ-001.** Población: `gestoresCola` y `candidatos` con `GESTOR_COLAS`.

**MQ-002.** Población: `gestoresCola` ubicados en el nivel padre de INTEGRACIÓN. Asociaciones: `deploymentAssociations`.

**MQ-003.** Población: parejas de `relaciones` con un gestor (servicio, otro gestor o BPMNEvent de tipo Mensaje; no comando). Pendiente: `conexionesPendientes` con un gestor o un servicio.
