> Histórico: consumo medido con Skills de 41 reglas (v11.2.x).

# Telemetría y análisis de consumo — Fase 1.5

Fuente: `qa/runs/fase1-c14/…/telemetry.json` y `qa/runs/fase1-c15/…/telemetry.json` (generados por el controlador a partir de las transcripciones guardadas; sin nuevas llamadas al modelo). Modelo `claude-opus-5-5`, Claude Code 2.1.309.

## 0. Qué representa el costo

El costo es `total_cost_usd` del CLI, calculado a **precios de lista** (`costBasis: "list"`). No es un cargo. El CLI está autenticado con claude.ai, así que el consumo se descuenta de las ventanas de uso del plan (`rate_limit_event`: ventana de 5 horas y semanal) y no de un saldo en USD. En los eventos observados `overageStatus` figura `rejected` con `out_of_credits` e `isUsingOverage: false`, es decir, el CLI no está cobrando por exceso. No existe un dato para convertir USD de lista en porcentaje del plan: **NO DISPONIBLE**. Desde la Fase 1.5 cada turno guarda la instantánea del límite de uso, de modo que la Fase 2 podrá medir cuánto avanza la ventana por ejecución.

Dos precisiones sobre cómo se mide:
- `total_cost_usd` y `duration_api_ms` son **acumulados** por sesión; `usage` es por turno. El informe de la Fase 1 sumó los acumulados y mostró USD 1,42 para c14. El valor correcto es **USD 0,505**.
- Los precios por millón de tokens que uso para repartir el costo (entrada 4; salida 20; lectura de caché 0,20; escritura de caché 1 h 8) son **implícitos**: salen de resolver el costo reportado en 4 turnos y dan valores redondos. No los publica el CLI. Con solo 4 observaciones y 4 incógnitas el ajuste es exacto, no una validación; los valores redondos y `costBasis: list` lo hacen plausible.

## 1. Telemetría por ejecución

| Métrica | c14 (plantilla) | c15 (sin evidencia) |
|---|---:|---:|
| Turnos | 3 | 1 |
| Pasos internos del CLI (`num_turns`, turno 1) | 17 | 17 |
| Tokens de entrada | 12 | 10 |
| Tokens de salida | 7.229 | 13.152 |
| de ellos, razonamiento | 1.270 | 7.279 |
| Salida sin razonamiento | 5.959 | 5.873 |
| Escritura de caché | 42.022 | 36.401 |
| Lectura de caché | 122.129 | 58.589 |
| Tokens totales | 171.392 | 108.152 |
| Costo reportado | USD 0,5052 | USD 0,5660 |
| Duración CLI | 81,4 s | 127,3 s |
| Tamaño del JSON compacto | 7.933 B | 6.418 B |
| Skill instalada / archivos leídos | 56.391 B / 13 (52.067 B) | ídem |
| Páginas / componentes / conexiones | 1 / 4 / 0 | 1 / 3 / 0 |
| Reglas evaluadas | 0 (no evaluable según el criterio nuevo; entregó 41) | 41 |

**NO DISPONIBLE** en estas dos ejecuciones: tiempo de reloj por turno (`wallMs`), uso por llamada a la API (el CLI solo expone la última iteración en `usage.iterations`), tarifas oficiales y consumo del plan. Las ejecuciones nuevas guardan `wallMs`, el uso por mensaje del asistente y la instantánea del límite de uso.

Por turno (c14): turno 1 USD 0,4299 (85,1 %), turno 2 USD 0,0531 (10,5 %), turno 3 USD 0,0223 (4,4 %).

## 2. Respuestas a las preguntas de consumo

| # | Pregunta | Respuesta con datos |
|---|---|---|
| 1 | Costo de iniciar una evaluación | El primer turno concentra 85 % (c14) y 100 % (c15) del costo. Solo la escritura de caché del contexto inicial cuesta USD 0,297 (c14) y 0,291 (c15): 37.128 y 36.401 tokens a USD 8 por millón. Ese contexto es el sistema, la Skill (13 archivos, 52 KB) y el JSON. |
| 2 | Responder MCI / exposición | Con el mismo contexto en caché, cada turno extra cuesta entre USD 0,022 y 0,053 en c14: lectura de unos 39–44 mil tokens (USD 0,008–0,009) más 450–530 tokens de salida y 564–4.330 de escritura. Aquí las respuestas fueron "No dispongo de ese dato"; con respuestas sustantivas es probable que cueste algo más, pero no se midió. |
| 3 | Generar las 41 reglas | Salida del turno 1: 6.252 tokens (USD 0,125) en c14 y 13.152 (USD 0,263) en c15. La salida visible es parecida (7.028 y 8.912 caracteres); la diferencia está casi toda en razonamiento. |
| 4 | Proporción de la salida | c14: 28,6 % del costo total; c15: 46,5 %. |
| 5 | Entrada y caché | La entrada sin caché es ~0 % en ambas. Escritura de caché: 66,5 % (c14) y 51,4 % (c15). Lectura de caché: 4,8 % y 2,1 %. |
| 6 | Uno o varios turnos | En c14, los turnos 2 y 3 sumaron USD 0,0753, el 14,9 % del total. Cada turno adicional re-lee el contexto completo desde caché, por lo que su costo crece con el contexto, no con el trabajo nuevo. |
| 7 | ¿Se recarga la Skill en cada turno? | **No como lectura nueva.** Los turnos 2 y 3 hicieron 0 llamadas a herramientas. La Skill queda en el historial y se vuelve a enviar desde caché (la lectura del turno 2 es 39.430 tokens, casi el contexto del turno 1). Es un cargo por lectura de caché, no por entrada nueva. |
| 8 | ¿La caché reduce el consumo facturable? | Con los precios implícitos, las lecturas de caché de c14 costaron USD 0,024; como entrada sin caché habrían costado USD 0,489 (aritmética, no medición). Pero la escritura de caché (USD 8/M, el doble de la entrada) es lo que más pesa en una sesión corta. No hay forma de medir el escenario "sin caché" con este CLI. |
| 9 | Fijo y variable | **Fijo** (≈ USD 0,29–0,30): escritura del contexto inicial; coincide en c14 y c15 dentro del 2 %. **Variable**: salida (USD 0,13–0,26, sobre todo razonamiento), turnos adicionales (USD 0,02–0,05 cada uno) y, en blueprints reales, el tamaño del JSON. En estos casos sintéticos el JSON mide 6–8 KB y casi no cuenta. |

## 3. Comparación c14 / c15

| Concepto | c14 | c15 | Diferencia c15 − c14 |
|---|---:|---:|---:|
| Costo reportado | USD 0,5052 | USD 0,5660 | **+USD 0,0608** |
| Salida | 7.229 | 13.152 | +5.923 → +USD 0,1185 |
| Escritura de caché | 42.022 | 36.401 | −5.621 → −USD 0,0450 |
| Lectura de caché | 122.129 | 58.589 | −63.540 → −USD 0,0127 |
| Entrada | 12 | 10 | −2 → ≈ 0 |
| Suma de diferencias | | | **+USD 0,0608** (cuadra con lo reportado) |

Qué se puede afirmar:
- Con los precios implícitos, la diferencia se reparte exactamente así. La premisa de la pregunta (USD 1,42 frente a 0,57) venía de mi error de suma. Con el valor correcto, c15 cuesta algo más que c14, no menos.
- La salida **sin razonamiento** es casi igual (5.959 frente a 5.873 tokens). Toda la diferencia de salida es razonamiento: 1.270 frente a 7.279.
- c14 gastó más en escritura y lectura de caché porque tuvo tres turnos; c15, uno.

Qué **no** se puede afirmar: por qué el modelo razonó seis veces más en c15. El CLI no expone la causa; podría ser el contenido de la página (hay que decidir qué es cada figura), el criterio de "No aplica" frente a "No verificable", o variación aleatoria entre ejecuciones. Con una ejecución por caso no se puede separar.

**Qué falta medir:** (1) repeticiones del mismo caso para conocer la variación del razonamiento; (2) uso por llamada a la API; (3) un caso con JSON grande para estimar los bytes por token reales; (4) reutilización de caché entre sesiones (en estas dos ejecuciones, hechas con minutos de diferencia, no se observó: ambas escribieron unos 36–37 mil tokens); (5) las tarifas y el uso de otro modelo; (6) el avance de la ventana del plan por ejecución.

## 4. Proyección presupuestal

Supuestos, todos con precios implícitos de `claude-opus-5-5` a lista:
- Contexto inicial ≈ USD 0,30 por sesión (medido: 0,29–0,30).
- Salida por evaluación de 41 reglas: USD 0,13–0,26 (medido, n = 2).
- Turnos adicionales: USD 0,02–0,05 cada uno (medido, n = 2).
- JSON compacto: escritura de caché a USD 8/M una vez y lectura a USD 0,2/M en cada turno posterior. Bytes por token: con la mezcla Skill + JSON de estas ejecuciones salen como máximo 1,6 bytes por token (cota inferior, incluye sobrecarga de lectura). Para JSON real supongo **entre 1,6 y 3,5 bytes por token (supuesto, sin medir)**.
- Las sesiones no comparten caché entre sí (no se observó).

| Escenario | Estimación | Cómo sale |
|---|---|---|
| Una evaluación, una página, JSON pequeño (≤ 10 KB) | **USD 0,43–0,70** (medido: 0,51 y 0,57) | 0,30 + salida 0,13–0,26 + 0–3 turnos extra |
| Una evaluación, tres páginas pequeñas | **USD 0,9–1,5** | contexto 0,30 + JSON ≈ 0,1 + 3 tablas 0,4–0,8 + 2–4 turnos |
| Una evaluación, una página real (≈ 100 KB de JSON) | USD 0,8–1,3 | contexto 0,30 + JSON 30–65 mil tokens (0,24–0,52) + salida + turnos |
| Una evaluación, tres páginas reales (≈ 400 KB de JSON) | USD 1,8–3,5 | contexto 0,30 + JSON 115–250 mil tokens (0,9–2,0) + 3 tablas + turnos |
| 16 casos × 1 ejecución (sintéticos pequeños) | **USD 7–11**; hasta ≈ 16 si algunos casos llegan a USD 1 | 16 × 0,43–0,70 |
| 16 casos × 3 ejecuciones (48 sesiones) | **USD 21–34**; hasta ≈ 48 | × 3 |
| 16 casos × 2 modelos | Modelo actual: USD 7–11. Segundo modelo: **NO DISPONIBLE** (no se conocen sus tarifas) | Si costara una fracción r del modelo actual: r = 0,2 → +USD 1,4–2,2; r = 0,5 → +3,5–5,6; r = 1 → +7–11 |

Qué significa: son USD **de lista**, no un cargo. Con la autenticación de claude.ai se descuentan del plan por ventanas de uso y no se pueden convertir a esa unidad. No proyecté solo con la salida: el contexto inicial es más de la mitad del costo de una sesión corta.

## 5. Para la Fase 2
- La telemetría nueva (por turno, por llamada y límite de uso) permitirá comprobar estas cifras con datos de 16 casos antes de las repeticiones.
- Recomiendo medir primero 2–3 repeticiones de un solo caso para estimar la variación del razonamiento, que es la parte menos predecible del costo.

---

# Parte 2 — Skill v11.2.2 y medición de tokens (Fase 1.6)

Las secciones 1 a 5 describen las ejecuciones con la Skill v11.2.1 (archivadas en `qa/runs/archive/skill-v11.2.1/`). Esta parte añade las ejecuciones con v11.2.2 y la medición del tamaño en tokens.

## 6. Ejecuciones con la Skill v11.2.2

| Ejecución | Turnos | Entrada | Salida (razonamiento) | Escritura de caché | Lectura de caché | Costo reportado | Duración CLI |
|---|---:|---:|---:|---:|---:|---:|---:|
| c14 (`v1122-c14`) | 1 | 8 | 2.195 (361) | 17.800 | 34.815 | USD 0,1933 | 34,3 s |
| c15 primera pasada (`v1122-c15`) | 2 | 12 | 5.128 (893) | 41.617 | 105.040 | USD 0,4566 | 63,2 s |
| c15 segunda pasada (`v1122-c15-r2`), 2 turnos | 2 | 12 | 5.220 (857) | 35.215 | 91.901 | USD 0,4045 | 59,5 s |
| c15 segunda pasada + turno de confirmación | 3 | 14 | 13.321 (4.912) | 36.174 | 129.418 | USD 0,5818 | 135,0 s |

- c14 pasó de USD 0,505 (v11.2.1, 3 turnos, tabla de 41 filas) a USD 0,193 (v11.2.2, 1 turno): el agente leyó 3 archivos y se detuvo en la clasificación, sin cargar los catálogos de reglas. Es consecuencia del cambio de comportamiento, no una optimización medida de forma aislada.
- El turno de confirmación de c15 (la tabla de 41 reglas) costó USD 0,1772: 8.101 tokens de salida (4.055 de razonamiento) y 961 de escritura de caché; la lectura de caché de ese turno fue unos 37,5 mil tokens.
- Dos pasadas de c15 con la misma Skill dieron USD 0,4566 y 0,4045 en sus dos primeros turnos (diferencia de 11 %), lo que da una primera idea de la variación entre ejecuciones. Con n = 2 no es una estimación estadística.

## 7. Medición del tamaño en tokens

### Qué se midió y qué se estimó
- **Medido** por el CLI: tokens de entrada, salida, razonamiento y caché por turno; ventana de contexto (`contextWindow`: 1.000.000) y salida máxima (`maxOutputTokens`: 128.000) del modelo.
- **Estimado:** el tamaño en tokens de un JSON que no se envió al modelo. No existe un tokenizador público compatible con este modelo, y la API de conteo de tokens requiere una clave que no está disponible. Para no gastar llamadas, calibré los tokens con las ejecuciones ya hechas.

### Calibración (5 ejecuciones, sin llamadas nuevas)
Relación entre los bytes leídos por el agente en el turno 1 (Skill + JSON) y los tokens de escritura de caché de ese turno:

| Ejecución | Bytes leídos | Tokens escritos (turno 1) |
|---|---:|---:|
| v11.2.1 c14 | 60.000 | 37.128 |
| v11.2.1 c15 | 58.485 | 36.401 |
| v11.2.2 c14 | 20.475 | 17.800 |
| v11.2.2 c15, primera pasada | 64.281 | 39.618 |
| v11.2.2 c15, segunda pasada | 48.098 | 33.148 |

Ajuste lineal: **tokens ≈ 8.170 + 0,49 × bytes**, es decir **≈ 2,04 bytes por token**, con un residuo máximo de 1,4 mil tokens (≈ 4 %). El término fijo (≈ 8 mil tokens) agrupa sistema, herramientas, prompt del agente y la salida intermedia del turno.

### Limitaciones de la estimación
1. El rango calibrado es de 20 a 64 KB; los JSON reales de la tabla de abajo (90–584 KB) quedan fuera, es una **extrapolación**.
2. La mezcla calibrada es en su mayoría Markdown en español. Un JSON con identificadores largos (`4Oc~UAg.ChZ2`) suele partir en más tokens por byte. Por eso presento un rango: **3,0 bytes/token (mínimo de tokens), 2,04 (central) y 1,6 (máximo)**. Este último es la cota que sale de la primera medición (≤ 1,62).
3. El conteo es de lo que el agente *lee*; el CLI añade numeración de líneas al leer, que ya está incluida en el ajuste.
4. No se midió el costo de ventanas de contexto largo (precio distinto a partir de cierto tamaño): **NO DISPONIBLE**.

### Tamaño estimado de JSON compactos representativos
Solo tamaños (bytes) de las exportaciones de los ejemplos locales; no se usó su contenido en el simulador. Cada fila es un JSON con las páginas que no son BDD; Evidence Studio preselecciona solo páginas operativas, por lo que en uso normal serían iguales o menores.

| JSON compacto | Bytes | Tokens (central) | Rango de tokens | % de la ventana de 1 M | Escritura única (USD) | Relectura por turno (USD) |
|---|---:|---:|---:|---:|---:|---:|
| 3 pág. / 89 comp. | 89.507 | 43,9 K | 29,8 K – 55,9 K | 4,4 % | 0,35 | 0,009 |
| 1 pág. / 99 comp. | 104.415 | 51,2 K | 34,8 K – 65,3 K | 5,1 % | 0,41 | 0,010 |
| 1 pág. / 126 comp. | 148.980 | 73,0 K | 49,7 K – 93,1 K | 7,3 % | 0,58 | 0,015 |
| 2 pág. / 192 comp. | 195.946 | 96,1 K | 65,3 K – 122,5 K | 9,6 % | 0,77 | 0,019 |
| 4 pág. / 307 comp. | 301.111 | 147,6 K | 100,4 K – 188,2 K | 14,8 % | 1,18 | 0,030 |
| 5 pág. / 349 comp. | 329.532 | 161,5 K | 109,8 K – 206,0 K | 16,2 % | 1,29 | 0,032 |
| 3 pág. / 381 comp. | 405.042 | 198,6 K | 135,0 K – 253,2 K | 19,9 % | 1,59 | 0,040 |
| 4 pág. / 536 comp. | 584.032 | 286,3 K | 194,7 K – 365,0 K | 28,6 % | 2,29 | 0,057 |
| c14 sintético | 7.933 | 3,9 K | — | 0,4 % | 0,03 | 0,001 |
| c15 sintético | 6.418 | 3,1 K | — | 0,3 % | 0,03 | 0,001 |

Regla práctica derivada de las 8 exportaciones: el JSON compacto pesa entre 944 y 1.182 bytes por componente. "Escritura única" y "Relectura por turno" usan los precios implícitos (USD 8 y 0,2 por millón) y el valor central.

### Contexto único frente a tokens acumulados
Son cosas distintas. Con la Skill v11.2.2, segunda pasada de c15 más el turno de confirmación:

| Turno | Contexto al inicio del turno (lectura de caché) | Tokens nuevos (escritura + entrada) | Salida | Tokens procesados en el turno |
|---|---:|---:|---:|---:|
| 1 | — (56.451 leídos en pasos internos) | 33.158 | 4.313 | 93.922 |
| 2 | 35.450 | 2.069 | 907 | 38.426 |
| 3 | 37.517 | 961 | 8.101 | 46.579 |

- **Contexto único** (lo que existe en la conversación): del orden de 35–38 mil tokens al empezar los turnos 2 y 3.
- **Tokens acumulados** (todo lo que se procesó): 178.927 en la ejecución, unas **4,7 veces** el contexto, porque cada turno vuelve a leer el contexto completo desde caché y el turno 1 hace varios pasos internos.
- Una parte pequeña del total se paga a precio completo de entrada: 14 tokens. Lo que más pesa es la escritura inicial de caché, seguida de la salida.
- **NO DISPONIBLE:** el uso por paso interno del turno 1 en las ejecuciones guardadas; la telemetría nueva lo captura a partir de ahora.

### Límite de contexto
El CLI reporta `contextWindow = 1.000.000` y `maxOutputTokens = 128.000` para `claude-opus-5-5`. El JSON compacto más grande de la tabla (584 KB) ocuparía entre 195 mil y 365 mil tokens (rango), es decir, cabe en la ventana, con una holgura estimada de más del 60 %. La salida de una evaluación de 41 reglas (4–13 mil tokens medidos) está muy por debajo del máximo. Esto no mide la calidad de la evaluación con contextos grandes.

## 8. Efecto sobre la proyección
La proyección de la sección 4 sigue vigente, con dos matices medidos con v11.2.2:
- El primer turno ya no fija un piso de USD 0,30 si la página no es evaluable: c14 costó USD 0,19.
- Una página `UNRESOLVED` añade un turno de aclaración antes de evaluar (c15: USD 0,40–0,46 en dos turnos, USD 0,58 con la tabla).

---

# Parte 3 — Piloto de la Fase 2 (Skill v11.2.2, `claude-opus-5-5`)

Costos de **lista** del CLI (no un cargo ni el consumo del plan). Una ejecución real por caso.

## 9. Telemetría por caso

| Métrica | P1 | P2 | P3 | P4 |
|---|---:|---:|---:|---:|
| Turnos | 2 | 2 (1 + `resume`) | 3 | 2 |
| Tokens de entrada | 12 | 12 | 16 | 12 |
| Tokens de salida | 19.190 | 17.965 | 20.377 | 28.433 |
| de ellos, razonamiento | 10.965 (57 %) | 9.970 (55 %) | 10.259 (50 %) | 16.433 (58 %) |
| Escritura de caché | 45.526 | 46.237 | 46.698 | 50.423 |
| Lectura de caché | 110.665 | 118.263 | 175.247 | 123.411 |
| Tokens acumulados (procesados) | 175.393 | 182.477 | 242.338 | 202.279 |
| **Costo de lista** | **USD 0,770** | **USD 0,753** | **USD 0,816** | **USD 0,997** |
| Duración del CLI | 196 s | 181 s | 207 s | 261 s |
| Tiempo de reloj | 200 s | 184 s | 212 s | 264 s |
| JSON compacto | 15.813 B | 16.515 B | 10.039 B | 25.314 B |
| Páginas / componentes / conexiones | 1 / 7 / 1 | 1 / 8 / 2 | 1 / 5 / 1 | 2 / 11 / 2 |
| Skill: archivos leídos / bytes | 13 / 57.863 | 13 / 57.863 | 13 / 57.863 | 13 / 57.863 |
| Reglas evaluadas (suma por página) | 41 | 41 | 41 | 82 |
| Preguntas del agente | 3 | 2 | 1 + 3 | 5 |
| Cambios entre dictamen preliminar y definitivo | 0 (sin dictamen preliminar) | 0 | 0 | 0 |
| Ventana de contexto / salida máxima del modelo (CLI) | 1.000.000 / 128.000 | ídem | ídem | ídem |

Nota: el contador `rulesEvaluated` de la telemetría contaba mal las reglas en casos multipágina (37 en P4, porque colapsaba las reglas repetidas entre páginas). Se corrigió para sumar por página y se regeneró la telemetría de P4 con `reevaluate`, sin llamar al modelo. La comparación entre dictámenes (`changesBetweenVersions`) tampoco distingue páginas: no se ejerció en el piloto, porque no hubo dictámenes preliminares.

Suma de los cuatro casos: USD 3,34 de lista, 802 mil tokens procesados.

## 10. Costo por fase de la conversación

| Fase | P1 | P2 | P3 | P4 |
|---|---:|---:|---:|---:|
| Turno 1: arrancar, leer la Skill y el JSON, preguntar (o suspender) | USD 0,433 | USD 0,447 | USD 0,361 (clasificación) | USD 0,481 |
| Turno de respuestas / tabla de 41 reglas | USD 0,338 | USD 0,306 | USD 0,051 (MCI) + USD 0,404 (tabla) | USD 0,516 |

- **Iniciar:** USD 0,36–0,48; la mitad es escribir en caché el contexto inicial (34–48 mil tokens a USD 8 por millón).
- **Responder las preguntas MCI/exposición:** en P3 el turno de las dos respuestas MCI costó USD 0,051 por sí solo.
- **Generar las 41 reglas:** USD 0,30–0,52 por tabla; 14–24 mil tokens de salida, de los cuales 9–16 mil son razonamiento. Una página adicional (P4) sumó unos USD 0,2 sobre el costo de una sola página, no el doble.
- **Salida frente a entrada y caché:** salida 48–57 % del costo; escritura de caché 41–49 %; lectura de caché 3–4 %; entrada sin caché ≈ 0 %.
- **Uno frente a varios turnos:** los turnos de respuesta cuestan poco cuando son cortos (P3 turno 2: USD 0,051); el costo lo dominan el primer turno y la tabla final.

## 11. Consumo real del plan (lo que sí se mide y lo que no)
Cada evento de límite de uso del CLI expone la utilización de la ventana de 5 horas y la semanal. En los cuatro casos la ventana de 5 horas pasó de 0,34 (final de P1) a 0,45 (P2), 0,48 (P3) y 0,51 (P4), y la semanal de 0,16 a 0,19. **Es una cifra de toda la cuenta**: incluye esta misma conversación de desarrollo y otras sesiones. No se puede atribuir una parte a cada caso, y la resolución de 0,01 es demasiado gruesa para un caso de menos de USD 1. Por eso el consumo real del plan por ejecución queda **NO DISPONIBLE**; solo se sabe que, en conjunto, esta etapa avanzó la ventana de 5 horas unos 0,17 puntos de utilización (incluyendo actividad ajena a los casos).

## 12. Efecto sobre la proyección
Las páginas operativas costaron **USD 0,75–1,00** (P1 a P4), por encima de la estimación anterior para una página (USD 0,43–0,70), porque ahora la tabla de 41 reglas se genera con contenido y razonamiento reales. Una página no evaluable cuesta USD 0,19 (c14). Con esa base: 16 casos con ~12 operativos y ~4 no evaluables, una repetición, USD 9,8–14,4 de lista (supuesto, sin medir); tres repeticiones, unos USD 29–43. El segundo modelo sigue **NO DISPONIBLE**.
