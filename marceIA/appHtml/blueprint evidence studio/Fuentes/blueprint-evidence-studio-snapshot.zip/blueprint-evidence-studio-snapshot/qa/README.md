# Blueprint Evaluation QA

Banco de pruebas independiente. Evalúa la Skill oficial `validar-blueprint-integracion` (ZIP distribuido, sin modificar) con un modelo que solo ve la Skill, un JSON compacto y las respuestas de una analista simulada. **No sustituye la prueba real con Copilot** y no certifica la Skill. Solo casos sintéticos; rama privada; `qa/` nunca se publica (la lista de la rama pública es explícita y no lo incluye).

## Estado actual
- Skill bajo prueba: **v11.2.4** (candidata funcional, no estable; 37 reglas, diez archivos), ZIP fijado en `skill.lock.json`; versiones anteriores archivadas en `skill-locks/`. Contrato: `copilot-factual-v0.4.6.1`. Aún no se ha ejecutado ningún caso real con esta versión.
- Casos vigentes: `c14`, `c15` y el piloto `p1`..`p4`, con prompts y expectativas por regla alineados a 37. Se retiraron las expectativas de reglas eliminadas o con otro significado; se regenerarán a partir de la prueba de la analista. Los casos `v123-*` y las herramientas de comparación de catálogos CSV están en `legacy-41/` (históricos, no se ejecutan).
- Aislamiento: validado para `opus` (probe del 24/10/2026): el entorno, no el modelo, deniega las lecturas fuera del sandbox. Se vuelve a auditar en cada ejecución.
- Pruebas locales: `node qa/controller/selftest.mjs` (CLI simulado, sin modelo).
- Sin batería completa: faltan los 16 casos y las repeticiones; requieren autorización.
- Pendientes normativos: `DECISIONES_PENDIENTES.md` (C14-Q3, C15-Q1, C15-Q2, C15-Q3). El piloto añadió observaciones (O1–O7 en `PILOTO_FASE2.md`) que no se han convertido en decisiones.

## Piezas
| Ruta | Contenido |
|---|---|
| `agent/blueprint-evaluation-qa.md` | Prompt mínimo del evaluador (sin reglas) |
| `controller/run.mjs` | Comandos del controlador |
| `controller/lib/` | ZIP, sandbox, runner, parser, conversación, `drive` (turnos y suspensión), comprobaciones (`checks`, `checks-pilot`), telemetría, `preflight`, informe |
| `controller/selftest.mjs`, `fake-claude.mjs` | Pruebas del controlador con un CLI de pruebas |
| `cases/<caso>/` | `lucid.json` sintético, `compact.json` generado con el HTML distribuido, `case.json` (prompt y guion) |
| `expected/` | Expectativas; solo las lee el controlador después de la ejecución. Cada una lleva un canario |
| `tools/` | Generadores de casos y verificación del ZIP (`verify-skill-zip.mjs`) |
| `legacy-41/` | Casos, herramientas y propuestas de la Skill de 41 reglas (históricos) |
| `skill.lock.json`, `skill-locks/` | Hash fijado de la Skill vigente y archivo de v11.2.1 |
| `runs/` | Resultados (ignorado por Git). `runs/archive/` conserva la Fase 1 |
| `DECISIONES.md`, `DECISIONES_PENDIENTES.md`, `PILOTO_FASE2.md`, `COSTOS.md`, `proposals/` | Decisiones vigentes e históricas, pendientes, resultados del piloto, consumo y propuestas |

## Comandos
```
node qa/controller/selftest.mjs                              # pruebas locales
node qa/controller/run.mjs preflight --model opus            # hash, ZIP, aislamiento, integridad de casos, guiones, canarios
node qa/controller/run.mjs pin                               # fijar el hash de la Skill vigente
node qa/controller/run.mjs probe-isolation --model opus      # probar el aislamiento con una sesión real
node qa/controller/run.mjs run <caso> --model opus           # una ejecución real
node qa/controller/run.mjs resume <run> <caso> --reply "<texto>" [--substantive]   # continuar una sesión (también --topic <tema>)
node qa/controller/run.mjs reevaluate <run> <caso>           # volver a evaluar una transcripción, sin llamar al modelo
node qa/tools/verify-skill-zip.mjs                           # verificar el ZIP de la Skill
```
`run` se niega si el aislamiento no está validado para el modelo (salvo `--allow-unvalidated`, que queda marcado). El modelo es configurable (`--model` o `QA_MODEL`).

## Reglas del controlador
- **Nunca inventa una respuesta de la analista.** Una pregunta que el guion no puede responder suspende la ejecución (`SUSPENDED_UNMAPPED_ANALYST_QUESTION`, código 5), conserva la pregunta literal y el historial, y pide revisar el guion. Se continúa con `resume`.
- Cada respuesta se registra con su origen: `SCRIPT`, `SCRIPT_UNKNOWN` (el guion dice explícitamente que no lo sabe) o `MANUAL_RESUME`.
- No inventa ni corrige filas: distingue fila válida, ausente, estado desconocido y formato ambiguo.
- No atribuye causas: genera una hoja de revisión para Andrés o la analista.
- `HIPOTESIS` y `CONFIRMADO` solo generan banderas de revisión.
- Solo comprueba automáticamente lo que puede demostrar; lo normativo interpretable queda como REVISAR.
- `reevaluate` y `resume` escriben en carpetas nuevas y nunca sobrescriben el informe original.

## Estados de conversación
`AWAITING_ANALYST_INPUT`, `PROVISIONAL_EVALUATION`, `FINAL_EVALUATION` y `FINAL_NO_EVALUATION`; paradas `FINAL`, `STOPPED_REPEATED_QUESTION`, `STOPPED_MAX_TURNS`, `STOPPED_NO_PROGRESS`, `STOPPED_CLI_ERROR` y `SUSPENDED_UNMAPPED_ANALYST_QUESTION`.

## Telemetría
Cada ejecución guarda `telemetry.json`: por turno, modelo, versión, tokens (entrada, salida, razonamiento, escritura y lectura de caché, totales), costo de lista del CLI (diferencia de acumulados), duración del CLI y de reloj, pasos internos, llamadas a la API observadas, tamaño del JSON, páginas, componentes, conexiones, reglas evaluadas y resumen de conversación (preguntas, respuestas por origen, versiones del dictamen y cambios entre ellas). Lo que el CLI no expone se marca `NO DISPONIBLE`. El costo es de lista (`costBasis: list`), no un cargo ni el consumo real del plan; ver `COSTOS.md`.
