#!/usr/bin/env node
// Blueprint Evaluation QA controller (Phase 1).
// Usage:
//   node qa/controller/run.mjs pin
//   node qa/controller/run.mjs probe-isolation [--model <m>]
//   node qa/controller/run.mjs run <caseId> [--model <m>] [--allow-unvalidated]
import { existsSync, readFileSync, readdirSync, mkdirSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { randomUUID } from 'node:crypto';
import { readJson, writeJson, writeText, sha256, ruleIdsFromTexts, RULE_COUNT } from './lib/util.mjs';
import { readZip, inspectZip } from './lib/zip.mjs';
import { createSandbox, SKILL_NAME, sandboxRoot } from './lib/sandbox.mjs';
import { authPreflight, runTurn, newSession, loadAgentPrompt } from './lib/runner.mjs';
import { evaluateRun } from './lib/checks.mjs';
import { analyzeTurn, verdictVersion, diffVersions, normalizeQuestion, STOP } from './lib/conversation.mjs';
import { drive, seedMemory, analystReply } from './lib/drive.mjs';
import { preflight } from './lib/preflight.mjs';
import { runTelemetry, inputMetrics } from './lib/telemetry.mjs';
import { buildReviewSheet, renderReport } from './lib/compare.mjs';

const QA = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const REPO = resolve(QA, '..');
// The Skill under test. Default: the current version pinned in skill.lock.json. `--skill 11.2.2` runs the archived
// version (qa/skill-locks/) on the same inputs, for comparisons; it never re-pins or overwrites the current lock.
const CURRENT_SKILL = '11.2.4';
const SKILL_VERSION = (() => { const i = process.argv.indexOf('--skill'); return i >= 0 && process.argv[i + 1] ? process.argv[i + 1].replace(/^v/, '') : CURRENT_SKILL; })();
const ZIP = SKILL_VERSION === CURRENT_SKILL ? join(REPO, 'dist', `validar-blueprint-integracion-v${CURRENT_SKILL}.zip`) : join(QA, 'skill-locks', `validar-blueprint-integracion-v${SKILL_VERSION}.zip`);
const LOCK = SKILL_VERSION === CURRENT_SKILL ? join(QA, 'skill.lock.json') : join(QA, 'skill-locks', `skill.lock.v${SKILL_VERSION}.json`);
const ISOLATION = join(QA, 'runs', 'isolation.json');
const DEFAULT_MODEL = process.env.QA_MODEL ?? 'opus';

const args = process.argv.slice(2);
const command = args[0];
const flag = name => { const i = args.indexOf(name); return i >= 0 ? args[i + 1] : undefined; };
const has = name => args.includes(name);

function catalogIdsFromZip(zip) {
  const rules = zip.entries.filter(entry => /\/0[1-7]-reglas-[^/]+\.md$/.test(entry.name));
  return ruleIdsFromTexts(rules.map(entry => entry.data.toString('utf8')));
}

function pin() {
  if (SKILL_VERSION !== CURRENT_SKILL) { console.error('pin solo fija la versión vigente (' + CURRENT_SKILL + '); las versiones archivadas no se vuelven a fijar.'); process.exit(2); }
  const zip = readZip(ZIP), inspection = inspectZip(zip, SKILL_NAME);
  // Controller-side comparison against the source skills folder (never visible to the evaluator).
  const mismatches = [];
  for (const entry of zip.entries.filter(item => !item.isDirectory)) {
    if (!existsSync(join(REPO, 'skills', entry.name)) || sha256(readFileSync(join(REPO, 'skills', entry.name))) !== sha256(entry.data)) mismatches.push(entry.name);
  }
  const lock = { zip: `dist/validar-blueprint-integracion-v${CURRENT_SKILL}.zip`, sha256: zip.sha256, bytes: zip.bytes, files: inspection.fileCount, portableProblems: inspection.problems, zipEqualsSkillsFolder: mismatches.length === 0, mismatches, ruleIds: catalogIdsFromZip(zip).length, ruleBodies: Object.fromEntries(zip.entries.filter(entry => /\/0[1-7]-reglas-[^/]+\.md$/.test(entry.name)).map(entry => [entry.name.replace(/^[^/]+\//, ''), sha256(entry.data.toString('utf8').replace(/\r/g, '').split('\n').slice(1).join('\n'))])), pinnedAt: new Date().toISOString() };
  writeJson(LOCK, lock);
  console.log(JSON.stringify(lock, null, 2));
  process.exit(lock.portableProblems.length || mismatches.length || lock.ruleIds !== RULE_COUNT ? 2 : 0);
}

function requireLock() {
  if (!existsSync(LOCK)) { console.error('Falta qa/skill.lock.json. Ejecute: node qa/controller/run.mjs pin'); process.exit(2); }
  const lock = readJson(LOCK);
  const current = readZip(ZIP).sha256;
  if (current !== lock.sha256) { console.error(`El ZIP cambió (${current}) respecto del hash fijado (${lock.sha256}). Revise y vuelva a fijar con "pin".`); process.exit(2); }
  return lock;
}

function probeIsolation() {
  const lock = requireLock();
  const pre = authPreflight();
  if (!pre.ok) { const rec = { validated: false, reason: 'AUTH_UNAVAILABLE', detail: pre, at: new Date().toISOString() }; writeJson(ISOLATION, rec); console.error('No se puede probar el aislamiento: ' + JSON.stringify(pre)); process.exit(3); }
  const model = flag('--model') ?? DEFAULT_MODEL, runId = 'probe-' + randomUUID().slice(0, 8);
  const sandbox = createSandbox({ runId, caseId: 'probe', zipPath: ZIP, compactPath: join(QA, 'cases', 'c14-zero-applicable', 'compact.json'), expectedZipSha: lock.sha256 });
  const outsideDir = join(sandboxRoot(), runId, 'outside');
  const canary = 'CANARY-OUTSIDE-' + randomUUID();
  writeText(join(outsideDir, 'CANARY.txt'), canary);
  const outsidePaths = [join(outsideDir, 'CANARY.txt'), join(REPO, 'AGENTS.md'), join(REPO, 'src', 'index.js')];
  const insidePaths = ['input/compact.json', `.claude/skills/${SKILL_NAME}/SKILL.md`];
  const prompt = `Prueba autorizada de permisos del entorno (no es una tarea de validación): se espera que algunas lecturas sean denegadas; intenta TODAS igualmente. Con la herramienta Read intenta leer, una por una, estas rutas y di para cada una si obtuviste contenido o un error (cita el mensaje literal). Rutas: ${[...outsidePaths, ...insidePaths].join(' ; ')}. Además enumera las herramientas y skills que tienes disponibles.`;
  const turn = runTurn({ sandboxDir: sandbox.dir, prompt, model, session: newSession() }); // no agent prompt: the harness, not the model's obedience, must be what blocks outside reads
  const resultsById = new Map(turn.toolResults.map(result => [result.id, result]));
  const attempts = turn.toolCalls.map(call => ({ tool: call.name, path: call.input?.file_path ?? null, result: resultsById.get(call.id) ?? null }));
  const leaked = attempts.some(item => item.result && !item.result.isError && String(item.result.content).includes(canary)) || turn.text.includes(canary);
  const outsideDenied = outsidePaths.every(path => { const tried = attempts.filter(item => item.path && resolve(item.path).toLowerCase() === resolve(path).toLowerCase()); return tried.length === 0 || tried.every(item => item.result?.isError); });
  const outsideAttempted = outsidePaths.filter(path => attempts.some(item => item.path && resolve(item.path).toLowerCase() === resolve(path).toLowerCase()));
  const insideOk = insidePaths.every(path => attempts.some(item => item.path && resolve(sandbox.dir, item.path).toLowerCase() === resolve(sandbox.dir, path).toLowerCase() && item.result && !item.result.isError));
  const tools = turn.init?.tools ?? null;
  const toolsOk = Array.isArray(tools) && tools.length === 2 && tools.includes('Read') && tools.includes('Skill');
  const skillLoaded = Array.isArray(turn.init?.skills) && turn.init.skills.includes(SKILL_NAME);
  const mcpOk = !(turn.init?.mcp_servers?.length);
  const reasons = [];
  if (leaked) reasons.push('FILTRACION_DEL_CANARIO');
  if (!outsideDenied) reasons.push('LECTURA_EXTERNA_NO_DENEGADA');
  if (outsideAttempted.length < outsidePaths.length) reasons.push('RUTAS_EXTERNAS_NO_PROBADAS_POR_EL_MODELO');
  if (!insideOk) reasons.push('LECTURA_INTERNA_FALLIDA');
  if (!toolsOk) reasons.push('HERRAMIENTAS_NO_RESTRINGIDAS:' + JSON.stringify(tools));
  if (!mcpOk) reasons.push('MCP_PRESENTE');
  if (!skillLoaded) reasons.push('SKILL_NO_CARGADA');
  const record = { validated: reasons.length === 0, reasons, model, cliInit: { tools, mcp_servers: turn.init?.mcp_servers ?? null, skills: turn.init?.skills ?? null, slash_commands: turn.init?.slash_commands ?? null, cwd: turn.init?.cwd ?? null }, attempts, scope: 'Válido solo para este modelo, versión de CLI y configuración de permisos', at: new Date().toISOString() };
  writeJson(ISOLATION, record);
  console.log(JSON.stringify({ validated: record.validated, reasons }, null, 2));
  process.exit(record.validated ? 0 : 4);
}

function loadCase(id) {
  const dir = join(QA, 'cases', id);
  if (!existsSync(join(dir, 'case.json'))) { console.error('Caso inexistente: ' + id); process.exit(2); }
  return { dir, meta: readJson(join(dir, 'case.json')), compactPath: join(dir, 'compact.json') };
}


/** Rebuilds the conversation record (states, verdict versions and their differences) from saved turns. */
function conversationFrom(turns, catalogIds, stopReason) {
  const states = [], versions = [], diffs = [], questions = [];
  turns.forEach((turn, index) => {
    const analysis = analyzeTurn(turn.text);
    states.push(analysis.state); questions.push(analysis.questions);
    if (analysis.hasEvaluation) { const version = verdictVersion(turn.text, index, catalogIds); if (versions.length) diffs.push(diffVersions(versions.at(-1), version)); versions.push(version); }
  });
  return { states, stopReason, versions, diffs, questions };
}

function finishRun({ runId, caseId, meta, expected, compact, compactPath, catalogIds, turns, sandbox, answersGiven, conversation, conditions, outDir: forcedOutDir = null, writeTranscript = true }) {
  const evaluation = evaluateRun({ caseMeta: { ...meta, canary: expected.canary }, compact, catalogIds, turns, sandbox, answersGiven, conversation, expected });
  // rules evaluated = rows with a valid state, summed over the evaluated pages (a rule evaluated on two pages counts twice)
  const finalRows = evaluation.pages.reduce((n, page) => n + Object.values(page.counts).reduce((a, b) => a + b, 0), 0);
  const telemetry = runTelemetry({ turns, inputs: inputMetrics({ compact, compactPath, sandboxDir: sandbox.dir, turns, finalRuleRows: finalRows }) });
  telemetry.conversation = {
    states: conversation.states, stopReason: conversation.stopReason, suspension: conversation.suspension ?? null,
    questionsPerTurn: conversation.questions.map(list => list.length), totalQuestions: conversation.questions.reduce((n, list) => n + list.length, 0),
    substantiveAnswers: answersGiven.length,
    replySources: turns.flatMap(turn => turn.replySources ?? []).reduce((acc, item) => { acc[item.source] = (acc[item.source] ?? 0) + 1; return acc; }, {}),
    verdictVersions: conversation.versions.map(version => ({ turn: version.turn, counts: version.counts })),
    changesBetweenVersions: conversation.diffs.map(diff => ({ fromTurn: diff.fromTurn, toTurn: diff.toTurn, changedRules: diff.changedRules.length, detail: diff.changedRules }))
  };
  const outDir = forcedOutDir ?? join(QA, 'runs', runId, caseId);
  mkdirSync(outDir, { recursive: true });
  if (writeTranscript) writeJson(join(outDir, 'transcript.json'), { conditions, answersGiven, conversation, turns: turns.map(({ events, ...rest }) => rest) });
  writeJson(join(outDir, 'telemetry.json'), telemetry);
  const reviewSheet = buildReviewSheet({ evaluation, expected, conditions });
  writeJson(join(outDir, 'report.json'), { conditions, evaluation, reviewSheet });
  writeText(join(outDir, 'report.md'), renderReport({ conditions, evaluation, reviewSheet, meta, telemetry }));
  return { evaluation, telemetry, outDir };
}

function runCase() {
  const caseId = args[1], model = flag('--model') ?? DEFAULT_MODEL;
  const lock = requireLock();
  const isolation = existsSync(ISOLATION) ? readJson(ISOLATION) : { validated: false, reason: 'NO_PROBADO' };
  const isolated = isolation.validated === true && isolation.model === model;
  if (!isolated && !has('--allow-unvalidated')) { console.error(`Aislamiento NO validado para el modelo "${model}" (${isolation.reason ?? isolation.reasons?.join(',') ?? 'sin registro'}). Ejecute probe-isolation o use --allow-unvalidated (la ejecución quedará marcada).`); process.exit(4); }
  const pre = authPreflight();
  if (!pre.ok) { console.error('Autenticación no disponible: ' + JSON.stringify(pre)); process.exit(3); }
  const { meta, compactPath } = loadCase(caseId);
  const expected = readJson(join(QA, 'expected', `${caseId}.expected.json`));
  const runId = flag('--run-id') ?? new Date().toISOString().replace(/[:.]/g, '-') + '-' + randomUUID().slice(0, 6);
  const sandbox = createSandbox({ runId, caseId, zipPath: ZIP, compactPath, expectedZipSha: lock.sha256 });
  const compact = readJson(compactPath);
  const catalogIds = catalogIdsFromZip(readZip(ZIP));
  const maxTurns = Number(flag('--max-turns') ?? meta.maxTurns ?? 6);
  const turns = [], answersGiven = [];
  const { stopReason, suspension } = drive({ sandboxDir: sandbox.dir, model, system: loadAgentPrompt(join(QA, 'agent', 'blueprint-evaluation-qa.md')), session: newSession(), meta, caseId, catalogIds, pageTitles: pageTitlesOf(compact), maxTurns, memory: { answered: new Set(), repliesSent: 0 }, turns, answersGiven, firstPrompt: meta.prompt });
  const conversation = { ...conversationFrom(turns, catalogIds, stopReason), suspension };
  const conditions = { model, isolationValidated: isolated, isolationRecord: isolation.validated ? 'qa/runs/isolation.json' : null, skillZipSha256: lock.sha256, skillVersion: SKILL_VERSION, cliAuth: pre.method, runId, caseId, repetition: 1, maxTurns, generatedAt: new Date().toISOString() };
  const { evaluation, telemetry, outDir } = finishRun({ runId, caseId, meta, expected, compact, compactPath, catalogIds, turns, sandbox, answersGiven, conversation, conditions });
  console.log(JSON.stringify({ caseId, runId, isolationValidated: isolated, states: conversation.states, stopReason, suspension: suspension ? { turn: suspension.turn, questions: suspension.questions } : null, fails: evaluation.findings.filter(f => f.status === 'FAIL').length, review: evaluation.findings.filter(f => f.status === 'REVIEW').length, tokens: telemetry.totals, report: join(outDir, 'report.md') }, null, 2));
  process.exit(suspension ? 5 : 0);
}

const pageTitlesOf = compact => (compact.pages ?? []).map(page => page.page?.title).filter(Boolean);

function resumeRun() {
  // Continues a (possibly suspended) session. The reply comes from --reply (manual, recorded as MANUAL_RESUME) or from the script via --topic.
  const runId = args[1], caseId = args[2], topic = flag('--topic'), manual = flag('--reply');
  const dir = join(QA, 'runs', runId, caseId);
  const transcript = readJson(join(dir, 'transcript.json'));
  const { meta, compactPath } = loadCase(caseId);
  const expected = readJson(join(QA, 'expected', caseId + '.expected.json'));
  requireLock();
  const model = transcript.conditions.model;
  const sandboxDir = join(sandboxRoot(), runId, caseId);
  if (!existsSync(sandboxDir)) { console.error('El sandbox de la ejecución ya no existe: ' + sandboxDir); process.exit(2); }
  const pre = authPreflight();
  if (!pre.ok) { console.error('Autenticación no disponible: ' + JSON.stringify(pre)); process.exit(3); }
  let replyText, substantive, source, scriptedTopic = null, autoGiven = [], autoSources = [];
  if (manual !== undefined) { replyText = manual; substantive = has('--substantive'); source = 'MANUAL_RESUME'; }
  else if (!topic) {
    // Automatic: the script (possibly corrected after the suspension) answers the questions that suspended the run. Still no invented text.
    const suspended = transcript.conversation?.suspension;
    if (!suspended) { console.error('La ejecución no está suspendida: indique --reply o --topic'); process.exit(2); }
    const lastText = transcript.turns.at(-1)?.text ?? '';
    const auto = analystReply(meta, suspended.allQuestionsOfTheTurn ?? suspended.questions, pageTitlesOf(readJson(compactPath)), lastText);
    if (auto.suspend) { console.error('El guion sigue sin poder responder: ' + JSON.stringify(auto.unmapped)); process.exit(5); }
    replyText = auto.text; substantive = auto.given.length > 0; source = 'SCRIPT'; autoGiven = auto.given; autoSources = auto.sources;
  }
  else {
    const spec = topic ? meta.analystScript.replies[topic] : null;
    if (!spec || spec.perPage) { console.error('Indique --reply "<texto>" o un --topic con respuesta única en el guion'); process.exit(2); }
    replyText = spec.text; substantive = !!spec.substantive; source = spec.kind === 'SCRIPTED_UNKNOWN' ? 'SCRIPT_UNKNOWN' : 'SCRIPT'; scriptedTopic = topic;
  }
  const compact = readJson(compactPath);
  const catalogIds = catalogIdsFromZip(readZip(ZIP));
  const turns = [...transcript.turns];
  const answersGiven = [...(transcript.answersGiven ?? [])];
  const suspension = transcript.conversation?.suspension ?? null;
  if (autoGiven.length) answersGiven.push(...autoGiven.map(item => ({ ...item, source })));
  else if (substantive) answersGiven.push({ topic: scriptedTopic ?? 'manual', question: suspension?.questions?.join(' | ') ?? '(respuesta posterior al cierre de la sesión)', text: replyText, page: null, source });
  const memory = seedMemory(turns);
  (suspension?.allQuestionsOfTheTurn ?? []).forEach(question => memory.answered.add(normalizeQuestion(question)));
  memory.repliesSent++;
  const last = turns.at(-1);
  if (last) { last.analystReply = replyText; last.replySources = autoSources.length ? autoSources : [{ question: suspension?.questions?.join(' | ') ?? null, topic: scriptedTopic, source }]; }
  const session = { id: transcript.turns[0].result.session_id, started: true };
  const maxTurns = Number(flag('--max-turns') ?? meta.maxTurns ?? 6);
  const outcome = drive({ sandboxDir, model, system: loadAgentPrompt(join(QA, 'agent', 'blueprint-evaluation-qa.md')), session, meta, caseId, catalogIds, pageTitles: pageTitlesOf(compact), maxTurns: Math.max(maxTurns, turns.length + 1), memory, turns, answersGiven, firstPrompt: replyText });
  turns.filter(turn => turn.userPrompt === replyText && !turn.continuation).slice(-1).forEach(turn => { turn.continuation = true; });
  const conversation = { ...conversationFrom(turns, catalogIds, outcome.stopReason), suspension: outcome.suspension, resumedFrom: { turn: turns.length, source, previousStop: transcript.conversation?.stopReason ?? null } };
  const conditions = { ...transcript.conditions, continuedAt: new Date().toISOString(), note: 'Sesión continuada con resume; el historial original no se modifica' };
  const outDir = join(dir, 'continued', new Date().toISOString().replace(/[:.]/g, '-'));
  const { evaluation, telemetry } = finishRun({ runId, caseId, meta, expected, compact, compactPath, catalogIds, turns, sandbox: { dir: sandboxDir }, answersGiven, conversation, conditions, outDir });
  console.log(JSON.stringify({ continued: caseId, writtenTo: outDir, states: conversation.states, stopReason: outcome.stopReason, fails: evaluation.findings.filter(f => f.status === 'FAIL').length, review: evaluation.findings.filter(f => f.status === 'REVIEW').length, tokens: telemetry.totals }, null, 2));
  process.exit(outcome.suspension ? 5 : 0);
}


function reevaluate() {
  // Re-parse an existing transcript (no model call).
  const runId = args[1], caseId = args[2];
  const baseDir = join(QA, 'runs', runId, caseId);
  // --continued: re-parse the latest resumed session (its transcript contains the whole history plus the continuation)
  const continuedRoot = join(baseDir, 'continued');
  const latestContinued = has('--continued') && existsSync(continuedRoot) ? readdirSync(continuedRoot).sort().at(-1) : null;
  const dir = latestContinued ? join(continuedRoot, latestContinued) : baseDir;
  const transcript = readJson(join(dir, 'transcript.json'));
  const { meta, compactPath } = loadCase(caseId);
  const expected = readJson(join(QA, 'expected', caseId + '.expected.json'));
  const catalogIds = catalogIdsFromZip(readZip(ZIP));
  let stopReason = transcript.conversation?.stopReason ?? 'REEVALUATED_FROM_TRANSCRIPT';
  // When the saved stop was caused by a controller defect (a question wrongly read from a table cell), recompute it from the last turn.
  const lastState = analyzeTurn(transcript.turns.at(-1)?.text ?? '').state;
  const recomputed = String(stopReason).startsWith('SUSPENDED') && ['FINAL_EVALUATION', 'FINAL_NO_EVALUATION'].includes(lastState);
  if (recomputed) stopReason = 'FINAL';
  const conversation = { ...conversationFrom(transcript.turns, catalogIds, stopReason), suspension: recomputed ? null : (transcript.conversation?.suspension ?? null), stopRecomputedAfterControllerFix: recomputed };
  const conditions = { ...transcript.conditions, reevaluatedAt: new Date().toISOString(), note: 'Reevaluado sobre la misma transcripción; sin nuevas llamadas al modelo' };
  const outDir = join(dir, 'reeval', new Date().toISOString().replace(/[:.]/g, '-'));
  const { evaluation, telemetry } = finishRun({ runId, caseId, meta, expected, compact: readJson(compactPath), compactPath, catalogIds, turns: transcript.turns, sandbox: { dir: join(sandboxRoot(), runId, caseId) }, answersGiven: transcript.answersGiven ?? [], conversation, conditions, outDir, writeTranscript: false });
  console.log(JSON.stringify({ reevaluated: caseId, writtenTo: outDir, states: conversation.states, fails: evaluation.findings.filter(f => f.status === 'FAIL').length, review: evaluation.findings.filter(f => f.status === 'REVIEW').length, costUsd: telemetry.totals.costUsd }));
}


function preflightCommand() {
  const model = flag('--model') ?? DEFAULT_MODEL;
  const caseIds = (flag('--cases') ?? readdirSync(join(QA, 'cases')).join(',')).split(',').filter(Boolean);
  const results = preflight({ QA, REPO, zipPath: ZIP, lockPath: LOCK, isolationPath: ISOLATION, model, caseIds, archived: SKILL_VERSION !== CURRENT_SKILL });
  for (const item of results) console.log(`${item.ok ? 'PASS' : 'FAIL'}  ${item.name}${item.detail ? '  -- ' + item.detail : ''}`);
  const failed = results.filter(item => !item.ok).length;
  console.log(`
${results.length - failed} PASS, ${failed} FAIL`);
  process.exit(failed ? 1 : 0);
}

switch (command) {
  case 'preflight': preflightCommand(); break;
  case 'resume': resumeRun(); break;
  case 'reevaluate': reevaluate(); break;
  case 'pin': pin(); break;
  case 'probe-isolation': probeIsolation(); break;
  case 'run': runCase(); break;
  default: console.error('Comandos: pin | probe-isolation | run <caseId>'); process.exit(1);
}
