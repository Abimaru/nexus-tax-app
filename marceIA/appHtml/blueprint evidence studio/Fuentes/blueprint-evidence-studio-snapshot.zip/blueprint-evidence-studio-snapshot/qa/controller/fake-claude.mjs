#!/usr/bin/env node
// Test double for the `claude` CLI. It lets the controller be validated without a model.
// It reads the skill catalog from the sandbox it is run in (cwd), exactly as a real evaluator would.
// Like the real CLI, `total_cost_usd` and `duration_api_ms` are CUMULATIVE per session while `usage` is per turn.
import { readFileSync, writeFileSync, existsSync } from 'node:fs';
import { join } from 'node:path';
const args = process.argv.slice(2);
if (args[0] === 'auth') { console.log(JSON.stringify({ loggedIn: true, authMethod: 'fake' })); process.exit(0); }
const scenario = process.env.QA_FAKE_SCENARIO ?? 'good';
const counterFile = join(process.cwd(), '.fake-turn'), costFile = join(process.cwd(), '.fake-cost');
const turn = (existsSync(counterFile) ? Number(readFileSync(counterFile, 'utf8')) : 0) + 1; // 1-based
writeFileSync(counterFile, String(turn));
const out = event => console.log(JSON.stringify(event));
const refsDir = join(process.cwd(), '.claude', 'skills', 'validar-blueprint-integracion', 'references');
const csv = ['01-reglas-estructura','02-reglas-api-servicios','03-reglas-eventos','04-reglas-despliegue','05-reglas-escenarios','06-reglas-modelos-comandos','07-reglas-gestores-colas'].map(n => readFileSync(join(refsDir, n + '.md'), 'utf8')).join(' ');
const ids = [...csv.matchAll(/^#{2,3} ([A-Z]+[0-9]?-\d{3}) - /gm)].map(m => m[1]);
const sessionId = args[args.indexOf('--session-id') + 1] ?? args[args.indexOf('--resume') + 1];
out({ type: 'system', subtype: 'init', session_id: sessionId, tools: ['Read', 'Skill'], mcp_servers: [], skills: ['validar-blueprint-integracion'], model: 'fake-model', claude_code_version: '0.0.0-double', cwd: process.cwd() });
let toolId = 0;
const read = (file, error = false) => {
  out({ type: 'assistant', message: { id: 'm' + turn + 'r', content: [{ type: 'tool_use', id: 't' + (++toolId), name: 'Read', input: { file_path: file } }], usage: { input_tokens: 1, output_tokens: 1 } } });
  out({ type: 'user', message: { content: [{ type: 'tool_result', tool_use_id: 't' + toolId, is_error: error, content: error ? 'Permission denied' : 'ok' }] } });
};
const say = (text) => {
  const usage = { input_tokens: 100, output_tokens: 50 * turn, cache_read_input_tokens: 1000 * turn, cache_creation_input_tokens: turn === 1 ? 2000 : 300, output_tokens_details: { thinking_tokens: 10 } };
  const turnCost = (usage.input_tokens * 4 + usage.output_tokens * 20 + usage.cache_read_input_tokens * 0.2 + usage.cache_creation_input_tokens * 8) / 1e6;
  const cumulative = (existsSync(costFile) ? Number(readFileSync(costFile, 'utf8')) : 0) + turnCost;
  writeFileSync(costFile, String(cumulative));
  out({ type: 'assistant', message: { id: 'm' + turn, content: [{ type: 'text', text }], usage } });
  out({ type: 'result', subtype: 'success', result: text, total_cost_usd: cumulative, duration_ms: 1000 * turn, duration_api_ms: 900 * turn * (turn + 1) / 2, num_turns: 3, usage, modelUsage: { 'fake-model': {} }, session_id: sessionId, permission_denials: [] });
};
const FIXED = ['| rule_id | Estado | Evidencia | Justificación | Información pendiente |', '|---|---|---|---|---|'];
function table(counts, opts = {}) {
  const states = [];
  for (const [state, n] of counts) for (let i = 0; i < n; i++) states.push(state);
  let rows = ids.map((id, i) => `| ${id} | ${states[i] ?? 'No aplica'} | evidencia en \`input/compact.json\` | justificación breve | pendiente: ninguno |`);
  if (opts.dropLast) rows = rows.slice(0, -1);
  if (opts.unknown) rows[3] = `| ${ids[3]} | Parcialmente cumple | x | y | z |`;
  if (opts.duplicate) rows.push(`| ${ids[0]} | No cumple | x | y | z |`);
  return [...FIXED, ...rows].join('\n');
}
function verdict(counts, opts = {}) {
  const c = Object.fromEntries(counts);
  const den = (c['Cumple'] ?? 0) + (c['No cumple'] ?? 0) + (c['No verificable'] ?? 0);
  const pct = opts.pct ?? (den ? (c['Cumple'] ?? 0) / den * 100 : null);
  return `Informe de la página.\n\n${table(counts, opts)}\n\nConteos: Cumple ${c['Cumple'] ?? 0}; No cumple ${c['No cumple'] ?? 0}; No verificable ${c['No verificable'] ?? 0}; No aplica ${c['No aplica'] ?? 0}.\n${pct === null ? 'Cumplimiento: no calculable.' : `Cumplimiento: ${pct.toFixed(1)} %`}\n${opts.provenance ? 'Respuestas registradas como DECLARADO_POR_ANALISTA.' : ''}${opts.question ? `\n\n${opts.question}` : ''}`;
}
const Q_CLASS = 'La página «operacionSinEvidencia» está clasificada como UNRESOLVED y no puedo emitir un dictamen definitivo. ¿Confirmas que la clasificación es una operación real que debe evaluarse?';
const Q_CLASS_TYPE = 'No puedo emitir el dictamen. **La página «operacionSinEvidencia» (`ops`) está clasificada como `UNRESOLVED`. ¿Cuál es su tipo: `OPERATIONAL`, `MIXED`, `TEMPLATE_OR_LEGEND` o `BDD_OR_REQUIREMENTS`?**';
const Q_CONTR = 'La página «plantilla» está clasificada como TEMPLATE_OR_LEGEND, pero contiene evidencia de operación (escenario HIPOTESIS, componente principal «x»). ¿Confirmas que es una operación real que debe evaluarse?';
const TECHNICAL_NA = ['CA-001', 'FT-001', 'MQ-003', 'COM-002', 'COM-003', 'COM-004'];
function c15verdict(overrides = {}, opts = {}) {
  const states = Object.fromEntries(ids.map(id => [id, TECHNICAL_NA.includes(id) ? 'No aplica' : 'No verificable']));
  Object.assign(states, overrides);
  const rows = ids.map(id => `| ${id} | ${states[id]} | evidencia en \`input/compact.json\` | justificación breve | — |`);
  const c = {}; for (const s of Object.values(states)) c[s] = (c[s] ?? 0) + 1;
  const den = (c['Cumple'] ?? 0) + (c['No cumple'] ?? 0) + (c['No verificable'] ?? 0);
  return [...FIXED, ...rows].join('\n') + `\n\nConteos: Cumple ${c['Cumple'] ?? 0}; No cumple ${c['No cumple'] ?? 0}; No verificable ${c['No verificable'] ?? 0}; No aplica ${c['No aplica'] ?? 0}.\nCumplimiento: ${(((c['Cumple'] ?? 0) / den) * 100).toFixed(1)} %\n${opts.provenance ? 'Clasificación confirmada por la analista: DECLARADO_POR_ANALISTA.' : ''}`;
}
const NORMAL = [['Cumple', 10], ['No verificable', 16], ['No aplica', 11]];
const AFTER = [['Cumple', 12], ['No verificable', 14], ['No aplica', 11]];
if (scenario === 'outside-read') read('/outside-sandbox/AGENTS.md', true);
if (scenario === 'extra-tool') out({ type: 'assistant', message: { id: 'mx', content: [{ type: 'tool_use', id: 'tx', name: 'Bash', input: { command: 'ls' } }] } });
read('input/compact.json');
const Q_MAIN = '¿Qué componente cumple la función de principal en esta página?';
const Q_MCI = '¿La API o servicio principal está en MCI? ¿El servicio hijo principal está en MCI? ¿Cuál es la exposición (Private, Public o Partner)?';
// ---- pilot scenarios (P1..P4): the fake reads the compact JSON of the sandbox, like a real evaluator
const compact = existsSync(join(process.cwd(), 'input', 'compact.json')) ? JSON.parse(readFileSync(join(process.cwd(), 'input', 'compact.json'), 'utf8')) : { pages: [] };
const evaluable = scenario.startsWith('pilot-contradiction') ? compact.pages : compact.pages.filter(p => ['OPERATIONAL', 'MIXED'].includes(p.pageClassification.kind));
const pageHeading = p => `## Página \`${p.page.title}\``;
function pageTable(statesById) {
  const rows = ids.map(id => `| ${id} | ${statesById[id]} | evidencia en \`input/compact.json\` | justificación breve | — |`);
  return [...FIXED, ...rows].join('\n');
}
function distribution(counts) { const out = {}; let i = 0; for (const [state, n] of counts) for (let k = 0; k < n; k++) out[ids[i++]] = state; for (; i < ids.length; i++) out[ids[i]] = 'No aplica'; return out; }
function countsOf(states) { const c = { 'Cumple': 0, 'No cumple': 0, 'No verificable': 0, 'No aplica': 0 }; for (const s of Object.values(states)) c[s]++; return c; }
const pct = c => { const d = c['Cumple'] + c['No cumple'] + c['No verificable']; return d ? c['Cumple'] / d * 100 : null; };
function pilotFinal({ perPage, naive = false, provenance = true, legendMisuse = false }) {
  const parts = [], all = [];
  evaluable.forEach((p, i) => {
    const states = perPage[i] ?? distribution([['Cumple', 10], ['No verificable', 16]]);
    if (legendMisuse && i === 0) states['MQ-001'] = 'Cumple';
    const c = countsOf(states); all.push(c);
    parts.push(`${pageHeading(p)}\n\n${legendMisuse && i === 0 ? pageTable(states).replace(/\| MQ-001 \| Cumple \| [^|]*\|/, '| MQ-001 | Cumple | `p2-leg-qm` (Nombre Gestor de Colas) |') : pageTable(states)}\n\nConteos: Cumple ${c['Cumple']}; No cumple ${c['No cumple']}; No verificable ${c['No verificable']}; No aplica ${c['No aplica']}.\nCumplimiento de la página: ${pct(c).toFixed(1)} %${provenance ? '\nRespuestas de la analista: DECLARADO_POR_ANALISTA.' : ''}`);
  });
  const total = all.reduce((a, c) => { for (const k of Object.keys(c)) a[k] += c[k]; return a; }, { 'Cumple': 0, 'No cumple': 0, 'No verificable': 0, 'No aplica': 0 });
  const value = naive ? all.map(pct).reduce((a, b) => a + b, 0) / all.length : pct(total);
  return parts.join('\n\n') + (evaluable.length > 1 ? `\n\n## Total del blueprint\nCumplimiento consolidado del blueprint: ${value.toFixed(1)} %` : '');
}
const pilotQuestions = (opts = {}) => evaluable.map(p => `### Página «${p.page.title}»\n- ¿La API principal está en MCI?\n- ¿El servicio hijo principal está en MCI?${(opts.exposure ?? []).includes(p.page.title) ? '\n- ¿Cuál es la exposición (Private, Public o Partner)?' : ''}`).join('\n\n');
const P4_DIFFERENT = [distribution([['Cumple', 10], ['No verificable', 16]]), distribution([['Cumple', 20], ['No verificable', 6], ['No cumple', 4]])];
switch (scenario) {
  case 'pilot-good': if (turn === 1) say('Antes del dictamen necesito confirmar:\n' + pilotQuestions({ exposure: [evaluable[0]?.page.title] })); else say(pilotFinal({ perPage: scenario === 'x' ? [] : (evaluable.length > 1 ? P4_DIFFERENT : []) })); break;
  case 'pilot-good-noexposure': if (turn === 1) say('Antes del dictamen necesito confirmar:\n' + pilotQuestions()); else say(pilotFinal({ perPage: [] })); break;
  case 'pilot-naive-mean': if (turn === 1) say('Antes del dictamen necesito confirmar:\n' + pilotQuestions({ exposure: [evaluable[0]?.page.title] })); else say(pilotFinal({ perPage: P4_DIFFERENT, naive: true })); break;
  case 'pilot-reuse-proposal': if (turn === 1) say('Antes del dictamen: ¿quieres que reutilice las respuestas de la primera página en la segunda?'); else say(pilotQuestions({ exposure: [evaluable[0]?.page.title] }) + '\n(Pregunto cada página por separado.)'); break;
  case 'pilot-legend-misuse': if (turn === 1) say('Antes del dictamen necesito confirmar:\n' + pilotQuestions()); else say(pilotFinal({ perPage: [], legendMisuse: true })); break;
  case 'pilot-contradiction': if (turn === 1) say('La página «' + compact.pages[0].page.title + '» está clasificada como ' + compact.pages[0].pageClassification.kind + ', pero contiene evidencia de operación real: la conexión ' + compact.pageClassificationPath + ' ' + (compact.pages[0].pageClassification.operationalPathIds[0]) + ' de la API ' + (compact.pages[0].components.find(c => c.role === 'PRINCIPAL')?.id ?? '') + ' al evento. ¿Confirmas que es una operación real que debe evaluarse?'); else if (turn === 2) say('Entendido, la evalúo como OPERATIONAL (DECLARADO_POR_ANALISTA, solo clasificación). Antes necesito: ¿la API principal está en MCI? ¿El servicio hijo principal está en MCI?'); else say(pilotFinal({ perPage: [] })); break;
  case 'pilot-contradiction-premature': say(pilotFinal({ perPage: [] })); break;
  case 'pilot-contradiction-silent-discard': say('La página «' + compact.pages[0].page.title + '» es BDD_OR_REQUIREMENTS y queda como no evaluable.'); break;
  case 'unmapped-question': if (turn === 1) say('Antes de seguir: ¿Qué versión del esquema de integración usa el equipo?'); else say(c15verdict({}, { provenance: true })); break;
  case 'script-unknown': if (turn === 1) say('Antes del dictamen necesito confirmar: ' + Q_MCI); else say(c15verdict({}, { provenance: true })); break;

  // --- original defect scenarios (turn 1 asks, turn 2 delivers)
  case 'good': case 'outside-read': case 'extra-tool': case 'premature': case 'no-provenance': case 'missing-row': case 'unknown-state': case 'duplicate': case 'wrong-metric':
  case 'zero-denominator-ok': case 'zero-denominator-bad': case 'prose-no-table': {
    if (turn === 1 && scenario !== 'premature') { say('Antes del dictamen necesito confirmar: ' + Q_MCI); break; }
    const opts = { good: { provenance: true }, 'outside-read': { provenance: true }, 'extra-tool': { provenance: true }, 'missing-row': { dropLast: true }, 'unknown-state': { unknown: true }, duplicate: { duplicate: true }, 'wrong-metric': { pct: 99.9 } }[scenario] ?? {};
    if (scenario === 'zero-denominator-ok') say(verdict([['No aplica', 37]]));
    else if (scenario === 'zero-denominator-bad') say(verdict([['No aplica', 37]]).replace('no calculable', '0.0 %'));
    else if (scenario === 'prose-no-table') say('Todas las reglas quedan No verificable porque no hay evidencia. ' + ids.slice(0, 3).join(', ') + ' son ejemplos.');
    else say(verdict(NORMAL, opts));
    break;
  }
  // --- conversation state machine
  case 'provisional-then-final':
    if (turn === 1) say(verdict(NORMAL, { question: Q_MAIN })); else say(verdict(AFTER, { provenance: true }));
    break;
  case 'repeated-question': say(verdict(NORMAL, { question: Q_MAIN })); break; // asks the same thing every turn
  case 'endless-new-questions': say(verdict([['Cumple', 10 + turn], ['No verificable', 16 - turn], ['No aplica', 11]], { question: `¿La API principal está en MCI (confirmación número ${turn})?` })); break;
  case 'no-progress': say(verdict(NORMAL, { question: `¿Podrías indicar otra vez si la API principal está en MCI (intento ${turn})?` })); break;
  case 'conditional-promise-only': say(verdict(NORMAL, { question: 'Cuando el principal esté identificado, te preguntaré su MCI y su exposición.' })); break;
  case 'template-not-evaluable': say('La página `tpl` (plantillaSintetica) es una plantilla pura (TEMPLATE_OR_LEGEND). Es una página no evaluable: no se aplican las 37 reglas. Motivo: solo contiene la leyenda de notación.'); break;
  case 'template-evaluated': say(verdict([['No aplica', 37]])); break;
  case 'unresolved-asks-then-evaluates': if (turn === 1) say(Q_CLASS); else say(c15verdict({}, { provenance: true })); break;
  case 'unresolved-asks-type': if (turn === 1) say(Q_CLASS_TYPE); else say(c15verdict({}, { provenance: true })); break;
  case 'unresolved-final-premature': say(c15verdict()); break;
  case 'contradiction-question': if (turn === 1) say(Q_CONTR); else say(c15verdict({}, { provenance: true })); break;
  case 'c15-mq-na': if (turn === 1) say(Q_CLASS); else say(c15verdict({ 'MQ-001': 'No aplica' }, { provenance: true })); break;
  case 'c15-com002-nv': if (turn === 1) say(Q_CLASS); else say(c15verdict({ 'COM-002': 'No verificable' }, { provenance: true })); break;
  case 'c15-all-nv': if (turn === 1) say(Q_CLASS); else say(c15verdict(Object.fromEntries(ids.map(id => [id, 'No verificable'])), { provenance: true })); break;
  default: say('escenario desconocido');
}
