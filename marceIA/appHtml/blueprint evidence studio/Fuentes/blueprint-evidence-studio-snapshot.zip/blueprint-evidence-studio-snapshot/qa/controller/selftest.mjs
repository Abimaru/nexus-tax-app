#!/usr/bin/env node
// Infrastructure self-test: the controller must detect every defect of the test double. No model involved.
import { spawnSync } from 'node:child_process';
import { readFileSync, existsSync, readdirSync } from 'node:fs';
import { join, resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { tmpdir } from 'node:os';
import { parseRows, summarizeRows, parseReportedMetric, detectQuestions, splitByPages } from './lib/parser.mjs';
import { topicsOf, topicsWithContext, attributeAll, extractQuestions } from './lib/conversation.mjs';
import { metricFromCounts } from './lib/util.mjs';

const QA = resolve(dirname(fileURLToPath(import.meta.url)), '..');
let pass = 0, fail = 0;
const t = (name, ok, detail = '') => { if (ok) pass++; else fail++; console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${ok ? '' : '  -- ' + detail}`); };

// ======================= parser units =======================
const ids = Array.from({ length: 37 }, (_, i) => `CNT-${String(i + 1).padStart(3, '0')}`);
const row = (id, state) => `| ${id} | ${state} | e | j |`;
let s = summarizeRows(parseRows(ids.map(id => row(id, 'Cumple')).join('\n')), ids);
t('parser: 37 valid rows', s.valid.length === 37 && !s.missing.length);
s = summarizeRows(parseRows(ids.slice(0, 36).map(id => row(id, 'Cumple')).join('\n')), ids);
t('parser: missing row is reported, not invented', s.valid.length === 36 && s.missing.length === 1 && s.missing[0] === ids[36]);
s = summarizeRows(parseRows(ids.map((id, i) => row(id, i === 5 ? 'Parcialmente cumple' : 'Cumple')).join('\n')), ids);
t('parser: unknown state is not coerced', s.unknownState.length === 1 && s.valid.length === 36 && s.unknownState[0].raw === 'Parcialmente cumple');
s = summarizeRows(parseRows(ids.map((id, i) => row(id, i === 5 ? 'cumple' : 'No verificable')).join('\n')), ids);
t('parser: case-insensitive canonical state accepted as valid', s.valid.length === 37 && s.valid.find(r => r.id === ids[5]).state === 'Cumple');
s = summarizeRows(parseRows([...ids.map(id => row(id, 'Cumple')), row(ids[0], 'No cumple')].join('\n')), ids);
t('parser: contradictory duplicate flagged ambiguous', s.ambiguous.includes(ids[0]) && s.issues.some(i => i.code === 'FILA_DUPLICADA_CONTRADICTORIA'));
s = summarizeRows(parseRows(ids.map(id => `- ${id}: **No verificable** — falta evidencia`).join('\n')), ids);
t('parser: bullet format with bold state', s.valid.length === 37, String(s.valid.length));
s = summarizeRows(parseRows(ids.map(id => `${id},No aplica,"ev","just"`).join('\n')), ids);
t('parser: CSV format', s.valid.length === 37, String(s.valid.length));
s = summarizeRows(parseRows(ids.map((id, i) => `| ${i + 1} | ${id} | No aplica | motivo, igual que la fila 17 (EVT-001) |`).join('\n')), ids);
t('parser: leading # column before the ID (seen in a real run)', s.valid.length === 37, String(s.valid.length));
t('questions: a refusal to ask is not a question', !detectQuestions('Preguntas a la analista (MCI y exposición): no hago ninguna, no existe principal.').asked.mciPrincipal);
t('parser: prose that merely mentions IDs yields no rows', parseRows('Las reglas CNT-001, CNT-002 y CNT-003 requieren evidencia.').length === 0);
const m = parseReportedMetric('Conteos: Cumple 13; No cumple 0; No verificable 13; No aplica 15.\nCumplimiento: 50,0 %');
t('metric parser: percentage and counts', m.percentages[0] === 50 && m.counts['Cumple'] === 13 && m.counts['No aplica'] === 15, JSON.stringify(m));
t('metric: independent formula 13/26', metricFromCounts({ Cumple: 13, 'No cumple': 0, 'No verificable': 13, 'No aplica': 15 }).percentage === 50);
t('metric: zero denominator is null', metricFromCounts({ 'No aplica': 37 }).percentage === null);
t('questions: topics detected', (() => { const q = detectQuestions('¿La API principal está en MCI? ¿El servicio hijo principal está en MCI? ¿Es Private, Public o Partner?').asked; return !!(q.mciPrincipal && q.mciHijo && q.exposicion); })());
t('a prose line that merely names a rule (recommendations list) does not contradict that rule\'s row', (() => { const text = ids.map(id => row(id, 'No cumple')).join('\n') + '\n1. **CNT-001:** añadir el contenedor'; const s2 = summarizeRows(parseRows(text), ids); return s2.valid.length === 37 && !s2.ambiguous.length && s2.counts['No cumple'] === 37; })());
t('metric parser: percentage in a "Cumplimiento" table column (seen in the P1 run)', (() => { const m2 = parseReportedMetric('| Página | Cumple | No cumple | No verificable | No aplica | Total | Cumplimiento |\n|---|---:|---:|---:|---:|---:|---:|\n| p1 | 11 | 2 | 15 | 13 | 37 | **39,29 %** |\n| **Blueprint** | 11 | 2 | 15 | 13 | 37 | **39,29 %** |'); return m2.percentages.length === 2 && m2.percentages[0] === 39.29 && m2.counts['Cumple'] === 11; })());
t('questions inside Markdown table rows (pending-information cells) are not questions for the analyst', (() => { const table = '| CNT-001 | No verificable | e | ¿el hijo entra en las reglas SRV? | pendiente |'; return extractQuestions(table).length === 0 && extractQuestions('- ¿La API principal está en MCI?').length === 1; })());

// ======================= end-to-end with the scripted CLI =======================
const FAKE_ENV = { ...process.env, QA_CLAUDE_BIN: join(QA, 'controller', 'fake-claude.mjs'), QA_SKIP_AUTH_PREFLIGHT: '1', QA_SANDBOX_ROOT: join(tmpdir(), 'bes-qa-selftest') };
const run = (scenario, caseId = 'c15-evidence-free', extra = []) => {
  const runId = `selftest-${scenario}`;
  const r = spawnSync(process.execPath, [join(QA, 'controller', 'run.mjs'), 'run', caseId, '--model', 'selftest-double', '--allow-unvalidated', '--run-id', runId, ...extra], { env: { ...FAKE_ENV, QA_FAKE_SCENARIO: scenario }, encoding: 'utf8' });
  const dir = join(QA, 'runs', runId, caseId), file = join(dir, 'report.json');
  if (!existsSync(file)) return { error: r.stderr || r.stdout, findings: [], by: () => [] };
  const report = JSON.parse(readFileSync(file, 'utf8'));
  const telemetry = existsSync(join(dir, 'telemetry.json')) ? JSON.parse(readFileSync(join(dir, 'telemetry.json'), 'utf8')) : null;
  return { report, telemetry, exit: r.status, findings: report.evaluation.findings, by: name => report.evaluation.findings.filter(f => f.check === name) };
};
const status = (r, name) => r.by(name).map(f => f.status);
const conv = r => r.report?.evaluation.conversation;

const good = run('good');
t('e2e good: runs', !good.error, good.error);
const mustPass = ['FILAS_37', 'METRICA', 'PREGUNTAS_ANTES_DEL_DICTAMEN', 'AISLAMIENTO_HERRAMIENTAS', 'AISLAMIENTO_RUTAS', 'AISLAMIENTO_CANARIO', 'CONTEOS_INFORMADOS'];
t('e2e good: rows, metric, questions-first, isolation and counts PASS', mustPass.every(n => status(good, n).length && status(good, n).every(x => x === 'PASS')), JSON.stringify(good.findings.filter(f => f.status !== 'PASS').map(f => f.check + ':' + f.status)));
t('e2e: non-substantive analyst replies do not demand provenance', status(good, 'PROCEDENCIA')[0] === 'INFO', JSON.stringify(status(good, 'PROCEDENCIA')));
t('e2e: usage aggregated across the two turns', good.report?.evaluation.usage.turns === 2 && good.report.evaluation.usage.outputTokens === 150);
t('e2e: sandbox holds only skill + input', (() => { const d = join(tmpdir(), 'bes-qa-selftest', 'selftest-good', 'c15-evidence-free'); return existsSync(join(d, 'input', 'compact.json')) && existsSync(join(d, '.claude', 'skills', 'validar-blueprint-integracion', 'SKILL.md')) && !existsSync(join(d, 'expected')) && !existsSync(join(d, 'src')) && !existsSync(join(d, 'AGENTS.md')); })());
for (const [scenario, check, expected] of [
  ['missing-row', 'FILAS_37', 'FAIL'], ['missing-row', 'FILA_AUSENTE', 'FAIL'], ['unknown-state', 'ESTADO_DESCONOCIDO', 'FAIL'], ['duplicate', 'ERROR_DE_FORMATO', 'FAIL'],
  ['wrong-metric', 'METRICA', 'FAIL'], ['premature', 'PREGUNTAS_ANTES_DEL_DICTAMEN', 'REVIEW'], ['outside-read', 'AISLAMIENTO_RUTAS', 'FAIL'], ['extra-tool', 'AISLAMIENTO_HERRAMIENTAS', 'FAIL'], ['prose-no-table', 'FILAS_37', 'FAIL']
]) { const r = run(scenario); t(`e2e ${scenario}: ${check} -> ${expected}`, status(r, check).includes(expected), JSON.stringify(r.findings.map(f => f.check + ':' + f.status)) || r.error); }
const zero = run('zero-denominator-ok'); t('e2e zero denominator "no calculable" accepted', status(zero, 'METRICA')[0] === 'PASS', JSON.stringify(zero.by('METRICA')));
const zeroBad = run('zero-denominator-bad'); t('e2e zero denominator reported as 0 % is rejected', status(zeroBad, 'METRICA')[0] === 'FAIL', JSON.stringify(zeroBad.by('METRICA')));
const missing = run('missing-row');
t('e2e: nothing is repaired (missing row case keeps 36 valid rows)', Object.values(missing.report?.evaluation.pages[0].counts ?? {}).reduce((a, b) => a + b, 0) === 36);
t('review sheet never assigns a cause', good.report?.reviewSheet.items.every(i => i.attribution === 'PENDIENTE_DE_REVISION' && i.decision === null) === true);
t('run refuses without validated isolation (no --allow-unvalidated)', (() => { const r = spawnSync(process.execPath, [join(QA, 'controller', 'run.mjs'), 'run', 'c15-evidence-free', '--model', 'selftest-double'], { env: FAKE_ENV, encoding: 'utf8' }); return r.status === 4 && /NO validado/.test(r.stderr); })());

// ======================= conversation state machine =======================
const pf = run('provisional-then-final');
t('conversation: provisional evaluation with a question continues to final', conv(pf)?.states.join() === 'PROVISIONAL_EVALUATION,FINAL_EVALUATION' && conv(pf).stopReason === 'FINAL', JSON.stringify(conv(pf)?.states));
t('conversation: both verdict versions kept and the changed rules recorded', conv(pf)?.versions.length === 2 && conv(pf).diffs[0].changedRules.length === 2 && conv(pf).diffs[0].changedRules.every(c => c.from === 'No verificable' && c.to === 'Cumple'), JSON.stringify(conv(pf)?.diffs));
t('conversation: the table is not treated as final while a question is pending', status(pf, 'PREGUNTAS_ANTES_DEL_DICTAMEN')[0] === 'PASS', JSON.stringify(status(pf, 'PREGUNTAS_ANTES_DEL_DICTAMEN')));
t('conversation: final report is the LAST version (metric uses the updated rows)', status(pf, 'METRICA')[0] === 'PASS' && pf.report.evaluation.pages[0].counts['Cumple'] === 12);
const rq = run('repeated-question');
t('conversation: repeated question stops the loop', conv(rq)?.stopReason === 'STOPPED_REPEATED_QUESTION' && status(rq, 'CONVERSACION')[0] === 'FAIL', JSON.stringify(conv(rq)?.stopReason));
const en = run('endless-new-questions', 'c15-evidence-free', ['--max-turns', '3']);
t('conversation: turn limit stops endless new questions', conv(en)?.stopReason === 'STOPPED_MAX_TURNS' && en.report.evaluation.usage.turns === 3, JSON.stringify(conv(en)?.stopReason));
const np = run('no-progress');
t('conversation: identical verdict after a reply stops as no progress', conv(np)?.stopReason === 'STOPPED_NO_PROGRESS', JSON.stringify(conv(np)?.stopReason));
const cp = run('conditional-promise-only');
t('conversation: a conditional promise ("cuando..., te preguntaré") is not a pending question', conv(cp)?.states.join() === 'FINAL_EVALUATION', JSON.stringify(conv(cp)?.states));
const tn = run('template-not-evaluable', 'c14-zero-applicable');
t('pure template reported as not evaluable passes', status(tn, 'PAGINA_NO_EVALUABLE')[0] === 'PASS' && status(tn, 'TRAZABILIDAD_PAGINA')[0] === 'PASS', JSON.stringify(tn.findings.map(f => f.check + ':' + f.status)));
t('pure template: trace needs ID, title, type and reason', status(tn, 'TRAZABILIDAD_PAGINA')[0] === 'PASS' && tn.by('TRAZABILIDAD_PAGINA')[0].trace.id && tn.by('TRAZABILIDAD_PAGINA')[0].trace.kind);
t('pure template: no 37 rows, no percentage', tn.report.evaluation.pages.length === 0 && status(tn, 'SIN_METRICA_NORMATIVA')[0] === 'PASS');
const te = run('template-evaluated', 'c14-zero-applicable');
t('37-rule evaluation of a pure template is flagged against the approved criterion', status(te, 'PAGINA_NO_EVALUABLE')[0] === 'FAIL');
t('expectations: absent-population rules are compared per rule', status(good, 'RESULTADOS_ESPERADOS_TECNICOS').length === 1);

// ======================= telemetry =======================
const tel = good.telemetry;
t('telemetry: per-turn record with model, version and tokens', tel?.perTurn.length === 2 && tel.perTurn[0].model === 'fake-model' && tel.perTurn[0].cliVersion === '0.0.0-double' && tel.perTurn[0].outputTokens === 50);
t('telemetry: turn cost is the DIFFERENCE of cumulative costs (Fase 1 summed cumulative values by mistake)', Math.abs(tel.perTurn.reduce((n, r) => n + r.costUsdTurn, 0) - tel.perTurn.at(-1).costUsdCumulative) < 1e-9 && Math.abs(tel.totals.costUsd - tel.perTurn.at(-1).costUsdCumulative) < 1e-9);
t('telemetry: implied-price split reconciles with the reported cost', Math.abs(tel.reconciliation.differenceUsd) < 1e-9, JSON.stringify(tel.reconciliation));
t('telemetry: totals sum per-turn usage', tel.totals.outputTokens === 150 && tel.totals.cacheReadTokens === 3000 && tel.totals.totalTokens === tel.perTurn.reduce((n, r) => n + r.totalTokens, 0));
t('telemetry: input metrics (compact size, pages, components, rules) recorded', tel.inputs.pages === 1 && tel.inputs.components === 3 && typeof tel.inputs.compactBytes === 'number' && tel.inputs.rulesEvaluated === 37, JSON.stringify(tel.inputs));
t('telemetry: unavailable metrics are labelled, never estimated', tel.perTurn[0].rateLimit === 'NO DISPONIBLE' && tel.unavailable.length > 0);
t('telemetry: the note says the reported cost is not a charge', /no es un cargo/i.test(tel.note));
t('telemetry: per-API-call usage is captured when the stream exposes it', typeof tel.perTurn[0].apiCallsObserved === 'number');
t('telemetry: conversation summary (questions, answers by source, verdict versions, changes)', tel.conversation && tel.conversation.totalQuestions >= 1 && Array.isArray(tel.conversation.verdictVersions) && Array.isArray(tel.conversation.changesBetweenVersions), JSON.stringify(tel.conversation));

// ======================= v11.2.2: UNRESOLVED, contradiction question, population expectations =======================
const ua = run('unresolved-asks-then-evaluates');
t('UNRESOLVED: asks for classification review before any verdict, then evaluates after confirmation', status(ua, 'CLASIFICACION_SOLICITADA')[0] === 'PASS' && status(ua, 'SIN_DICTAMEN_DEFINITIVO_PREVIO')[0] === 'PASS' && conv(ua)?.states.join() === 'AWAITING_ANALYST_INPUT,FINAL_EVALUATION', JSON.stringify(conv(ua)?.states));
t('UNRESOLVED: the confirmation is a substantive answer and provenance is demanded', status(ua, 'PROCEDENCIA')[0] === 'PASS' && !ua.report.evaluation.conversation.suspension);
t('UNRESOLVED: technical absent-population rules are within expectations', status(ua, 'RESULTADOS_ESPERADOS_TECNICOS')[0] === 'PASS' && status(ua, 'RESULTADOS_ESPERADOS_NORMATIVOS')[0] === 'PASS', JSON.stringify(ua.by('RESULTADOS_ESPERADOS_NORMATIVOS')));
const up = run('unresolved-final-premature');
t('UNRESOLVED: a definitive verdict without asking is flagged', status(up, 'SIN_DICTAMEN_DEFINITIVO_PREVIO')[0] === 'FAIL' && status(up, 'CLASIFICACION_SOLICITADA')[0] === 'FAIL');
const cq = run('contradiction-question');
t('contradiction between kind and operation: the confirmation question is understood and answered', status(cq, 'CLASIFICACION_SOLICITADA')[0] === 'PASS' && !cq.report.evaluation.conversation.suspension && cq.report.evaluation.conversation.stopReason === 'FINAL');
const mq = run('c15-mq-na');
t('MQ rules reported No aplica are a REVIEW item, not an automatic technical failure', status(mq, 'RESULTADOS_ESPERADOS_TECNICOS')[0] === 'PASS' && status(mq, 'RESULTADOS_ESPERADOS_NORMATIVOS')[0] === 'REVIEW' && mq.by('RESULTADOS_ESPERADOS_NORMATIVOS')[0].rows.length === 1, JSON.stringify(mq.by('RESULTADOS_ESPERADOS_NORMATIVOS')[0]?.rows?.map(r => r.id)));
t('MQ review rows carry the technical-convention note', mq.by('RESULTADOS_ESPERADOS_NORMATIVOS')[0].rows.every(r => r.assumption === null || typeof r.assumption === 'string'));
const ca = run('c15-com002-nv');
t('a rule whose own No aplica text is demonstrably met (COM-002) is a technical failure when answered otherwise', status(ca, 'RESULTADOS_ESPERADOS_TECNICOS')[0] === 'FAIL' && ca.by('RESULTADOS_ESPERADOS_TECNICOS')[0].rows[0].id === 'COM-002');
const anv = run('c15-all-nv');
t('"All 37 No verificable" is not accepted as the single right answer (per-rule population)', status(anv, 'RESULTADOS_ESPERADOS_TECNICOS')[0] === 'FAIL' && anv.by('RESULTADOS_ESPERADOS_TECNICOS')[0].rows.length === 3);
const ut = run('unresolved-asks-type');
t('UNRESOLVED: the real phrasing "¿Cuál es su tipo: OPERATIONAL, MIXED, …?" is recognised and answered (seen in the first v11.2.2 run)', status(ut, 'CLASIFICACION_SOLICITADA')[0] === 'PASS' && !ut.report.evaluation.conversation.suspension && ut.report.evaluation.conversation.states.join() === 'AWAITING_ANALYST_INPUT,FINAL_EVALUATION' && status(ut, 'PROCEDENCIA')[0] === 'PASS', JSON.stringify(ut.report?.evaluation.conversation));
t('reevaluate never overwrites the original report (writes to a new folder)', (() => { const dir = join(QA, 'runs', 'selftest-unresolved-asks-then-evaluates', 'c15-evidence-free'); const before = readFileSync(join(dir, 'report.json'), 'utf8'); const r = spawnSync(process.execPath, [join(QA, 'controller', 'run.mjs'), 'reevaluate', 'selftest-unresolved-asks-then-evaluates', 'c15-evidence-free'], { env: FAKE_ENV, encoding: 'utf8' }); return r.status === 0 && readFileSync(join(dir, 'report.json'), 'utf8') === before && existsSync(join(dir, 'reeval')); })());

// ======================= Fase 2: unmapped analyst questions, script vs controller replies, wordings =======================
const runResume = (runId, caseId, extra) => spawnSync(process.execPath, [join(QA, 'controller', 'run.mjs'), 'resume', runId, caseId, ...extra], { env: FAKE_ENV, encoding: 'utf8' });
const um = run('unmapped-question');
const umS = um.report?.evaluation.conversation;
t('UNMAPPED_ANALYST_QUESTION: the run is suspended and the literal question is kept', umS?.stopReason === 'SUSPENDED_UNMAPPED_ANALYST_QUESTION' && umS.suspension?.code === 'UNMAPPED_ANALYST_QUESTION' && umS.suspension.questions[0] === '¿Qué versión del esquema de integración usa el equipo?' && umS.suspension.turn === 1 && umS.suspension.caseId === 'c15-evidence-free', JSON.stringify(umS?.suspension));
t('UNMAPPED_ANALYST_QUESTION: exit code 5 (suspended), not an error', um.exit === 5, String(um.exit));
t('UNMAPPED_ANALYST_QUESTION: no reply is invented (no second turn, no reply recorded)', um.report?.evaluation.usage.turns === 1 && um.telemetry?.conversation.substantiveAnswers === 0 && Object.keys(um.telemetry?.conversation.replySources ?? {}).length === 0);
t('UNMAPPED_ANALYST_QUESTION: reported as a REVIEW finding that asks to review the script', status(um, 'UNMAPPED_ANALYST_QUESTION')[0] === 'REVIEW' && /resume/.test(um.by('UNMAPPED_ANALYST_QUESTION')[0].action) && status(um, 'FILAS_37').length === 0);
t('UNMAPPED_ANALYST_QUESTION: the history (transcript) is preserved', existsSync(join(QA, 'runs', 'selftest-unmapped-question', 'c15-evidence-free', 'transcript.json')) && JSON.parse(readFileSync(join(QA, 'runs', 'selftest-unmapped-question', 'c15-evidence-free', 'transcript.json'), 'utf8')).turns.length === 1);
const originalReport = readFileSync(join(QA, 'runs', 'selftest-unmapped-question', 'c15-evidence-free', 'report.json'), 'utf8');
const rr = runResume('selftest-unmapped-question', 'c15-evidence-free', ['--reply', 'La versión del esquema es la 3.', '--substantive']);
const contDir = join(QA, 'runs', 'selftest-unmapped-question', 'c15-evidence-free', 'continued');
const cont = existsSync(contDir) ? JSON.parse(readFileSync(join(contDir, readdirSync(contDir)[0], 'report.json'), 'utf8')) : null;
t('resume continues a suspended run with a manual reply recorded as MANUAL_RESUME', rr.status === 0 && cont?.evaluation.conversation.stopReason === 'FINAL' && cont.evaluation.usage.turns === 2 && JSON.stringify(cont.evaluation.conversation.resumedFrom).includes('MANUAL_RESUME'), rr.stderr + JSON.stringify(cont?.evaluation.conversation?.resumedFrom));
t('resume never overwrites the original report', readFileSync(join(QA, 'runs', 'selftest-unmapped-question', 'c15-evidence-free', 'report.json'), 'utf8') === originalReport);
const su = run('script-unknown');
const sources = su.telemetry?.conversation.replySources ?? {};
t('a scripted "no sé" is labelled SCRIPT_UNKNOWN and no controller fallback exists', (sources.SCRIPT_UNKNOWN ?? 0) >= 1 && !Object.keys(sources).some(key => /FALLBACK|CONTROLLER/.test(key)), JSON.stringify(sources));
for (const [question, expectedTopics] of [
  ['¿La API principal está en MCI?', ['mciPrincipal']], ['¿El componente principal está en MCI o no?', ['mciPrincipal']], ['¿El servicio hijo principal está en MCI?', ['mciHijo']], ['¿Está el hijo principal dentro de MCI?', ['mciHijo']],
  ['¿La API principal y el servicio hijo están en MCI?', ['mciPrincipal', 'mciHijo']], ['¿Cuál es la exposición de la API (Private, Public o Partner)?', ['exposicion']], ['¿La API es Public?', ['exposicion']],
  ['¿Qué tipo tiene la página «x»?', ['pageClassification']], ['¿Cuál es su tipo: OPERATIONAL, MIXED?', ['pageClassification']], ['¿Confirmas que es una operación real que debe evaluarse?', ['pageClassification']],
  ['¿Qué componente cumple la función de principal en esta página?', ['principalIdentity']], ['¿Quieres que reutilice las respuestas de la página A en la página B?', ['reuseConfirmation']],
  ['¿Qué versión del esquema de integración usa el equipo?', []], ['¿Cuál es el nombre del equipo dueño?', []], ['¿Puedes enviarme el diagrama original?', []]
]) t(`wording → ${expectedTopics.join('+') || 'UNMAPPED'}: ${question.slice(0, 55)}`, JSON.stringify(topicsOf(question)) === JSON.stringify(expectedTopics), JSON.stringify(topicsOf(question)));
const ctxMsg = '1. **MCI de la API principal** `Transferencias - Fondos`: ¿está desplegada en MCI (sí o no)?\n2. **MCI del hijo principal** `ms-x`: ¿está desplegado en MCI (sí o no)?';
t('wording with its subject in the introducing line (seen in the P2 run): the line gives the topic', JSON.stringify(topicsWithContext('¿está desplegada en MCI (sí o no)?', ctxMsg)) === JSON.stringify(['mciPrincipal']) && JSON.stringify(topicsWithContext('¿está desplegado en MCI (sí o no)?', ctxMsg)) === JSON.stringify(['mciHijo']), JSON.stringify([topicsWithContext('¿está desplegada en MCI (sí o no)?', ctxMsg), topicsWithContext('¿está desplegado en MCI (sí o no)?', ctxMsg)]));
t('a question with no context and no topic stays unmapped', topicsWithContext('¿Qué versión del esquema usa el equipo?', 'texto sin relación').length === 0);
const pages = ['consultarClientePorId', 'actualizarClienteContacto'];
const msg = '### Página «consultarClientePorId»\n- ¿La API principal está en MCI?\n\n### Página «actualizarClienteContacto»\n- ¿La API principal está en MCI?';
t('page attribution: identical question wordings under two pages are attributed in order', JSON.stringify(attributeAll(msg, ['¿La API principal está en MCI?', '¿La API principal está en MCI?'], pages)) === JSON.stringify([['consultarClientePorId'], ['actualizarClienteContacto']]), JSON.stringify(attributeAll(msg, ['¿La API principal está en MCI?', '¿La API principal está en MCI?'], pages)));
t('page attribution: a question naming a page keeps it', JSON.stringify(attributeAll(msg, ['¿La API de actualizarClienteContacto está en MCI?'], pages)) === JSON.stringify([['actualizarClienteContacto']]));

// ======================= Fase 2: pilot cases =======================
const p1 = run('pilot-good', 'p1-operational');
t('P1: all three questions recognised for the page, 37 rows, metric, provenance, scenario', ['PREGUNTAS_POR_PAGINA', 'FILAS_37', 'METRICA', 'PROCEDENCIA', 'ESCENARIO_COHERENTE_CON_EL_JSON'].every(n => status(p1, n).length && status(p1, n).every(x => x === 'PASS')), JSON.stringify(p1.findings.filter(f => f.status !== 'PASS' && f.status !== 'INFO').map(f => f.check + ':' + f.status)));
t('P1: provable absent-population rules (COM-002..004) are checked as technical', status(p1, 'RESULTADOS_ESPERADOS_TECNICOS')[0] === 'PASS');
const p2l = run('pilot-legend-misuse', 'p2-mixed');
t('P2: a Cumple that rests on a legend figure is a FAIL', status(p2l, 'LEYENDA_COMO_EVIDENCIA_NORMATIVA')[0] === 'FAIL' && p2l.by('LEYENDA_COMO_EVIDENCIA_NORMATIVA')[0].rows.includes('MQ-001'), JSON.stringify(p2l.by('LEYENDA_COMO_EVIDENCIA_NORMATIVA')));
const p2g = run('pilot-good-noexposure', 'p2-mixed');
t('P2: clean run — no legend evidence, no question about the accredited exposure', status(p2g, 'LEYENDA_COMO_EVIDENCIA_NORMATIVA')[0] === 'PASS' && status(p2g, 'PREGUNTAS_NO_PROCEDENTES_POR_PAGINA')[0] === 'PASS' && status(p2g, 'PREGUNTAS_POR_PAGINA')[0] === 'PASS', JSON.stringify(p2g.findings.filter(f => f.status !== 'PASS' && f.status !== 'INFO').map(f => f.check + ':' + f.status)));
const p2x = run('pilot-good', 'p2-mixed');
t('P2: asking for an exposure the diagram already accredits (and the script does not know) suspends the run instead of inventing an answer', status(p2x, 'UNMAPPED_ANALYST_QUESTION')[0] === 'REVIEW' && p2x.report.evaluation.usage.turns === 1);
const p3 = run('pilot-contradiction', 'p3-contradiction');
t('P3: contradiction detected, evidence cited, confirmation requested, no verdict before the reply', ['CONTRADICCION_DETECTADA', 'EVIDENCIA_CITADA_EN_LA_CONTRADICCION', 'CONFIRMACION_SOLICITADA', 'SIN_DICTAMEN_DEFINITIVO_PREVIO', 'OPERACION_NO_DESCARTADA'].every(n => status(p3, n)[0] === 'PASS'), JSON.stringify(p3.findings.filter(f => /CONTRAD|CONFIRM|DICTAMEN|OPERACION/.test(f.check)).map(f => f.check + ':' + f.status)));
t('P3: after the confirmation the page is evaluated with 37 rows and provenance', status(p3, 'FILAS_37')[0] === 'PASS' && status(p3, 'PROCEDENCIA')[0] === 'PASS', JSON.stringify(p3.findings.filter(f => /FILAS|PROCEDENCIA|CONVERSACION/.test(f.check)).map(f => f.check + ':' + f.status + ':' + f.detail)));
const p3p = run('pilot-contradiction-premature', 'p3-contradiction');
t('P3: a verdict before any confirmation is a FAIL', status(p3p, 'SIN_DICTAMEN_DEFINITIVO_PREVIO')[0] === 'FAIL' && status(p3p, 'CONFIRMACION_SOLICITADA')[0] === 'FAIL');
const p3d = run('pilot-contradiction-silent-discard', 'p3-contradiction');
t('P3: silently discarding the operation without asking is a FAIL', status(p3d, 'OPERACION_NO_DESCARTADA')[0] === 'FAIL' && status(p3d, 'CONTRADICCION_DETECTADA')[0] === 'FAIL');
const p4 = run('pilot-good', 'p4-multipage');
t('P4: questions are recognised page by page (titles attributed from the preceding heading)', status(p4, 'PREGUNTAS_POR_PAGINA')[0] === 'PASS' && status(p4, 'PREGUNTAS_NO_PROCEDENTES_POR_PAGINA')[0] === 'PASS', JSON.stringify(p4.by('PREGUNTAS_POR_PAGINA')[0]?.missing) + JSON.stringify(p4.by('PREGUNTAS_NO_PROCEDENTES_POR_PAGINA')[0]?.forbidden));
t('P4: two pages with 37 rows each and the weighted consolidated percentage', status(p4, 'PAGINAS_EVALUADAS_CON_37')[0] === 'PASS' && status(p4, 'PORCENTAJE_CONSOLIDADO')[0] === 'PASS', JSON.stringify(p4.by('PORCENTAJE_CONSOLIDADO')));
t('P4: provenance is registered in each page section', status(p4, 'PROCEDENCIA_POR_PAGINA')[0] === 'PASS', JSON.stringify(p4.by('PROCEDENCIA_POR_PAGINA')));
const p4n = run('pilot-naive-mean', 'p4-multipage');
t('P4: the mean of page percentages instead of the weighted one is a FAIL', status(p4n, 'PORCENTAJE_CONSOLIDADO')[0] === 'FAIL' && /promedio simple/.test(p4n.by('PORCENTAJE_CONSOLIDADO')[0].detail), JSON.stringify(p4n.by('PORCENTAJE_CONSOLIDADO')));
t('P4: per-page rule expectations are applied page by page', p4.by('RESULTADOS_ESPERADOS_TECNICOS').length === 2);

// ======================= preflight =======================
const pf1 = spawnSync(process.execPath, [join(QA, 'controller', 'run.mjs'), 'preflight', '--model', 'opus'], { encoding: 'utf8' });
t('preflight: the Skill hash, ZIP, isolation record, cases, scripts and canaries are consistent', pf1.status === 0 && /0 FAIL/.test(pf1.stdout), pf1.stdout.split('\n').filter(l => l.startsWith('FAIL')).join(' | '));
t('preflight: refuses a model whose isolation was never validated', (() => { const r = spawnSync(process.execPath, [join(QA, 'controller', 'run.mjs'), 'preflight', '--model', 'other-model', '--cases', 'p1-operational'], { encoding: 'utf8' }); return r.status === 1 && /aislamiento validado para el modelo "other-model"/.test(r.stdout.split('\n').filter(l => l.startsWith('FAIL')).join()); })());

const autoResume = runResume('selftest-pilot-good', 'p2-mixed', []);
t('resume without --reply uses the script only: if it still cannot answer, it stays suspended (exit 5) and invents nothing', autoResume.status === 5 && /sigue sin poder responder/.test(autoResume.stderr), autoResume.stderr + autoResume.status);
t('metric parser: number-first counts ("3 Cumple · 2 No cumple …") are read', (() => { const x = parseReportedMetric('**Conteo de pb:** 3 Cumple · 2 No cumple · 21 No verificable · 15 No aplica, que suman 41.'); return x.counts['Cumple'] === 3 && x.counts['No cumple'] === 2 && x.counts['No verificable'] === 21 && x.counts['No aplica'] === 15; })());
t('metric parser: a totals table gives each page its own row, chosen by page reference', (() => { const table = '| | Cumple | No cumple | No verificable | No aplica | Cumplimiento |\n|---|---:|---:|---:|---:|---:|\n| pa | 4 | 5 | 18 | 14 | 14,8 % |\n| pb | 3 | 2 | 21 | 15 | 11,5 % |'; const b = parseReportedMetric(table, { pageRefs: ['actualizarClienteContacto', 'pb'] }); const none = parseReportedMetric(table, { pageRefs: ['otra'] }); return b.counts['Cumple'] === 3 && b.counts['No verificable'] === 21 && Object.keys(none.counts).length === 0; })());
t('page segments end before the "Total del blueprint" section', (() => { const text = '## Página `pa` · consultarClientePorId\n| CNT-001 | Cumple | e | j | - |\n\n## Página `pb` · actualizarClienteContacto\n| CNT-001 | Cumple | e | j | - |\n\n## Total del blueprint\n| pa | 4 | 5 |'; const seg = splitByPages(text, ['consultarClientePorId', 'actualizarClienteContacto']); return seg.length === 2 && !seg[1].text.includes('Total del blueprint'); })());
t('cited identifiers written as `[id]` are verified against the JSON (seen in the P3 run)', (() => { const compact = JSON.stringify({ pages: [{ components: [{ id: 'p3-prod' }] }] }); return /^[\[(]+|[\])]+$/g.test('[p3-prod]') && '[p3-prod]'.replace(/^[\[(]+|[\])]+$/g, '') === 'p3-prod' && compact.includes('p3-prod'); })());
t('telemetry: multi-page cases count the rules evaluated per page (74 for two pages), not the collapsed rule IDs', p4.telemetry?.inputs.rulesEvaluated === 74, String(p4.telemetry?.inputs.rulesEvaluated));
// ---- v11.2.3 validation: count layouts seen in the v11.2.2 comparison runs (the reports were right; the controller misread them)
t('metric parser: counts given in one sentence ("5 reglas que cumplen, 5 que no cumplen, 13 que no se pueden verificar y 18 que no aplican") and a later "cumple 21,7 %" do not collide', (() => { const x = parseReportedMetric('La página tiene **5 reglas que cumplen, 5 que no cumplen, 13 que no se pueden verificar y 18 que no aplican**. El cumplimiento es de **21,74 %**.\nLa página cumple **21,7 %** de las reglas.'); return x.counts['Cumple'] === 5 && x.counts['No cumple'] === 5 && x.counts['No verificable'] === 13 && x.counts['No aplica'] === 18; })());
t('metric parser: a table with one row per state ("| Cumple | 5 | 5 |") is read before any loose match', (() => { const x = parseReportedMetric('| Estado | Página | Blueprint |\n|---|---|---|\n| Cumple | 5 | 5 |\n| No cumple | 5 | 5 |\n| No verificable | 13 | 13 |\n| No aplica | 18 | 18 |\nEl cumplimiento es 21,74 %.'); return x.counts['Cumple'] === 5 && x.counts['No aplica'] === 18; })());
t('metric parser: "6 Cumple, 4 No cumple, 13 No verificable y 18 No aplica" is read in order', (() => { const x = parseReportedMetric('**Resultado:** 6 Cumple, 4 No cumple, 13 No verificable y 18 No aplica, con un cumplimiento del **26,09 %**.'); return x.counts['Cumple'] === 6 && x.counts['No cumple'] === 4 && x.counts['No verificable'] === 13 && x.counts['No aplica'] === 18; })());
t('metric parser: the loose search is still the fallback when no complete layout exists', (() => { const x = parseReportedMetric('Conteos: Cumple 13; No cumple 0; No verificable 13; No aplica 15.'); return x.counts['Cumple'] === 13 && x.counts['No aplica'] === 15; })());
t('metric parser: a header table of states wins over "cumple **21,7 %**" in the prose above it (seen in the v11.2.2 case C run)', (() => { const x = parseReportedMetric('**Resultado:** la página `vc` cumple **21,7 %** de las reglas aplicables: 5 cumplen de 23.\n| Página | Cumple | No cumple | No verificable | No aplica | Total | Cumplimiento |\n|---|---|---|---|---|---|---|\n| `vc` | 5 | 5 | 13 | 18 | 37 | **21,7 %** |\n| **Blueprint** | 5 | 5 | 13 | 18 | 37 | **21,7 %** |', { pageRefs: ['vc'] }); return x.counts['Cumple'] === 5 && x.counts['No cumple'] === 5 && x.counts['No verificable'] === 13 && x.counts['No aplica'] === 18; })());
console.log(`\n${pass} PASS, ${fail} FAIL`);
process.exit(fail ? 1 : 0);
