// Self-test of the normative comparison with synthetic catalogs (no corporate text). Run: node qa/tools/compare-normative.selftest.mjs
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { join, resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { COLUMNS, compare, contractFields, loadCatalog, loadMatrix, parseCsv, renderMarkdown } from './compare-normative.mjs';

const REPO = resolve(dirname(fileURLToPath(import.meta.url)), '..', '..'), REFS = join(REPO, 'skills', 'validar-blueprint-integracion', 'references');
const header = COLUMNS.join(',');
const row = (id, over = {}) => { const base = { id, familia: id.split('-')[0], titulo: `Titulo ${id}`, resumen: 'Resumen', aplica_a: 'Poblacion', criterio: 'Criterio', evidencia: 'Evidencia', no_cumple: 'NC', no_verificable: 'NV', no_aplica: 'NA', ...over }; return COLUMNS.map(column => `"${base[column].replace(/"/g, '""')}"`).join(','); };
const csv = (...rows) => [header, ...rows].join('\n');
let pass = 0, fail = 0;
const t = (name, fn) => { try { fn(); pass++; console.log(`PASS  ${name}`); } catch (error) { fail++; console.log(`FAIL  ${name}\n      ${error.message.split('\n')[0]}`); } };

const matrix = loadMatrix('| rule_id | Evidencia requerida | Campo compacto | Respuesta humana |\n|---|---|---|---|\n| X-001 | algo | `scenario`, `inexistente` | No |\n| X-002 | algo | `textAreas` | MCI principal |\n');
const fields = new Set(['scenario', 'textAreas']);

t('parseCsv handles quotes, commas and embedded line breaks', () => { const rows = parseCsv('a,b\n"x, y","l1\nl2"\n'); assert.deepEqual(rows[1], ['x, y', 'l1\nl2']); });
t('identical catalogs produce no differences', () => { const c = loadCatalog(csv(row('X-001'), row('X-002'))); const r = compare(c, c, matrix, fields); assert.equal(r.counts.changed + r.counts.added + r.counts.removed, 0); assert.equal(r.counts.unchanged, 2); });
t('added and removed IDs are detected', () => { const r = compare(loadCatalog(csv(row('X-001'), row('X-002'))), loadCatalog(csv(row('X-001'), row('X-003'))), matrix, fields); assert.deepEqual(r.added, ['X-003']); assert.deepEqual(r.removed, ['X-002']); });
t('a change is attributed to the right dimension', () => {
  const old = loadCatalog(csv(row('X-001'), row('X-002'), row('X-004'), row('X-005')));
  const now = loadCatalog(csv(row('X-001', { titulo: 'Otro titulo' }), row('X-002', { aplica_a: 'Otra poblacion' }), row('X-004', { evidencia: 'Otra evidencia' }), row('X-005', { no_verificable: 'Otro NV' })));
  const dims = Object.fromEntries(compare(old, now).changed.map(item => [item.id, item.dimensions.join()]));
  assert.deepEqual(dims, { 'X-001': 'texto', 'X-002': 'aplicabilidad', 'X-004': 'evidencia', 'X-005': 'criterio' });
});
t('whitespace-only differences are ignored', () => { const r = compare(loadCatalog(csv(row('X-001', { criterio: 'a   b' }))), loadCatalog(csv(row('X-001', { criterio: 'a b ' })))); assert.equal(r.counts.changed, 0); });
t('same title with a different ID is reported only as a possible rename', () => { const r = compare(loadCatalog(csv(row('X-001', { titulo: 'Mismo' }))), loadCatalog(csv(row('Y-001', { titulo: 'Mismo' })))); assert.deepEqual(r.possibleRenames, [{ oldId: 'X-001', newId: 'Y-001' }]); assert.deepEqual(r.added, ['Y-001']); });
t('evidence availability: mapped, unmapped and undocumented fields', () => {
  const r = compare(loadCatalog(csv(row('X-002'))), loadCatalog(csv(row('X-001'), row('X-002', { criterio: 'nuevo' }), row('X-009'))), matrix, fields);
  const by = Object.fromEntries(r.evidence.map(item => [item.id, item.availability]));
  assert.equal(by['X-001'], 'CAMPO_NO_DOCUMENTADO'); assert.equal(by['X-002'], 'DISPONIBLE_EN_CONTRATO'); assert.equal(by['X-009'], 'SIN_MAPEO');
});
t('missing columns and duplicate IDs are reported, not hidden', () => { assert.throws(() => loadCatalog('id,familia\nX-001,X\n'), /faltan columnas/); assert.deepEqual(loadCatalog(csv(row('X-001'), row('X-001'))).duplicates, ['X-001']); });
t('the real current catalog compares equal to itself and its 41 rules all map to compact fields', () => {
  const text = readFileSync(join(REFS, 'catalogo-reglas-v11.2.csv'), 'utf8');
  const current = loadCatalog(text), same = loadCatalog(text), matrixReal = loadMatrix(readFileSync(join(REFS, 'MATRIZ-EVIDENCIA-41.md'), 'utf8')), fieldsReal = contractFields(readFileSync(join(REFS, 'CONTRATO-COMPACTO.md'), 'utf8'));
  assert.equal(current.map.size, 41);
  const r = compare(current, same, matrixReal, fieldsReal);
  assert.equal(r.counts.unchanged, 41);
  const forced = compare(loadCatalog('id,familia,titulo,resumen,aplica_a,criterio,evidencia,no_cumple,no_verificable,no_aplica\n'), current, matrixReal, fieldsReal);
  assert.equal(forced.added.length, 41);
  assert.equal(forced.evidence.filter(item => item.availability === 'SIN_MAPEO').length, 0);
  assert.deepEqual(forced.evidence.filter(item => item.availability === 'CAMPO_NO_DOCUMENTADO').map(item => `${item.id}:${item.unknownFields}`), [], 'campos de la matriz ausentes del diccionario');
});
t('markdown report names each changed dimension and never invents rule text', () => { const r = compare(loadCatalog(csv(row('X-001'))), loadCatalog(csv(row('X-001', { criterio: 'nuevo criterio' }), row('X-002'))), matrix, fields); const md = renderMarkdown(r); assert.match(md, /### X-001/); assert.match(md, /criterio · criterio/); assert.match(md, /antes: Criterio/); assert.match(md, /ahora: nuevo criterio/); assert.match(md, /No se infiere ninguna regla/); });

console.log(`\n${pass} PASS, ${fail} FAIL`);
process.exit(fail ? 1 : 0);
