# Propuesta de ajuste de la Skill (aplicada en v11.2.2)

Estado: **aplicada en la Skill v11.2.2** (con las diferencias indicadas en `qa/DECISIONES.md`, D7–D9). Se conserva como registro de la propuesta original.

## 1. La contradicción actual

| Archivo | Texto vigente |
|---|---|
| `SKILL.md`, paso 6 | "Evaluar exactamente las 41 reglas por cada página seleccionada." |
| `references/00-procedimiento.md`, flujo, paso 1 | "Confirmar que la página está seleccionada y no es plantilla pura." |

Una página `TEMPLATE_OR_LEGEND` seleccionada queda cubierta por las dos frases con efectos opuestos. En la ejecución real de c14 el agente aplicó la primera: entregó 41 filas "No aplica".

## 2. Cambio exacto propuesto (decisión aprobada)

### 2.1 `SKILL.md`, paso 6

Antes:
```
6. Evaluar exactamente las 41 reglas por cada página seleccionada. Estados únicos: `Cumple`, `No cumple`, `No verificable` y `No aplica`. Evidencia parcial, ambigua, incompleta o contradictoria es `No verificable` e indica lo faltante.
```
Después:
```
6. Evaluar exactamente las 41 reglas por cada página seleccionada y evaluable. Una página con `pageClassification.kind` = `TEMPLATE_OR_LEGEND` es no evaluable: informar su ID, título, `kind` y el motivo, sin filas de reglas, sin conteos y sin porcentaje, y excluirla del total. En una página `MIXED` evaluar solo los componentes de la operación real y excluir las figuras de `pageClassification.legendShapeIds`. Estados únicos: `Cumple`, `No cumple`, `No verificable` y `No aplica`. Evidencia parcial, ambigua, incompleta o contradictoria es `No verificable` e indica lo faltante.
```

### 2.2 `SKILL.md`, paso 8

Antes: `... 41 resultados por página, conteos, porcentaje, evidencia pendiente y recomendaciones. Verificar IDs únicos, estados válidos y suma 41.`
Después: `... 41 resultados por página evaluada, las páginas no evaluables con su motivo, conteos, porcentaje, evidencia pendiente y recomendaciones. Verificar IDs únicos, estados válidos y suma 41 en cada página evaluada.`

### 2.3 `references/00-procedimiento.md`, flujo, paso 1

Antes: `1. Confirmar que la página está seleccionada y no es plantilla pura.`
Después:
```
1. Confirmar que la página está seleccionada. Si `pageClassification.kind` es `TEMPLATE_OR_LEGEND`, informarla como no evaluable (ID, título, `kind`, motivo) y no ejecutar los pasos 2 a 6 sobre ella. Si es `MIXED`, excluir las figuras de `pageClassification.legendShapeIds`.
```

## 3. Ajustes recomendados, no solicitados explícitamente

Se proponen aparte porque cambian guía, no obligaciones. Decida Andrés / la analista.

| # | Motivo | Cambio mínimo |
|---|---|---|
| A | La ejecución de c15 trató como "No verificable" las reglas MQ-001…004 aunque la página no tiene ninguna figura de gestor. `CONTRATO-COMPACTO.md` solo dice que `architecturalType: null` no certifica tipo, y no dice cómo se reconoce un gestor. | En `CONTRATO-COMPACTO.md`, añadir bajo `architecturalType`: "`GESTOR_COLAS` corresponde a la figura `UMLActiveClassBlock` (`lucidchartType`). Si ningún componente tiene esa figura, la población de gestores de colas está ausente y las reglas MQ se evalúan como No aplica." |
| B | La Skill no dice qué hacer con una población vacía. | En `00-procedimiento.md`, estados: "No aplica: la población de la regla está demostrablemente ausente (no existe ninguna figura de esa clase). Si la población podría existir pero no se puede verificar, es No verificable." |
| C | `CONTRATO-COMPACTO.md` no documenta `pageClassification` ni `groups` (hallazgo N-01 de la auditoría 0.4.6.1). | Añadir las filas correspondientes. |
| D | Las páginas `BDD_OR_REQUIREMENTS` seleccionadas no tienen regla. | Pendiente de decisión (C14-Q2). |

## 4. Efecto esperado en las pruebas

- c14 pasará a cumplirse con el comportamiento "no evaluable" (comprobación `PAGINA_NO_EVALUABLE`).
- Hasta aplicar el cambio, c14 falla contra la Skill vigente. La causa candidata es la propia Skill; el controlador no la atribuye.
- Si se acepta el ajuste A, se debe regenerar `dist/validar-blueprint-integracion-*.zip`, actualizar la versión y fijar el nuevo hash con `node qa/controller/run.mjs pin`.
