// Compares two sets of runs of the same cases (e.g. Skill v11.2.3 vs v11.2.2) without calling any model.
// Usage: node qa/tools/compare-runs.mjs --a <runPrefix:v1123-> --b <runPrefix:v1122cmp-> --cases v123-a-inicio,v123-b-mod001,v123-c-hijo [--out <md>] [--json <json>]
// A difference between versions is data, never a verdict: classification is left to the reviewer.
import { readFileSync, writeFileSync, existsSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { parseRows } from '../controller/lib/parser.mjs';

const QA = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const args = process.argv.slice(2), flag = name => { const i = args.indexOf(name); return i >= 0 ? args[i + 1] : null; };
const prefixA = flag('--a') ?? 'v1123-', prefixB = flag('--b') ?? 'v1122cmp-';
const cases = (flag('--cases') ?? 'v123-a-inicio,v123-b-mod001,v123-c-hijo').split(',');
const short = id => id.replace(/^v123-/, '');
const load = (prefix, caseId) => {
  const dir = join(QA, 'runs', prefix + short(caseId), caseId);
  if (!existsSync(join(dir, 'transcript.json'))) return null;
  const transcript = JSON.parse(readFileSync(join(dir, 'transcript.json'), 'utf8')), telemetry = JSON.parse(readFileSync(join(dir, 'telemetry.json'), 'utf8')), report = JSON.parse(readFileSync(join(dir, 'report.json'), 'utf8'));
  const finalText = transcript.turns.at(-1).text ?? '';
  const byId = new Map();
  for (const row of parseRows(finalText)) if (!byId.has(row.id)) byId.set(row.id, row);
  const toolPaths = transcript.turns.flatMap(turn => (turn.toolCalls ?? []).map(call => call.input?.file_path ?? call.input?.skill ?? call.name));
  return { dir, transcript, telemetry, report, rows: byId, finalText, toolPaths };
};
const cell = row => row ? row.state : '—';
const fmt = n => typeof n === 'number' ? n.toLocaleString('en-US') : String(n);
const result = { generatedBy: 'qa/tools/compare-runs.mjs', a: prefixA, b: prefixB, cases: {} };
const md = ['# Comparación de ejecuciones — mismas entradas', '', `A = prefijo \`${prefixA}\` · B = prefijo \`${prefixB}\`. Las diferencias son datos, no veredictos; la clasificación la hace el revisor.`, ''];

for (const caseId of cases) {
  const a = load(prefixA, caseId), b = load(prefixB, caseId);
  if (!a || !b) { md.push(`## ${caseId}`, '', `Falta una de las ejecuciones (A: ${!!a}, B: ${!!b}).`, ''); continue; }
  const ids = [...new Set([...a.rows.keys(), ...b.rows.keys()])];
  const diffs = ids.filter(id => cell(a.rows.get(id)) !== cell(b.rows.get(id)));
  const counts = run => { const c = {}; for (const row of run.rows.values()) c[row.state] = (c[row.state] ?? 0) + 1; return c; };
  const conditionsA = a.report.conditions, conditionsB = b.report.conditions;
  result.cases[caseId] = { versionA: conditionsA.skillVersion, versionB: conditionsB.skillVersion, diffRules: diffs, countsA: counts(a), countsB: counts(b) };
  md.push(`## ${caseId}`, '', `Skill A ${conditionsA.skillVersion} (\`${conditionsA.skillZipSha256.slice(0, 12)}…\`) vs B ${conditionsB.skillVersion} (\`${conditionsB.skillZipSha256.slice(0, 12)}…\`)`, '', `Conteos A: ${JSON.stringify(counts(a))} · B: ${JSON.stringify(counts(b))}`, '', `Reglas con estado distinto: **${diffs.length}**`, '');
  if (diffs.length) { md.push('| Regla | A | B | Justificación A | Justificación B |', '|---|---|---|---|---|'); for (const id of diffs) md.push(`| ${id} | ${cell(a.rows.get(id))} | ${cell(b.rows.get(id))} | ${String(a.rows.get(id)?.fields?.justification ?? '').replace(/\|/g, '/').slice(0, 160)} | ${String(b.rows.get(id)?.fields?.justification ?? '').replace(/\|/g, '/').slice(0, 160)} |`); md.push(''); }
  md.push('No cumple (A):', '');
  for (const row of a.rows.values()) if (row.state === 'No cumple') md.push(`- ${row.id}: ${String(row.fields?.justification ?? row.text).replace(/\s+/g, ' ').slice(0, 260)}`);
  md.push('', 'No cumple (B):', '');
  for (const row of b.rows.values()) if (row.state === 'No cumple') md.push(`- ${row.id}: ${String(row.fields?.justification ?? row.text).replace(/\s+/g, ' ').slice(0, 260)}`);
  md.push('');
}

md.push('## Telemetría y consumo', '', 'Costo = **costo de lista** reportado por el CLI para la sesión (valor acumulado final del último turno; no se suman los acumulados de los turnos). No es un cargo ni el consumo real del plan; el consumo estimado del plan solo puede leerse como la utilización de las ventanas de límite (`rate_limit_event`).', '');
const head = ['Caso', 'Skill', 'Modelo', 'CLI', 'ZIP sha256', 'Turnos', 'Llamadas a herramientas', 'Entrada', 'Salida', 'Razonamiento', 'Escritura caché', 'Lectura caché', 'Total tokens', 'Costo de lista USD (final de sesión)', 'Duración CLI s', 'Reloj s', 'JSON compacto B', 'Archivos Skill leídos', 'Bytes Skill leídos', 'Ventana 5 h', 'Ventana 7 d'];
md.push('| ' + head.join(' | ') + ' |', '|' + head.map(() => '---').join('|') + '|');
const totalsBy = { A: 0, B: 0 }, tokensBy = { A: 0, B: 0 };
const telemetryRows = [];
for (const caseId of cases) for (const [label, prefix] of [['A', prefixA], ['B', prefixB]]) {
  const run = load(prefix, caseId);
  if (!run) continue;
  const t = run.telemetry, c = run.report.conditions, last = t.perTurn.at(-1), first = t.perTurn[0];
  const tools = t.perTurn.reduce((n, turn) => n + (turn.toolCalls ?? 0), 0);
  const windows = last.rateLimit?.unifiedWindows ?? {};
  const row = [caseId, `${c.skillVersion} (${label})`, last.model, last.cliVersion, c.skillZipSha256.slice(0, 12) + '…', t.totals.turns, tools, fmt(t.totals.inputTokens), fmt(t.totals.outputTokens), fmt(t.totals.thinkingTokens), fmt(t.totals.cacheCreationTokens), fmt(t.totals.cacheReadTokens), fmt(t.totals.totalTokens), t.totals.costUsd.toFixed(4), (t.totals.durationMs / 1000).toFixed(0), (t.totals.wallMs / 1000).toFixed(0), fmt(t.inputs.compactBytes), t.inputs.skillFilesRead, fmt(t.inputs.skillBytesRead), `${windows.five_hour?.utilization ?? 'ND'} → ${first.rateLimit?.unifiedWindows?.five_hour?.utilization ?? 'ND'}`.split(' → ').reverse().join(' → '), `${windows.seven_day?.utilization ?? 'ND'}`];
  md.push('| ' + row.join(' | ') + ' |');
  totalsBy[label] += t.totals.costUsd; tokensBy[label] += t.totals.totalTokens;
  telemetryRows.push({ caseId, label, skillVersion: c.skillVersion, zip: c.skillZipSha256, totals: t.totals, inputs: t.inputs, tools, reconciliation: t.reconciliation, rateLimitLast: last.rateLimit });
}
md.push('', `Suma de costos de lista por sesión (cada sesión usa su valor acumulado final): A ${totalsBy.A.toFixed(4)} USD · B ${totalsBy.B.toFixed(4)} USD. Tokens totales: A ${fmt(tokensBy.A)} · B ${fmt(tokensBy.B)}.`, '', 'Las ventanas de uso se muestran como «utilización al final del primer turno → al final de la sesión» (fracción de la ventana de 5 h y de 7 d de la cuenta). Con ejecuciones simultáneas la utilización de la cuenta incluye todas las sesiones en curso y no puede atribuirse a una sola.', '');
result.telemetry = telemetryRows;
if (flag('--out')) writeFileSync(join(resolve(QA, '..'), flag('--out')), md.join('\n')); else console.log(md.join('\n'));
if (flag('--json')) writeFileSync(join(resolve(QA, '..'), flag('--json')), JSON.stringify(result, null, 2));
