#!/usr/bin/env node
// Writes the three synthetic cases of the Skill v11.2.3 functional validation (sources, case.json, independent expectations).
// Every name is invented. Structures are derived from patterns verified in the real examples (ENTRADA/SALIDA as customData on BPMNActivity,
// shared groups, unnamed/nested RectangleContainerBlock) but contain no corporate data. Expectations are written BEFORE any model runs.
import { mkdirSync, writeFileSync } from 'node:fs';
import { join, resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
const QA = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const wj = (file, value) => { mkdirSync(dirname(file), { recursive: true }); writeFileSync(file, JSON.stringify(value, null, 2) + '\n'); };

const box = (id, text, kids = [], cls = 'UMLRectangleContainerBlock') => ({ id, class: cls, textAreas: text === '' ? [] : [{ label: 'Text', text }], customData: [], linkedData: [], contains: { shapes: kids, lines: [], groups: [] } });
const api = (id, title, operation, third) => ({ id, class: 'UMLClassBlock', textAreas: [{ label: 'Title', text: title }, { label: 'Text1', text: operation }, ...(third ? [{ label: 'Text2', text: third }] : [])], customData: [], linkedData: [] });
const event = (id, text = '') => ({ id, class: 'BPMNEvent', textAreas: text ? [{ label: 'Text', text }] : [], customData: [], linkedData: [] });
const model = (id, key, text) => ({ id, class: 'BPMNActivity', textAreas: [{ label: 'Text', text }], customData: [{ key, value: '' }], linkedData: [] });
const label = (id, text) => ({ id, class: 'DefaultSquareBlock', textAreas: [{ label: 'Text', text }], customData: [], linkedData: [] });
const line = (id, from, to) => ({ id, endpoint1: { style: 'None', connectedTo: from }, endpoint2: { style: 'Arrow', connectedTo: to }, textAreas: [], customData: [], linkedData: [] });
const group = (id, members) => ({ id, members, customData: [], linkedData: [] });
const page = (id, title, index, shapes, lines, groups = []) => ({ id, title, index, items: { shapes, lines, groups, layers: [] }, customData: [], linkedData: [] });
const doc = (id, title, pages) => ({ id, title, pages, data: { collections: [] } });
const write = (caseDir, value) => wj(join(QA, 'cases', caseDir, 'lucid.json'), value);

// ---- A: E1 whose Inicio cannot be certified. The event carries the free text "Inicio" (free text never certifies) and no customData.
write('v123-a-inicio', doc('qa-v123a', 'QA v11.2.3 A', [page('va', 'consultarEstadoPago', 0, [
  box('va-integ', 'INTEGRACIÓN', ['va-api']),
  api('va-api', 'Pagos - Consulta Estado v1.0.0', 'consultarEstadoPago', 'Private'),
  box('va-prod', 'DOMINIO PRODUCTOR', ['va-child', 'va-ev']),
  box('va-child', 'ms-pagos-estado', ['va-ev'], 'RectangleContainerBlock'),
  event('va-ev', 'Inicio del proceso')
], [line('va-l1', 'va-api', 'va-ev')])]));

// ---- B: MOD-001 evidence. ENTRADA/SALIDA live in customData (class BPMNActivity, architecturalType null); a label "Modelo de Salida" is typed MODELO by name only.
write('v123-b-mod001', doc('qa-v123b', 'QA v11.2.3 B', [page('vb', 'consultarFacturaCliente', 0, [
  box('vb-integ', 'INTEGRACIÓN', ['vb-api', 'vb-in', 'vb-out', 'vb-orphan', 'vb-label']),
  api('vb-api', 'Facturas - Consulta Cliente v1.0.0', 'consultarFacturaCliente', 'Private'),
  model('vb-in', 'ENTRADA', 'facturaRequest {\n  clienteId\n}'),
  model('vb-out', 'SALIDA', 'facturaResponse {\n  total\n}'),
  model('vb-orphan', 'ENTRADA', 'otroRequest {\n  codigo\n}'),
  label('vb-label', 'Modelo de Salida'),
  box('vb-prod', 'DOMINIO PRODUCTOR', ['vb-child', 'vb-ev']),
  box('vb-child', 'ms-facturas-core', ['vb-ev', 'vb-child-out'], 'RectangleContainerBlock'),
  model('vb-child-out', 'SALIDA', 'detalleInterno {\n  linea\n}'),
  event('vb-ev')
], [line('vb-l1', 'vb-api', 'vb-ev')], [group('vb-g1', ['vb-api', 'vb-in', 'vb-out'])])]));

// ---- C: child containers. Main child (named, holds the event), a secondary named child without main role, and an unnamed wrapper that nests it.
write('v123-c-hijo', doc('qa-v123c', 'QA v11.2.3 C', [page('vc', 'consultarSaldoTarjeta', 0, [
  box('vc-integ', 'INTEGRACIÓN', ['vc-api']),
  api('vc-api', 'Tarjetas - Consulta Saldo v1.0.0', 'consultarSaldoTarjeta', 'Private'),
  box('vc-prod', 'DOMINIO PRODUCTOR', ['vc-child', 'vc-wrap', 'vc-ev']),
  box('vc-child', 'ms-tarjetas-saldo', ['vc-ev'], 'RectangleContainerBlock'),
  box('vc-wrap', '', ['vc-aux'], 'RectangleContainerBlock'),
  box('vc-aux', 'ms-tarjetas-auditoria', [], 'RectangleContainerBlock'),
  event('vc-ev')
], [line('vc-l1', 'vc-api', 'vc-ev')])]));

// ---------------------------------------------------------------- case.json + expectations
const NA = 'No aplica', NV = 'No verificable', OK = 'Cumple';
const PROMPT = 'Valida este blueprint con la Skill validar-blueprint-integracion. El JSON compacto (contrato copilot-factual-v0.4.6.1) está en input/compact.json. Evalúa las páginas seleccionadas. Presenta las 41 reglas de cada página evaluable en una tabla con las columnas rule_id, Estado, Evidencia, Justificación e Información pendiente.';
const yes = text => ({ text, substantive: true });
const rule = (population, acceptable, status, basis) => ({ population, acceptable, status, basis });
const technical = basis => rule('POBLACION_FUERA_DE_ALCANCE_DEMOSTRADA', [NA], 'TECHNICAL', basis);
const pending = (accept, basis, population = 'A_REVISAR_POR_ANALISTA') => rule(population, accept, 'PENDING_REVIEW', basis);
const common = () => {
  const r = {
    'COM-001': technical('No hay ninguna BPMNActivity de comando: ni comandos certificados ni candidatos.'),
    'COM-002': technical('Sin comandos no hay APIs invocadas relacionadas con comandos.'),
    'COM-003': technical('Sin comandos no hay servicios invocados relacionados con comandos.'),
    'COM-004': technical('Sin comandos no hay gestores relacionados con comandos.'),
    'MQ-005': technical('No hay gestores relacionados con servicios invocados.'),
    'CA-002': technical('La regla declara "No existe figura de Capa" y el JSON no tiene ninguna.'),
    'FT-002': technical('La regla declara "No existe figura de Flujo" y el JSON no tiene ninguna.'),
    'GW-001': pending([NA, NV], 'No hay BPMNGateway; regla condicional a su presencia.'),
    'EXT-001': pending([NA, NV], 'No hay auxiliares externos.'), 'EXT-002': pending([NA, NV], 'Ídem.'),
    'CNT-006': pending([OK, NV], 'Población de "componentes evaluables" pendiente (C15-Q3).')
  };
  for (const id of ['MQ-001', 'MQ-002', 'MQ-003', 'MQ-004']) r[id] = pending([NV], 'Sin figura de gestor: No aplica vs No verificable pendiente (C15-Q1).', 'POBLACION_POTENCIAL_NO_VERIFICABLE');
  return r;
};
const otherScenarios = own => Object.fromEntries(['E2-001', 'E3-001', 'E1-001'].filter(id => !id.startsWith(own)).map(id => [id, pending([NA, NV], 'Escenario solo HIPOTESIS: la regla dice No aplica con escenario certificado de otro tipo; sin certificar, No verificable.')]));
const base = (id, title, canary, extra) => ({ canary, version: 'validación funcional Skill v11.2.3', caseId: id, title, authoredBefore: 'Redactado antes de ejecutar ningún modelo. No usa informes de Codex ni de auditorías previas como fuente de verdad: parte del texto de las reglas y del contrato.', ...extra });

// A
wj(join(QA, 'cases/v123-a-inicio/case.json'), { id: 'v123a', title: 'v11.2.3-A — Escenario E1 con Inicio no certificado', prompt: PROMPT, maxTurns: 6, checkScenarioMention: true,
  requiredQuestionsByPage: { consultarEstadoPago: ['mciPrincipal', 'mciHijo'] }, mustNotAskByPage: { consultarEstadoPago: ['exposicion'] },
  analystScript: { replies: { mciPrincipal: yes('Sí, la API principal está en MCI.'), mciHijo: yes('No, el servicio hijo principal no está en MCI.'), principalIdentity: yes('El principal es la API «Pagos - Consulta Estado v1.0.0».') } },
  conditionalChecks: [
    { type: 'ruleStateNot', name: 'E1_001_NO_CUMPLE_SIN_INICIO_CERTIFICADO', rule: 'E1-001', states: ['Cumple'], severity: 'FAIL', reason: 'la Skill v11.2.3 (§5) no admite Cumple en E1-001 sin Inicio certificado' },
    { type: 'ruleStateNot', name: 'E1_001_NO_ES_NO_CUMPLE_POR_HIPOTESIS', rule: 'E1-001', states: ['No cumple'], severity: 'REVIEW', reason: 'la estructura visible es compatible con E1; No cumple exige estructura certificada que contradiga el escenario' },
    { type: 'ruleEvidenceMentionsNone', name: 'NO_CUMPLE_NO_SE_APOYA_EN_HIPOTESIS', tokens: ['hipotesis'], states: ['No cumple'], severity: 'FAIL', reason: 'HIPOTESIS no es incumplimiento' },
    { type: 'ruleEvidenceMentionsAny', name: 'CNT_002_LECTURA_DEL_ESCENARIO_CERTIFICADO', rule: 'CNT-002', anyOf: ['hipotesis', 'certific', 'escenario'], reason: 'registrar cómo interpreta el evaluador "escenario certificado" (pendiente normativo)' },
    { type: 'finalTextMatches', name: 'EXPLICA_QUE_HIPOTESIS_NO_ES_ESTADO_NORMATIVO', pattern: 'hip[oó]tesis', severity: 'REVIEW', passDetail: 'El informe menciona HIPOTESIS', failDetail: 'El informe no menciona que el escenario es solo HIPOTESIS' },
    { type: 'finalTextMustNotMatch', name: 'TEXTO_LIBRE_NO_CERTIFICA_INICIO', pattern: 'inicio (est[aá] )?(certificad|confirmad)[oa]s?\\s+por (el )?(texto|nombre)', severity: 'FAIL', passDetail: 'No toma el texto «Inicio del proceso» como certificación', failDetail: 'Toma el texto libre como certificación del subtipo Inicio' }
  ] });
wj(join(QA, 'expected/v123-a-inicio.expected.json'), base('v123a', 'E1 sin Inicio certificado', 'QA-CANARY-v123a-7f2c19d4', {
  facts: { pageKind: 'OPERATIONAL o MIXED', scenario: 'E1/HIPOTESIS', main: 'va-api (API, PRINCIPAL, INTEGRACIÓN)', child: 'va-child (SERVICIO_HIJO/HIJO_PRINCIPAL, DOMINIO PRODUCTOR)', event: 'va-ev: BPMNEvent con el texto libre "Inicio del proceso" y sin customData → subtypeStatus NO_VERIFICABLE', exposureAccredited: true },
  objectiveInvariants: ['Pregunta MCI del principal y del hijo; no pregunta la exposición (Private figura en la tercera sección)', '41 filas con IDs del catálogo y estados válidos; métrica recalculada coincide', 'E1-001 no se declara Cumple (Inicio sin certificar)', 'HIPOTESIS no se usa para justificar un No cumple', 'El texto libre «Inicio del proceso» no certifica el subtipo', 'CNT-002 no extiende el requisito de Inicio certificado: su lectura de «escenario certificado» queda registrada para revisión'],
  ruleExpectations: { ...common(), ...otherScenarios('E1'), 'E1-001': pending([NV], 'El Inicio no está certificado: la regla integral no puede ser Cumple; No cumple exigiría estructura certificada que contradiga E1 (la estructura es compatible).'), 'CNT-002': pending([OK, NV], 'Dos lecturas defendibles de «escenario certificado» (identificado estructuralmente vs CONFIRMADO). Se registra lo que hace el evaluador; no es fallo.') },
  pendingNormativeReview: [{ id: 'VA-Q1', question: 'CNT-002: «escenario certificado» ¿incluye el escenario identificado estructuralmente (HIPOTESIS)? El resultado del evaluador se registra, no se juzga.' }] }));

// B
wj(join(QA, 'cases/v123-b-mod001/case.json'), { id: 'v123b', title: 'v11.2.3-B — MOD-001 con ENTRADA/SALIDA en customData', prompt: PROMPT, maxTurns: 6, checkScenarioMention: true,
  requiredQuestionsByPage: { consultarFacturaCliente: ['mciPrincipal', 'mciHijo'] }, mustNotAskByPage: { consultarFacturaCliente: ['exposicion'] },
  analystScript: { replies: { mciPrincipal: yes('Sí, la API principal está en MCI.'), mciHijo: yes('No, el servicio hijo principal no está en MCI.'), principalIdentity: yes('El principal es la API «Facturas - Consulta Cliente v1.0.0».') } },
  conditionalChecks: [
    { type: 'ruleEvidenceMentionsAny', name: 'MOD_001_CONSULTA_CUSTOMDATA', rule: 'MOD-001', anyOf: ['customData', 'vb-in', 'vb-out', 'ENTRADA', 'SALIDA'], reason: 'MOD-001 debe apoyarse en customData ENTRADA/SALIDA y no solo en architecturalType MODELO' },
    { type: 'ruleEvidenceMentionsNone', name: 'MOD_001_NO_USA_LA_ETIQUETA_COMO_MODELO', rules: ['MOD-001'], states: ['Cumple'], tokens: ['vb-label'], severity: 'REVIEW', reason: 'la etiqueta «Modelo de Salida» (tipo MODELO por nombre, sin customData) no es un modelo de datos' },
    { type: 'ruleEvidenceMentionsNone', name: 'MOD_001_NO_ASOCIA_EL_HUERFANO', rules: ['MOD-001'], states: ['Cumple'], tokens: ['vb-orphan', 'vb-child-out'], severity: 'REVIEW', reason: 'vb-orphan (sin grupo) y vb-child-out (contenido en el hijo, sin grupo) no están asociados al principal; citarlos como evidencia de su entrada/salida sería crear una asociación' },
    { type: 'finalTextMatches', name: 'DISTINGUE_GRUPO_CONTENCION_PROPIEDAD', pattern: 'grupo', severity: 'REVIEW', passDetail: 'El informe menciona la pertenencia a grupo', failDetail: 'El informe no menciona grupos al evaluar los modelos' }
  ] });
wj(join(QA, 'expected/v123-b-mod001.expected.json'), base('v123b', 'MOD-001 con ENTRADA/SALIDA', 'QA-CANARY-v123b-4a90e6c2', {
  facts: { pageKind: 'OPERATIONAL o MIXED', scenario: 'E1/HIPOTESIS', main: 'vb-api', models: { 'vb-in': 'ENTRADA, BPMNActivity, architecturalType null, en el grupo vb-g1 con vb-api, contenida en INTEGRACIÓN', 'vb-out': 'SALIDA, ídem', 'vb-orphan': 'ENTRADA sin grupo, contenida en INTEGRACIÓN: sin propietario demostrado', 'vb-child-out': 'SALIDA contenida en el hijo, sin grupo: su padre estructural es el hijo, no la API', 'vb-label': 'DefaultSquareBlock "Modelo de Salida": architecturalType MODELO por nombre, sin customData' }, exposureAccredited: true },
  objectiveInvariants: ['Pregunta MCI del principal y del hijo; no pregunta la exposición', '41 filas válidas; métrica coincide', 'MOD-001 consulta customData (ENTRADA/SALIDA), no solo architecturalType MODELO', 'No cita la etiqueta vb-label como modelo de datos', 'No asocia vb-orphan ni vb-child-out al principal', 'Distingue pertenencia a grupo (vb-g1), contención (INTEGRACIÓN / hijo) y propiedad'],
  ruleExpectations: { ...common(), ...otherScenarios('E1'), 'E1-001': pending([NV], 'Inicio no certificado: No verificable (la v11.2.3 no admite Cumple).'), 'CNT-002': pending([OK, NV], 'Lectura de «escenario certificado» pendiente.'), 'MOD-001': pending([OK, NV], 'Pendiente de interpretación: si la pertenencia a un grupo basta como asociación explícita (Cumple) o no (No verificable). No cumple sería erróneo: existen entrada y salida en el grupo del principal.') },
  pendingNormativeReview: [{ id: 'VB-Q1', question: 'MOD-001: ¿la pertenencia al grupo del principal basta como «asociación explícita» de ENTRADA/SALIDA? Decide la analista.' }] }));

// C
wj(join(QA, 'cases/v123-c-hijo/case.json'), { id: 'v123c', title: 'v11.2.3-C — Contenedores hijo: tipo vs rol, sin ampliar SRV', prompt: PROMPT, maxTurns: 6, checkScenarioMention: true,
  requiredQuestionsByPage: { consultarSaldoTarjeta: ['mciPrincipal', 'mciHijo'] }, mustNotAskByPage: { consultarSaldoTarjeta: ['exposicion'] },
  analystScript: { replies: { mciPrincipal: yes('Sí, la API principal está en MCI.'), mciHijo: yes('No, el servicio hijo principal no está en MCI.'), principalIdentity: yes('El principal es la API «Tarjetas - Consulta Saldo v1.0.0».') } },
  conditionalChecks: [
    { type: 'finalTextMustNotMatch', name: 'NO_RECLASIFICA_EL_HIJO_COMO_SERVICIO_O_INVOCADO', pattern: '(ms-tarjetas-saldo|ms-tarjetas-auditoria)[^\\n|]{0,60}(es|como|tratad[oa]\\s+como|tipo)\\s+(un\\s+)?(servicio\\s+invocado|invocado\\b|SERVICIO\\b(?!_HIJO))', severity: 'REVIEW', passDetail: 'No se detecta que reclasifique los contenedores hijo como SERVICIO o INVOCADO', failDetail: 'Parece reclasificar un contenedor hijo como SERVICIO o INVOCADO' },
    { type: 'ruleEvidenceMentionsNone', name: 'SECUNDARIO_NO_SE_PRESENTA_COMO_PRINCIPAL', rules: ['CNT-002', 'E1-001', 'SRV-001', 'SRV-002', 'SRV-003'], states: ['Cumple', 'No cumple'], tokens: ['vc-aux'], severity: 'REVIEW', reason: 'vc-aux no es el hijo principal; evaluarlo como tal en una fila definitiva sería ampliar la población' },
    { type: 'finalTextMatches', name: 'MENCIONA_EL_CONTENEDOR_SIN_ROL_PRINCIPAL', pattern: 'vc-aux|ms-tarjetas-auditoria|role:\\s*null|sin rol', severity: 'REVIEW', passDetail: 'El informe menciona el contenedor sin rol principal', failDetail: 'El informe no menciona el contenedor hijo sin rol principal' }
  ] });
wj(join(QA, 'expected/v123-c-hijo.expected.json'), base('v123c', 'Contenedores hijo', 'QA-CANARY-v123c-b5d83e07', {
  facts: { pageKind: 'OPERATIONAL o MIXED', scenario: 'E1/HIPOTESIS (por verificar en el compacto)', main: 'vc-api', mainChild: 'vc-child (SERVICIO_HIJO / HIJO_PRINCIPAL)', secondaryChild: 'vc-aux (SERVICIO_HIJO, role null, anidado en vc-wrap)', unnamedWrapper: 'vc-wrap (SERVICIO_HIJO, sin nombre, role null)', exposureAccredited: true, noServiceFigure: 'La página no tiene ninguna figura SERVICIO ni INVOCADO' },
  objectiveInvariants: ['Pregunta MCI del principal y del hijo; no pregunta la exposición', '41 filas válidas; métrica coincide', 'No reclasifica los contenedores hijo como SERVICIO ni INVOCADO', 'No presenta vc-aux ni vc-wrap como hijo principal', 'SRV-001..003 no amplían su población al hijo por analogía: si hay duda de población, la declaran'],
  ruleExpectations: { ...common(), ...otherScenarios('E1'), 'E1-001': pending([NV], 'Inicio no certificado: No verificable.'), 'CNT-002': pending([OK, NV], 'Lectura de «escenario certificado» pendiente.'), 'SRV-001': pending([NA, NV], 'La página no tiene figura SERVICIO; el hijo (SERVICIO_HIJO) no entra por analogía: duda de población pendiente (No aplica o No verificable); Cumple/No cumple sería ampliar la población.', 'POBLACION_PENDIENTE_DE_DEFINICION'), 'SRV-002': pending([NA, NV], 'Ídem.', 'POBLACION_PENDIENTE_DE_DEFINICION'), 'SRV-003': pending([NA, NV], 'Ídem.', 'POBLACION_PENDIENTE_DE_DEFINICION') },
  pendingNormativeReview: [{ id: 'VC-Q1', question: 'Población de SRV-001..003: ¿incluye al servicio hijo principal? Decide la analista. Cualquier estado distinto de No aplica / No verificable queda para revisión, no como fallo.' }] }));
console.log('v11.2.3 cases written');
