# Plantilla de comparación normativa

Para cuando la analista entregue su consolidado actualizado. **No contiene reglas nuevas ni las inventa**: compara tres fuentes y deja las decisiones a quien corresponde.

| Fuente | Qué es | Dónde está |
|---|---|---|
| Normativa vigente | Catálogo de la Skill (41 reglas) | `skills/validar-blueprint-integracion/references/catalogo-reglas-v11.2.csv` |
| Consolidado nuevo | Archivo de la analista, convertido al mismo formato | `qa/templates/catalogo-consolidado-NUEVO.plantilla.csv` (solo cabecera) |
| Evidencia disponible | Matriz regla→campo y diccionario del contrato compacto | `MATRIZ-EVIDENCIA-41.md`, `CONTRATO-COMPACTO.md` |

## 1. Formato de entrada
CSV UTF-8 con las columnas del catálogo vigente: `id, familia, titulo, resumen, aplica_a, criterio, evidencia, no_cumple, no_verificable, no_aplica`. La conversión desde el documento de la analista es manual y debe conservar el texto literal; si el consolidado tiene otra estructura, se registra la diferencia aparte (no se fuerza).

## 2. Ejecución
```
node qa/tools/compare-normative.mjs --new <consolidado.csv> --out qa/runs/comparacion-normativa.md --json qa/runs/comparacion-normativa.json
node qa/tools/compare-normative.selftest.mjs        # autoprueba con catálogos sintéticos
```
`--old` es opcional (por defecto, el catálogo vigente). La salida está en `qa/runs/`, que no se publica.

## 3. Qué detecta
| Dimensión | Columnas comparadas | Ejemplo de hallazgo |
|---|---|---|
| ID | `id` | regla nueva, retirada, posible renombre (mismo título, otro ID) |
| Texto | `familia`, `titulo`, `resumen` | cambio de nombre o resumen |
| Aplicabilidad | `aplica_a`, `no_aplica` | cambia la población o la condición de No aplica |
| Evidencia | `evidencia` | cambia la evidencia mínima |
| Criterio | `criterio`, `no_cumple`, `no_verificable` | cambia el criterio o los umbrales de estado |

Las diferencias solo de espacios se ignoran. Un ID retirado y otro nuevo con el mismo título se señalan como **posible** renombre, nunca como equivalencia.

## 4. Evidencia disponible en Evidence Studio
Para cada regla nueva o modificada la herramienta consulta la matriz vigente:
- `DISPONIBLE_EN_CONTRATO`: los campos citados existen en el diccionario del contrato compacto. No prueba que un blueprint concreto tenga evidencia suficiente.
- `CAMPO_NO_DOCUMENTADO`: la matriz cita un campo que el diccionario no define.
- `SIN_MAPEO`: la regla no figura en la matriz; hay que definir qué evidencia la sustenta antes de implementarla.

## 5. Hoja de decisión (a completar por Andrés y la analista)
| ID | Cambio detectado | Dimensiones | Evidencia en Evidence Studio | ¿Requiere cambio del motor / del contrato / de la Skill? | Decisión (aprobada / rechazada / pendiente) | Quién decide | Fecha |
|---|---|---|---|---|---|---|---|

Reglas de uso:
1. Ningún cambio se implementa sin decisión expresa en la hoja.
2. Una regla nueva con `SIN_MAPEO` o `CAMPO_NO_DOCUMENTADO` no entra en la Skill hasta que exista evidencia definida.
3. Un cambio solo de `aplica_a`/`no_aplica` modifica poblaciones y, por tanto, la métrica; se avisa del efecto antes de aprobarlo.
4. Tras aprobar cambios: nueva versión de la Skill, pruebas de hashes por regla, `skill:pack`, `skill:zip:validate` y actualización de `MATRIZ-EVIDENCIA-41.md`.
5. El consolidado de la analista es corporativo: se guarda solo en el repositorio privado autorizado.
