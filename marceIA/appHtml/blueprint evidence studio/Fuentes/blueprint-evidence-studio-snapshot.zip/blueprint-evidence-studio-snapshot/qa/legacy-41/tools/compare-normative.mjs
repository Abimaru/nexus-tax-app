// Normative comparison: current catalog vs. a new consolidated catalog, plus the evidence Evidence Studio can supply.
// Read-only. It invents no rules: it only reports what differs between the two files it is given.
// Usage:
//   node qa/tools/compare-normative.mjs --new <catalogo-nuevo.csv> [--old <catalogo-vigente.csv>] [--matrix <MATRIZ-EVIDENCIA-41.md>]
//        [--contract <CONTRATO-COMPACTO.md>] [--out <informe.md>] [--json <informe.json>]
// Both CSV files use the columns of the current catalog:
//   id,familia,titulo,resumen,aplica_a,criterio,evidencia,no_cumple,no_verificable,no_aplica
import { readFileSync, writeFileSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';

const REPO = resolve(dirname(fileURLToPath(import.meta.url)), '..', '..');
const REFS = join(REPO, 'skills', 'validar-blueprint-integracion', 'references');
export const COLUMNS = ['id', 'familia', 'titulo', 'resumen', 'aplica_a', 'criterio', 'evidencia', 'no_cumple', 'no_verificable', 'no_aplica'];
// What each comparison dimension covers.
export const DIMENSIONS = {
  texto: ['familia', 'titulo', 'resumen'],
  aplicabilidad: ['aplica_a', 'no_aplica'],
  evidencia: ['evidencia'],
  criterio: ['criterio', 'no_cumple', 'no_verificable']
};

export function parseCsv(text) {
  const rows = []; let row = [], field = '', quoted = false;
  const source = text.replace(/^﻿/, '');
  for (let i = 0; i < source.length; i++) {
    const c = source[i];
    if (quoted) { if (c === '"') { if (source[i + 1] === '"') { field += '"'; i++; } else quoted = false; } else field += c; }
    else if (c === '"') quoted = true;
    else if (c === ',') { row.push(field); field = ''; }
    else if (c === '\n' || c === '\r') { if (c === '\r' && source[i + 1] === '\n') i++; row.push(field); field = ''; if (row.length > 1 || row[0] !== '') rows.push(row); row = []; }
    else field += c;
  }
  if (field !== '' || row.length) { row.push(field); rows.push(row); }
  return rows;
}

export function loadCatalog(text, label = 'catálogo') {
  const [header, ...body] = parseCsv(text);
  const missing = COLUMNS.filter(column => !header?.includes(column));
  if (missing.length) throw new Error(`${label}: faltan columnas ${missing.join(', ')}`);
  const map = new Map(), duplicates = [];
  for (const cells of body) {
    const record = Object.fromEntries(header.map((name, index) => [name, (cells[index] ?? '').trim()]));
    if (!record.id) continue;
    if (map.has(record.id)) duplicates.push(record.id);
    map.set(record.id, record);
  }
  return { map, duplicates };
}

const norm = value => String(value ?? '').replace(/\s+/g, ' ').trim();
const hash = value => createHash('sha256').update(norm(value)).digest('hex').slice(0, 10);

export function loadMatrix(text) {
  const matrix = new Map();
  for (const line of text.split(/\r?\n/)) {
    const match = line.match(/^\| ([A-Z0-9]+-\d+) \| (.*?) \| (.*?) \| (.*?) \|$/);
    if (match) matrix.set(match[1], { evidenciaRequerida: match[2], campos: [...match[3].matchAll(/`([^`]+)`/g)].map(token => token[1]), respuestaHumana: match[4] });
  }
  return matrix;
}

export function contractFields(text) {
  const fields = new Set();
  for (const line of text.split(/\r?\n/)) {
    const cell = line.match(/^\| (.*?) \|/);
    if (cell) for (const token of cell[1].matchAll(/`([^`]+)`/g)) { const name = token[1].replace(/^pages\[\]\./, '').replace(/\[\]$/, '').split('.')[0]; if (/^[A-Za-z]\w*$/.test(name)) fields.add(name); }
  }
  return fields;
}

export function compare(oldCatalog, newCatalog, matrix = new Map(), fields = null) {
  const added = [], removed = [], changed = [], unchanged = [];
  for (const [id, now] of newCatalog.map) {
    const before = oldCatalog.map.get(id);
    if (!before) { added.push(id); continue; }
    const dimensions = [];
    const detail = {};
    for (const [dimension, columns] of Object.entries(DIMENSIONS)) {
      const diffs = columns.filter(column => norm(before[column]) !== norm(now[column]));
      if (diffs.length) { dimensions.push(dimension); detail[dimension] = diffs.map(column => ({ column, before: before[column], after: now[column], beforeHash: hash(before[column]), afterHash: hash(now[column]) })); }
    }
    if (dimensions.length) changed.push({ id, dimensions, detail }); else unchanged.push(id);
  }
  for (const id of oldCatalog.map.keys()) if (!newCatalog.map.has(id)) removed.push(id);
  // An ID that disappears while another appears with the same normalized title is only a *possible* rename.
  const titleOf = (catalog, id) => norm(catalog.map.get(id)?.titulo).toLowerCase();
  const possibleRenames = removed.flatMap(oldId => added.filter(newId => titleOf(oldCatalog, oldId) && titleOf(oldCatalog, oldId) === titleOf(newCatalog, newId)).map(newId => ({ oldId, newId })));
  const evidence = [...added, ...changed.map(item => item.id)].map(id => {
    const entry = matrix.get(id);
    if (!entry) return { id, availability: 'SIN_MAPEO', detail: 'La regla no figura en la matriz de evidencia vigente.' };
    const unknown = fields ? entry.campos.filter(campo => !fields.has(campo.split('.')[0])) : [];
    return { id, availability: unknown.length ? 'CAMPO_NO_DOCUMENTADO' : 'DISPONIBLE_EN_CONTRATO', campos: entry.campos, respuestaHumana: entry.respuestaHumana, unknownFields: unknown };
  });
  return { counts: { old: oldCatalog.map.size, new: newCatalog.map.size, added: added.length, removed: removed.length, changed: changed.length, unchanged: unchanged.length }, added, removed, changed, unchanged, possibleRenames, evidence, duplicates: { old: oldCatalog.duplicates, new: newCatalog.duplicates } };
}

export function renderMarkdown(result, names = { old: 'vigente', new: 'nuevo' }) {
  const lines = [`# Comparación normativa: ${names.old} → ${names.new}`, '', 'No se infiere ninguna regla: el informe solo muestra diferencias entre los dos archivos recibidos.', '', '```json', JSON.stringify(result.counts, null, 2), '```', ''];
  if (result.duplicates.old.length || result.duplicates.new.length) lines.push(`**IDs duplicados** — vigente: ${result.duplicates.old.join(', ') || '—'}; nuevo: ${result.duplicates.new.join(', ') || '—'}`, '');
  lines.push('## Reglas nuevas (ID presente solo en el consolidado nuevo)', '', result.added.length ? result.added.map(id => `- ${id}`).join('\n') : '_ninguna_', '');
  lines.push('## Reglas retiradas (ID presente solo en el catálogo vigente)', '', result.removed.length ? result.removed.map(id => `- ${id}`).join('\n') : '_ninguna_', '');
  if (result.possibleRenames.length) lines.push('## Posibles renombres (mismo título, distinto ID; confirmar con la analista)', '', result.possibleRenames.map(item => `- ${item.oldId} → ${item.newId}`).join('\n'), '');
  lines.push('## Reglas modificadas', '', '| ID | Texto | Aplicabilidad | Evidencia | Criterio |', '|---|---|---|---|---|');
  for (const item of result.changed) lines.push(`| ${item.id} | ${item.dimensions.includes('texto') ? 'cambia' : '='} | ${item.dimensions.includes('aplicabilidad') ? 'cambia' : '='} | ${item.dimensions.includes('evidencia') ? 'cambia' : '='} | ${item.dimensions.includes('criterio') ? 'cambia' : '='} |`);
  if (!result.changed.length) lines.push('| _ninguna_ | | | | |');
  lines.push('');
  for (const item of result.changed) {
    lines.push(`### ${item.id}`, '');
    for (const [dimension, diffs] of Object.entries(item.detail)) for (const diff of diffs) lines.push(`- **${dimension} · ${diff.column}** (${diff.beforeHash} → ${diff.afterHash})`, `  - antes: ${diff.before || '_vacío_'}`, `  - ahora: ${diff.after || '_vacío_'}`);
    lines.push('');
  }
  lines.push('## Evidencia disponible en Evidence Studio para las reglas nuevas y modificadas', '', '| ID | Disponibilidad | Campos del compacto | Respuesta humana |', '|---|---|---|---|');
  for (const item of result.evidence) lines.push(`| ${item.id} | ${item.availability} | ${(item.campos ?? []).join(', ') || '—'}${item.unknownFields?.length ? ` (no documentados: ${item.unknownFields.join(', ')})` : ''} | ${item.respuestaHumana ?? '—'} |`);
  if (!result.evidence.length) lines.push('| _ninguna_ | | | |');
  lines.push('', '`DISPONIBLE_EN_CONTRATO` solo significa que los campos citados existen en el diccionario del contrato compacto; no significa que haya evidencia suficiente en un blueprint concreto. `SIN_MAPEO` exige definir la evidencia antes de implementar la regla.', '');
  return lines.join('\n');
}

function main() {
  const args = process.argv.slice(2), get = flag => { const index = args.indexOf(flag); return index > -1 ? args[index + 1] : null; };
  const newPath = get('--new');
  if (!newPath) { console.error('Uso: node qa/tools/compare-normative.mjs --new <catalogo-nuevo.csv> [--old <vigente.csv>] [--matrix <md>] [--contract <md>] [--out <md>] [--json <json>]'); process.exit(2); }
  const oldPath = get('--old') ?? join(REFS, 'catalogo-reglas-v11.2.csv');
  const matrixPath = get('--matrix') ?? join(REFS, 'MATRIZ-EVIDENCIA-41.md');
  const contractPath = get('--contract') ?? join(REFS, 'CONTRATO-COMPACTO.md');
  const result = compare(loadCatalog(readFileSync(oldPath, 'utf8'), 'vigente'), loadCatalog(readFileSync(newPath, 'utf8'), 'nuevo'), loadMatrix(readFileSync(matrixPath, 'utf8')), contractFields(readFileSync(contractPath, 'utf8')));
  const markdown = renderMarkdown(result, { old: oldPath.split(/[\\/]/).pop(), new: newPath.split(/[\\/]/).pop() });
  if (get('--out')) writeFileSync(get('--out'), markdown); else console.log(markdown);
  if (get('--json')) writeFileSync(get('--json'), JSON.stringify(result, null, 2));
}
if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) main();
