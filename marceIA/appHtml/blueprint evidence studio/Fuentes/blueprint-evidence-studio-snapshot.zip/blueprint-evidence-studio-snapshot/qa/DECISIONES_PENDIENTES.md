> Histórico: pendientes planteados con la Skill de 41 reglas. La Skill v11.2.4 tiene 37 reglas confirmadas por la analista; solo se retoma lo que la prueba con Copilot demuestre.

# Decisiones normativas pendientes

Ninguna de estas decisiones la toma el banco de pruebas. Son de Andrés o de la analista. Mientras no se resuelvan, el controlador marca los resultados afectados como REVISAR y **no** como fallo técnico, y no se modifica ningún texto de la Skill ni de las 41 obligaciones.

Las preguntas se citan literalmente de `qa/expected/*.expected.json`.

---

## C14-Q3
**Pregunta exacta:** "Cuando exista una página BDD pura seleccionada, ¿basta con el aviso de no evaluable o debe sugerirse deseleccionarla? (decisión operativa; la Skill solo exige informar ID, título, tipo y motivo)"

**Regla afectada:** ninguna de las 41. Afecta al procedimiento (clasificación de páginas) y a la interfaz de Evidence Studio.

**Comportamiento actual:** la Skill v11.2.2 exige informar ID, título, tipo y motivo y no generar 41 filas. Evidence Studio ya no preselecciona las páginas BDD ni las plantillas, pero el usuario puede marcarlas. No hay instrucción de sugerir deseleccionarla.

| Opción | Impacto |
|---|---|
| A. Basta con el aviso de no evaluable (hoy) | Sin cambios en la Skill. El informe puede repetir el aviso en cada ejecución si la analista deja marcada la página. |
| B. Además, sugerir deseleccionar la página al exportar | Cambio en la Skill (una frase en el procedimiento) o en Evidence Studio (aviso en la interfaz). Hace falta un ZIP nuevo o una versión nueva del HTML. |
| C. Bloquear la selección de páginas BDD en la interfaz | Cambio en Evidence Studio; impide analizar una operación legítima con título BDD (el caso P3). No recomendada. |

**Recomendación técnica:** A para el piloto; B si las analistas dejan seleccionadas páginas no evaluables con frecuencia. Descartar C por el caso de contradicción tipo/evidencia.

---

## C15-Q1
**Pregunta exacta:** "Confirmar las poblaciones marcadas PENDING_REVIEW, en especial MQ-001..004 (No verificable por población potencial) frente a No aplica, y GW-001 / EXT-001 / EXT-002."

**Reglas afectadas:** MQ-001, MQ-002, MQ-003, MQ-004, GW-001, EXT-001, EXT-002 (y, por extensión, EVT-007 y COM-001 en las expectativas).

**Evidencia del piloto de la Fase 2 (Skill v11.2.2):** en las cuatro páginas operativas sintéticas, todas sin ninguna figura de gestor de colas y con todas las figuras tipificadas, el agente respondió **No aplica** en MQ-001…004 (en P4, MQ-002…004), con el razonamiento "no existe gestor ni candidato en la operación". La expectativa vigente es No verificable. En la página sin tipificar de c15 respondió No verificable.

**Comportamiento actual:** en una página sin ninguna figura de gestor de colas, el agente respondió No verificable para MQ-001…004 y No aplica para MQ-005; para GW-001 y EXT-002 respondió No aplica y para EXT-001 No verificable. Las expectativas aceptan No verificable en MQ-001…004 (según el criterio aprobado: la ausencia de la figura no equivale a la ausencia de la obligación) y aceptan ambos estados en GW-001 y EXT-001/002.

| Opción | Impacto |
|---|---|
| A. Sin figura, la población de MQ-001…004 está fuera de alcance (No aplica) | Sube el número de No aplica y el porcentaje de cumplimiento de las páginas sin gestor. Contradice el criterio aprobado salvo que se declare que un gestor es opcional. Cambia la interpretación de las obligaciones. |
| B. Sin evidencia sobre si debe existir un gestor, No verificable (hoy) | Mantiene el criterio aprobado. Todas las páginas sin gestor arrastran 4 No verificable, lo que reduce el porcentaje. |
| C. Decidir regla por regla y escribirlo en el texto de cada regla (p. ej. "gestor opcional") | Es la opción más precisa, pero modifica obligaciones normativas. Requiere una revisión normativa formal. |

**Recomendación técnica:** mantener B hasta que la analista indique si el gestor es opcional; si lo es, esa aclaración debería ir en la regla (C), no en el agente. Para GW-001, EXT-001 y EXT-002, que son condicionales a la presencia de la figura, aceptar No aplica parece natural, pero es decisión normativa.

---

## C15-Q2
**Pregunta exacta:** "¿Es admisible algún "No cumple" en esta página (por ejemplo CNT-001)? El controlador solo lo marca para revisión."

**Regla afectada:** CNT-001 (y cualquier regla de estructura en una página sin dominio resuelto).

**Comportamiento actual:** el agente dio No verificable en CNT-001 y no emitió ningún No cumple. El criterio de CNT-001 dice que No cumple es "falta un contenedor obligatorio con cobertura completa". El controlador marca como REVISAR cualquier No cumple en una página sin evidencia material.

| Opción | Impacto |
|---|---|
| A. Sin evidencia material no se admite No cumple (hoy, vía REVISAR) | Los incumplimientos solo se declaran con evidencia demostrada. Riesgo de no señalar una página incompleta. |
| B. Admitir No cumple en CNT-001 cuando el JSON tiene cobertura completa y falta INTEGRACIÓN | Más informativo para la analista. Exige definir cuándo la cobertura es "completa" (una página UNRESOLVED puede estar incompleta por diseño). |
| C. No fijar regla general; decidir por regla | Más lento; se evalúa caso a caso. |

**Recomendación técnica:** A mientras no se defina "cobertura completa"; documentar B como criterio futuro.

---

## C15-Q3
**Pregunta exacta:** "CNT-006: el Cumple está sustentado por a→box y b→box (JSON.contains, RESOLVED). Falta precisar la población de "componentes evaluables" (¿incluye el contenedor raíz?)."

**Regla afectada:** CNT-006 ("Exclusividad de padre directo", *Aplica a:* "Componentes evaluables").

**Comportamiento actual:** el agente dio Cumple evaluando a y b y dejando fuera el contenedor raíz `box`, que no tiene padre declarado (`NOT_DECLARED`). El procedimiento v11.2.2 documenta el criterio operativo sin tocar el texto de la regla. **CNT-006 mantiene su texto actual.**

| Opción | Impacto |
|---|---|
| A. La raíz no se evalúa como componente con padre (hoy) | Cumple es posible con padres únicos. Una página con varios contenedores raíz no genera incidencia. |
| B. La raíz también cuenta como componente evaluable | La raíz siempre incumpliría o sería No verificable (no tiene padre); haría casi imposible un Cumple. No recomendada. |
| C. Evaluar solo los componentes con `structuralParent` declarado, y señalar aparte las raíces múltiples | Es A más una advertencia. Requiere acordar si varias raíces son una anomalía (probablemente sí en un blueprint de integración). |

**Recomendación técnica:** A con la advertencia de C como recomendación (no como incumplimiento). No decido esto por la analista: cualquier cambio de la población modifica la interpretación de la obligación.
