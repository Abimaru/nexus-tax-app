#!/usr/bin/env node
// Independent verification of the shipped Skill ZIP (reads the ZIP, not the working folder, for every content check).
import { readFileSync, existsSync } from 'node:fs';
import { join, resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { readZip, inspectZip } from '../controller/lib/zip.mjs';
import { sha256, ruleIdsFromTexts, RULE_COUNT } from '../controller/lib/util.mjs';

const REPO = resolve(dirname(fileURLToPath(import.meta.url)), '..', '..');
const zipPath = join(REPO, process.argv[2] ?? 'dist/validar-blueprint-integracion-v11.2.4.zip');
const ROOT = 'validar-blueprint-integracion', VERSION = 'v11.2.4';
const zip = readZip(zipPath), report = [];
const check = (name, ok, detail = '') => { report.push({ name, ok, detail }); console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? '  -- ' + detail : ''}`); };
const text = name => zip.entries.find(entry => entry.name === `${ROOT}/${name}`)?.data.toString('utf8').replace(/\r/g, '') ?? null;

const inspection = inspectZip(zip, ROOT);
check('estructura portátil (rutas con /, carpeta raíz única, sin traversal)', inspection.problems.length === 0, inspection.problems.join(','));
const ruleFiles = ['01-reglas-estructura', '02-reglas-api-servicios', '03-reglas-eventos', '04-reglas-despliegue', '05-reglas-escenarios', '06-reglas-modelos-comandos', '07-reglas-gestores-colas'].map(n => `references/${n}.md`);
const required = ['SKILL.md', 'references/MANIFEST.md', 'references/00-procedimiento.md', ...ruleFiles];
check('los diez archivos requeridos están presentes', required.every(name => text(name) !== null), required.filter(name => text(name) === null).join(','));
check('sin archivos de más (exactamente diez)', inspection.fileCount === 10, `${inspection.fileCount} archivos`);

const skill = text('SKILL.md');
const front = skill.match(/^---\n([\s\S]*?)\n---\n/);
const keys = front ? [...front[1].matchAll(/^([A-Za-z_-]+):\s*(.+)$/gm)] : [];
check('YAML: claves name/description y nombre correcto', !!front && keys.map(k => k[1]).join() === 'name,description' && keys[0][2].trim() === ROOT && keys[1][2].trim().length > 20, keys.map(k => k[1]).join());
check(`versión ${VERSION} en el manifiesto y en los siete archivos de reglas`, ['references/MANIFEST.md', ...ruleFiles].every(name => text(name).includes(VERSION)));
check('contrato copilot-factual-v0.4.6.1 nombrado en manifiesto y procedimiento', ['references/MANIFEST.md', 'references/00-procedimiento.md'].every(name => text(name).includes('copilot-factual-v0.4.6.1')));

const ids = ruleIdsFromTexts(ruleFiles.map(text));
check(`${RULE_COUNT} IDs únicos en los encabezados de las reglas`, ids.length === RULE_COUNT && new Set(ids).size === RULE_COUNT, `${ids.length}/${new Set(ids).size}`);
const manifest = text('references/MANIFEST.md');
check('el manifiesto lista los 37 IDs', ids.every(id => manifest.includes(id)));

const all = required.map(text).join('\n');
check('cuatro estados presentes; sin estados inventados', ['Cumple', 'No cumple', 'No verificable', 'No aplica'].every(state => all.includes(state)) && !/Parcialmente cumple|Cumple parcial/i.test(all));
check('fórmula definitiva presente', /Cumple \/ \(Cumple \+ No cumple \+ No verificable\) × 100/.test(text('references/00-procedimiento.md')));
const present = new Set(required.map(name => name.split('/').pop()));
const missingRefs = [...new Set(all.match(/[A-Za-z0-9_.-]+\.(?:md|csv)/g))].filter(name => !present.has(name));
check('ninguna referencia a archivos inexistentes', missingRefs.length === 0, missingRefs.join(','));
check('sin restos del catálogo de 41 reglas', !/\b41\b|MATRIZ-EVIDENCIA|CONTRATO-COMPACTO|GUIA-TEXTAREAS|INSTRUCCIONES-AGENTE|v11\.2\.[123]/.test(all));
check('páginas evaluables: 37 resultados; plantilla/leyenda no evaluable sin filas', /37 resultados/.test(skill) && /no evaluable/i.test(skill) && /TEMPLATE_OR_LEGEND/.test(text('references/00-procedimiento.md')));

// Normative bodies pinned in skill.lock.json (written by `run.mjs pin`): the seven rule files must not drift.
const lockPath = join(REPO, 'qa', 'skill.lock.json'), lock = existsSync(lockPath) ? JSON.parse(readFileSync(lockPath, 'utf8')) : null;
if (lock?.ruleBodies) check('cuerpos normativos iguales a los fijados en skill.lock.json', ruleFiles.every(name => sha256(text(name).split('\n').slice(1).join('\n')) === lock.ruleBodies[name]));

const mismatches = zip.entries.filter(entry => !entry.isDirectory).filter(entry => { const local = join(REPO, 'skills', entry.name); return !existsSync(local) || sha256(readFileSync(local)) !== sha256(entry.data); }).map(entry => entry.name);
check('contenido del ZIP idéntico a skills/ archivo por archivo', mismatches.length === 0, mismatches.join(','));
console.log(JSON.stringify({ zip: zipPath.slice(REPO.length + 1), sha256: zip.sha256, bytes: zip.bytes, files: inspection.fileCount, failures: report.filter(r => !r.ok).length }));
process.exit(report.some(r => !r.ok) ? 1 : 0);
