// Read-only audit of RectangleContainerBlock figures (typed SERVICIO_HIJO by the engine) in the real examples.
// Reports, per container: unnamed, without parent, nested, without main role, page scenario NO_DETERMINADO.
// It never changes a classification. Usage: node qa/tools/audit-child-containers.mjs [--out <md>]
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const REPO = resolve(dirname(fileURLToPath(import.meta.url)), '..', '..');
const { analyzeBlueprint, copilotExport } = await import(pathToFileURL(join(REPO, 'src', 'exporter.js')).href);
const CASES = {
  Oski: 'Blueprints_ejemplos/Collections_Bill_Payments/NMD - BP -  Collections_Bill_Payments-Pay_Bill U (1).json',
  'Currency Exchange': 'Blueprints_ejemplos/Ejemplo E2/MCI - BP - Currency Exchange Transaction Pricing - Currency Receiving (3).json',
  'Virtual Account Opening': 'Blueprints_ejemplos/Virtual Account Opening/MCI - BP - Virtual Account Opening - Virtual Account V2.1.0 (2).json',
  'Debit Card': 'Blueprints_ejemplos/Debit Card Issuance/Copy of MCI - BP - [Debit Card Issuance] - [Management].json',
  Mortgage: 'Blueprints_ejemplos/Mortgage Loan Disbursement Management/MCI - BP -  [Mortgage Loan Disbursement Management] - [Disbursement Execution].json',
  'QR Payment': 'Blueprints_ejemplos/QR Payment Transactions Reporting/MCI - BP - QR Payment Transactions Reporting - Payment Transactions.json',
  'Escenario2': 'Solicitud Ajustes/Escenario2_Original.json'
};
const textOf = component => (component.textAreas ?? []).map(area => (typeof area === 'string' ? area : area?.text ?? '')).join(' ').replace(/\s+/g, ' ').trim();
const records = [];
for (const [blueprint, path] of Object.entries(CASES)) {
  const raw = JSON.parse(readFileSync(join(REPO, path), 'utf8').replace(/^﻿/, ''));
  const compact = copilotExport(analyzeBlueprint(raw, { sourceName: path }));
  for (const page of compact.pages) {
    const rawPage = raw.pages.find(item => item.id === page.page.id), byId = new Map(page.components.map(component => [component.id, component]));
    const rawById = new Map((rawPage.items?.shapes ?? []).map(shape => [shape.id, shape]));
    for (const container of page.components.filter(component => component.lucidchartType === 'RectangleContainerBlock')) {
      const rawShape = rawById.get(container.id), contained = rawShape?.contains?.shapes ?? [];
      const chainTypes = (container.containerChainIds ?? []).filter(id => id !== container.id).map(id => byId.get(id)?.architecturalType ?? null);
      records.push({
        blueprint, page: page.page.title || '(sin título)', pageKind: page.pageClassification?.kind, scenario: page.scenario?.scenario ?? null, scenarioStatus: page.scenario?.status ?? null,
        id: container.id, architecturalType: container.architecturalType, role: container.role, text: textOf(container).slice(0, 40),
        flags: {
          sinNombre: textOf(container) === '',
          sinPadre: !container.structuralParent?.id,
          anidado: container.structuralParent?.type === 'CHILD_CONTAINER' || chainTypes.includes('SERVICIO_HIJO'),
          sinRolPrincipal: container.role !== 'HIJO_PRINCIPAL',
          escenarioNoDeterminado: (page.scenario?.status ?? 'NO_DETERMINADO') === 'NO_DETERMINADO'
        },
        parent: container.structuralParent ? { id: container.structuralParent.id ?? null, type: container.structuralParent.type ?? null, status: container.structuralParent.status ?? null } : null,
        containedShapes: contained.length, inScenarioMain: page.scenario?.mainChildServiceId === container.id
      });
    }
  }
}
const operational = records.filter(record => ['OPERATIONAL', 'MIXED'].includes(record.pageKind));
const count = (list, flag) => list.filter(record => record.flags[flag]).length;
const summary = Object.fromEntries(['sinNombre', 'sinPadre', 'anidado', 'sinRolPrincipal', 'escenarioNoDeterminado'].map(flag => [flag, { operativas: count(operational, flag), plantillas: count(records.filter(record => !['OPERATIONAL', 'MIXED'].includes(record.pageKind)), flag) }]));
const flagged = operational.filter(record => record.flags.sinNombre || record.flags.sinPadre || record.flags.anidado || (record.flags.sinRolPrincipal && record.flags.escenarioNoDeterminado));
const lines = ['# Auditoría de contenedores hijo (`RectangleContainerBlock`) — solo lectura', '', `Reproducible con \`node qa/tools/audit-child-containers.mjs --out <archivo>\`. Total de contenedores: ${records.length}; en páginas OPERATIONAL/MIXED: ${operational.length}. Ninguna clasificación se modifica.`, '', '## Resumen por condición', '', '```json', JSON.stringify(summary, null, 2), '```', '', '## Contenedores operativos con alguna condición a señalar', '', '| Blueprint · página | ID | Tipo | Rol | Texto | Padre | Contiene | Sin nombre | Sin padre | Anidado | Escenario |', '|---|---|---|---|---|---|---|---|---|---|---|'];
for (const record of flagged) lines.push(`| ${record.blueprint} · ${record.page} | ${record.id} | ${record.architecturalType} | ${record.role ?? 'null'} | ${record.text || '_vacío_'} | ${record.parent?.id ?? '—'} (${record.parent?.type ?? '—'}) | ${record.containedShapes} | ${record.flags.sinNombre ? 'sí' : 'no'} | ${record.flags.sinPadre ? 'sí' : 'no'} | ${record.flags.anidado ? 'sí' : 'no'} | ${record.scenario ?? 'NO_DETERMINADO'} |`);
if (!flagged.length) lines.push('| _ninguno_ | | | | | | | | | | |');
lines.push('');
const out = process.argv.indexOf('--out');
if (out > -1) writeFileSync(join(REPO, process.argv[out + 1]), lines.join('\n')); else console.log(lines.join('\n'));
mkdirSync(join(REPO, 'qa', 'runs'), { recursive: true });
writeFileSync(join(REPO, 'qa', 'runs', 'child-containers-audit.json'), JSON.stringify({ summary, records }, null, 2));
