#!/usr/bin/env node
// Builds qa/cases/<id>/compact.json from the synthetic Lucidchart source by driving the DISTRIBUTED HTML
// (a real user path). It does not import the engine from src/.
import { createRequire } from 'node:module';
import { readFileSync, writeFileSync } from 'node:fs';
import { resolve, join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
const REPO = resolve(dirname(fileURLToPath(import.meta.url)), '..', '..');
const { chromium } = createRequire(join(REPO, 'package.json'))('playwright');
const id = process.argv[2];
const dir = join(REPO, 'qa', 'cases', id);
const html = join(REPO, 'dist', 'BlueprintEvidenceStudio.html');
const lucid = JSON.parse(readFileSync(join(dir, 'lucid.json'), 'utf8'));
const browser = await chromium.launch({ channel: 'msedge', headless: true });
try {
  const page = await browser.newPage();
  await page.goto('file:///' + html.replaceAll(String.fromCharCode(92), '/'));
  await page.fill('#blueprintId', 'QA-' + id.toUpperCase());
  await page.fill('#blueprintName', 'QA Sintético ' + id);
  await page.setInputFiles('#jsonFile', join(dir, 'lucid.json'));
  await page.waitForSelector('.pageChoice');
  await page.evaluate(() => document.querySelectorAll('.pageChoice').forEach(c => { c.checked = true; })); // select every page, as a user may
  const before = await page.evaluate(() => window.__BES__.getGeneration());
  await page.click('#analyze');
  await page.waitForFunction(x => window.__BES__.getGeneration() > x, before);
  const result = await page.evaluate(() => JSON.parse(JSON.stringify(window.__BES__.getResult())));
  writeFileSync(join(dir, 'compact.json'), JSON.stringify(result, null, 2) + '\n');
  writeFileSync(join(dir, 'compact.provenance.json'), JSON.stringify({ generatedBy: 'dist/BlueprintEvidenceStudio.html', htmlSha256: createHash('sha256').update(readFileSync(html)).digest('hex'), contract: result.contract, source: 'qa/cases/' + id + '/lucid.json (sintético)', pages: result.pages.map(p => ({ title: p.page.title, kind: p.pageClassification.kind, scenario: p.scenario.status })) }, null, 2) + '\n');
  console.log(id, result.contract, result.pages.map(p => `${p.page.title}:${p.pageClassification.kind}:${p.scenario.status}`).join(' | '));
} finally { await browser.close(); }
