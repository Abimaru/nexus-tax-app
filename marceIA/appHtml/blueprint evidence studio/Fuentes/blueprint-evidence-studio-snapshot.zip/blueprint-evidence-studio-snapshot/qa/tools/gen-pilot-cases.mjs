#!/usr/bin/env node
// Writes case.json and expected/*.expected.json for the four pilot cases.
// Expectations are authored from the synthetic sources and the rule texts BEFORE any model runs.
import { mkdirSync, writeFileSync, readFileSync } from 'node:fs';
import { join, resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
const QA = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const NA = 'No aplica', NV = 'No verificable', OK = 'Cumple';
const wj = (file, value) => { mkdirSync(dirname(file), { recursive: true }); writeFileSync(file, JSON.stringify(value, null, 2) + '\n'); };

const PROMPT = 'Valida este blueprint con la Skill validar-blueprint-integracion. El JSON compacto (contrato copilot-factual-v0.4.6.1) está en input/compact.json. Evalúa las páginas seleccionadas. Presenta las 41 reglas de cada página evaluable en una tabla con las columnas rule_id, Estado, Evidencia, Justificación e Información pendiente.';
const yes = text => ({ text, substantive: true });
const unknown = { text: 'No dispongo de ese dato.', substantive: false, kind: 'SCRIPTED_UNKNOWN' };

const rule = (population, acceptable, status, basis) => ({ population, acceptable, status, basis });
const technical = basis => rule('POBLACION_FUERA_DE_ALCANCE_DEMOSTRADA', [NA], 'TECHNICAL', basis);
const pending = (accept, basis, population = 'A_REVISAR_POR_ANALISTA') => rule(population, accept, 'PENDING_REVIEW', basis);

// Rules whose own No aplica text is met by facts the controller can prove from the compact JSON.
function commonRules({ hasCapaFlujo }) {
  const r = {
    'COM-001': technical('No hay ninguna BPMNActivity: ni comandos certificados ni candidatos.'),
    'COM-002': technical('Sin comandos no hay APIs invocadas relacionadas con comandos.'),
    'COM-003': technical('Sin comandos no hay servicios invocados relacionados con comandos.'),
    'COM-004': technical('Sin comandos no hay gestores relacionados con comandos.'),
    'MQ-005': technical('No hay gestores relacionados con servicios invocados: no existe ninguna conexión de ese tipo.'),
    'GW-001': pending([NA, NV], 'No hay BPMNGateway; la regla es condicional a su presencia.'),
    'EXT-001': pending([NA, NV], 'No hay auxiliares externos.'),
    'EXT-002': pending([NA, NV], 'Ídem.'),
    'CNT-006': pending([OK, NV], 'Cada componente con padre tiene un único structuralParent RESOLVED; la población "componentes evaluables" está pendiente (C15-Q3).')
  };
  for (const id of ['MQ-001', 'MQ-002', 'MQ-003', 'MQ-004']) r[id] = pending([NV], 'La ausencia de la figura de gestor no demuestra que no deba existir: No verificable; No aplica queda para revisión (C15-Q1).', 'POBLACION_POTENCIAL_NO_VERIFICABLE');
  if (!hasCapaFlujo) {
    r['CA-002'] = technical('La regla declara "No existe figura de Capa" y el JSON no tiene ninguna.');
    r['FT-002'] = technical('La regla declara "No existe figura de Flujo" y el JSON no tiene ninguna.');
  }
  return r;
}
const scenarioRules = scenario => Object.fromEntries(['E1-001', 'E2-001', 'E3-001'].map(id => [id, id.startsWith(scenario) ? pending([OK, NV], 'Escenario HIPOTESIS: la conexión al evento de Inicio no está certificada (el evento no declara subtipo).') : pending([NA, NV], 'Escenario solo HIPOTESIS (no certificado): la regla dice No aplica con escenario certificado de otro tipo.')]));

const base = (id, title, canary, extra) => ({ canary, version: 'piloto Fase 2', caseId: id, title, authoredBefore: 'Redactado antes de ejecutar ningún modelo. No usa informes de Codex ni de auditorías previas.', ...extra });

// ---- P1
wj(join(QA, 'cases/p1-operational/case.json'), { id: 'p1', title: 'P1 — OPERATIONAL: preguntas MCI y exposición, escenario, 41 resultados y métricas', prompt: PROMPT, maxTurns: 6,
  requiredQuestionsByPage: { consultarSaldoCuenta: ['mciPrincipal', 'mciHijo', 'exposicion'] }, checkScenarioMention: true,
  analystScript: { replies: { mciPrincipal: yes('Sí, la API principal está en MCI.'), mciHijo: yes('No, el servicio hijo principal no está en MCI.'), exposicion: yes('La exposición es Private.'), principalIdentity: yes('El principal es la API «Cuentas - Consulta Saldo v1.0.0».') } },
  conditionalChecks: [{ type: 'noRowHasState', name: 'NO_CUMPLE_PARA_REVISION', state: 'No cumple', reason: 'revisar que el incumplimiento esté demostrado por evidencia, no por la hipótesis de escenario' }] });
wj(join(QA, 'expected/p1-operational.expected.json'), base('p1', 'OPERATIONAL', 'QA-CANARY-p1-3c91e0a7', {
  facts: { pageKind: 'OPERATIONAL', scenario: 'E1/HIPOTESIS', main: 'p1-api (API, PRINCIPAL, INTEGRACIÓN)', child: 'p1-child (SERVICIO_HIJO, DOMINIO PRODUCTOR)', association: 'Flujo→Capa→API por contención directa (no acredita MCI)', exposureAccredited: false },
  objectiveInvariants: ['Pregunta MCI del principal, MCI del hijo y exposición (no está acreditada) antes del dictamen definitivo', '41 filas con IDs del catálogo, estados válidos', 'Métrica recalculada coincide', 'Registra DECLARADO_POR_ANALISTA', 'No usa la asociación Flujo/Capa para dar por acreditado el MCI', 'No pregunta contención, conexiones ni escenario'],
  ruleExpectations: { ...commonRules({ hasCapaFlujo: true }), ...scenarioRules('E1'), 'API-004': pending([OK, NV, 'No cumple'], 'Depende de la respuesta MCI del analista y de las asociaciones Capa/Flujo (contención directa); revisar que el MCI no se infiera de la asociación.') },
  pendingNormativeReview: [{ id: 'P1-Q1', question: 'API-004 con MCI declarado Sí, exposición Private y Capa+Flujo por contención: ¿Cumple o No verificable? Revisar la justificación del agente.' }] }));

// ---- P2
wj(join(QA, 'cases/p2-mixed/case.json'), { id: 'p2', title: 'P2 — MIXED: operación real con leyenda NOTACIÓN que no debe usarse como evidencia', prompt: PROMPT, maxTurns: 6,
  requiredQuestionsByPage: { transferirFondos: ['mciPrincipal', 'mciHijo'] }, mustNotAskByPage: { transferirFondos: ['exposicion'] }, legendCheck: true, checkScenarioMention: true,
  analystScript: { replies: { mciPrincipal: yes('Sí, la API principal está en MCI.'), mciHijo: yes('Sí, el servicio hijo principal está en MCI.'), principalIdentity: yes('El principal es la API «Transferencias - Fondos v1.0.0».') } },
  conditionalChecks: [] });
wj(join(QA, 'expected/p2-mixed.expected.json'), base('p2', 'MIXED', 'QA-CANARY-p2-b27d4f15', {
  facts: { pageKind: 'MIXED', scenario: 'E2/HIPOTESIS', main: 'p2-api', child: 'p2-child (en la misma INTEGRACIÓN)', legendShapeIds: ['p2-legend', 'p2-leg-api', 'p2-leg-qm', 'p2-leg-ev'], trap: 'La leyenda contiene una figura UMLActiveClassBlock (aparece como GESTOR_COLAS), una API de plantilla "Nombre API" y una conexión API→evento', exposureAccredited: true },
  objectiveInvariants: ['Evalúa 41 reglas de la operación real', 'Ninguna fila Cumple/No cumple se apoya en figuras de legendShapeIds', 'No evalúa MQ con la figura de la leyenda', 'No evalúa API-001..003 con "Nombre API"', 'No pregunta la exposición (Private ya figura en la tercera sección)', 'Pregunta MCI del principal y del hijo'],
  ruleExpectations: { ...commonRules({ hasCapaFlujo: false }), ...scenarioRules('E2') },
  pendingNormativeReview: [{ id: 'P2-Q1', question: 'MQ-001..004 en una página MIXED cuya única figura de gestor es de leyenda: No verificable (población potencial) frente a No aplica (revisión C15-Q1). El controlador solo comprueba que la leyenda no se use como evidencia.' }] }));

// ---- P3
wj(join(QA, 'cases/p3-contradiction/case.json'), { id: 'p3', title: 'P3 — Contradicción tipo/evidencia: BDD por el título con operación real', prompt: PROMPT, maxTurns: 6, pageExpectation: 'CONTRADICTION_REQUIRES_CONFIRMATION',
  requiredQuestionsByPage: { 'Escenarios BDD - consultarSaldoCuenta': ['mciPrincipal', 'mciHijo'] }, mustNotAskByPage: { 'Escenarios BDD - consultarSaldoCuenta': ['exposicion'] },
  analystScript: { replies: { pageClassification: yes('Es una operación real (OPERATIONAL) y debe evaluarse.'), mciPrincipal: yes('Sí, la API principal está en MCI.'), mciHijo: yes('No, el servicio hijo principal no está en MCI.'), principalIdentity: yes('El principal es la API «Cuentas - Consulta Saldo v1.0.0».') } },
  conditionalChecks: [] });
wj(join(QA, 'expected/p3-contradiction.expected.json'), base('p3', 'Contradicción', 'QA-CANARY-p3-9e8a6c43', {
  facts: { pageKind: 'BDD_OR_REQUIREMENTS (por el título)', scenarioInCompact: 'NO_DETERMINADO / PAGE_NOT_OPERATIONAL', evidenceOfOperation: ['pageClassification.operationalPathIds = [p3-l1]', 'conexión p3-l1 de p3-api a p3-ev (None→Arrow)', 'p3-api con role PRINCIPAL y architecturalType API', 'p3-child SERVICIO_HIJO en DOMINIO PRODUCTOR'], exposureAccredited: true },
  objectiveInvariants: ['El primer turno detecta la contradicción entre el tipo y la evidencia', 'Cita al menos un identificador de la evidencia (conexión p3-l1, p3-api, operationalPathIds)', 'Pide confirmación de que es una operación real', 'No emite evaluación de reglas antes de la respuesta', 'No descarta la operación por contener BDD', 'Tras la confirmación evalúa 41 reglas; registra la confirmación como DECLARADO_POR_ANALISTA solo para la clasificación'],
  ruleExpectations: { ...commonRules({ hasCapaFlujo: false }), 'E1-001': pending([NV], 'El JSON declara el escenario NO_DETERMINADO: la estructura no está certificada.'), 'E2-001': pending([NV, NA], 'Escenario no determinado: no hay escenario certificado que haga No aplica.'), 'E3-001': pending([NV, NA], 'Ídem.') },
  pendingNormativeReview: [{ id: 'P3-Q1', question: 'Tras confirmar la clasificación, el compacto sigue con escenario NO_DETERMINADO (el exportador excluye las páginas BDD del escenario). ¿El agente puede apoyarse en la estructura visible (role PRINCIPAL, conexión) para sus reglas o debe tratarlas como No verificable? Decide Andrés / la analista.' }] }));

// ---- P4
const A = 'consultarClientePorId', B = 'actualizarClienteContacto';
wj(join(QA, 'cases/p4-multipage/case.json'), { id: 'p4', title: 'P4 — Multipágina: dos operaciones con componentes compartidos y respuestas distintas', prompt: PROMPT, maxTurns: 8, consolidated: true, expectedEvaluablePages: 2, checkScenarioMention: true,
  requiredQuestionsByPage: { [A]: ['mciPrincipal', 'mciHijo', 'exposicion'], [B]: ['mciPrincipal', 'mciHijo'] }, mustNotAskByPage: { [B]: ['exposicion'] },
  analystScript: { replies: {
    mciPrincipal: { perPage: { [A]: yes('Sí, la API principal está en MCI.'), [B]: yes('No, la API principal no está en MCI.') } },
    mciHijo: { perPage: { [A]: yes('No, el servicio hijo principal no está en MCI.'), [B]: yes('Sí, el servicio hijo principal está en MCI.') } },
    exposicion: { perPage: { [A]: yes('La exposición es Private.'), [B]: yes('La exposición es Public, como figura en el diagrama.') } },
    reuseConfirmation: { text: 'No reutilices respuestas entre páginas: pregunta cada página por separado.', substantive: false },
    principalIdentity: { perPage: { [A]: yes('El principal es la API «Clientes - Consulta v1.0.0».'), [B]: yes('El principal es la API «Clientes - Contacto v1.0.0».') } } } },
  conditionalChecks: [] });
wj(join(QA, 'expected/p4-multipage.expected.json'), base('p4', 'Multipágina', 'QA-CANARY-p4-51f0d2be', {
  facts: { pages: { [A]: 'OPERATIONAL, E1/HIPOTESIS, exposición NO acreditada (Entidad)', [B]: 'OPERATIONAL, E2/HIPOTESIS, exposición acreditada (Public)' }, shared: 'ms-validar-cliente (mismo nombre en ambas páginas) y el hijo ms-cliente-core (mismo nombre, dominios distintos)', scriptedAnswers: { [A]: { mciPrincipal: 'Sí', mciHijo: 'No', exposicion: 'Private' }, [B]: { mciPrincipal: 'No', mciHijo: 'Sí', exposicion: 'Public' } } },
  objectiveInvariants: ['Preguntas independientes por página (MCI principal, MCI hijo; exposición solo en la página donde no está acreditada)', 'No traslada respuestas de una página a otra sin confirmación explícita (las respuestas son opuestas)', 'Registra DECLARADO_POR_ANALISTA en la sección de cada página', '41 resultados por cada página evaluable', 'Porcentaje consolidado ponderado por evaluaciones regla–página, no promedio de porcentajes'],
  ruleExpectations: undefined,
  perPageRuleExpectations: { [A]: { ...commonRules({ hasCapaFlujo: false }), ...scenarioRules('E1') }, [B]: { ...commonRules({ hasCapaFlujo: false }), ...scenarioRules('E2') } },
  pendingNormativeReview: [{ id: 'P4-Q1', question: 'Los componentes compartidos por nombre (ms-validar-cliente, ms-cliente-core) no son el mismo componente: son figuras distintas en páginas distintas. ¿Debe el agente tratarlas por separado en todo caso? (criterio de la Skill: cada página se evalúa de forma independiente)' }] }));

// ---- scripted-unknown replies for C14 / C15 (no fallback text any more)
for (const dir of ['c14-zero-applicable', 'c15-evidence-free']) {
  const file = join(QA, 'cases', dir, 'case.json');
  const meta = JSON.parse(readFileSync(file, 'utf8'));
  delete meta.analystScript.fallback;
  for (const topic of ['mciPrincipal', 'mciHijo', 'exposicion']) meta.analystScript.replies[topic] = { ...unknown };
  if (meta.analystScript.replies.principalIdentity) meta.analystScript.replies.principalIdentity = { text: 'No puedo precisar cuál es el componente principal.', substantive: false, kind: 'SCRIPTED_UNKNOWN' };
  wj(file, meta);
}
console.log('pilot cases + expectations written');
