// Read-only, reproducible check of the evidence available for MOD-001 (input/output models).
// Reads the original Lucidchart JSON files, runs the distributed engine (src/) and compares what the
// compact export preserved. It never writes to Blueprints_ejemplos/ and never changes any classification.
// Usage: node qa/tools/audit-mod001.mjs [--out docs/audits/MOD001_VERIFICACION_2026-10-25.md]
import { readFileSync, writeFileSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { isDeepStrictEqual } from 'node:util';

const REPO = resolve(dirname(fileURLToPath(import.meta.url)), '..', '..');
const { analyzeBlueprint, copilotExport } = await import(pathToFileURL(join(REPO, 'src', 'exporter.js')).href);

const CASES = {
  Oski: 'Blueprints_ejemplos/Collections_Bill_Payments/NMD - BP -  Collections_Bill_Payments-Pay_Bill U (1).json',
  'Currency Exchange': 'Blueprints_ejemplos/Ejemplo E2/MCI - BP - Currency Exchange Transaction Pricing - Currency Receiving (3).json',
  'Virtual Account Opening': 'Blueprints_ejemplos/Virtual Account Opening/MCI - BP - Virtual Account Opening - Virtual Account V2.1.0 (2).json',
  'Debit Card': 'Blueprints_ejemplos/Debit Card Issuance/Copy of MCI - BP - [Debit Card Issuance] - [Management].json',
  Mortgage: 'Blueprints_ejemplos/Mortgage Loan Disbursement Management/MCI - BP -  [Mortgage Loan Disbursement Management] - [Disbursement Execution].json',
  'QR Payment': 'Blueprints_ejemplos/QR Payment Transactions Reporting/MCI - BP - QR Payment Transactions Reporting - Payment Transactions.json',
  'Escenario2 (nombreOperacion)': 'Solicitud Ajustes/Escenario2_Original.json'
};
const MODEL_KEYS = ['ENTRADA', 'SALIDA'];
const OWNER_TYPES = new Set(['API', 'SERVICIO', 'SERVICIO_HIJO', 'EVENTO', 'GESTOR_COLAS']);
const readJson = path => JSON.parse(readFileSync(join(REPO, path), 'utf8').replace(/^﻿/, ''));
const modelKeyOf = shape => {
  const keys = (Array.isArray(shape.customData) ? shape.customData : []).map(entry => String(entry?.key ?? '').toUpperCase()).filter(key => MODEL_KEYS.includes(key));
  return [...new Set(keys)];
};

const rows = [], totals = { pages: 0, evaluablePages: 0, models: 0, preserved: 0, modelsInOneGroupWithMain: 0, modelsAmbiguous: 0, modelsUngrouped: 0, mainsWithBoth: 0, mainsEvaluated: 0, mainsMissing: 0, mainsAmbiguous: 0 };

for (const [name, path] of Object.entries(CASES)) {
  const raw = readJson(path), model = analyzeBlueprint(raw, { sourceName: path }), compact = copilotExport(model);
  for (const cp of compact.pages) {
    const rawPage = raw.pages.find(page => page.id === cp.page.id), shapes = rawPage.items?.shapes ?? [], groups = rawPage.items?.groups ?? [], lines = rawPage.items?.lines ?? [];
    const byId = new Map(cp.components.map(component => [component.id, component]));
    const rawById = new Map(shapes.map(shape => [shape.id, shape]));
    const kind = cp.pageClassification?.kind;
    totals.pages++;
    const evaluable = kind === 'OPERATIONAL' || kind === 'MIXED';
    if (evaluable) totals.evaluablePages++;
    const modelShapes = shapes.filter(shape => modelKeyOf(shape).length);
    const mainId = cp.scenario?.mainComponentId ?? null;
    const mainCandidates = cp.components.filter(component => component.role === 'PRINCIPAL').map(component => component.id);
    const issues = [];
    const modelRecords = modelShapes.map(shape => {
      const compactComponent = byId.get(shape.id), keys = modelKeyOf(shape);
      const preserved = !!compactComponent && isDeepStrictEqual(compactComponent.customData, shape.customData) && isDeepStrictEqual(compactComponent.textAreas, shape.textAreas) && compactComponent.lucidchartType === shape.class && compactComponent.id === shape.id;
      const containing = groups.filter(group => group.members.includes(shape.id));
      const compactGroups = (cp.groups ?? []).filter(group => group.directMemberIds.includes(shape.id));
      const groupsPreserved = containing.length === compactGroups.length && containing.every(group => compactGroups.some(cg => cg.id === group.id && isDeepStrictEqual(cg.directMemberIds, group.members)));
      const withOwners = containing.map(group => ({ groupId: group.id, owners: group.members.filter(id => OWNER_TYPES.has(byId.get(id)?.architecturalType) || id === mainId).filter(id => id !== shape.id) }));
      const withMain = withOwners.filter(entry => mainId && entry.owners.includes(mainId));
      const lineRefs = lines.filter(line => [line.endpoint1?.connectedTo, line.endpoint2?.connectedTo].includes(shape.id)).length;
      let association;
      if (!containing.length) association = 'SIN_GRUPO';
      else if (withMain.length === 1 && containing.length === 1 && withOwners[0].owners.length === 1) association = 'GRUPO_UNICO_CON_PRINCIPAL';
      else if (withMain.length >= 1) association = 'GRUPO_CON_PRINCIPAL_Y_OTROS_CANDIDATOS';
      else association = 'GRUPO_SIN_PRINCIPAL';
      return { id: shape.id, lucidchartClass: shape.class, keys, architecturalType: compactComponent?.architecturalType ?? null, preserved, groupsPreserved, groups: containing.map(group => group.id), association, ownerCandidates: [...new Set(withOwners.flatMap(entry => entry.owners))], lineRefs, structuralParent: compactComponent?.structuralParent?.id ?? null };
    });
    totals.models += modelRecords.length;
    totals.preserved += modelRecords.filter(record => record.preserved && record.groupsPreserved).length;
    totals.modelsInOneGroupWithMain += modelRecords.filter(record => record.association === 'GRUPO_UNICO_CON_PRINCIPAL').length;
    totals.modelsAmbiguous += modelRecords.filter(record => record.association === 'GRUPO_CON_PRINCIPAL_Y_OTROS_CANDIDATOS' || record.association === 'GRUPO_SIN_PRINCIPAL').length;
    totals.modelsUngrouped += modelRecords.filter(record => record.association === 'SIN_GRUPO').length;
    let mainState = 'NO_APLICA_PAGINA_NO_EVALUABLE';
    if (evaluable) {
      totals.mainsEvaluated++;
      const mine = modelRecords.filter(record => mainId && record.ownerCandidates.includes(mainId));
      const haveIn = mine.some(record => record.keys.includes('ENTRADA')), haveOut = mine.some(record => record.keys.includes('SALIDA'));
      if (!mainId) { mainState = 'SIN_PRINCIPAL_RESUELTO'; totals.mainsMissing++; }
      else if (haveIn && haveOut) { mainState = mine.every(record => record.association === 'GRUPO_UNICO_CON_PRINCIPAL') ? 'ENTRADA_Y_SALIDA_ASOCIADAS_POR_GRUPO' : 'ENTRADA_Y_SALIDA_CON_AMBIGUEDAD'; if (mainState === 'ENTRADA_Y_SALIDA_ASOCIADAS_POR_GRUPO') totals.mainsWithBoth++; else totals.mainsAmbiguous++; }
      else { mainState = `FALTA_${!haveIn ? 'ENTRADA' : ''}${!haveIn && !haveOut ? '_Y_' : ''}${!haveOut ? 'SALIDA' : ''}_ASOCIADA`; totals.mainsMissing++; }
    }
    if (modelRecords.some(record => !record.preserved)) issues.push('modelo no preservado literalmente en el compacto');
    if (modelRecords.some(record => !record.groupsPreserved)) issues.push('membresía de grupo distinta entre original y compacto');
    const decorative = shapes.filter(shape => /^Modelo (de )?(Entrada|Salida|Lectura)/i.test((shape.textAreas?.[0]?.text ?? '').trim())).map(shape => ({ id: shape.id, class: shape.class, text: shape.textAreas[0].text.trim(), architecturalType: byId.get(shape.id)?.architecturalType ?? null }));
    rows.push({ blueprint: name, page: cp.page.title || '(sin título)', pageId: cp.page.id, kind, mainId, mainCandidates, scenario: cp.scenario?.scenario ?? null, models: modelRecords, labelShapes: decorative, mainState, issues });
  }
}

const out = { generatedBy: 'qa/tools/audit-mod001.mjs', readOnly: true, totals, rows };
const outIndex = process.argv.indexOf('--out');
const md = [];
md.push('# Verificación de MOD-001 — evidencia disponible (solo lectura)', '', 'Reproducible con `node qa/tools/audit-mod001.mjs --out <archivo>`. Lee los JSON originales, ejecuta el motor vigente sin modificarlo y compara lo que el compacto conserva. **No** reclasifica `MODELO`, **no** crea asociaciones y **no** emite dictamen: informa la evidencia que MOD-001 tendría disponible.', '');
md.push('## Totales', '', '```json', JSON.stringify(totals, null, 2), '```', '');
md.push('## Por página', '', '| Blueprint · página | Tipo de página | Escenario | Principal | Modelos con ENTRADA/SALIDA (customData) | Preservados | Asociación por grupo | Estado para el principal |', '|---|---|---|---|---|---|---|---|');
for (const row of rows) {
  const preserved = row.models.length ? (row.models.every(m => m.preserved && m.groupsPreserved) ? 'sí' : 'NO') : '—';
  const assoc = row.models.length ? [...new Set(row.models.map(m => m.association))].join(', ') : '—';
  md.push(`| ${row.blueprint} · ${row.page} | ${row.kind} | ${row.scenario ?? '—'} | ${row.mainId ?? '—'} | ${row.models.length ? row.models.map(m => `${m.id} (${m.keys.join('/')})`).join(', ') : 'ninguno'} | ${preserved} | ${assoc} | ${row.mainState} |`);
}
md.push('', '## Figuras con el texto «Modelo de …» (etiquetas, no datos)', '', '| Blueprint · página | ID | Clase | Texto | `architecturalType` en el compacto |', '|---|---|---|---|---|');
for (const row of rows) for (const label of row.labelShapes) md.push(`| ${row.blueprint} · ${row.page} | ${label.id} | ${label.class} | ${label.text} | ${label.architecturalType ?? 'null'} |`);
md.push('');
const text = md.join('\n');
if (outIndex > -1) writeFileSync(join(REPO, process.argv[outIndex + 1]), text);
else console.log(text);
writeFileSync(join(REPO, 'qa', 'runs', 'mod001-audit.json'), JSON.stringify(out, null, 2));
