#!/usr/bin/env node
// Writes the synthetic Lucidchart sources of the four pilot cases (P1..P4). No corporate data: every name is invented.
import { mkdirSync, writeFileSync } from 'node:fs';
import { join, resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
const QA = resolve(dirname(fileURLToPath(import.meta.url)), '..');

const box = (id, text, kids = [], cls = 'UMLRectangleContainerBlock') => ({ id, class: cls, textAreas: [{ label: 'Text', text }], customData: [], linkedData: [], contains: { shapes: kids, lines: [], groups: [] } });
const api = (id, title, operation, third) => ({ id, class: 'UMLClassBlock', textAreas: [{ label: 'Title', text: title }, { label: 'Text1', text: operation }, ...(third ? [{ label: 'Text2', text: third }] : [])], customData: [], linkedData: [] });
const qm = (id, text) => ({ id, class: 'UMLActiveClassBlock', textAreas: [{ label: 'Text', text }], customData: [], linkedData: [] });
const event = (id, text = '') => ({ id, class: 'BPMNEvent', textAreas: text ? [{ label: 'Text', text }] : [], customData: [], linkedData: [] });
const line = (id, from, to) => ({ id, endpoint1: { style: 'None', connectedTo: from }, endpoint2: { style: 'Arrow', connectedTo: to }, textAreas: [], customData: [], linkedData: [] });
const page = (id, title, index, shapes, lines) => ({ id, title, index, items: { shapes, lines, groups: [], layers: [] }, customData: [], linkedData: [] });
const doc = (id, title, pages) => ({ id, title, pages, data: { collections: [] } });
const write = (caseDir, value) => { const dir = join(QA, 'cases', caseDir); mkdirSync(dir, { recursive: true }); writeFileSync(join(dir, 'lucid.json'), JSON.stringify(value, null, 2) + '\n'); };

// P1 — OPERATIONAL (E1): API in INTEGRACIÓN with Flujo/Capa by containment, child service in the producer domain. Exposure NOT accredited.
write('p1-operational', doc('qa-p1', 'QA piloto P1', [page('p1', 'consultarSaldoCuenta', 0, [
  box('p1-integ', 'INTEGRACIÓN', ['p1-flujo', 'p1-capa', 'p1-api']),
  box('p1-flujo', 'Flujo Transaccional - no-monetario', ['p1-capa', 'p1-api']),
  box('p1-capa', 'Capa de Arquitectura - sistema', ['p1-api']),
  api('p1-api', 'Cuentas - Consulta Saldo v1.0.0', 'consultarSaldoCuenta', 'Entidad'),
  box('p1-prod', 'DOMINIO PRODUCTOR', ['p1-child', 'p1-ev']),
  box('p1-child', 'ms-cuentas-saldo', ['p1-ev'], 'RectangleContainerBlock'),
  event('p1-ev')
], [line('p1-l1', 'p1-api', 'p1-ev')])]));

// P2 — MIXED (E2): real operation plus a NOTACIÓN legend that contains tempting API / queue-manager / event figures and a connection.
write('p2-mixed', doc('qa-p2', 'QA piloto P2', [page('p2', 'transferirFondos', 0, [
  box('p2-integ', 'INTEGRACIÓN', ['p2-api', 'p2-child', 'p2-ev']),
  api('p2-api', 'Transferencias - Fondos v1.0.0', 'transferirFondos', 'Private'),
  box('p2-child', 'ms-transferir-fondos', ['p2-ev'], 'RectangleContainerBlock'),
  event('p2-ev'),
  box('p2-legend', 'NOTACIÓN', ['p2-leg-api', 'p2-leg-qm', 'p2-leg-ev']),
  api('p2-leg-api', 'Nombre API', 'nombreFuncionalMetodo', 'Clasificación API'),
  qm('p2-leg-qm', 'Nombre Gestor de Colas'),
  event('p2-leg-ev', 'Evento de ejemplo')
], [line('p2-l1', 'p2-api', 'p2-ev'), line('p2-leg-l1', 'p2-leg-api', 'p2-leg-ev')])]));

// P3 — type/evidence contradiction: the title says BDD (so the exporter classifies BDD_OR_REQUIREMENTS) but the page holds a real operation.
write('p3-contradiction', doc('qa-p3', 'QA piloto P3', [page('p3', 'Escenarios BDD - consultarSaldoCuenta', 0, [
  box('p3-integ', 'INTEGRACIÓN', ['p3-api']),
  api('p3-api', 'Cuentas - Consulta Saldo v1.0.0', 'consultarSaldoCuenta', 'Private'),
  box('p3-prod', 'DOMINIO PRODUCTOR', ['p3-child', 'p3-ev']),
  box('p3-child', 'ms-cuentas-saldo', ['p3-ev'], 'RectangleContainerBlock'),
  event('p3-ev')
], [line('p3-l1', 'p3-api', 'p3-ev')])]));

// P4 — two operations sharing component names (same child service name, same invoked service). Different declared data per page.
write('p4-multipage', doc('qa-p4', 'QA piloto P4', [
  page('pa', 'consultarClientePorId', 0, [
    box('pa-integ', 'INTEGRACIÓN', ['pa-api', 'pa-svc']),
    api('pa-api', 'Clientes - Consulta v1.0.0', 'consultarClientePorId', 'Entidad'),
    api('pa-svc', 'ms-validar-cliente', 'validarCliente', 'Tarea'),
    box('pa-prod', 'DOMINIO PRODUCTOR', ['pa-child', 'pa-ev']),
    box('pa-child', 'ms-cliente-core', ['pa-ev'], 'RectangleContainerBlock'),
    event('pa-ev')
  ], [line('pa-l1', 'pa-api', 'pa-ev')]),
  page('pb', 'actualizarClienteContacto', 1, [
    box('pb-integ', 'INTEGRACIÓN', ['pb-api', 'pb-child', 'pb-ev', 'pb-svc']),
    api('pb-api', 'Clientes - Contacto v1.0.0', 'actualizarClienteContacto', 'Public'),
    box('pb-child', 'ms-cliente-core', ['pb-ev'], 'RectangleContainerBlock'),
    event('pb-ev'),
    api('pb-svc', 'ms-validar-cliente', 'validarCliente', 'Tarea')
  ], [line('pb-l1', 'pb-api', 'pb-ev')])
]));
console.log('pilot sources written');
