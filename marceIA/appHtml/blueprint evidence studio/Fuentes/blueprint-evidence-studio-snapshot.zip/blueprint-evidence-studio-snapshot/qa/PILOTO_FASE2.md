> Histórico: piloto ejecutado con la Skill v11.2.2 (41 reglas).

# Piloto de la Fase 2 — cuatro casos sintéticos

Skill v11.2.2 (SHA-256 `9b35a98e…`), contrato `copilot-factual-v0.4.6.1`, modelo `claude-opus-5-5` (alias `opus`), Claude Code 2.1.309. Una ejecución real por caso; ninguna repetición automática. Resultados en `qa/runs/pilot-p1…p4`. **No es una certificación de la Skill.**

## 1. Resultado por caso

| Caso | Qué prueba | Resultado técnico | Reglas | Cumplimiento |
|---|---|---|---|---|
| P1 OPERATIONAL | Preguntas MCI/exposición, escenario, 41 resultados, métrica | Sin FAIL. 15 comprobaciones PASS, 2 REVISAR | 41 | 11/28 = **39,29 %** |
| P2 MIXED | Operación real con leyenda NOTACIÓN | Sin FAIL. Ninguna fila Cumple/No cumple usa la leyenda | 41 | 3/23 = **13,04 %** |
| P3 contradicción | Título BDD con operación real | Sin FAIL. Detectó la contradicción, citó `p3-l1`, `p3-api`, `p3-ev`, pidió confirmación y no evaluó antes | 41 (tras confirmar) | 2/22 = **9,09 %** |
| P4 multipágina | Dos operaciones, respuestas distintas, consolidado | Sin FAIL. Preguntas por página, sin reutilizar, 41 + 41, consolidado ponderado | 41 + 41 | pa 4/27 = **14,81 %**; pb 3/26 = **11,54 %**; blueprint 7/53 = **13,21 %** |

Los "Sin FAIL" son tras corregir cinco defectos del **controlador** (sección 5); las transcripciones originales no cambiaron.

## 2. Preguntas y respuestas por turno

| Caso | Turno | El agente preguntó | Respuesta del guion (origen `SCRIPT`) |
|---|---|---|---|
| P1 | 1 | MCI de `p1-api`; MCI de `p1-child`; exposición de `p1-api` (la tercera sección dice "Entidad") | Sí; No; Private |
| P1 | 2 | — (informe final) | — |
| P2 | 1 | MCI de `p2-api`; MCI de `p2-child`. No preguntó la exposición (la API ya declara `Private`) | Sí; Sí |
| P2 | 2 | — (informe final) | — |
| P3 | 1 | "¿Confirmas que es una operación real que debe evaluarse?" citando `p3-api` (PRINCIPAL) y `p3-l1` | "Es una operación real (OPERATIONAL) y debe evaluarse." |
| P3 | 2 | MCI de `p3-api`; si `p3-child` es el hijo principal y su MCI. No preguntó la exposición (`Private`) | Sí; No |
| P3 | 3 | — (informe final) | — |
| P4 | 1 | Página pa: MCI principal, MCI hijo, exposición. Página pb: MCI principal, MCI hijo. No preguntó la exposición de pb (`Public`) y advirtió que no reutilizaría respuestas entre páginas | pa: Sí, No, Private. pb: No, Sí |
| P4 | 2 | — (informe final) | — |

Procedencia: en los cuatro informes las respuestas figuran como `DECLARADO_POR_ANALISTA`, por página en P4 (en una tabla con una columna de página). Ningún agente propuso reutilizar respuestas entre páginas, y en P4 las dos páginas recibieron respuestas **opuestas** que se aplicaron cada una en la suya (pa: API-004, CA-001 y FT-001 No cumple por MCI; pb: API-004 No aplica por no ser MCI).

## 3. Reglas evaluadas y métricas

| Caso | Cumple | No cumple | No verificable | No aplica | Denominador | % |
|---|---:|---:|---:|---:|---:|---:|
| P1 | 11 | 2 | 15 | 13 | 28 | 39,29 |
| P2 | 3 | 3 | 17 | 18 | 23 | 13,04 |
| P3 | 2 | 5 | 15 | 19 | 22 | 9,09 |
| P4 pa | 4 | 5 | 18 | 14 | 27 | 14,81 |
| P4 pb | 3 | 2 | 21 | 15 | 26 | 11,54 |
| P4 blueprint | 7 | 7 | 39 | 29 | 53 | 13,21 |

El controlador recalculó cada porcentaje a partir de las filas del propio agente y coinciden. En P4 el agente informó que no promedia porcentajes (el promedio simple, 13,18 %, y el ponderado, 13,21 %, quedan demasiado cerca para distinguirlos con estos datos).

## 4. Comparación con las expectativas

| Expectativa (redactada antes de ejecutar) | P1 | P2 | P3 | P4 |
|---|---|---|---|---|
| Preguntas obligatorias por página y ninguna sobre datos acreditados | ✔ | ✔ | ✔ | ✔ |
| 41 filas válidas, estados válidos | ✔ | ✔ | ✔ | ✔ (×2) |
| Métrica coincide | ✔ | ✔ | ✔ | ✔ |
| Procedencia registrada | ✔ | ✔ | ✔ | ✔ (por página) |
| Escenario coherente con el JSON | E1 | E2 | NO_DETERMINADO | E1 y E2 |
| Aislamiento (herramientas, rutas, canario) | ✔ | ✔ | ✔ | ✔ |
| Leyenda no usada como evidencia | — | ✔ | — | — |
| Contradicción: detectada, evidencia citada, confirmación, sin dictamen previo | — | — | ✔ | — |
| Reglas con población demostrablemente ausente (TECHNICAL: COM-001…004, MQ-005, CA-002/FT-002 donde no hay Capa/Flujo) | ✔ | ✔ | ✔ | ✔ |
| Reglas PENDING_REVIEW fuera de lo aceptable | MQ-001…004 No aplica | MQ-001…004 No aplica | MQ-001…004 No aplica | MQ-002…004 No aplica (en pa y en pb) |

## 5. Errores del controlador (corregidos; sin nuevas llamadas al modelo salvo `resume`)

| # | Qué falló | Efecto | Corrección |
|---|---|---|---|
| 1 | Una pregunta dentro de una celda de tabla de "Información pendiente" se leyó como pregunta para la analista (P1) | La ejecución se suspendió con el informe ya entregado | Las filas de tabla ya no cuentan como preguntas; `reevaluate` recalcula la parada |
| 2 | Línea de recomendaciones ("1. **API-003:** añadir…") contada como fila contradictoria (P1) | 39 de 41 filas | Las líneas sin estado no contradicen la fila real |
| 3 | Porcentaje en columna "Cumplimiento" de una tabla no se leía (P1) | Métrica sin porcentaje legible | Lectura de columna por cabecera |
| 4 | La pregunta "¿está desplegada en MCI (sí o no)?" no se podía mapear sin su línea introductoria (P2) | El caso se suspendió correctamente con `UNMAPPED_ANALYST_QUESTION` y sin responder nada | Mapeo con el contexto de la línea; se continuó con `resume` automático (respuestas del guion) |
| 5 | Conteos "3 Cumple · 2 No cumple…" y la tabla de totales dentro del segmento de la segunda página (P4) | Falso FAIL de conteos; procedencia por página no reconocida | Lectura con número delante, fila elegida por página, segmentos que terminan antes del total; procedencia aceptada en una tabla por página |
| 6 | Identificadores citados como `[id]` marcados desconocidos (P3) | Falso REVISAR | Se quitan corchetes y paréntesis |

Además, el guion de los casos multipágina enviaba las respuestas sin etiqueta de página. En P4 el agente las asignó bien por orden, pero ya se etiqueta cada respuesta con su página. Limitaciones que persisten: el mapeo de preguntas sigue siendo por palabras clave, y en P3 una respuesta se registró dos veces (el texto enviado se deduplica y no afecta al agente).

## 6. Inconsistencias y observaciones del agente (para revisión humana; sin causa asignada)

| # | Observación | Casos | Frecuencia |
|---|---|---|---|
| O1 | MQ-001…004 → No aplica en páginas sin gestor, cuando el criterio aprobado es No verificable salvo que haya evidencia de inaplicabilidad. Razonamiento del agente: "no existe gestor ni candidato en la operación" (todas las figuras están tipificadas). Ver C15-Q1 | P1, P2, P3; P4 (MQ-002…004) | 4 de 4 ejecuciones |
| O2 | SRV-001…003 con el mismo tipo de estructura (hijo principal y sin servicios invocados): No verificable en P1, No aplica en P2 y P3 | P1 vs P2/P3 | Inconsistencia entre ejecuciones |
| O3 | CA-001 / FT-001: P1 Cumple; P3 y P4 pa No cumple (y además API-004 No cumple, que ya cubre la falta de Capa y Flujo); P2 No verificable con API-004 No cumple. Posible doble conteo de la misma falta | P2, P3, P4 | 3 de 4 |
| O4 | API-003 → No cumple en los cuatro casos porque la tercera sección no contiene el modelo (o, en P1, el tipo de exposición: el agente dice que declarar "Private" ante la analista no suple el diagrama). Hay tensión con el paso 4 de la Skill, que pregunta la exposición cuando no está acreditada | P1…P4 | 4 de 4 |
| O5 | P3: atribuye el "No MCI" a `p3-child` aunque su `role` es `null`, y lo declara como limitación | P3 | Transparente; revisar |
| O6 | P1: SRV-001…003 quedan No verificable con la nota "¿el hijo entra en las reglas SRV?" | P1 | Pregunta normativa abierta |
| O7 | MOD-001 → No cumple (no hay modelos de entrada y salida) | P1, P2, P3, P4 | Coherente con el texto de la regla; revisar si procede No cumple o No verificable |

Lo que **no** ocurrió: el agente no usó la leyenda como evidencia (P2), no descartó la operación BDD (P3), no trasladó respuestas entre páginas (P4), no dio un dictamen definitivo antes de confirmar la clasificación (P3), no inventó principal ni escenario y no declaró estable ni certificado nada.

## 7. Pendientes de revisión normativa
Las cuatro decisiones de `DECISIONES_PENDIENTES.md` siguen abiertas (C14-Q3, C15-Q1, C15-Q2, C15-Q3). El piloto añade evidencia a C15-Q1 (O1) y a C15-Q3 (CNT-006 dio Cumple en los cuatro casos, evaluando solo los componentes con padre). Las observaciones O2, O3, O4 y O6 son candidatas a nuevas preguntas normativas; no se han abierto como decisiones.

## 8. Aislamiento
Probe del 24/10/2026 con la Skill v11.2.2: el entorno denegó la lectura del canario, de `AGENTS.md` y de `src/index.js`. Cada ejecución del piloto volvió a auditar sus lecturas: 15 llamadas por caso (13 lecturas de archivos de la Skill, 1 del JSON y 1 invocación de la Skill), todas dentro del sandbox, solo `Read` y `Skill`, y ningún canario apareció. Validado para este modelo, esta versión del CLI y este conjunto de herramientas.

## 9. Telemetría
Ver `COSTOS.md`, parte 3 (tokens, costo de lista, tiempos y tamaños por caso) y `qa/runs/pilot-*/…/telemetry.json`.
