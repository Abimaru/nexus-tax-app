> Histórico: decisiones tomadas con la Skill de 41 reglas (v11.2.x). Se conservan como contexto.

# Decisiones del banco de pruebas

Estado a la fecha del piloto de la Fase 2. Este documento separa lo **vigente** de lo **histórico**. Las decisiones pendientes están en [DECISIONES_PENDIENTES.md](DECISIONES_PENDIENTES.md).

| Sección | Estado |
|---|---|
| A. Decisiones vigentes (Skill v11.2.2) | En vigor |
| B. Decisiones pendientes | Ver `DECISIONES_PENDIENTES.md` (C14-Q3, C15-Q1, C15-Q2, C15-Q3) |
| C. Histórico | Superado o resuelto; se conserva como registro |

---

## A. Decisiones vigentes

### A1. Clasificación de páginas
Aprobada y aplicada en la Skill v11.2.2.

| `pageClassification.kind` | Tratamiento |
|---|---|
| `OPERATIONAL` | 41 reglas |
| `MIXED` | 41 reglas sobre la operación real, sin las figuras de `legendShapeIds` |
| `TEMPLATE_OR_LEGEND` | no evaluable |
| `BDD_OR_REQUIREMENTS` | no evaluable |
| `UNRESOLVED` | sin dictamen definitivo; se pide revisar la clasificación |

Las páginas no evaluables conservan ID, título, tipo y motivo, sin 41 filas, sin conteos y sin porcentaje, y no entran en el total. Si el tipo contradice una operación real (escenario distinto de `NO_DETERMINADO`, componente `PRINCIPAL` o conexión orientada de API o servicio a un evento), el agente cita la evidencia y pide confirmación ("¿Confirmas que es una operación real que debe evaluarse?"). No se excluye una operación legítima solo porque contenga información BDD. La confirmación se registra como `DECLARADO_POR_ANALISTA`, vale para la clasificación y no certifica estructura ni cumplimiento.

La pregunta sobre el tratamiento de las páginas BDD (antes C14-Q2) quedó **resuelta**: son no evaluables, salvo contradicción con evidencia de operación real.

### A2. `No aplica` y poblaciones
`No aplica` solo si el criterio individual de la regla lo justifica. La ausencia de una figura no equivale a la ausencia de la obligación. Cuatro situaciones: población demostrablemente fuera de alcance (No aplica), población potencial no verificable (No verificable), población presente con evidencia insuficiente (No verificable), incumplimiento demostrado (No cumple). `UMLActiveClassBlock` ↔ `GESTOR_COLAS` es una convención técnica, no normativa.

En las expectativas del banco de pruebas, `TECHNICAL` (desviación = FAIL) se usa solo cuando el texto de la propia regla declara su condición de No aplica y el JSON la demuestra (CA-002, FT-002, MQ-005, COM-002, COM-003, COM-004; COM-001 solo cuando no existe ninguna `BPMNActivity`). Todo lo demás es `PENDING_REVIEW` (desviación = REVISAR).

### A3. CNT-006
Texto normativo sin cambios (verificado por hash). Criterio operativo del procedimiento: Cumple con evidencia positiva de un único `structuralParent` `RESOLVED` por `JSON.contains`, sin conflicto ni `issues`; no con la falta de referencias. Se sustentó en c15 con a→box y b→box. La población "componentes evaluables" sigue por precisar (C15-Q3); hasta entonces el texto de CNT-006 no cambia.

### A4. Continuidad conversacional
Estados por turno: `AWAITING_ANALYST_INPUT`, `PROVISIONAL_EVALUATION`, `FINAL_EVALUATION`, `FINAL_NO_EVALUATION`. Una pregunta pendiente es una oración con `¿…?`; una promesa condicional no cuenta. Paradas: `FINAL`, `STOPPED_REPEATED_QUESTION`, `STOPPED_MAX_TURNS` (6 por defecto), `STOPPED_NO_PROGRESS`, `STOPPED_CLI_ERROR` y `SUSPENDED_UNMAPPED_ANALYST_QUESTION`. Se conserva cada versión del dictamen y las reglas que cambiaron entre ellas.

### A5. Preguntas que el guion no sabe responder
**El controlador nunca inventa una respuesta.** Si una pregunta del agente no se puede asignar a una respuesta del guion:
1. Se conserva la pregunta literal.
2. Se registra el caso, el turno y la hora (`suspension` en la conversación).
3. La ejecución se suspende (`SUSPENDED_UNMAPPED_ANALYST_QUESTION`, código de salida 5) sin enviar nada y sin perder el historial.
4. El informe pide revisar el guion (`UNMAPPED_ANALYST_QUESTION`, estado REVISAR).
5. Se continúa con `resume`, con `--reply "<texto>" [--substantive]` (queda como `MANUAL_RESUME`) o con `--topic <tema>` (respuesta del guion).

Hay tres orígenes de respuesta, siempre registrados: `SCRIPT` (respuesta sustantiva del guion), `SCRIPT_UNKNOWN` (el guion dice explícitamente "No dispongo de ese dato") y `MANUAL_RESUME`. No existe un texto de respaldo del controlador. En guiones multipágina, la respuesta se elige por la página a la que se refiere la pregunta (el título citado en la pregunta o el último título de página que la precede en el mensaje); si no se puede atribuir, la pregunta no está mapeada.

### A6. Informe del evaluador
El informe natural de la Skill no cambia. El prompt pide una tabla con columnas estables (`rule_id`, Estado, Evidencia, Justificación, Información pendiente). El parser acepta variaciones de Markdown (columna "#" previa, columnas combinadas, viñetas, CSV) y distingue fila válida, ausente, estado desconocido y formato ambiguo. Los errores del parser son del controlador y no se corrigen en silencio. El resultado normativo solo se evalúa contra expectativas.

### A7. Qué comprueba automáticamente el controlador
Solo lo que puede demostrar: estructura (41 filas, IDs, estados), métricas recalculadas, consolidado ponderado, preguntas y procedencia, aislamiento, consistencia con el JSON (escenario, leyenda, evidencia citada) y poblaciones demostrablemente ausentes. Todo lo normativo interpretable queda como REVISAR para Andrés o la analista.

### A8. Trazabilidad de versiones
- v11.2.1: `qa/skill-locks/` (lock y ZIP archivados, SHA-256 `825e7747…`). Ejecuciones de la Fase 1 en `qa/runs/fase1-*` y copia en `qa/runs/archive/skill-v11.2.1/`.
- v11.2.2: `qa/skill.lock.json` (SHA-256 `9b35a98e…`). Ejecuciones en `qa/runs/v1122-*`.
- Las transcripciones y la telemetría de C14 y C15 no se modifican. `reevaluate` y `resume` escriben en carpetas nuevas (`reeval/`, `continued/`).

---

## B. Decisiones pendientes
Ver [DECISIONES_PENDIENTES.md](DECISIONES_PENDIENTES.md): C14-Q3, C15-Q1, C15-Q2, C15-Q3.

---

## C. Histórico (superado o resuelto)

| Antes | Qué pasó | Vigente hoy |
|---|---|---|
| D1 (Fase 1.5). "Una plantilla pura no recibe evaluación; la contradicción entre `SKILL.md` y el procedimiento queda en una propuesta" | La propuesta se aplicó en la Skill v11.2.2 | A1 |
| D1. "Pendiente: C14-Q2, tratamiento de páginas BDD" | Resuelta en la Fase 1.6: no evaluables | A1 |
| D2 (Fase 1.5). Expectativas TECHNICAL de c15 incluían MQ-001…004 y COM-001 | Se revisó regla por regla: MQ-001…004 y COM-001 pasaron a PENDING_REVIEW | A2 |
| D3 (Fase 1.5). Análisis de CNT-006 | Se mantiene como criterio operativo | A3 |
| D6. El informe de la Fase 1 sumó costos acumulados | El costo real de c14 con v11.2.1 fue USD 0,505 y no USD 1,42; corregido en el controlador y cubierto por una prueba | `COSTOS.md` |
| D11 (Fase 1.6). El mapeo por palabras clave no reconoció dos redacciones y el controlador envió "No dispongo de ese dato" | No es un fallo del agente ni de la Skill. Se hizo independiente de la redacción y, en el piloto, ya no existe ningún texto de respaldo: una pregunta sin mapear suspende la ejecución | A5 |

Historial del incidente D11: la primera pasada de c15 con v11.2.2 recibió esa respuesta de respaldo, por lo que la evaluación posterior a la confirmación no se ejercitó. Se corrigió el mapeo y se continuó la sesión con `resume`; por eso c15 tiene dos pasadas reales con v11.2.2 más un turno de continuación.
