import { analyzeBlueprint, copilotExport, diagnosticExport, VERSION, blockingPages, blockingMessage, looseArrowNotices, connectionBlockers } from '../src/index.js';

const $=id=>document.getElementById(id);
let factual=null,diagnosticModel=null,generation=0,completedGeneration=0;
const status=(message,error=false)=>{$('status').textContent=message;$('status').className='status'+(error?' error':'');};
const escapeHtml=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot',"'":'&#39;'}[c]));
const literal=value=>value===undefined?'Ausente':JSON.stringify(value);
const cell=value=>escapeHtml(value==null||value===''?'—':value);
const code=value=>`<code>${cell(value)}</code>`;
export const normalizeBlueprintName=value=>{const clean=String(value??'').trim().replace(/\s+/g,'').replace(/[^\p{L}\p{N}_-]/gu,'').slice(0,140);if(!clean)throw new Error('Nombre Blueprint inválido.');return clean;};
const download=(data,name)=>{const a=document.createElement('a'),url=URL.createObjectURL(new Blob([JSON.stringify(data,null,2)],{type:'application/json'}));a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),500);};

async function analyzeFiles(jsonFile,metadata={}){
  if(!metadata.blueprintName?.trim())throw new Error('Nombre Blueprint es obligatorio.');
  const input=JSON.parse((await jsonFile.text()).replace(/^\uFEFF/,''));
  const normalizedBlueprintName=normalizeBlueprintName(metadata.blueprintName);
  diagnosticModel=analyzeBlueprint(input,{sourceName:jsonFile.name,blueprintName:metadata.blueprintName.trim(),normalizedBlueprintName,selectedPageIds:metadata.selectedPageIds});
  const result=copilotExport(diagnosticModel,{selectedPageIds:metadata.selectedPageIds});return result;
}

function eventRows(result){
  const rows=[];
  for(const page of result.pages){
    const scenarioEvent=page.scenario?.event,principal=page.components.find(x=>x.id===page.scenario?.mainComponentId);
    for(const event of page.components.filter(x=>x.lucidchartType==='BPMNEvent')){
      const inScenario=scenarioEvent?.id===event.id,shared=(principal?.connections??[]).filter(id=>(event.connections??[]).includes(id));
      const subtypeStatus=inScenario?(scenarioEvent.subtypeStatus??'SIN_ESTADO_PUBLICADO'):'SIN_CERTIFICACION_PUBLICADA';
      if(subtypeStatus==='CERTIFIED_BY_EXPLICIT_CUSTOM_DATA')continue;
      const conflicts=inScenario?(scenarioEvent.conflicts??[]):[];
      const relation=inScenario?`Evento relacionado con escenario ${page.scenario.scenario??'NO_DETERMINADO'} (${page.scenario.status})`:shared.length?`Comparte conexión declarada con el principal: ${shared.join(', ')}`:'Sin relación publicada con el escenario';
      const reason=conflicts.length?conflicts.join(', '):event.customData===undefined?'Sin declaración customData':Array.isArray(event.customData)&&event.customData.length===0?'customData vacío':inScenario?'El subtipo no está certificado por la evidencia publicada':'El contrato no publica certificación de subtipo para este evento';
      rows.push(`<tr data-page-kind="${cell(page.pageClassification.kind)}"><td>${cell(page.page.title||'(sin nombre)')}<br><span class="badge">${cell(page.pageClassification.kind)}</span></td><td>${code(event.id)}</td><td><span class="badge warn">${cell(subtypeStatus)}</span></td><td>${code(literal(event.customData))}</td><td>${cell(conflicts.join(', '))}</td><td>${cell(relation)}</td><td>${cell(reason)}</td></tr>`);
    }
  }
  return rows;
}

const evidenceIds=(scenario,domainId)=>{
  const ids=new Set([domainId]);
  if(scenario?.sourceRootDomainId===domainId||scenario?.destinationRootDomainId===domainId){for(const value of[scenario.mainComponentId,scenario.mainChildServiceId,scenario.event?.id,scenario.connection?.id])if(value)ids.add(value);for(const item of scenario.evidence??[]){if(item.domainId===domainId&&item.domainId)ids.add(item.domainId);for(const id of item.containerChainIds??[])ids.add(id);}}
  return[...ids];
};

function producerRows(result){
  const rows=[];
  for(const page of result.pages){
    const domains=new Map();
    for(const component of page.components.filter(x=>x.domainRole==='PRODUCER'&&x.architecturalDomain?.id)){const domain=component.architecturalDomain;if(!domains.has(domain.id))domains.set(domain.id,domain);}
    for(const domain of domains.values()){
      const source=domain.roleSource??domain.source??'SIN_PROCEDENCIA_PUBLICADA',certainty=domain.status??'SIN_ESTADO_PUBLICADO',kind=source==='DECLARED_DOMAIN_NAME'||source==='DECLARED_CUSTOM_DATA'?'DECLARADO':'INFERIDO_ESTRUCTURALMENTE';
      rows.push(`<tr><td>${cell(page.page.title||'(sin nombre)')}</td><td>${code(domain.id)}<br>${cell(domain.name)}</td><td><span class="badge">${kind}</span><br>${cell(source)}</td><td>${cell(certainty)}</td><td>${cell((domain.conflicts??[]).map(x=>x.code??literal(x)).join(', '))}</td><td>${code(evidenceIds(page.scenario,domain.id).join(', '))}</td></tr>`);
    }
  }
  return rows;
}

function childRows(result){
  const rows=[];
  for(const page of result.pages)for(const child of page.components.filter(x=>x.architecturalType==='SERVICIO_HIJO')){
    const directCount=page.components.filter(x=>x.structuralParent?.id===child.id).length,role=child.role??'Rol no determinado',resolution=[`padre:${child.structuralParent?.status??'SIN_ESTADO'}`,`dominio:${child.architecturalDomain?.status??'SIN_ESTADO'}`];
    if(page.scenario?.mainChildServiceId===child.id)resolution.push(`escenario:${page.scenario.status}`);
    rows.push(`<tr><td>${cell(page.page.title||'(sin nombre)')}</td><td>${code(child.id)}<br>${cell(child.name||'(sin nombre)')}</td><td>${cell(child.architecturalType)}</td><td>${cell(role)}</td><td>${child.structuralParent?.id?`${code(child.structuralParent.id)}<br>${cell(child.structuralParent.name)}`:'No declarado'}</td><td>${code((child.containerChainIds??[]).join(' → '))}</td><td>${directCount}</td><td>${cell(resolution.join(' · '))}</td></tr>`);
  }
  return rows;
}

function modelRows(result){
  const rows=[];
  for(const page of result.pages)for(const model of page.components.filter(x=>Array.isArray(x.customData)&&x.customData.some(d=>d&&typeof d==='object'&&['ENTRADA','SALIDA'].includes(String(d.key??'').trim().toUpperCase())))){
    const groups=page.groups.filter(g=>(g.directMemberIds??[]).includes(model.id)||(g.relatedComponentIds??[]).includes(model.id)),groupText=groups.length?groups.map(g=>`${g.id} (${g.status})`).join(', '):'Sin grupo declarado',conflicts=[...groups.flatMap(g=>(g.conflicts??[]).map(x=>x.code??literal(x))),...(model.deploymentAssociations??[]).filter(x=>!String(x.status??'').startsWith('RESOLVED')).map(x=>x.status)];
    if(!groups.length)conflicts.push('ASOCIACION_DE_GRUPO_NO_DECLARADA');
    rows.push(`<tr><td>${cell(page.page.title||'(sin nombre)')}<br><span class="badge">${cell(page.pageClassification.kind)}</span></td><td>${code(model.id)}</td><td>${cell(model.lucidchartType)}</td><td>${code(literal(model.customData))}</td><td>${code(groupText)}</td><td>${model.structuralParent?.id?code(model.structuralParent.id):'No declarado'}<br>${cell(model.structuralParent?.status)}</td><td>${cell([...new Set(conflicts)].join(', '))}</td></tr>`);
  }
  return rows;
}

const fillRows=(id,rows,empty,colspan)=>{$(id).innerHTML=rows.length?rows.join(''):`<tr><td colspan="${colspan}" class="empty">${escapeHtml(empty)}</td></tr>`;};

function showBlockers(result){
  const blocked=blockingPages(result),box=$('pageWarning');
  box.hidden=!blocked.length;
  box.innerHTML=blocked.length?'<h2>⚠ No se genera el JSON: hay páginas seleccionadas que no están catalogadas como MIXED</h2>'+blocked.map(p=>{const m=blockingMessage(p);return `<h3>${escapeHtml(m.title)}</h3><p>${escapeHtml(m.text)}</p>${m.hints.length?`<ul>${m.hints.map(h=>`<li>${escapeHtml(h)}</li>`).join('')}</ul>`:''}`;}).join('')+'<p><b>Las descargas están deshabilitadas</b> y el JSON no se genera mientras alguna página seleccionada esté como TEMPLATE_OR_LEGEND, UNRESOLVED o BDD_OR_REQUIREMENTS. Desmarque esas páginas y analice de nuevo, o corrija el BP y cárguelo otra vez.</p>':'';
  for(const id of['downloadCopilot','downloadDiagnostic'])$(id).disabled=blocked.length>0||connectionBlockers(result).length>0;
}

function showLooseNotice(result){
  const notices=connectionBlockers(result),box=$('looseNotice');
  box.hidden=!notices.length;box.className=notices.length?'warning-box no-print':'notice-box no-print';
  const who=e=>e?`${e.kind?escapeHtml(e.kind)+' ':''}${e.name?`«${escapeHtml(e.name)}»`:'sin texto'} (${escapeHtml(e.id)})`:'(sin figura)';
  box.innerHTML=notices.length?'<h2>⚠ No se genera el JSON: hay conexiones con un extremo suelto</h2><p>Corrija las conexiones en Lucidchart, vuelva a exportar el JSON del blueprint y cárguelo de nuevo. Un extremo suelto no está pegado a ninguna figura, por lo que esa conexión no cuenta aunque se vea unida en el diagrama. Las terminaciones del conector las evalúan las reglas del Skill; las líneas None–None y las de las anotaciones no se evalúan.</p>'+notices.map(n=>`<h3>${escapeHtml(n.pageTitle)}</h3><ul>${n.loose.map(l=>`<li>Línea ${escapeHtml(l.id)} (${escapeHtml(l.styles.map(x=>x??'sin estilo').join(' – '))}): sin figura en el ${l.looseEnd}${l.other?`; el otro extremo está en ${who(l.other)}`:''}.</li>`).join('')}${n.notAllowed.map(l=>`<li>Conector no permitido en la línea ${escapeHtml(l.id)}: ${escapeHtml(l.styles.map(x=>x??'sin estilo').join(' – '))}, entre ${who(l.ends[0])} y ${who(l.ends[1])}.</li>`).join('')}</ul>`).join('')+'<p><b>Las descargas están deshabilitadas</b> mientras exista alguna de estas conexiones.</p>':'';
}

function render(result){
  factual=result;$('results').hidden=false;$('downloads').hidden=false;showBlockers(result);showLooseNotice(result);
  const totals=result.pages.reduce((a,p)=>({shapes:a.shapes+p.counts.shapes,connections:a.connections+p.counts.connections}),{shapes:0,connections:0});
  $('metrics').innerHTML=`<div class="metric"><b>${result.pages.length}</b><br>Páginas</div><div class="metric"><b>${totals.shapes}</b><br>Figuras</div><div class="metric"><b>${totals.connections}</b><br>Conexiones</div>`;
  $('pages').innerHTML=result.pages.map(p=>`<tr><td>${escapeHtml(p.page.title)}</td><td>${p.pageClassification.kind}</td><td>${p.scenario.scenario??'—'} / ${p.scenario.status}</td><td>${p.counts.shapes}</td><td>${p.counts.connections}</td><td>${p.deploymentAssociations.filter(x=>x.associatedComponentId).length}</td><td>${p.issues.length}</td></tr>`).join('');
  const events=eventRows(result);fillRows('bpmnRows',events,'No hay eventos BPMN con subtipo pendiente en las páginas seleccionadas.',7);$('bpmnSummary').textContent=`${events.length} evento(s) BPMN sin subtipo certificado. Evidencia descriptiva; no es un indicador normativo.`;
  fillRows('producerRows',producerRows(result),'No hay dominios con rol PRODUCER resuelto en las páginas seleccionadas.',6);
  fillRows('childRows',childRows(result),'No hay componentes tipados SERVICIO_HIJO en las páginas seleccionadas.',8);
  fillRows('modelRows',modelRows(result),'No hay figuras con customData ENTRADA/SALIDA en las páginas seleccionadas.',7);
  $('technical').textContent=JSON.stringify(result.pages.map(p=>({page:p.page,scenario:p.scenario,components:p.components,deployment:p.deploymentAssociations,warnings:p.issues})),null,2);
  status(blockingPages(result).length?`No se genera el JSON: hay páginas seleccionadas que no están catalogadas como MIXED. Revise el aviso naranja.`:connectionBlockers(result).length?`No se genera el JSON: hay conexiones con un extremo suelto. Revise el aviso naranja.`:`Análisis completado (motor v${VERSION}).`);
}

async function loadPages(){const file=$('jsonFile').files[0];if(!file){$('pageSelection').innerHTML='';return;}try{const document=JSON.parse((await file.text()).replace(/^\uFEFF/,'')),classified=analyzeBlueprint(document,{sourceName:file.name}),kinds=new Map(classified.pages.map(p=>[p.page.id,p.pageClassification.kind]));const visible=document.pages.filter(p=>['OPERATIONAL','MIXED'].includes(kinds.get(p.id)));$('pageSelection').innerHTML='<p><b>Páginas/operaciones</b></p>'+(visible.length?visible.map(p=>`<label><input class="pageChoice" type="checkbox" value="${escapeHtml(p.id)}" checked> ${escapeHtml(p.title||'(sin nombre)')} <span class="muted">${escapeHtml(kinds.get(p.id))}</span></label>`).join(''):'<p class="muted">El JSON no tiene páginas operativas o mixtas para evaluar.</p>');}catch(error){status(error.message,true);}}

$('jsonFile').addEventListener('change',loadPages);
$('analyze').onclick=async()=>{const current=++generation;try{const file=$('jsonFile').files[0];if(!file)throw new Error('Seleccione un JSON.');const selectedPageIds=[...document.querySelectorAll('.pageChoice:checked')].map(x=>x.value);if(!selectedPageIds.length)throw new Error('Seleccione al menos una página para analizar.');render(await analyzeFiles(file,{blueprintName:$('blueprintName').value,selectedPageIds}));}catch(error){factual=null;diagnosticModel=null;status(error.message,true);$('results').hidden=true;$('downloads').hidden=true;$('pageWarning').hidden=true;$('looseNotice').hidden=true;}finally{completedGeneration=current;}};
$('clear').onclick=()=>{factual=null;diagnosticModel=null;for(const id of['jsonFile','blueprintName'])$(id).value='';$('pageSelection').innerHTML='';$('results').hidden=true;$('pageWarning').hidden=true;$('looseNotice').hidden=true;for(const id of['downloadCopilot','downloadDiagnostic'])$(id).disabled=false;$('looseNotice').hidden=true;for(const id of['metrics','pages','bpmnRows','producerRows','childRows','modelRows','bpmnSummary','technical'])$(id).innerHTML='';status('Seleccione un JSON.');generation++;completedGeneration=generation;};
$('downloadCopilot').onclick=()=>factual&&!blockingPages(factual).length&&!connectionBlockers(factual).length&&download(factual,`${factual.metadata.normalizedBlueprintName}-ENRIQUECIDO.json`);
$('downloadDiagnostic').onclick=()=>diagnosticModel&&!blockingPages(factual).length&&!connectionBlockers(factual).length&&download(diagnosticExport(diagnosticModel),`${factual.metadata.normalizedBlueprintName}-DIAGNOSTICO.json`);
$('print').onclick=()=>window.print();
Object.defineProperty(window,'__BES__',{value:{VERSION,UI_VERSION:'0.11.0',analyzeFiles,getResult:()=>factual,getDiagnostic:()=>diagnosticModel?diagnosticExport(diagnosticModel):null,getGeneration:()=>completedGeneration},enumerable:false,writable:false,configurable:false});
