# Arquitectura v0.4.6.1

Existe un solo motor ES modules. `ui/app.js` importa `src/index.js`; `scripts/build.mjs` lo empaqueta e incrusta en el HTML autocontenido. Las pruebas unitarias y E2E ejecutan el mismo código.

| Módulo | Responsabilidad |
|---|---|
| `lucidchart.js` | Normaliza documento, páginas y `items.{shapes,lines,groups,layers}`; tipa por evidencia textual/clase. |
| `containment.js` | Reconcilia `contains`, selecciona un único padre inmediato cuando es demostrable, deriva ancestros y detecta conflictos/ciclos/referencias ausentes. |
| `connections.js` | Conserva conexiones crudas y genera rutas candidatas solo desde extremos declarados. |
| `groups.js` | Reconstruye membresías y jerarquías de grupos sin convertirlas en contención estructural. |
| `deployment.js` | Relaciona parejas Flujo/Capa por evidencia de contención o grupo superior común y conserva candidatos ambiguos. |
| `exporter.js` | Construye el modelo normalizado, la proyección Copilot compacta seleccionada y el diagnóstico completo. |
| `evaluation.js` | Valida los cuatro estados, los resultados por regla de cada página (37 en la Skill vigente) y calcula métricas sin promediar porcentajes. |
| `build.mjs` | Genera el único HTML autocontenido, sin dependencias de red. |

Flujo: JSON Lucidchart → normalización → contención/grupos/conexiones/despliegue → exportación factual o diagnóstica. Desde 0.5.0 el Studio no recibe SVG: todo el análisis sale del JSON de Lucidchart.

La generación PDF usa impresión del navegador. Las proyecciones Copilot y diagnóstico nacen del mismo resultado normalizado. `window.__BES__` es un gancho E2E no enumerable, de solo lectura y sin capacidades de red.

## Actualización 0.8.3 (03/11/2026)

Los módulos y el flujo anteriores siguen vigentes. Desde 0.6.0 el Studio añade, sin evaluar reglas (ADR-0004):

| Elemento | Descripción | ADR |
|---|---|---|
| `inventory` por página | Listas `{id, name, ubicacion}` por tipo (APIs, servicios, eventos de integración, gestores, comandos, auxiliares, hijo, `capasTopicos`), más `contenedores` (con `contiene`, que separa `SIN_TIPO` de `ACTIVIDAD_SIN_TIPO`), `relaciones` con `par`, `compuertas`, `modelos`, `conexionesPendientes`, `omitidos` y `nombres` (id → nombre) | 0005, 0009 |
| Reconocimiento en tres estados | Certificado, candidato (`possibleTypes`), sin tipo | 0005 |
| `CAPA_TOPICOS` | Contenedor que contiene directamente un evento de integración certificado; post-pase en `src/exporter.js` | 0006 |
| Exclusiones | Leyenda de notación y descripción de API no se exportan; hijo = contenedor de `mainChildServiceId` | 0011 |
| `cleanName` | Primer texto no vacío entre Title, Text y FloatingTitle; contenedores con `operation: null` | 0010 |

`src/inventory.js` construye el inventario a partir del modelo ya clasificado; `src/exporter.js` aplica la clasificación y la compactación. La Skill consume el inventario con las fichas de `08-fichas.md`.

## Actualización 0.11.0 / Skill 12.2.0 (25/11/2026)

Autoría: ver `AUTORIA.md`. Los módulos y el flujo anteriores siguen vigentes. Desde 0.10.0 (línea con etiquetas de la biblioteca):

| Elemento | Descripción | ADR |
|---|---|---|
| `inventory.js` | Módulo que construye `pages[].inventory` (listas por tipo, contenedores, relaciones, compuertas, modelos, capas). | 0020 |
| `figuraBiblioteca` / `figura` | Etiqueta del grupo raíz de la biblioteca (`LIB_FIGURES` en `exporter.js`); manda el grupo más externo. | 0020 |
| Etiquetas de grupo | `groups[].labels` (`groups.js`). | 0020 |
| Comandos, modelos, eventos, compuertas por etiqueta | `COMMAND_BY_CUSTOMDATA`, `MODEL_BY_CUSTOMDATA…`, `eventSubtype`, `compuertas[].subtipo`. | 0020, 0021 |
| `qualifyingChildren` | El hijo también se certifica con la etiqueta `SERVICE`. | 0020 |
| `mqInfo` | `consumidoPorColas` y `capaTopicos` (por contención o por grupo; `asociadaPor: GRUPO`; `capasTopicosCandidatas`). | 0022 |
| `connectionBlockers` | Conectores con extremo suelto bloquean el JSON; descripción de la figura por tipo y texto. | 0020 |
| HTML | Encabezado negro con logo SVG, páginas BDD/plantilla ocultas, versión y autoría en el pie. | — |
