# Distribución pública segura

La rama privada contiene fuentes corporativas y desciende de `fcc67ac`; nunca debe enviarse al remoto público.

La rama pública se crea con historia independiente desde `origin/main` e incluye únicamente código genérico, UI, documentación depurada, tests que usan fixtures sintéticos y el HTML. Se excluyen blueprints reales, Skill, ZIP, auditoría independiente sin depurar y artefactos privados.

Antes de push:

1. `git ls-tree -r --name-only <rama-publica>` y confirmar ausencia de rutas prohibidas.
2. Buscar `accountId`, nombres internos, IDs conocidos y normativa.
3. Confirmar que `git merge-base --is-ancestor fcc67ac <rama-publica>` devuelve falso.
4. Ejecutar pruebas públicas exclusivamente con fixtures sintéticos.
5. Solo entonces publicar sin force push.

La Skill se construye únicamente en la rama/local privado mediante `npm run skill:validate` y `npm run skill:pack`.
