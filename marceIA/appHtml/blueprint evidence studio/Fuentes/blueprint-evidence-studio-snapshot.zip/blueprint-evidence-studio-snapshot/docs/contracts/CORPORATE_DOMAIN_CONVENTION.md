# Contrato de dominios v0.4.6.1

Los dominios se identifican solo después de validar el contenedor arquitectónico; nunca se alteran padre, cadena o raíz estructural.

- `INTEGRACIÓN`: nombre exacto normalizado.
- `EXTERNAL_SYSTEM`: `SISTEMA EXTERNO`, `SISTEMAS EXTERNOS` y sus variantes exactas `(OPCIONAL)`.
- `PRODUCER`: nombre literal `DOMINIO PRODUCTOR` o productor único sustentado por servicio hijo, BPMNEvent, pertenencia, ruta principal y ausencia de conflicto.
- Otro contenedor personalizado: `NO_DETERMINADO`, con posibles roles productor/externo, hasta que la estructura de una operación lo resuelva.

Solo puede resolverse un productor por operación. Dos candidatos conservan evidencias y el conflicto se propaga a `scenario.conflicts`. Un externo explícito nunca se reclasifica; si contiene estructura productora registra contradicción. Otros contenedores personalizados no se convierten en externos por descarte. E2 no inventa productor.

Cuando `domainRole` queda resuelto, `possibleDomainRoles` debe ser `[]`; cuando permanece sin resolver, solo enumera alternativas sustentadas. La fuente `STRUCTURAL_CHILD_EVENT_MAIN_PATH` identifica una inferencia estructural, no una declaración ni cumplimiento.

La raíz estructural y `architecturalDomain` pueden diferir. Los conflictos de contención dejan dominio y rol sin resolver.
