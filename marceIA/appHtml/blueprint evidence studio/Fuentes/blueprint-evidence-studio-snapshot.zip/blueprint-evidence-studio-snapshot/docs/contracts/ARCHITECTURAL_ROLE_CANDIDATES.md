# Candidaturas y escenario estructural v0.4.6.1

Las candidaturas forman parte del diagnóstico técnico, no del inventario Copilot compacto. Se derivan de conexión orientada, hijo y dominio efectivo; nunca de BDD ni del nombre de página.

Estados internos: `CANDIDATE`, `INFERRED`, `AMBIGUOUS` y `UNRESOLVED`. La proyección compacta consolida el resultado por componente como tipo, rol, evidencia, contradicciones y estado, evitando colecciones competidoras.

El escenario usa `CONFIRMADO`, `HIPOTESIS` o `NO_DETERMINADO`. `CONFIRMADO` exige un patrón estructural único y subtipo START declarado mediante clave y valor exactos de `customData`. Un BPMNEvent genérico, texto “Inicio/Start”, descripciones, nombres o claves ajenas producen como máximo `HIPOTESIS`. Declaraciones incompatibles registran conflicto.

E1 requiere API principal en INTEGRACIÓN y evento del hijo no gestionado en productor. E2 requiere API e hijo bajo la misma INTEGRACIÓN. E3 requiere servicio principal e hijo bajo el mismo productor. Todos mantienen `normativeEvaluation:null`, `nonNormative:true` y `bddEvidenceUsed:false`.
