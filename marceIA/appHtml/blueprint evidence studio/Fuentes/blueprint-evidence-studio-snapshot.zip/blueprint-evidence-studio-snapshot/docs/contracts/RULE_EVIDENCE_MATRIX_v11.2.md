> **Histórico (Skill v11.2.3, 41 reglas).** Ya no es la referencia vigente: la Skill v11.2.4 tiene 37 reglas y su evidencia mínima está en cada regla (`skills/validar-blueprint-integracion/references/`). No usar esta matriz para evaluar.

# Matriz 41 reglas ↔ evidencia compacta

La matriz detallada está en `references/catalogo-reglas-v11.2.csv`. La correspondencia contractual es:

| IDs | Evidencia compacta principal |
|---|---|
| CNT-001…006 | `components[].structuralParent`, `containerChainIds`, `architecturalDomain`, `domainRole` |
| EXT-001…002 | `architecturalType=SISTEMA_EXTERNO_AUXILIAR`, `containedComponentIds`, `connections` |
| GW-001 | componentes BPMN y `connections[]` |
| API-001…004 | API, rol, operación, `textAreas`, dominio y `deploymentAssociations` |
| SRV-001…003 | SERVICIO/SERVICIO_HIJO, rol, nombre, dominio y relaciones |
| EVT-001…008 | EVENTO, `customData`, conexiones, dominio y asociaciones |
| CA-001…002 | componentes CAPA y asociaciones con fuente/evidencia |
| FT-001…002 | componentes FLUJO y asociaciones con fuente/evidencia |
| E1-001, E2-001, E3-001 | `scenario`, principal, hijo, dominios, evento y conexión |
| MOD-001 | componentes MODELO, grupos y asociaciones |
| COM-001…004 | operación, tipos y extremos de `connections[]` |
| MQ-001…005 | GESTOR_COLAS, dominio, conexiones y pareja Flujo/Capa |

Cuando el campo requerido sea `null`, ambiguo o contradictorio, la regla puede ser No verificable con justificación; nunca se completa por proximidad. Las preguntas MCI/exposición aportan evidencia `DECLARADO_POR_ANALISTA` sin acreditar automáticamente cumplimiento.
