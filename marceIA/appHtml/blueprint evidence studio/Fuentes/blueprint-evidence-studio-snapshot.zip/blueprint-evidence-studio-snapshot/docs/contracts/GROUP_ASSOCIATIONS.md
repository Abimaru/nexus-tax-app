# Contrato de agrupaciones y despliegue v0.4.6.1

`groupStructure.groups[]` conserva ID, miembros directos, grupos hijos, padre o padres conflictivos, ancestros, componentes, fuente e incidencias. `componentMemberships[]` expone membresías directas, superiores y múltiples.

Se distinguen `GROUP_MEMBERSHIP`, `DIRECT_CONTAINMENT`, `ANCESTOR_CONTAINMENT` y `DEPLOYMENT_ASSOCIATION`. Ningún grupo reparenta figuras.

Una asociación Flujo/Capa se resuelve por contención declarada `Flujo → Capa → Componente` o, si esta no basta, cuando una agrupación contiene exactamente la pareja y un grupo superior común contiene además un grupo de componente inequívoco. Ciclos, autorreferencias, miembros ausentes y membresías múltiples se propagan como conflictos. Si contención y grupo apuntan a componentes distintos, la asociación queda ambigua. Compartir dominio, proximidad o unicidad residual no basta. La asociación no equivale a cumplimiento MCI.
