# Contrato Copilot compacto v0.4.6.1

`copilotExport()` produce `copilot-factual-v0.4.6.1`. `pages[]` contiene solo páginas seleccionadas; `metadata.selectedPageIds`, `omittedPages` y `pageCount` describen la selección.

Cada página contiene `components`, `connections`, `groups`, `deploymentAssociations`, `scenario` e `issues`. Cada componente conserva ID, clase, nombre, operación, `textAreas`, `structuralParent`, `containerChainIds`, `rootContainer`, `architecturalDomain`, `domainRole`, `possibleDomainRoles`, conexiones, asociaciones e inferencia. Si el original posee `customData`, se copia literalmente para cualquier clase; si no, el campo queda ausente. Un arreglo vacío sigue siendo `[]`.

Tipos permitidos: `API`, `SERVICIO`, `SERVICIO_HIJO`, `GESTOR_COLAS`, `SISTEMA_EXTERNO_AUXILIAR`, `EVENTO`, `CAPA`, `FLUJO`, `MODELO` y `null`. `SERVICE` no es válido. Entidad, Utilidad, Tarea, Private, Public y Partner permanecen en `textAreas` y no bastan para tipar. ENTRADA/SALIDA se conserva sin promover automáticamente a MODELO.

Un rol resuelto implica `possibleDomainRoles:[]`; las posibilidades solo se publican sin resolución. No se asigna EXTERNAL_SYSTEM por descarte. Un candidato principal ambiguo no publica tipo ni rol definitivo. `INVOCADO` requiere relación inequívocamente orientada hacia el componente.

`scenario` es no normativo. `CONFIRMADO` exige declaración BPMN inequívoca bajo `PROPOSED_CLOSED_CATALOG`; cualquier valor reconocido adicional dudoso impide certificar. Conflictos de productor pasan a `scenario.conflicts`.

Las asociaciones conservan fuentes y conflictos. Contención y grupo incompatibles producen ambigüedad. El diagnóstico `diagnostic-v0.4.6.1` procede del mismo núcleo, mantiene todas las páginas y añade índices técnicos opcionales.
