# Asociaciones Flujo/Capa v0.4.6.0

- Currency Exchange: `4Oc~UAg.ChZ2` → `4Oc~STvzS7WZ` → gestor `4Oc~oPj98AFn`, resuelto por `JSON.contains`; no se asocia a ninguna otra pareja.
- `nombreOperacion1`: API `3gn9iRxfHfin` asociada por grupo superior `3gn9Z0fP~kxr`; hijo `TJ7m.cKnR-~v` y gestor `~ez.jtoEp~8-` quedan asociados a sus parejas específicas por contención directa; la pareja con solo evento permanece pendiente.
- Los grupos nunca modifican la jerarquía estructural. Un grupo con varios componentes, varios padres o varias parejas incompatibles no resuelve asociación.

Estas relaciones son factuales y no constituyen dictamen de MQ-004, API-004 ni MCI.
