# PLAN_MIGRACION_QA_41_A_37 (diseño, sin implementar)

> No modifica el controlador ni ejecuta baterías. Candidato.

## Principios
1. El banco `qa/` deja de fijar 41 filas; las expectativas se indexan por ID del catálogo vigente.
2. Las expectativas históricas (41) se conservan separadas en `qa/expectations-historical/`; nunca se reutilizan para 37.
3. El catálogo se fija por hash (`qa/skill.lock.json` ampliado con `catalogSha256` y lista de IDs).

## Cambios previstos
| Componente | Cambio |
|---|---|
| `lib/parser.mjs` | contar filas según el catálogo fijado, no el literal 41 |
| `lib/preflight.mjs` | verificar hash del catálogo y que los 37 IDs existan |
| `lib/checks.mjs` | nuevo check `catalogIdsExact`; check de ID retirado presente en la salida; check de ID reutilizado con significado distinto (usa MAPEO_IDS_41_A_37) |
| `qa/cases/*/expect.json` | un archivo por catálogo: `expect.v37.json`; `expect.v41.json` se conserva |
| `selftest.mjs` | pruebas de 37 filas, ID retirado, ID reutilizado, hash incorrecto |
| telemetría y aislamiento | sin cambios |

## Mapeo
Usar `MAPEO_IDS_41_A_37_2026-10-26.csv` (44 filas; riesgo ALTO 13 / MEDIO 22 / BAJO 9). Reutilizados con significado distinto: EXT-002, EVT-004…007, MQ-002, MQ-003 → sus expectativas históricas **no** migran.
Retirados: CNT-006, EXT-002 antiguo, EVT-004 antiguo, EVT-008, CA-002, FT-002, MQ-002 antiguo, MQ-004/MQ-005 (fusionados).

## Pasos
1. Aprobación del catálogo (C-02) y de las expectativas por la analista. 2. Pin del hash del catálogo. 3. Convertir las 97 combinaciones ejecutables (99 fichas) en casos sintéticos; las 72 EJECUTABLE_DEFINITIVA entran como `TECHNICAL` sólo tras la aprobación de la analista (hasta entonces `PENDING_REVIEW`: precondiciones reproducidas no equivalen a expectativa aprobada). 4. Las 25 CON_RESERVA quedan como `PENDING_REVIEW`. 5. Selftest. 6. Preflight. 7. Batería (requiere autorización).
