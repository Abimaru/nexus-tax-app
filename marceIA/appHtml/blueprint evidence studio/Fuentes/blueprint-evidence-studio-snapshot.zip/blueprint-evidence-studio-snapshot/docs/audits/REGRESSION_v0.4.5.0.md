# Regresión v0.4.5.0

## Matriz de escenarios y dominios

| Caso | Resultado | Dominio productor |
|---|---|---|
| nombreOperacion1 | E2 HIPOTESIS | No aplica |
| Oski | E1 HIPOTESIS | RECAUDOS |
| Currency Exchange | E2 HIPOTESIS | No aplica |
| initiateVirtualAccount | E1 HIPOTESIS | CORE GLOBAL ACCOUNT |
| initiateVirtualAccountAlias | E1 HIPOTESIS | CORE GLOBAL ACCOUNT |
| E3 sintético | E3 CONFIRMADO | Dominio sintético |

## Agrupaciones nombreOperacion1

`3gn9Z0fP~kxr` une `3gn9dZVeQSQU` (API y modelos) con `3gn9KcIquAF8` (Flujo/Capa). Se resuelve una `DEPLOYMENT_ASSOCIATION` para `3gn9iRxfHfin`. `x6OM65TToMCK`, `Th5DjjWdQFLe` y `rj5Dw-V.hbb2` carecen de superior común inequívoco y quedan pendientes. El Excel es contexto; el JSON original es la fuente.

## Verificación automatizada

- Unitarias: 40/40.
- E2E sobre el HTML distribuible: 3/3.
- Auditoría privada: 35 páginas procedentes de 9 JSON, incluidos `Virtual Account Opening` y `Solicitud Ajustes/Escenario2_Original.json`; 0 incidencias estructurales reportadas.
- Validación y empaquetado de Skill v11.1.2: correctos; se conservan los 41 IDs normativos.
- Artefactos factual y diagnóstico: generados por cada JSON en `artifacts/private-evidence/` (directorio privado ignorado por Git).
- HTML autocontenido: 55.008 bytes, SHA-256 `22CA811407FF85F0D4FC95A640D6FFAF8AF1F4EEAE0A62D785D8658282383A28`, 0 URLs HTTP(S).
- Skill ZIP: 20.201 bytes, SHA-256 `EC783854563B42B0B58711707C7640C2A18012709651F82BE10807EADA90EF1D`.

## Diferencias del contrato JSON

- `metadata` incorpora identidad del blueprint, páginas seleccionadas y omitidas.
- `architecturalStructure.groupStructure` conserva grupos, miembros, jerarquías, conflictos y relaciones sin tratarlos como contención.
- `deploymentPairs` separa evidencia de contención y agrupación, y solo resuelve componente con grupo superior común inequívoco.
- `domainResolution` documenta la resolución estructural del productor.
- `structuralScenario.status` queda restringido a `CONFIRMADO`, `HIPOTESIS` o `NO_DETERMINADO`; `normativeEvaluation` permanece `null`.

## Decisiones normativas pendientes

F-13 no fue modificado. La propuesta mantiene E1 con servicio hijo principal no gestionado en el productor, E2 con servicio hijo principal gestionado en INTEGRACIÓN y E3 con servicio hijo no gestionado en el productor. La decisión sobre conexión directa frente a conexión declarada continúa separada y pendiente de aprobación.

## Capacidades visuales pendientes

La versión conserva selección de páginas/operaciones, inventario factual, detalle de conexiones, colores/figuras crudos y salida imprimible, pero todavía no recupera al nivel de v0.3.3 el árbol operativo detallado, el inventario navegable, la lectura gráfica de conexiones ni el PDF enriquecido con evidencia. La recuperación propuesta es incremental sobre el núcleo actual: navegador de operaciones, árbol jerárquico, grafo visual y finalmente plantilla PDF, sin duplicar el motor.

## Riesgos

- Pruebas funcionales de analista pendientes.
- E3 real no disponible.
- F-13 y directa/declarada sin decisión normativa.
- SVG solo aporta emparejamiento de página; no certifica geometría ni semántica visual.
