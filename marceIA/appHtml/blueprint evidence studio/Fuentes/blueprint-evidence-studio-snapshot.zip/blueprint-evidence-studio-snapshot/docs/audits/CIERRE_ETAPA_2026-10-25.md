# Cierre de etapa y normalización contractual-normativa — 25/10/2026

Evidence Studio v0.4.6.1 · Skill `validar-blueprint-integracion` v11.2.2 · contrato `copilot-factual-v0.4.6.1`

**Alcance de esta auditoría:** solo lectura. No se modificó Evidence Studio, la Skill ni las 41 obligaciones. No se ejecutaron los 16 casos. No se hizo commit, push ni PR. Los únicos archivos creados son documentos nuevos (este informe, la matriz de 41 reglas y `PROJECT_CONTEXT_2026-10-25.md`).

**Criterio de lectura:** *hecho verificado* = comprobado hoy con el motor sobre los JSON reales; *decisión aprobada* = consta en `AGENTS.md`, en la Skill o en un mensaje del analista; *inferencia* = deducción de esta auditoría; *pendiente* = requiere decisión expresa del analista. Los informes históricos no son fuente superior al catálogo vigente.

Entregables: (1) matriz de 41 reglas → [`MATRIZ_41_REGLAS_2026-10-25.md`](MATRIZ_41_REGLAS_2026-10-25.md) y [`.csv`](MATRIZ_41_REGLAS_2026-10-25.csv); (2) auditoría de contenedores hijo → Parte I; (3) registro de decisiones → Parte III; (4) registro de contradicciones → Parte III.2; (5) plan correctivo → Parte V; (6) preguntas → Parte VII; (7) conservación Git → Parte VI; (8) contexto → `PROJECT_CONTEXT_2026-10-25.md`; (9) estado Git → Parte VI.1; (10) siguiente iteración → Parte VIII.

---

## I. Contenedores hijo (hechos verificados con el motor vigente)

Generados con `analyzeBlueprint` + `copilotExport` sobre los originales (sin modificar). Las columnas `type`, `role`, `padre`, `dominio` son las del JSON compacto.

### I.1 Páginas operativas solicitadas

| Blueprint · página | Escenario | Hijo (ID) | `architecturalType` | `role` | Padre inmediato | Cadena de ancestros | Dominio / rol de dominio |
|---|---|---|---|---|---|---|---|
| Currency Exchange · executeTransactionCurrencyExchange | E2 / HIPOTESIS | `TJ7m.cKnR-~v` | SERVICIO_HIJO | HIJO_PRINCIPAL | `x6OMFCgq99Xl` (Capa «composicion», ARCHITECTURE_LAYER) | INTEGRACIÓN > Flujo no-monetario > Capa composicion | INTEGRACIÓN / INTEGRATION |
| Oski · msDebitAccountPayment | E1 / HIPOTESIS | `20QoxCoCdtvE` | SERVICIO_HIJO | HIJO_PRINCIPAL | `20QoN3lLcXy.` («Recaudos», ARCHITECTURAL_DOMAIN_UNCLASSIFIED) | Recaudos | Recaudos / PRODUCER (inferido) |
| Virtual Account Opening · initiateVirtualAccount | E1 / HIPOTESIS | `8S4u74NmLpa2` | SERVICIO_HIJO | HIJO_PRINCIPAL | `8S4uExzgId93` («CORE GLOBAL ACCOUNT», UNCLASSIFIED) | CORE GLOBAL ACCOUNT | CORE GLOBAL ACCOUNT / PRODUCER (inferido) |
| Virtual Account Opening · initiateVirtualAccountAlias | E1 / HIPOTESIS | `Lym7WQZ~U4V3` | SERVICIO_HIJO | HIJO_PRINCIPAL | `Lym7ntV6NQR5` (CORE GLOBAL ACCOUNT, UNCLASSIFIED) | CORE GLOBAL ACCOUNT | CORE GLOBAL ACCOUNT / PRODUCER (inferido) |
| nombreOperacion1 (Escenario2_Original) | E2 / HIPOTESIS | `TJ7m.cKnR-~v` | SERVICIO_HIJO | HIJO_PRINCIPAL | `x6OMFCgq99Xl` (Capa «nombre-capa-arquitectura SERV») | INTEGRACIÓN > Flujo > Capa | INTEGRACIÓN / INTEGRATION |
| nombreOperacion2 (Escenario2_Original) | E1 / HIPOTESIS | `b8xDiwjbD70l` | SERVICIO_HIJO | HIJO_PRINCIPAL | `b8xDjB.kGxkp` (DOMINIO PRODUCTOR, ARCHITECTURAL_DOMAIN) | DOMINIO PRODUCTOR | DOMINIO PRODUCTOR / PRODUCER (declarado) |

API principal en las seis páginas: `API / PRINCIPAL`, dominio INTEGRACIÓN / INTEGRATION, `possibleDomainRoles: []` (rol resuelto ⇒ vacío, conforme a AGENTS). Los IDs de las APIs son `tQ7mFTFbJ1SW`, `wniB5n~8CzU8`, `8S4uZBWnl~74`, `Lym7MFM_bghX`, `3gn9iRxfHfin`, `qhn9N0Pfiowl`.

**Conexión al evento BPMN (hecho):** la línea está en la **API principal** (1 conexión por API: `gT7m.rKo0qu-`, `wniB.7Dl~hrs`, `8S4u2s~XnOuy`, `Lym73fLTpRP5`, `b8xDu93Uhhr-`); el contenedor hijo tiene 0 conexiones propias. La evidencia del escenario cita `JSON.line.endpoints` + `JSON.contains` + `DECLARED_DOMAIN_NAME`; en E1 de Oski y VAO el dominio productor figura como `STRUCTURAL_CHILD_EVENT_MAIN_PATH` (inferencia estructural positiva, no por descarte).

### I.2 Resto del corpus (para contrastar la regla general)

| Blueprint · página | Hijos tipificados | `HIJO_PRINCIPAL` | Observación |
|---|---|---|---|
| Debit Card · asociatePreIssuedCardMediadoConsulta | `Mm89nlPpWhXc`, `Mm89cWGdOYLg` | 1 | segundo hijo sin texto y sin padre declarado (`structuralParent` nulo) |
| Debit Card · createCustomizedCardConsulta | `AAztRTdbhApb`, `iy.SVb3uZRsH`, `AAztE7-ReJ9u` | 0 (escenario NO_DETERMINADO) | 3 hijos sin texto; `AAztE7-ReJ9u` anidado en otro hijo |
| Debit Card · createVirtualCard | `BbYhTgCQpwds`, `BbYhFkV9zgrq`, `BbYhfjREOgCH` | 0 | igual |
| Debit Card · createVirtualCardConsulta | `X389BE3abxll`, `X389OYd9uWQh` | 1 (`X389BE3abxll`) | igual al primero |
| Mortgage · initiateMortgageLoanDisbursement | `TJ7m.cKnR-~v` | 1 | E2 / HIPOTESIS |
| QR Payment · 3 páginas | `b8xDiwjbD70l`, `sILyY7t.1b6l`, `vILyRUcL-2dz` | 1 por página | E1; dominio «NEPA - NUEVAS EXPERIENCIAS DE PAGO», UNCLASSIFIED |
| Plantillas (TEMPLATE_OR_LEGEND) en VAO, Esc2, Mortgage, QR | `5S7mpO00NqZh`, `j8ud2IlxOs56` | 0 | tipificados pero no evaluables |

### I.3 Respuestas a las preguntas de la Parte I

1. **¿Todos los contenedores hijo están tipificados?** Sí, en todo el corpus: *toda* figura `RectangleContainerBlock` recibe `SERVICIO_HIJO`. La tipificación sale de la clase de figura, no del contenido (hecho: `architecturalType()` en `src/exporter.js`). Incluye contenedores sin texto y sin padre (Debit Card).
2. **¿Solo el hijo principal recibe `HIJO_PRINCIPAL`?** Sí: 0 o 1 por página, solo si `structuralScenario.mainChildServiceId` coincide. Sin escenario (NO_DETERMINADO) ninguno lo recibe aunque haya tres hijos.
3. **¿Hijos legítimos sin clasificar?** `architecturalType` sí, `role` no. Los hijos secundarios quedan con `role: null`. El contrato dice que `null` conserva incertidumbre, de modo que no hay contradicción, pero el JSON no distingue «hijo secundario legítimo» de «contenedor vacío o auxiliar».
4. **¿Roles sin evidencia suficiente?** Ninguno de los seis casos solicitados. El rol `PRODUCER` de Oski y VAO descansa en inferencia estructural (dominio no clasificado + ruta principal del evento) y no en el nombre «DOMINIO PRODUCTOR».
5. **¿La Skill interpreta bien ambas propiedades?** **No hay instrucción operativa.** `SERVICIO_HIJO` y `HIJO_PRINCIPAL` solo aparecen en el diccionario de `CONTRATO-COMPACTO.md`; ningún archivo de reglas ni `SKILL.md` indica que «contenedor hijo principal» (CNT-002, E1/E3) corresponde a `role = HIJO_PRINCIPAL`, ni si SRV-001..003 cubren al hijo. Clase C (O6 del piloto).
6. **Contradicciones tipo/rol/escenario:** ninguna en los datos reales. Tensiones: (a) todo contenedor es «servicio hijo» por forma; (b) escenario siempre HIPOTESIS ⇒ CNT-002 y E1/E2/E3-001 quedan en No verificable por diseño (0 de 341 BPMNEvent con `customData`); (c) productor inferido ≠ literal «DOMINIO PRODUCTOR».

No se cambió ninguna clasificación para ajustar expectativas.

---

## III. Decisiones históricas — registro

Estados: **A**probada · **I**mplementada · **V**erificada · **P**endiente · **R**eemplazada. Fuente superior: catálogo vigente de la Skill y `AGENTS.md`.

| Decisión | Estado | Evidencia / observación |
|---|---|---|
| Productor único (rol de dominio estructural) | A, I, V | `domainResolution`; conflicto ⇒ `CONFLICTING_MULTIPLE_PRODUCERS` |
| Dominio INTEGRACIÓN | A, I, V | `DECLARED_DOMAIN_NAME` en 6/6 páginas I.1 |
| Contenedor hijo | A, I, V (tipo por forma) | ver I.3; falta instrucción en la Skill |
| Servicio hijo principal | A, I, V | `mainChildServiceId`; hijos secundarios `role:null` |
| Servicio INVOCADO | A, I; **no alcanzable** en el corpus | exige entrada verificada y sin salida; ninguna página lo produce ⇒ API-001..003/SRV/MOD-001/COM-002..003 «invocados» sin población real |
| Convención prefijo `ms` | A, I (opcional en SRV-001) | no determina el tipo |
| SISTEMAS EXTERNOS | A, I; sin `EXTERNAL_SYSTEM` por descarte | `possibleDomainRoles` |
| BPMNGroup auxiliar externo | A, I | `SISTEMA_EXTERNO_AUXILIAR` solo con nombre real |
| Asociaciones Flujo/Capa | A, I, V | explícita o grupo superior común inequívoco; nunca proximidad |
| Contención vs agrupación | A, I, V | `DIRECT/ANCESTOR_CONTAINMENT` vs asociación de grupo |
| Eventos BPMN | A, I; E1/E2/E3 HIPOTESIS | CONFIRMADO solo con `customData` del catálogo cerrado |
| customData | A, I, V | exportado literalmente; 0/341 eventos lo traen |
| Modelos ENTRADA/SALIDA | A, I; **verificar** | MOD-001 No cumple 4/4 en piloto (O7) |
| Clasificación de páginas | A, I, V (v11.2.2) | pilotos P1–P4 |
| MCI | A, I | pregunta por página; `DECLARADO_POR_ANALISTA` |
| Exposición | A, I; **interpretación P** | API-003 (O4) |
| Cuatro estados | A, I, V | |
| Métrica | A, I, V | autocomprobada por el controlador |
| F-13 (E1/E3 hijo en productor; E2 en INTEGRACIÓN) | A, I (CNT-002, E1-001, E3-001) | |
| Conexión directa vs declarada | **P** | E1/E2 dicen «declarada», E3 dice «directa» |

### III.2 Registro de contradicciones

| # | Contradicción | Fuentes | Clase |
|---|---|---|---|
| K1 | E3-001 exige «conexión **directa**» y E1/E2-001 «conexión **declarada**»; AGENTS la declara pendiente | CSV v11.2; `05-reglas-escenarios.md`; AGENTS | D |
| K2 | ~~Contradicción~~ → **reclasificada (Parte IX.1):** F-13 y CNT-002 usan «DOMINIO PRODUCTOR» como dominio efectivo; el motor emite `PRODUCER` por evidencia estructural también para Recaudos, CORE GLOBAL ACCOUNT y NEPA, conforme a una decisión previa confirmada. Sin acción normativa | CSV; `roles.js`; convención | cerrada |
| K3 | «Escenario certificado» en CNT-002/E1/E2/E3 vs escenario siempre HIPOTESIS en el corpus real ⇒ nunca Cumple | CSV; AGENTS | B/D |
| K4 | Las poblaciones «invocados» existen en el texto normativo, pero el motor no emite INVOCADO en el corpus real | CSV; `roles.js` | A/B |
| K5 | SRV-001..003 cubren «servicios principal e invocados»; la Skill no dice si el hijo principal cuenta | CSV; CONTRATO-COMPACTO | C |
| K6 | API-003: «no reclasificar» y la Skill pregunta exposición; el piloto dio No cumple sin preguntar (O4) | Procedimiento; piloto | C/F |
| K7 | CA-001/FT-001/API-004 detectan la misma ausencia de Capa/Flujo (O3) | CSV | C/D |

No se recuperó ninguna decisión reemplazada (p. ej. COM-001 como TECHNICAL en c15, costos acumulados).

---

## IV. Ambigüedades del piloto — clasificación

| Regla | Clase | Razonamiento |
|---|---|---|
| MQ-001..004 | D | Sin figura de gestor: No aplica (agente) vs No verificable (criterio aprobado). Decisión C15-Q1 |
| SRV-001..003 | C (+D) | Resultado distinto entre páginas (NV en P1/P4, NA en P2/P3) por población SRV no definida; el agente no es defectuoso por sí |
| API-003 | C/F | Correcto al leer la tercera sección; la Skill no dice si la respuesta de exposición cambia el estado |
| API-004 | C | Depende de MCI declarado y exposición |
| CA-001, FT-001 | C/D | Duplican API-004; en P1 Cumple, en P2 NV: criterio de aplicabilidad |
| CNT-001 | D | C15-Q2 |
| CNT-006 | D | C15-Q3 |
| MOD-001 | F (B por verificar) | Casos sintéticos sin modelos ⇒ No cumple justificable; hay que probar con un JSON real que los modelos se exportan |

Ningún caso se etiqueta como defecto del agente (clase E) con la evidencia actual.

---

## V. Plan correctivo (propuesta; nada implementado)

### Grupo 1 — ajustes autorizados sin cambio normativo
| Ajuste | Archivo | Regla | Impacto contractual | Prueba | Riesgo | Versión |
|---|---|---|---|---|---|---|
| Verificar que los modelos ENTRADA/SALIDA reales llegan al JSON compacto | `src/exporter.js` (solo lectura primero) | MOD-001 | Ninguno si ya se exportan | prueba sobre un blueprint real | bajo | — |
| Documentar que INVOCADO no se emite en el corpus | `docs/contracts/` | API/SRV/COM | Ninguno | — | bajo | — |

### Grupo 2 — ajustes operativos de la Skill (sin tocar texto de reglas)
| Ajuste | Archivo | Regla | Impacto | Prueba | Riesgo | Versión |
|---|---|---|---|---|---|---|
| Indicar que «contenedor hijo principal» = `role: HIJO_PRINCIPAL` y que los demás `SERVICIO_HIJO` no se evalúan como principal | `00-procedimiento.md`, `CONTRATO-COMPACTO.md` | CNT-002, E1/E3, SRV | Interpretación operativa | hash de cuerpos de reglas (sin cambio) + caso piloto | medio | v11.2.3 |
| Indicar qué hace la respuesta de exposición en API-003 | `00-procedimiento.md` | API-003 | operativo | caso P1/P3 | medio | v11.2.3 |

### Grupo 3 — decisiones normativas pendientes (no se implementan sin aprobación expresa)
C14-Q3, C15-Q1, C15-Q2, C15-Q3 (ver `qa/DECISIONES_PENDIENTES.md`), más K1, K2, K3, K5, K7 y las poblaciones de SRV y de los gestores. Cada una modifica la interpretación de una obligación; no se asigna versión hasta que se decidan.

---

## VI. Git y conservación

### VI.1 Estado verificado (solo lectura)
- Remoto único: `origin = https://github.com/Abimaru/blueprint-evidence-studio.git`, **visibilidad PÚBLICA** (`gh repo view`). Solo existe `origin/main` = `1a1bb45` («Initial commit», solo `README.md`).
- Local: `main` = `1a1bb45`; la historia privada (`feature/evidence-studio-v0.4.2 … v0.4.6.1-private`, 14 commits en la punta, 2,6 MB) desciende de ese commit; las ramas `public/*` (7) son raíces independientes sin ancestro común con `main`.
- Rama actual `feature/evidence-studio-v0.4.6.1-private` (`81b7542`); 24 entradas sin confirmar (AGENTS, CHANGELOG, HANDOFF, README, Skill, scripts, tests) más `dist/…v11.2.2.zip`, `docs/audits/AUDIT_v0.4.6.1_independent.md` y `qa/` sin seguimiento.
- Contenido corporativo **rastreado** en la rama privada: 42 archivos en `Blueprints_ejemplos/` y `skills/validar-blueprint-integracion/`, más `Solicitud Ajustes/` (xlsx/docx de normativa, JSON y `solicitud.txt`) y `docs/audits/NORMATIVE_*`. `qa/runs/` está ignorado; `qa/` aún no se rastrea.

### VI.2 Propuesta
1. **No subir nada a `origin`**: es público y contiene solo `README.md`. Empujar cualquier rama privada publicaría material corporativo.
2. Crear un **repositorio nuevo y privado** (nombre sugerido `blueprint-evidence-studio-private`) con rama `main` que conserve la historia privada completa. Como la historia privada desciende de `1a1bb45`, bastaría avanzar una `main` privada a la punta aprobada, sin fusionar con las ramas `public/*`.
3. Antes de cualquier push: confirmar destino, visibilidad (privada), colaboradores y los archivos incluidos; revisar la lista con `git ls-files` y decidir qué se excluye (ver VI.3).
4. Incluir `qa/` solo si el analista autoriza (son casos sintéticos; `qa/runs/` ya se ignora).
5. Las ramas `public/*` siguen siendo el único camino al remoto público; no se derivan de `fcc67ac`.

### VI.3 Datos cuya retención en un remoto no está autorizada (a confirmar)
`Blueprints_ejemplos/` (blueprints de la organización), `Solicitud Ajustes/*.docx|*.xlsx` (normativa), `skills/` (41 obligaciones), `artifacts/private-evidence/`, auditorías que nombran blueprints corporativos. AGENTS prohíbe su publicación en el remoto **público**; no hay autorización registrada para alojarlos en un tercero privado. Pregunta Q9.

---

## VII. Preguntas originales Q1–Q10 (versión inicial del 25/10)
> **Superada por la Parte IX**, que consolida el estado de cada pregunta tras la revisión del analista. Se conserva como registro. K2 (Parte III.2) queda reclasificada por la decisión Q1 de la Parte IX.

| # | Pregunta | Reglas |
|---|---|---|
| Q1 | ¿Un dominio productor inferido estructuralmente (Recaudos, CORE GLOBAL ACCOUNT) cuenta como «DOMINIO PRODUCTOR»? | CNT-002, CNT-004, E1/E3-001 |
| Q2 | Con escenario HIPOTESIS, ¿se admite Cumple en CNT-002/E1/E2/E3 o debe quedar No verificable? | idem |
| Q3 | Conexión al evento de Inicio: ¿directa o declarada (K1)? | E1/E2/E3-001 |
| Q4 | ¿El hijo principal entra en la población de SRV-001..003? | SRV |
| Q5 | Un gestor de colas ¿es opcional? (C15-Q1) | MQ-001..004, GW-001, EXT-001/002 |
| Q6 | Cobertura «completa» y No cumple sin evidencia material (C15-Q2) | CNT-001 |
| Q7 | Población de CNT-006 (C15-Q3) | CNT-006 |
| Q8 | ¿Qué regla porta la ausencia de Capa/Flujo: API-004, CA-001 o FT-001? | API-004, CA-001, FT-001 |
| Q9 | ¿Se autoriza algún remoto privado de terceros para el material corporativo? ¿Cuál? | — |
| Q10 | ¿Se incluye `qa/` en la conservación? | — |

---

## VIII. Recomendación para la siguiente iteración (versión inicial; ver Parte X)
1. Revisar este informe y la matriz; responder Q1–Q10.
2. Con las respuestas, aplicar solo el Grupo 2 como Skill v11.2.3 (texto de reglas intacto, hashes comprobados).
3. Resolver Git (Q9) antes de cualquier push.
4. Solo después, ejecutar la batería de 16 casos. Hoy **no** se recomienda: Q1, Q2 y Q5 cambian los resultados esperados.

---

## IX. Consolidación de decisiones Q1–Q10 (25/10/2026)

Categorías: **DPC** = `DECISION_PREVIA_CONFIRMADA` · **CCV** = `CRITERIO_CONSERVADOR_VIGENTE` · **DNP** = `DECISION_NORMATIVA_PENDIENTE`. Fuente = quién/qué la sustenta. Esta tabla no atribuye a la analista aprobaciones que no consten; «cerrada» significa solo que no se vuelve a preguntar.

| Q | Estado | Fuente | Alcance | ¿Cerrada? |
|---|---|---|---|---|
| Q1 Productor inferido | **DPC** (motor) + nota de lectura | Decisión previa de la analista (RECAUDOS en Oski, CORE GLOBAL ACCOUNT en VAO); `CORPORATE_DOMAIN_CONVENTION.md`; AGENTS («productor único… nunca por descarte») | Solo la identificación del rol `PRODUCER` por evidencia estructural, con procedencia, certeza, conflictos y dominio efectivo. No altera el texto de CNT-002/CNT-004/E1/E3 | Sí |
| Q2 HIPOTESIS y cumplimiento | **CCV** + **DNP** (lectura de CNT-002) | AGENTS; `00-procedimiento.md` §escenario («no son estados de cumplimiento») | Ver IX.2 | Parcial |
| Q3 Directa/declarada | **DNP** | AGENTS («sigue pendiente»); texto actual de E1/E2 vs E3 | Redacción conservada; sin homogeneizar | No |
| Q4 Hijo y SRV | **DNP** | Sin decisión previa | Población de SRV-001..003; tipo ≠ rol ≠ INVOCADO | No |
| Q5 Gestores | **CCV** + **DNP** | Criterio aprobado «ausencia de figura ≠ No aplica»; sin decisión general | MQ-001..004, GW-001, EXT-001/002 | Parcial |
| Q6 Cobertura | **CCV** + **DNP** | Texto de las reglas («con cobertura completa»); procedimiento v11.2.2 | CNT-001 y reglas con «cobertura completa» | Parcial |
| Q7 CNT-006 | **CCV** (propuesta operativa) + **DNP** | Procedimiento v11.2.2 (texto de la regla intacto) | Población de «componentes evaluables» | No |
| Q8 API-004/CA-001/FT-001 | **DPC** (evaluación independiente) + **DNP** (reparto) | Principio de evaluación independiente aprobado | Ver IX.3 | Parcial |
| Q9 Git privado | **CCV** (no empujar al público) + **DNP** (destino) | AGENTS; verificación del remoto | Destino, visibilidad y alcance permitidos | No |
| Q10 `qa/` | **DPC** | Aprobación del analista | `qa/` es parte del proyecto privado autorizado; se excluyen `qa/runs/`, transcripciones sensibles y temporales; nunca en la distribución pública | Sí |

**Cerradas:** Q1 y Q10. **Cerradas en su parte aprobada, abiertas en el resto:** Q2, Q5, Q6, Q8. **Abiertas:** Q3, Q4, Q7, Q9.

### IX.1 Q1 — qué exige realmente el catálogo (verificado)
- Los textos de CNT-002, E1-001 y E3-001 usan «DOMINIO PRODUCTOR» como nombre del dominio arquitectónico *efectivo* («dominio arquitectónico efectivo DOMINIO PRODUCTOR»). Ninguna regla valida el nombre literal de un contenedor productor; CNT-004 y MQ-002 hablan de «dominio productor» en minúsculas, como rol.
- `CORPORATE_DOMAIN_CONVENTION.md` (documento del proyecto, no del catálogo) define `PRODUCER` como nombre literal **o** productor único sustentado por hijo, BPMNEvent, pertenencia, ruta principal y ausencia de conflicto.
- Conclusión: el catálogo no exige nombre literal ni lo excluye. La lectura «rol, no nombre» es coherente con la decisión previa y con el motor, pero la frase del catálogo no la declara expresamente. Por eso no se tocan CNT-002, CNT-004, E1-001 ni E3-001, y la lectura queda como nota de confirmación en la pregunta de Q2.
- K2 (Parte III.2) deja de ser contradicción y pasa a «redacción del catálogo que admite lectura de rol», sin acción normativa.

### IX.2 Q2 — contraste CNT-002, E1-001, E2-001, E3-001
| Regla | ¿Exige Inicio certificado? | Evaluable sin Inicio certificado | Lectura |
|---|---|---|---|
| CNT-002 | Su evidencia mínima dice «escenario certificado»; no menciona Inicio ni evento | Padre directo, cadena y dominio efectivo del hijo | **Dos lecturas defendibles:** (a) «escenario certificado» = escenario identificado estructuralmente (incluye HIPOTESIS); (b) = `CONFIRMADO`. → **DNP** |
| E1-001 / E2-001 | La evidencia mínima incluye «semántica del evento»; la conexión se exige «cuando la exija el estándar» | Ubicación de API e hijo, dominios, padre y cadena | La regla es integral: sin Inicio certificado no se declara Cumple; las partes estructurales pueden citarse como evidencia |
| E3-001 | Igual, con «conexión directa… cuando corresponda» | Ubicación de servicio principal e hijo, dominio efectivo común | Igual; además depende de Q3 |

Criterio vigente (CCV): HIPOTESIS no es No cumple; CONFIRMADO no es Cumple; la certificación estructural y el cumplimiento son independientes; no se convierte HIPOTESIS en CONFIRMADO. Con evidencia estructural completa que *contradice* el escenario identificado se puede declarar No cumple; sin Inicio certificado en una regla integral, el máximo es No verificable.

### IX.3 Q8 — API-004, CA-001, FT-001: ¿duplicación real?
| Regla | Pregunta que responde | Población | Qué es «No cumple» según el catálogo |
|---|---|---|---|
| API-004 | ¿La API principal declara el detalle de despliegue que exige su exposición y MCI? (private MCI: Capa y Flujo; partner MCI: Capa; public: no aplican) | API principal | Falta detalle obligatorio **o existe detalle no permitido** |
| CA-001 | ¿Existe la figura Capa cuando es obligatoria y su nombre sigue el patrón? | Componentes con Capa aplicable | Capa ausente cuando es obligatoria **o nombre inválido** |
| FT-001 | Igual para Flujo | Componentes con Flujo aplicable | Igual |

Resultado: solapan solo cuando la causa es **ausencia de la figura**; API-004 además cubre detalle *no permitido* y asociación a la API, y CA-001/FT-001 cubren *nombre inválido*, que API-004 no evalúa. Por tanto no hay duplicación total y no se funden ni se suprime ninguna. Un mismo hecho (ausencia de Capa en una API private MCI) puede violar legítimamente dos obligaciones distintas; qué regla debe portarlo cuando las dos aplican sigue **DNP**. No se cambia ningún estado para evitar doble penalización.

### IX.4 Q3 — explicación comparativa para la analista (sin recomendación)
Textos vigentes: E1/E2 «conexión **declarada** al evento de Inicio cuando la exija el estándar»; E3 «conexión **directa** al evento de Inicio cuando corresponda a las exigencias del estándar».

| | Lectura A: son equivalentes | Lectura B: son distintas |
|---|---|---|
| Significado | En los tres escenarios basta una línea con extremos explícitos en el JSON entre el componente principal y el evento de Inicio | E3 exige línea sin figuras intermedias; E1/E2 admiten una conexión declarada aunque pase por otras figuras (p. ej. auxiliar o actividad) |
| Efecto en E1/E2 | ninguno | podría aceptar más casos |
| Efecto en E3 | ninguno | exigiría más |
| Hecho del motor | El motor identifica el escenario a partir de una línea con extremos explícitos y orientación verificada entre el componente y el evento (`JSON.line.endpoints`); no se verificó en esta auditoría si algún blueprint del corpus pasa por figuras intermedias | Ídem: hoy el motor no distingue ambas lecturas |
| Costo de decidir | Ajustar redacción de E3 o de E1/E2 | Definir qué figuras intermedias son admisibles |

Decisión: la analista. Mientras tanto se conserva la redacción y no se homogeneiza.

### IX.5 Preguntas reducidas para la analista (8)
1. **Q2/CNT-002:** «escenario certificado» ¿incluye el escenario identificado estructuralmente (HIPOTESIS) o exige `CONFIRMADO`? Además, ¿«DOMINIO PRODUCTOR» en CNT-002/E1/E3 se refiere al rol arquitectónico (como en la convención) y no al nombre literal?
2. **Q3:** conexión al evento de Inicio ¿lectura A o B (IX.4)?
3. **Q4:** ¿el servicio hijo principal forma parte de la población de SRV-001..003? Si no, ¿qué reglas le aplican?
4. **Q5:** para MQ-001..004, ¿hay un caso en el que la ausencia de gestor demuestre «No aplica», o siempre es No verificable salvo evidencia?
5. **Q6:** ¿qué hace que la cobertura de CNT-001 sea «completa» de forma verificable (p. ej. todas las páginas seleccionadas, todos los contenedores de nivel raíz)?
6. **Q7:** ¿la población de CNT-006 son los componentes con padre declarado, sin exigir padre al contenedor raíz? ¿Se registran las raíces múltiples como anomalía aparte?
7. **Q8:** cuando una API private MCI no tiene Capa, ¿el hallazgo se registra en API-004, en CA-001, o en ambas?
8. **Q9:** ¿qué repositorio privado está autorizado y qué categorías pueden alojarse en él? (IX.6)

### IX.6 Conservación Git — categorías (sin push)
| Categoría | Contenido | Remoto público | Repositorio privado |
|---|---|---|---|
| Código | `src/`, `ui/`, `scripts/`, tests genéricos, `dist/BlueprintEvidenceStudio.html` | Solo la rama pública saneada | Sí |
| QA sintético | `qa/` sin `runs/`, transcripciones sensibles ni temporales | **No** | Sí (Q10 aprobada) |
| Skill y normativa | `skills/`, ZIPs de la Skill, `Solicitud Ajustes/*.docx\|xlsx` | **No** | **Pendiente de autorización de destino** |
| Blueprints reales | `Blueprints_ejemplos/` | **No** | **Pendiente de autorización de destino** |
| Auditorías corporativas | `docs/audits/` que nombran blueprints o arquitectura | **No** | **Pendiente de autorización de destino** |

No se asume que un repositorio privado externo esté autorizado para guardar material corporativo. No se hace push hasta confirmar destino y alcance.

### IX.7 Ajustes operativos preparables (Skill v11.2.3) frente a cambios normativos
**Preparables sin alterar la normativa** (no cambian el texto ni los hashes de las 41 reglas; requieren tu aprobación para implementarlos):
1. Relacionar en `00-procedimiento.md` el término «contenedor hijo principal» con `role: HIJO_PRINCIPAL`, diciendo explícitamente que `SERVICIO_HIJO`+`HIJO_PRINCIPAL` **no** equivale a `SERVICIO`+`INVOCADO` y que no se amplía la población de SRV por analogía.
2. Pedir que al citar `domainRole: PRODUCER` se indique procedencia (`DECLARED_DOMAIN_NAME` o estructural), certeza y conflictos, y que no se tome como obligación de nombre.
3. Aclarar que, en reglas integrales que requieren Inicio certificado, la falta de esa evidencia impide Cumple y deja No verificable; HIPOTESIS no es No cumple y CONFIRMADO no es Cumple (la Skill ya declara que no son estados de cumplimiento).
4. Pedir que API-004, CA-001 y FT-001 se evalúen cada una con su propio criterio, citando evidencia propia, sin fusionar ni ajustar estados.
5. Recordar que No cumple exige evidencia suficiente de infracción y distinguir «ausencia demostrada con cobertura suficiente» de «incertidumbre estructural».
6. Revisar el flujo de API-003 con exposición declarada (O4); solo si el cambio es de procedimiento y no de criterio.

**Cambios normativos pendientes (no se preparan):** lectura de «escenario certificado» en CNT-002; directa/declarada; población de SRV; gestores MQ; definición de cobertura completa; población de CNT-006; reparto API-004/CA-001/FT-001; destino de la Skill y la normativa en un remoto privado. La delimitación de CNT-006 permanece como propuesta operativa del banco de pruebas, **sin** incorporarse a la Skill como criterio aprobado.

**Fuera de la Skill:** el mapeo de preguntas por palabras clave del controlador de `qa/` y la exportación de modelos en MOD-001 se revisan en el banco de pruebas y en Evidence Studio, respectivamente.

---

## X. Dónde estamos, qué falta y hacia dónde ir

### X.1 Dónde estamos (verificado)
- **Motor:** estable en v0.4.6.1. Contención estructural, grupos como asociación, escenarios E1/E2/E3 con certeza, clasificación de páginas y roles de dominio por evidencia funcionan y están cubiertos por 61 pruebas, auditoría, compilación y E2E.
- **Skill v11.2.2:** 41 reglas con hashes fijados, cuatro estados, métrica, clasificación de páginas y preguntas MCI/exposición; ZIP validado.
- **Banco de pruebas:** controlador aislado, telemetría y 6 casos sintéticos; el piloto de 4 casos no mostró fallos técnicos tras las correcciones del controlador.
- **Decisiones:** 2 cerradas (Q1, Q10), 4 parcialmente cerradas, 4 abiertas.

### X.2 Qué falta
1. Respuestas de la analista a las 8 preguntas reducidas (IX.5).
2. Skill v11.2.3 operativa (IX.7), tras tu aprobación.
3. Autorización del destino privado antes de conservar normativa y blueprints.
4. Batería de 16 casos y repeticiones, no autorizada.
5. Prueba con la analista real en Copilot: el banco de pruebas no la sustituye.

### X.3 Dirección propuesta para mejorar Evidence Studio
Prioridades basadas en lo que el análisis mostró, sin cambiar obligaciones:
1. **Evidencia del subtipo Inicio.** Hoy 0 de 341 eventos reales traen `customData`, así que todo escenario es HIPOTESIS y las reglas integrales no pueden llegar a Cumple. La mejora de mayor impacto es ayudar a *declarar* el subtipo en Lucidchart (plantillas con la clave del catálogo cerrado) y mostrar en la interfaz qué eventos le falta. No certificar por texto o nombre.
2. **Tipo vs. rol visibles.** Mostrar por qué un contenedor es `SERVICIO_HIJO` (por forma) y por qué tiene o no `HIJO_PRINCIPAL`; señalar contenedores hijo sin texto y sin padre (Debit Card) como evidencia incompleta, sin reclasificarlos.
3. **Procedencia del productor.** Exponer en la interfaz y el compacto si `PRODUCER` es nombre declarado o estructural, con certeza y conflictos.
4. **Modelos ENTRADA/SALIDA.** Verificar la exportación y la asociación de modelos con blueprints reales antes de que MOD-001 se interprete.
5. **Calidad del compacto.** El compacto pesa 3,4–4,6× el original; reducir sin perder campos factuales ayudaría a la Skill (más reglas por turno y menor costo).
6. **Cobertura visible.** Un indicador de cobertura (páginas completas, referencias ausentes, ciclos) que haga verificable lo que Q6 llama «cobertura completa» una vez la analista la defina.
7. **Procedimiento de distribución.** Mantener el remoto público limitado a código genérico y fixtures sintéticos; automatizar la verificación de exclusiones antes de cada publicación.

Orden recomendado: (1) y (3) primero, porque eliminan incertidumbre sin tocar normativa; (2) y (6) después; (4) en paralelo como verificación; (5) y (7) como mejora continua. Nada de esto modifica las 41 obligaciones; cada cambio de Evidence Studio requiere su propia autorización, `npm test` antes y después, y versión nueva.
