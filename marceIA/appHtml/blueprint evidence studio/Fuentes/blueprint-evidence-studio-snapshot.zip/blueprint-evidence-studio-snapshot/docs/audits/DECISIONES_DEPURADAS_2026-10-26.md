# Decisiones depuradas — base única para consolidar las 37 reglas

26/10/2026 · Solo lectura · Reconcilia las 24 decisiones de la auditoría B (D-01..D-24) con las 13 agrupaciones de la auditoría A (D1..D13). Catálogo base: el derivado literalmente de los siete archivos normativos de la analista. No se reabre nada que el texto nuevo o una decisión confirmada de Andrés ya resolvió, salvo contradicción demostrada (se indica cuándo ocurre).

**Clases:** **RA** resuelta por la analista (el texto vigente lo establece expresamente) · **RAN** resuelta previamente por Andrés · **RE** resuelta mediante evidencia existente (código o corpus real) · **PT** propuesta técnica pendiente de aprobación · **RQ** requiere respuesta de la analista.

## 1. Resultado

De 24 + 13 entradas quedan **13 decisiones realmente pendientes (C-01..C-13)**: 12 provienen de B (varias también de A) y una, C-13 (asociación de modelos por grupo), es exclusiva de A. **20 se cierran** (R-01..R-20) y se anotan sin volver a preguntarlas. Solo C-11 es puramente editorial.

| Prioridad | Pendientes | Por qué |
|---|---|---|
| P0 (bloquean cualquier redacción) | C-01, C-02 | Sin SRV-001/002 y sin paquete cerrado no hay catálogo canónico |
| P1 (bloquean la evaluación de una familia) | C-04, C-05, C-06, C-07, C-08 | Determinan si E1-E3, EVT, SRV-003, COM-002/003, MQ-002/003 pueden dar algo distinto de No verificable |
| P2 (precisan la redacción o la lectura) | C-03, C-09, C-10, C-12, C-13 | Reducen la variabilidad entre ejecuciones |
| P3 (editorial) | C-11 | Erratas |

## 2. Reconciliación de las dos listas

| B | Clase | Destino | A | Destino |
|---|---|---|---|---|
| D-01 inventario base | RAN | R-01 (+ versionado en C-02) | D1 | C-01, C-02 |
| D-02 SRV-001/002 | RQ | C-01 | D2 plantillas | R-07 |
| D-03 API/servicio/evento no principal | RQ | C-04 | D3 subtipos BPMN | C-07 |
| D-04 INVOCADO | RQ+PT | C-05 | D4 representación de figuras | C-04, C-05, C-06 |
| D-05 figura→reconocimiento | RQ | C-06 | D5 MOD-001 grupo | C-13 |
| D-06 subtipos BPMN | RQ | C-07 | D6 No cumple con Inicio sin certificar | C-08 |
| D-07 plantillas | RAN | R-07 | D7 productor inferido | R-05 |
| D-08 No aplica | RA/RE | R-08 (+ C-03) | D8 cobertura completa | C-03 |
| D-09 F-13 | RA | R-03 | D9 «revisión manual» EXT-001 | C-10 |
| D-10 directa/declarada | RA/RE | R-04 | D10 versionado | C-02 |
| D-11 productor inferido | RAN | R-05 | D11 EXT-002 nueva / «EXT-003» | C-11 |
| D-12 criterios subjetivos | PT+RQ | C-09 | D12 preguntas MCI | R-10 |
| D-13 cascada EVT | RA | R-09 | D13 juicios semánticos | C-09 |
| D-14 MQ-002 | RA + RQ | R-10 y C-06 | | |
| D-15 EXT-001 | RQ | C-10 | | |
| D-16 EXT-002 subcadena | PT | C-11 | | |
| D-17 capitalización | RQ | C-11 | | |
| D-18 COM relación | PT+RQ | C-12 | | |
| D-19 MOD-001 reconocimiento | RE/RAN | R-11 (+ C-13) | | |
| D-20 agregado | RAN | R-12 | | |
| D-21 hijo = servicio principal | RA | R-06 | | |
| D-22 cobertura | PT+RQ | C-03 | | |
| D-23 reversiones | RA | R-13 (+ C-10) | | |
| D-24 E con Inicio sin certificar | RQ | C-08 | | |

Coincidencia de fondo: **A y B detectan las mismas 11 familias de problemas**; B aporta mecanismos técnicos concretos (G-2, G-5, G-7, D-16..D-18, EC-08) y A aporta medición sobre blueprints reales y el contexto de decisiones previas.

---

## 3. Decisiones resueltas (no se vuelven a abrir)

| # | Decisión | Clase | Fuente / sustento | Acción derivada |
|---|---|---|---|---|
| R-01 | La base es el catálogo de 37 reglas derivado de los siete archivos de la analista, no el CSV de 41 | RAN | Instrucción de Andrés (26/10) | Ninguna; el CSV del ZIP queda como histórico |
| R-02 | CNT-002 y CNT-004 no dependen del escenario certificado ni del Inicio | RA | CNT-002: «No se requiere identificar ni certificar un evento BPMN de Inicio»; CNT-004 sin dependencia | Retirar de la Skill la frase «no se extiende a CNT-002» (v11.2.3) |
| R-03 | «Gestionado / no gestionado» (F-13) queda retirado | RA | CNT-002: «no evalúa… su condición de gestionado o no gestionado» | **Andrés** actualiza `AGENTS.md` (aún cita F-13) |
| R-04 | «Conexión directa o declarada»: una línea `None→Arrow` entre la API y el evento | RA + RE | Texto idéntico en E1/E2/E3-001; 12 de 12 escenarios reales usan `None->Arrow` | Cerrada; el motor ya exige una línea con extremos API y evento |
| R-05 | Un productor identificado por evidencia estructural (Recaudos, CORE GLOBAL ACCOUNT) cuenta como DOMINIO PRODUCTOR | RAN | Confirmación de Andrés (Q1); 3 casos reales con procedencia `STRUCTURAL_CHILD_EVENT_MAIN_PATH` | Citar siempre procedencia, certeza y conflictos. Nota técnica: CNT-001 en E1 con productor inferido es tautológica (el patrón y el dominio salen del mismo camino); no es error y no se reabre |
| R-06 | El hijo principal representa el servicio principal del escenario; sigue sin ser `SERVICIO`/`INVOCADO` en el contrato | RA | MANIFEST, SRV-003 (lo excluye), SRV-004 | **Andrés** aprueba adaptar §2 de la Skill v11.2.3 |
| R-07 | Páginas plantilla/leyenda/BDD no se evalúan (sin filas ni porcentaje) | RAN | Decisión de Andrés en v11.2.2 | Avisar a la analista (su «No aplica» por plantilla es equivalente en métrica: No aplica sale del denominador); no se pregunta |
| R-08 | «No aplica» solo por el criterio individual de cada regla; la ausencia de la figura basta cuando la regla lo declara | RA + RAN | Cláusulas «No aplica» explícitas de la analista; principio de v11.2.2 | Redactar una sola vez en el procedimiento (ver C-03) |
| R-09 | Cascada EVT-004 → EVT-005/006/007 (Capa de Tópicos ausente = No cumple en EVT-004 y No verificable en las demás) | RA | EVT-005/006/007, viñeta «No aplica» | Declararla como dependencia en el catálogo |
| R-10 | Preguntas: MCI de la API principal; MCI del hijo solo en E1/E2; exposición opcional (solo API-004); se elimina la pregunta MCI del gestor | RA | MANIFEST «Respuestas humanas autorizadas» | **Andrés** actualiza `AGENTS.md` (hoy pide MCI del hijo sin distinguir E3) |
| R-11 | Los modelos ENTRADA/SALIDA se reconocen por `customData` literal; el nombre no los certifica | RE + RAN | 160 de 160 figuras preservadas; `MODELO` por nombre solo en 61; `GUIA-TEXTAREAS` del analista | Ninguna |
| R-12 | Un resultado por regla y página; el detalle por componente va en la justificación | RAN | Procedimiento de la Skill y `AGENTS.md` | Ninguna |
| R-13 | Reversiones explícitas de la analista: guion bajo obligatorio (EVT-001), camelCase (EVT-002), sin tilde (EVT-003), sin eventos ni gestores dentro de auxiliares o SISTEMAS EXTERNOS | RA | Textos detallados de las reglas | Registrar como decisiones de la analista; las consecuencias en diagramas reales van a C-10 |
| R-14 | API-003: sección completa sin modelo = No cumple; la exposición declarada no la corrige | RA | API-003 | Cierra la observación O4 del piloto |
| R-15 | API-004, CA-001 y FT-001 se separan (existencia en API-004/SRV-004/MQ-002; CA/FT solo nombres) | RA | 04 y 02 | Retirar la instrucción de v11.2.3 de evaluarlas «por separado» |
| R-16 | CNT-006 desaparece; la integridad del JSON pasa a controles previos | RA | MANIFEST | Se elimina el criterio operativo de CNT-006 (v11.2.2) |
| R-17 | Con `UMLActiveClassBlock` = gestor, «sin figura» da No aplica en MQ y en las reglas condicionales | RA | MQ-001 y cláusulas «No aplica» | Cierra C15-Q1 |
| R-18 | Cuatro estados, fórmula y prioridad `No cumple` > `No verificable` > `Cumple` > `No aplica` | RAN + RA | Skill y procedimiento §8 | Ninguna |
| R-19 | Las respuestas del analista solo se reutilizan entre páginas con confirmación explícita | RAN | Decisión de Andrés | Ninguna |
| R-20 | CNT-001 y CNT-002 se evalúan con el patrón estructural identificado aunque el escenario siga en HIPOTESIS | RA | CNT-001/002: «aunque el cumplimiento integral del escenario no esté confirmado» | Ninguna |

---

## 4. Decisiones realmente pendientes

Cada ficha: norma afectada · texto relevante · evidencia disponible · evidencia faltante · alternativas · recomendación · quién aprueba · consecuencia de no resolverla. «Real» = medido en los 7 blueprints (14 páginas operativas).

### C-01 · SRV-001 y SRV-002 — criterio y población (RQ) · P0
- **Norma:** SRV-001, SRV-002 (la analista las declara pendientes).
- **Texto:** SRV-001 «Servicios principal e invocados… Puede iniciar por ms; admite -, _ o espacios. Si hay versión, V/v y tres segmentos». SRV-002 «No deducir operación del nombre».
- **Evidencia:** 5 componentes `SERVICIO` (reconocidos por prefijo `ms`); nombres reales de hijos principales: `msDebitAccountPayment`, `user_ms`, «Currency Exchange Transacti…» (sin prefijo). El contenedor hijo tiene una sola sección de texto (no hay operación).
- **Falta:** criterio definitivo y población.
- **Alternativas:** (1) población = servicios invocados + componente principal de E3 (el hijo se valida por nombre en CNT-002); (2) incluir al hijo principal (SRV-002 no es evaluable en un contenedor sin operación → No verificable); (3) retirar ambas y absorber el nombramiento en otra regla.
- **Recomendación técnica:** (1), con formato paralelo a API-001/002 y prefijo `ms` convencional.
- **Aprueba:** analista (norma); Andrés valida la redacción.
- **Si no se resuelve:** 2 de 37 reglas darán siempre «No verificable — criterio pendiente» y bajan el porcentaje sin sustento; sus pruebas quedan bloqueadas.

### C-02 · Paquete cerrado y versionado (RQ analista + Andrés) · P0
- **Norma:** `MANIFEST.md` «Verificación final» (puntos 1–5).
- **Evidencia (A y B coinciden):** CSV con 41 reglas y nombre distinto al del manifiesto; instrucciones y contrato piden 41 filas; encabezados v11.2.1; paquete etiquetado «v11.2.2» (SHA distinto al nuestro); carpeta raíz anidada.
- **Falta:** paquete coherente y nomenclatura.
- **Alternativas:** (a) versión del paquete única (propuesta de A: v12.0.0-rc.1); (b) versión normativa N separada de versión de procedimiento P (propuesta de B).
- **Recomendación:** combinar: paquete `v12.0.0-rc.1` con `VERSION.md` que registre N y P y el hash del catálogo.
- **Aprueba:** analista (contenido del paquete), Andrés (nomenclatura).
- **Si no:** colisión de etiquetas, resultados no reproducibles, regreso de referencias a 41.

### C-03 · Cobertura completa, tabla issue→regla y «No aplica» (PT + RQ) · P2
- **Norma:** casi todas («cobertura suficiente/completa», «inventario completo»); procedimiento §2 y §8.
- **Texto:** las reglas condicionan No cumple y No aplica a «cobertura completa», que ningún archivo define.
- **Evidencia:** `counts`, `issues`, `metadata.omittedPages`, estado de grupos; sin tabla issue→regla.
- **Falta:** definición operativa y la tabla.
- **Alternativas:** una definición general (inventario completo = `counts` coherentes con el inventario y ningún `issue` sobre los componentes implicados o su cadena) frente a una por regla.
- **Recomendación:** la general, más la tabla; la redacta el técnico, la aprueba la analista; unifica R-08.
- **Aprueba:** analista; Andrés valida.
- **Si no:** No cumple por ausencia sin criterio uniforme; variabilidad ya observada entre ejecuciones.

### C-04 · Certificar API / servicio / evento de integración en figuras no principales (RQ) · P1
- **Norma:** API-001..003 («tipo arquitectónico certificado»), EVT-001..003 («clasificación certificada como evento de integración»), SRV-003, COM-002/003, EXT-002, MQ-003; `GUIA-TEXTAREAS`: «Private/Public/Partner no demuestran API; Entidad/Utilidad/Tarea no demuestran SERVICIO».
- **Evidencia real:** 62 `UMLClassBlock` sin tipo. Tercera sección: «entidad» 30, plantillas de leyenda («clasificación api/lógica») 24, «Empresarial - Event/Query» 5, «tarea» 1, «utilidad» 1, otras 1. Las APIs principales tienen «private - entidad» (4), «entidad» (5).
- **Contradicción con la propuesta de B:** su opción (B) (tercera sección ⇒ tipo) clasificaría como servicio los 30 invocados que solo dicen «Entidad», aunque su primera sección sigue el formato de API («Customer Account - Account v2.0.1»). Los datos reales refutan esa regla tal como está escrita.
- **Falta:** un discriminador aprobado.
- **Alternativas:** (A) declaración de la analista por componente (exige levantar la restricción de la guía para ese uso); (B) tercera sección (refutada en parte); (C) formato de la primera sección (`Producto - Nombre vX.Y.Z` ⇒ candidato a API; `ms…` ⇒ servicio), por validar sobre las 62 figuras; (D) mantener No verificable.
- **Recomendación:** pedir el discriminador a la analista; mientras tanto (D).
- **Aprueba:** analista (con Andrés si cambia el motor, EC-06).
- **Si no:** API-001..003 de invocadas, SRV-003, COM-002/003, EXT-002, MQ-003 y EVT-001..003 quedan No verificable de forma sistemática.

### C-05 · Definición de «invocado» y rol `INVOCADO` (RQ + PT) · P1 · *reabre una decisión técnica previa por contradicción demostrada*
- **Norma:** SRV-003, COM-002, COM-003, MQ-003, API-004 (excluye invocadas).
- **Evidencia (código y corpus):** `INVOCADO` se emite solo si el tipo es API/SERVICIO, hay conexión entrante y **ninguna saliente** (`exporter.js`, línea 37). El patrón normativo de COM-002/003 es bidireccional, que crea una conexión saliente. Real: `INVOCADO` en 0 componentes; 56 pares comando↔componente bidireccionales frente a 5 de un solo sentido.
- **Falta:** definición normativa de «invocado».
- **Alternativas:** (a) invocado = componente no principal relacionado con un comando por conexión (cambia el motor, EC-01); (b) invocado = no principal y no hijo, tipado por C-04, sin usar el rol; (c) mantener y aceptar No verificable.
- **Recomendación:** (a) o (b) según C-04; sin código hasta aprobar.
- **Aprueba:** analista (definición) y Andrés (cambio de comportamiento de un campo publicado).
- **Si no:** el rol que las reglas necesitan nunca se emite en el patrón que ellas mismas exigen.

### C-06 · Cómo se reconocen las figuras de la norma (RQ con tabla prellenada) · P1
- **Norma:** CNT-003..005 (listas), EVT-004..006, MQ-002, EXT-001.
- **Evidencia real (prellenado de la tabla):**

| Figura | Representación observada | Estado |
|---|---|---|
| `Federado` | `UMLRectangleContainerBlock` o `MinimalTextBlock` con el texto exacto «Federado» (8 casos; padres: Iseries, COMEX - CIB, EVC…, Sistema Externo, INTEGRACIÓN) | observado; sin tipo; asociación al gestor sin definir |
| Evento de integración | `UMLClassBlock` con tercera sección «Empresarial - Event/Query» (5) | observado; sin tipo |
| Anotación | clase `BPMNTextAnnotation` (7) | observado |
| Capa de Tópicos / tópico | un único contenedor con texto «p.nombreTopico… s.nombre…» (Escenario2) | casi sin ejemplos |
| Concepto, pendiente, política | no identificados en este análisis | **falta** |
| Modelo ENTRADA/SALIDA | `customData` literal | resuelto (R-11) |
| Capa / Flujo | prefijo del nombre | resuelto, con límite G-6 |

- **Alternativas:** reconocer por clase Lucidchart, por texto literal o por `customData`.
- **Recomendación:** que la analista confirme/complete las 7 filas abiertas; luego campos aditivos (EC-03/EC-04) o lectura de `textAreas` en la Skill.
- **Aprueba:** analista.
- **Si no:** CNT-003..005, EVT-001..006 y MQ-002 dan No verificable aunque el literal exista en el diagrama.

### C-07 · Convención de subtipos BPMN (RQ + evidencia corporativa) · P1
- **Norma:** E1/E2/E3-001 (Inicio), EVT-007 (Señal de Envío/Recepción), MQ-003 (Mensaje).
- **Evidencia real:** 260 `BPMNEvent`; claves del JSON original: `id, class, textAreas, customData, linkedData, linkUrl` (ninguna de subtipo); `customData` en 0 de 260; texto «FIN» en 19; «Mensaje/Señal» solo en leyendas y BDD, no en eventos. El catálogo propuesto (START, END, SIGNAL, RECEIVE, EXCEPTION) no tiene Mensaje ni Envío y solo se interpreta en el evento del escenario.
- **Falta:** cómo se declara el subtipo en Lucidchart.
- **Alternativas:** (a) convención `customData` explícita, ampliando el catálogo e interpretándola en todos los eventos (EC-02); (b) otro mecanismo de la herramienta: **descartado** por el export; (c) texto convencional: contradice la regla (el texto no certifica); (d) aceptar No verificable permanente.
- **Recomendación:** (a) solo si el estándar corporativo ya lo exige; si no, (d).
- **Aprueba:** analista (convención) y Andrés (cambio aditivo).
- **Si no:** E1/E2/E3-001, EVT-007 y MQ-003 (Mensaje) no pueden dar Cumple.

### C-08 · E1/E2/E3-001: violación estructural certificada con Inicio sin certificar (RQ) · P1
- **Texto:** el procedimiento §8 dice que un incumplimiento certificado prevalece; la viñeta «No cumple» de cada regla exige también el subtipo Inicio certificado.
- **Evidencia:** 12 escenarios reales, ninguno con Inicio certificado.
- **Alternativas:** (a) No cumple si la violación estructural está certificada, aunque el Inicio no lo esté; (b) No verificable mientras el Inicio no esté certificado (literal de la viñeta).
- **Recomendación:** (a); ajustar la viñeta. Coincide con la recomendación de B.
- **Aprueba:** analista.
- **Si no:** resultados distintos para la misma página entre ejecuciones.

### C-09 · Criterios subjetivos (PT + RQ) · P2
- **Norma:** «específico» (34 apariciones), «genérico» (37), «plantilla» (36), «funcional» (20), «inequívoca/o» (30), idioma inglés, infinitivo en español (conteos de B).
- **Evidencia:** el motor solo tiene una lista cerrada de plantillas; en la validación v11.2.3 CNT-002/CNT-004 variaron entre ejecuciones.
- **Alternativas:** listas cerradas aprobadas; juicio del agente con justificación; No verificable si no hay certeza.
- **Recomendación:** listas cerradas de plantilla y de términos genéricos; el resto, juicio justificado; sin certeza, No verificable.
- **Aprueba:** analista (listas); Andrés (política de variabilidad).
- **Si no:** discrepancias entre ejecuciones y evaluadores en al menos 7 reglas según la matriz de B.

### C-10 · EXT-001 y CNT-005 frente a diagramas reales (RQ) · P2
- **Texto:** EXT-001 solo admite API, servicios, pendientes, conceptos, anotaciones (y capas en el nivel padre); un `BPMNEvent` interno deja No verificable y «Requiere revisión manual del analista»; CNT-005 no admite gestores en SISTEMAS EXTERNOS.
- **Evidencia real:** De 34 auxiliares, 21 contienen `BPMNEvent` y 11 contienen `BPMNActivity` (VAO, Debit); 21 llevan EVC/EPC/LDC en el nombre (15 bajo INTEGRACIÓN, 6 sin dominio resuelto); 4 auxiliares («Wenia») están vacíos (EXT-001 → No verificable por texto); 28 `BPMNGroup` sin nombre, todos vacíos (no son candidatos).
- **Preguntas:** (1) ¿los comandos dentro de un auxiliar están prohibidos o se omitieron de la lista? (2) ¿«revisión manual» es una pregunta del agente a la analista o simplemente No verificable? (3) Un gestor externo no tiene ahora ubicación válida (antes sí): ¿es intencional?
- **Recomendación:** confirmar con los casos reales.
- **Aprueba:** analista.
- **Si no:** EXT-001 daría No cumple en diagramas reales por contenido que quizá la lista olvidó, o el agente pediría revisiones manuales sin protocolo.

### C-11 · Erratas y precisiones editoriales (RQ, lote) · P3
1. EXT-002 se autorreferencia («sus conexiones se evalúan mediante EXT-002»). 2. EXT-002: «contenga EVC, EPC o LDC» como palabra completa o subcadena (en el corpus no hay falsos positivos). 3. API-004: «presenta todo la capa de despliegue». 4. EVT-005/006/007: la viñeta «No aplica» contiene casos de «No verificable». 5. CNT-003/004: el hijo principal no figura entre lo permitido en el nivel padre aunque la regla lo presupone. 6. SRV-003 acepta cualquier capitalización y API-003 exige minúsculas: ¿intencional? 7. El manifiesto habla de una «antigua EXT-003» que no existe en el catálogo de 41. 8. 14 reglas dependen de la regla global de prioridad (no repiten «prevalece No cumple»). 
- **Aprueba:** analista (una pasada). **Si no:** ambigüedad menor, pero inestabiliza pruebas.

### C-12 · COM: «relación» y «atribución inequívoca» (PT + RQ) · P2
- **Texto:** COM-001 «relación identificable»; COM-005 «atribución inequívoca».
- **Evidencia:** 61 pares comando↔componente por conexión; en 41, un único candidato compatible permitía atribuir.
- **Recomendación:** relación = conexión directa (no grupo); inequívoca = el auxiliar encapsula exactamente un componente compatible o la línea termina en el componente.
- **Aprueba:** analista. **Si no:** variabilidad en COM-001 y COM-005.

### C-13 · MOD-001: ¿un grupo compartido es asociación inequívoca? (RQ) · P2 · *solo A*
- **Texto:** la asociación «no puede establecerse únicamente por cercanía, alineación, superposición o pertenencia al mismo contenedor»; la norma no menciona grupos.
- **Evidencia real:** en páginas evaluables, 20 modelos están en un grupo único con el principal, 59 en grupos sin el principal y 43 sin grupo; en 10 de 14 páginas, ENTRADA y SALIDA del principal están en un grupo con él.
- **Alternativas:** (a) grupo con el principal = asociación; (b) no basta; (c) basta solo si el grupo contiene un único propietario posible.
- **Recomendación:** (c).
- **Aprueba:** analista. **Si no:** MOD-001 no puede dar Cumple/No cumple con criterio estable.

---

## 5. Cuestionario compacto para la analista (en orden)

1. **C-01** SRV-001/002: población, prefijo `ms`, versión, operación.
2. **C-07** ¿Cómo se declara el subtipo (Inicio, Señal de Envío/Recepción, Mensaje) en Lucidchart?
3. **C-04** ¿Cómo distinguimos API, servicio y evento de integración en las figuras no principales? (con la tabla de las 62).
4. **C-05** ¿Qué es un servicio/API «invocado»?
5. **C-06** Confirmar/completar la tabla de reconocimiento (concepto, pendiente, política, Capa de Tópicos, asociación de «Federado»).
6. **C-08** Violación estructural certificada con Inicio sin certificar: ¿No cumple o No verificable?
7. **C-13** ¿Un grupo con el principal basta para asociar modelos?
8. **C-10** Auxiliares con comandos/eventos dentro; «revisión manual»; ubicación del gestor externo.
9. **C-03/C-09** Definición de cobertura completa y listas cerradas de plantilla/genérico.
10. **C-12** Definición de relación y atribución inequívoca.
11. **C-11** Lote de erratas.

## 6. Pendientes de Andrés (no de la analista)
1. **C-02** nomenclatura de versiones y nombre del paquete.
2. `AGENTS.md`: retirar F-13, pasar a 37 reglas, preguntas MCI (hijo solo en E1/E2), `UMLActiveClassBlock` como norma.
3. Aprobar la adaptación de §2 de la Skill (R-06) y la retirada de «no se extiende a CNT-002» y de la evaluación separada de API-004/CA-001/FT-001.
4. Avisar a la analista del tratamiento de páginas plantilla (R-07).
5. Cuando se implemente: `SKILL_VERSION` en `src/version.js` dice `11.2.1` (metadato desfasado, hallazgo exclusivo de B, verificado).
