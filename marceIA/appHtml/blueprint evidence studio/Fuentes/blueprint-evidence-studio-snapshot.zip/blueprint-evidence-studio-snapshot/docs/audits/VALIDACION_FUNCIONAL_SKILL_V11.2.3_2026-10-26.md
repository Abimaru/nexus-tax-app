# Validación funcional de la Skill v11.2.3 — 26/10/2026

Evidence Studio v0.4.6.1 (sin cambios funcionales; HTML SHA-256 `a93f293d…a47`) · Skill v11.2.3 **preparada, no declarada estable** · Repositorio `Abimaru/blueprint-evidence-studio` **PRIVADO** (verificado hoy con `gh repo view`; `origin/main` sigue siendo solo `README.md`) · Sin commit, push, merge ni PR.

> Nota posterior (26/10): después de estas ejecuciones el HTML distribuible pasó a un candidato visual v0.4.7 (SHA-256 `205cc88e…93f5`). Los compactos de los tres casos se regeneraron con él y son idénticos byte a byte; los resultados de este informe no cambian. Ver `PROJECT_CONTEXT_2026-10-26.md`.

Alcance y límites: 3 casos sintéticos, **una ejecución por caso y versión** (6 sesiones). No es la batería de 16 casos ni una repetición estadística. Ninguna diferencia se interpreta como defecto sin clasificarla; lo pendiente de interpretación normativa no se marca como fallo.

## 1. Método
- ZIP v11.2.3 fijado por hash `e15c8bda8bef0eb4913ea671c1bfc8ad97b10e026112a51c4455be8f75939330` (verificado antes de cada ejecución). Comparación con el ZIP v11.2.2 archivado (`9b35a98e5073…c704d`) sobre **las mismas entradas** (`input/compact.json` idéntico).
- Infraestructura aislada de `qa/`: sandbox con solo la Skill y el compacto; herramientas `Read,Skill`; el evaluador no ve el motor, las expectativas, los canarios ni las auditorías (comprobaciones AISLAMIENTO_* PASS en las 6 sesiones; preflight 38/38 y 39/39 antes de ejecutar).
- Modelo `claude-opus-5-5`, CLI 2.1.310, autenticación claude.ai. Expectativas redactadas **antes** de ejecutar, en `qa/expected/v123-*.expected.json`.
- Casos (generados con `qa/tools/gen-v1123-cases.mjs`, compactos con el HTML distribuido; estructuras derivadas de las verificadas en los blueprints reales, nombres inventados):

| Caso | Qué prueba | Trampa incluida |
|---|---|---|
| `v123-a-inicio` | E1/HIPOTESIS sin Inicio certificado; HIPOTESIS≠No cumple; E1/E2/E3-001 sin Cumple; CNT-002 pendiente | El evento trae el texto libre «Inicio del proceso» y ningún `customData` |
| `v123-b-mod001` | MOD-001 con ENTRADA/SALIDA en `customData` | Etiqueta «Modelo de Salida» (tipo `MODELO` por nombre, sin `customData`); modelo huérfano sin grupo; modelo contenido en el hijo sin grupo; grupo compartido con la API |
| `v123-c-hijo` | `SERVICIO_HIJO` vs `HIJO_PRINCIPAL`; SRV-001..003 sin ampliar población | Hijo secundario sin rol principal anidado en un contenedor sin nombre; ninguna figura SERVICIO en la página |

## 2. Resultados con v11.2.3
Conversación: pregunta MCI del principal y del hijo (no la exposición, ya acreditada) → evaluación final en el 2.º turno, sin suspensiones. 41 filas válidas, métrica recalculada coincidente, 0 FAIL técnicos en las tres. Una única marca REVISAR por caso: MQ-001..004 (ver 4).

| Caso | Conteos (Cumple / No cumple / No verificable / No aplica) | Cumplimiento |
|---|---|---|
| A | 7 / 5 / 11 / 18 | 30,43 % (7/23) |
| B | 6 / 4 / 12 / 19 | 27,27 % (6/22) |
| C | 5 / 5 / 12 / 19 | 22,73 % (5/22) |

Comprobaciones de la validación (todas PASS en v11.2.3):
- **A:** E1-001 = No verificable (no Cumple ni No cumple); ningún No cumple se apoya en HIPOTESIS; el texto «Inicio del proceso» no se toma como certificación (el evaluador lo dice expresamente); CNT-002 registra su lectura (ver 4).
- **B:** MOD-001 = No verificable citando `customData`, `vb-in`, `vb-out`; declara que la etiqueta `vb-label` «no cuenta como modelo» y que no asigna dueño a `vb-orphan` «por cercanía»; menciona el grupo.
- **C:** SRV-001..003 = No aplica con el razonamiento «el hijo no equivale a servicio principal ni invocado; no se incluye por analogía»; no reclasifica `vc-child`, `vc-wrap` ni `vc-aux`; menciona el contenedor sin rol principal.

## 3. Comparación con v11.2.2 (mismas entradas)
Detalle: [`COMPARACION_V1123_VS_V1122_2026-10-26.md`](COMPARACION_V1123_VS_V1122_2026-10-26.md) (generado con `qa/tools/compare-runs.mjs`).

Estado por regla en las 6 sesiones (reglas relevantes):

| Regla | A 11.2.3 | A 11.2.2 | B 11.2.3 | B 11.2.2 | C 11.2.3 | C 11.2.2 |
|---|---|---|---|---|---|---|
| CNT-002 | **Cumple** | No verificable | No verificable | No verificable | No verificable | No verificable |
| CNT-004 | **Cumple** | No verificable | Cumple | Cumple | No verificable | No verificable |
| E1-001 / E2-001 / E3-001 | NV / NV / NV | NV / NV / NV | NV / NV / NV | NV / NV / NV | NV / NV / NV | NV / NV / NV |
| MOD-001 | No cumple | No cumple | No verificable | No verificable | No cumple | No cumple |
| SRV-001..003 | No aplica | No aplica | No aplica | No aplica | No aplica | No aplica |
| API-003, API-004, CA-001, FT-001 | No cumple ×4 | No cumple ×4 | No cumple ×4 | No cumple ×4 | No cumple ×4 | No cumple ×4 |
| MQ-001..004 | No aplica | No aplica | No aplica | No aplica | No aplica | No aplica |
| EVT-007 | No verificable | No verificable | **No aplica** | No verificable | **No aplica** | No verificable |

Lectura honesta:
1. **Solo 4 reglas difieren entre versiones en los tres casos** (CNT-002 y CNT-004 en A; EVT-007 en B y C). Ninguna de ellas corresponde a un ajuste de v11.2.3 salvo posiblemente CNT-002.
2. **Los casos no discriminan los ajustes 1–7**: todas las comprobaciones propias de v11.2.3 también pasan con v11.2.2 (el evaluador ya se comportaba así: E1-001 No verificable, no usa HIPOTESIS para un No cumple, no amplía SRV, evalúa API-004/CA-001/FT-001 por separado, usa `customData` en MOD-001). La diferencia observable de v11.2.3 es la **justificación**: cita el procedimiento («no equivale a servicio principal ni invocado», «se evalúa por separado de API-004 y CA-001»).
3. **Posible efecto no deseado de la cláusula «no se extiende a CNT-002»:** en A el evaluador respondió «La exigencia de Inicio certificado no se aplica a esta regla» y dio Cumple en CNT-002 y CNT-004; en B y C, con la misma Skill, dio No verificable. Con una ejecución por caso no puede separarse variabilidad del efecto de la frase. Se registra como riesgo de redacción (ver 5).

## 4. Hallazgos clasificados
Clases: **EX** error de extracción · **CT** error de contrato · **PS** error de procedimiento de la Skill · **EV** error del evaluador · **QA** error del controlador · **DN** decisión normativa pendiente.

| # | Hallazgo | Evidencia | Clase | Estado |
|---|---|---|---|---|
| 1 | `CONTEOS_INFORMADOS` FAIL en las 3 sesiones v11.2.2: el controlador leyó mal los conteos (los informes decían 5/5/13/18, 6/4/13/18, 5/5/13/18; leyó «No aplica 5», «Cumple 21» de «cumple 21,7 %») | Texto de las transcripciones | **QA** | Corregido en `qa/controller/lib/parser.mjs` (estrategia por tabla/frase completa antes del fallback), 5 pruebas nuevas (selftest 123/123), 6 sesiones reevaluadas **sin llamar al modelo**: 0 FAIL |
| 2 | CNT-002: Cumple (A, v11.2.3) frente a No verificable (otras 5) | Tabla §3 | **DN** (lectura de «escenario certificado») + riesgo **PS** de redacción | Pendiente de la analista; no se marca como fallo |
| 3 | CNT-004 varía entre casos y ejecuciones, también en v11.2.2 | Tabla §3 | **DN** (depende de si HIPOTESIS basta para ubicar el hijo) | No atribuible a v11.2.3 |
| 4 | E1/E2/E3-001 = No verificable en 18/18 filas | Tabla §3 | — (conforme al criterio vigente) | El ajuste 5 no se ejerció de forma discriminante |
| 5 | MQ-001..004 = No aplica en 6/6 sesiones (expectativa: No verificable) | `RESULTADOS_ESPERADOS_NORMATIVOS` | **DN** (C15-Q1) | Reaparece con la v11.2.3 pese a «la ausencia de una figura no basta»; sigue pendiente, no es fallo |
| 6 | EVT-007 = No aplica en B y C (v11.2.3) vs No verificable (v11.2.2) | Tabla §3 | **DN** (población «tópicos asociados» cuando no hay tópicos) | Ningún ajuste de v11.2.3 trata esta regla: probable variabilidad |
| 7 | API-003 = No cumple en 6/6 («falta el modelo») | Informes | **DN** (O4: tercera sección sin modelo) | No se modificó la interpretación |
| 8 | API-004, CA-001, FT-001 = No cumple en 6/6, cada una con justificación propia | Informes | **DN** (Q8: reparto) | Evaluación independiente confirmada; no hay fusión |
| 9 | MOD-001: No cumple en A y C (el JSON no tiene modelos: resultado correcto); No verificable en B | Informes | Resultado correcto (A, C); **DN** (B: ¿basta la pertenencia a un grupo?) | Consulta `customData` en 6/6 |
| 10 | SRV-001..003 = No aplica en 6/6; no se amplía por analogía | Informes | **DN** (población, Q4) | Conforme a v11.2.3; v11.2.2 igual |
| 11 | Extracción / contrato / evaluador | — | **EX**: ninguno; **CT**: ninguno nuevo (ver 5.1); **EV**: ninguno identificado | — |

## 5. Tres hallazgos técnicos
### 5.1 MOD-001 — independencia respecto de `MODELO`
Confirmado con `qa/tools/audit-mod001.mjs`: 160 figuras con `customData` ENTRADA/SALIDA (clase `BPMNActivity`) en 7 blueprints; **99 con `architecturalType: null` y 61 con `MODELO`** (`exporter.js:25`: el tipo `MODELO` se asigna si el **nombre** de la figura contiene «modelo»). Las etiquetas «Modelo de Salida/Lectura» (`DefaultSquareBlock`) también son `MODELO`. Por tanto la evidencia semántica ENTRADA/SALIDA es independiente del tipo `MODELO`.
¿Aclaración adicional en el procedimiento? **Recomendada, no urgente.** Hoy ni `00-procedimiento.md` ni `CONTRATO-COMPACTO.md` dicen cómo identificar un modelo de datos; el evaluador acertó en las 6 sesiones por la matriz (`customData`, `textAreas`, `groups`). Redacción candidata (operativa, sin inferencias de propiedad nuevas): «Los modelos de entrada y salida se identifican por la clave `ENTRADA`/`SALIDA` en `customData`; `architecturalType: MODELO` se asigna por el nombre de la figura y no los identifica. La pertenencia a un grupo es evidencia asociativa, no contención ni propiedad.» Requeriría una versión nueva de la Skill; no se hace.

### 5.2 Contenedores hijo sin nombre (trazabilidad, no incumplimiento)
Los 8 contenedores sin nombre están en Debit Card; 6 agrupan decenas de figuras:

| Página | ID | Figuras contenidas | Padre | Nota |
|---|---|---|---|---|
| createCustomizedCardConsulta | `AAztRTdbhApb` | 21 | — | sin padre |
| createCustomizedCardConsulta | `iy.SVb3uZRsH` | 68 | — | sin padre |
| createCustomizedCardConsulta | `AAztE7-ReJ9u` | 64 | `iy.SVb3uZRsH` | anidado |
| createVirtualCard | `BbYhTgCQpwds` | 21 | — | sin padre |
| createVirtualCard | `BbYhFkV9zgrq` | 66 | — | sin padre |
| createVirtualCard | `BbYhfjREOgCH` | 62 | `BbYhFkV9zgrq` | anidado |
| asociatePreIssuedCardMediadoConsulta | `Mm89cWGdOYLg` | 2 | — | sin padre |
| createVirtualCardConsulta | `X389OYd9uWQh` | 2 | — | sin padre |

Advertencias propuestas (informativas; no reclasifican ni afirman incumplimiento), con texto neutro: «Contenedor sin nombre que agrupa N figuras: se tipifica `SERVICIO_HIJO` por su figura, no por su contenido» · «Contenedor sin padre estructural declarado» · «Contenedor anidado dentro de otro contenedor hijo (ID)» · «Página con varios contenedores hijo y escenario no determinado: no se identifica hijo principal». Impacto: campos aditivos en `issues`/interfaz (contrato nuevo, requiere autorización y versión). Los sin nombre de 2 figuras y los de decenas pueden distinguirse por el conteo, sin juzgarlos.

### 5.3 Panel BPMN renombrado
Nombre vigente de la propuesta: **«Eventos BPMN con subtipo no certificado»** ([`PROPUESTA_CERTIFICACION_BPMN_2026-10-25.md`](PROPUESTA_CERTIFICACION_BPMN_2026-10-25.md)). Ningún texto presupone que un evento sea de Inicio antes de certificarlo; el texto libre «Inicio…» se muestra como literal. No se implementa ninguna convención `customData`; `PROPOSED_CLOSED_CATALOG` se mantiene. Nota: esa propuesta lleva fecha 25/10; el renombre se hizo el 26/10 por indicación de Andrés.

## 6. Telemetría y consumo
Tabla completa por ejecución en el [informe de comparación](COMPARACION_V1123_VS_V1122_2026-10-26.md) y en `qa/runs/v1123-*/` y `qa/runs/v1122cmp-*/` (`telemetry.json`). Tres conceptos distintos:
- **Costo de lista:** el que calcula el CLI a precios de lista para cada sesión (`costBasis=list`); se toma el **valor acumulado final de la sesión**, nunca la suma de los acumulados por turno.
- **Consumo estimado:** utilización de las ventanas de límite de la cuenta (`rate_limit_event`).
- **Cargo real:** no disponible; con inicio de sesión de claude.ai el consumo se descuenta de las ventanas del plan, no de un saldo en USD.

| | v11.2.3 (3 sesiones) | v11.2.2 (3 sesiones) | Diferencia |
|---|---|---|---|
| Costo de lista (suma de finales de sesión) | USD 2,3732 | USD 2,1936 | +8,2 % |
| Tokens totales | 539 590 | 513 968 | +5,0 % |
| Tokens de salida | 57 908 | 51 528 | +12,4 % |
| Duración del CLI | 560 s | 518 s | +8,1 % |
| Bytes de la Skill leídos (13 archivos en ambas) | 61 742 | 57 863 | +6,7 % |
| Llamadas a herramientas / turnos | 15 / 2 por sesión | 15 / 2 por sesión | 0 |

Por sesión (v11.2.3 · v11.2.2): costo de lista A 0,7631 · 0,7044; B 0,8310 · 0,7549; C 0,7791 · 0,7344 USD. Entrada 10–12 tokens, escritura de caché 44 012–49 827, lectura de caché 96 338–120 934, razonamiento 8 552–11 899. JSON compacto: A 11 675 B, B 19 934 B, C 14 437 B.
Límites: estado `allowed` en todas las sesiones; `overage` rechazado (`out_of_credits`) y sin uso de overage. Utilización de la cuenta observada: ventana de 5 h entre 0,44 y 0,54 y de 7 d entre 0,26 y 0,27. Las sesiones se ejecutaron en dos tandas simultáneas de tres, por lo que esa utilización incluye todas las sesiones en curso y **no puede atribuirse a una sola ni a una versión**.
Conclusión de consumo: la v11.2.3 cuesta ≈ 8 % más en lista en estos tres casos, por una Skill algo más larga y respuestas algo más extensas; no se mide un efecto sobre el plan.
Costo total de esta validación (6 sesiones): USD 4,5668 a precios de lista; las 12 reevaluaciones no llamaron al modelo.

## 7. Propuesta priorizada para Evidence Studio v0.4.7 (no implementada)
| Prioridad | Cambio | Archivos | Impacto contractual | Prueba | Riesgo |
|---|---|---|---|---|---|
| 1 | Panel «Eventos BPMN con subtipo no certificado» y advertencia no bloqueante | `ui/app.js` (+ lectura de `scenario.event`) | Ninguno (presentación) | casos de la propuesta BPMN | Bajo; redactar como evidencia, no como cumplimiento |
| 2 | Advertencias de trazabilidad de contenedores hijo (sin nombre/sin padre/anidado/varios sin principal) | `src/exporter.js`, `ui/app.js` | Aditivo en `issues` | auditoría de contenedores sobre el corpus | Medio: que se lean como incumplimiento |
| 3 | Mostrar procedencia, certeza y conflictos de `PRODUCER` | `ui/app.js` | Ninguno (campos existentes) | caso Oski y Virtual Account Opening | Bajo |
| 4 | Mostrar tipo (por figura) y rol (por escenario) de cada contenedor hijo | `ui/app.js` | Ninguno | caso hijo principal y secundario | Bajo |
| 5 | Listar los modelos ENTRADA/SALIDA detectados por `customData`, con su grupo y su padre, **sin** inferir propietario | `ui/app.js` | Ninguno | `qa/tools/audit-mod001.mjs` como oráculo | Medio: no sugerir propiedad |
| 6 | Indicador de cobertura (referencias ausentes, ciclos, páginas omitidas) | `src/`, `ui/` | Aditivo | corpus | Medio |
| 7 | Reducir el tamaño del compacto sin perder campos factuales | `src/exporter.js` | Posible cambio de contrato | comparación campo a campo | Alto: tocar el contrato |
| 8 | Automatizar la verificación de exclusiones antes de cada publicación pública | `scripts/` | Ninguno | prueba de la lista blanca | Bajo |
Cada punto requiere autorización expresa, `npm test` antes y después, y versión nueva. Ninguno modifica las 41 obligaciones.

## 8. Recomendación final
**Avanzar a pruebas con la analista usando v11.2.3 tal como está (sin declararla estable) y no emitir una v11.2.4 todavía.** Razones: (1) no muestra regresión frente a v11.2.2 en los 3 casos (0 FAIL, mismas filas salvo 4 reglas); (2) sus ajustes mejoran la trazabilidad de las justificaciones aunque estos casos no los discriminan; (3) todos los desvíos observados son interpretación normativa abierta (CNT-002/004, MQ, EVT-007, API-003, MOD-001/B, SRV), que solo la analista puede resolver; (4) el costo extra de ≈ 8 % es asumible.
Dos puntos para llevar a la analista como casos de revisión: **CNT-002/CNT-004** (la frase «no se extiende a CNT-002» puede leerse como licencia para Cumple; si la analista lo confirma o lo rechaza, se ajusta la redacción junto con su consolidado) y **MQ-001..004** (No aplica sistemático). Candidatos a incluir en la próxima versión, solo con aprobación: la aclaración de MOD-001 (5.1) y la neutralización de la frase sobre CNT-002.

## 9. Lo que no se hizo
No se ejecutó la batería de 16 casos ni repeticiones; no se modificó `src/`, `ui/`, la Skill ni las 41 obligaciones; no se crearon reglas; no se publicó material corporativo; no hubo commit, push, merge ni PR. Se modificó el banco de pruebas `qa/` (opción `--skill` para versiones archivadas, comprobaciones nuevas, corrección del parser de conteos, `compare-runs.mjs`, generador de casos).
