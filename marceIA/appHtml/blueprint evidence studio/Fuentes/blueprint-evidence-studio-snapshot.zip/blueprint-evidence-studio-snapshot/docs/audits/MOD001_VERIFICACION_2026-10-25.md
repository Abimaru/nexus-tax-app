# Verificación de MOD-001 — evidencia disponible (solo lectura)

Reproducible con `node qa/tools/audit-mod001.mjs --out <archivo>`. Lee los JSON originales, ejecuta el motor vigente sin modificarlo y compara lo que el compacto conserva. **No** reclasifica `MODELO`, **no** crea asociaciones y **no** emite dictamen: informa la evidencia que MOD-001 tendría disponible.

## Totales

```json
{
  "pages": 27,
  "evaluablePages": 14,
  "models": 160,
  "preserved": 160,
  "modelsInOneGroupWithMain": 20,
  "modelsAmbiguous": 71,
  "modelsUngrouped": 69,
  "mainsWithBoth": 10,
  "mainsEvaluated": 14,
  "mainsMissing": 4,
  "mainsAmbiguous": 0
}
```

## Por página

| Blueprint · página | Tipo de página | Escenario | Principal | Modelos con ENTRADA/SALIDA (customData) | Preservados | Asociación por grupo | Estado para el principal |
|---|---|---|---|---|---|---|---|
| Oski · Escenarios BDD | BDD_OR_REQUIREMENTS | — | — | ninguno | — | — | NO_APLICA_PAGINA_NO_EVALUABLE |
| Oski · msDebitAccountPayment | MIXED | E1 | wniB5n~8CzU8 | wniBEM0-xoDy (ENTRADA), wniB2Y_RRaIX (SALIDA), wniBDu.eIjlq (SALIDA), wniBroGb.zWm (ENTRADA), wniBsFTVBtyJ (ENTRADA), wniBwITKKSta (ENTRADA), wniBsgxChbL- (ENTRADA), wniBOtAw5jOx (ENTRADA), wniBC2C-A.lW (SALIDA), wniBFo1WD02b (SALIDA), wniBc5RQiP~0 (SALIDA), wniBIZWm2v4j (ENTRADA), wniBpXI~pJ-x (ENTRADA) | sí | GRUPO_SIN_PRINCIPAL, GRUPO_UNICO_CON_PRINCIPAL, SIN_GRUPO | ENTRADA_Y_SALIDA_ASOCIADAS_POR_GRUPO |
| Currency Exchange · Escenarios BDD | BDD_OR_REQUIREMENTS | — | — | ninguno | — | — | NO_APLICA_PAGINA_NO_EVALUABLE |
| Currency Exchange · executeTransactionCurrencyExchange | MIXED | E2 | tQ7mFTFbJ1SW | ebMWBMnh.z-M (ENTRADA), f_m.19rVT_uO (SALIDA), tQ7mv8VyFaR3 (ENTRADA), ebMW3fUNMUoF (SALIDA), tQ7mOxCbJC2l (SALIDA), f_m.wQO-PCoQ (ENTRADA) | sí | SIN_GRUPO, GRUPO_UNICO_CON_PRINCIPAL | ENTRADA_Y_SALIDA_ASOCIADAS_POR_GRUPO |
| Virtual Account Opening · Escenarios BDD | BDD_OR_REQUIREMENTS | — | — | ninguno | — | — | NO_APLICA_PAGINA_NO_EVALUABLE |
| Virtual Account Opening · initiateVirtualAccount | MIXED | E1 | 8S4uZBWnl~74 | 8S4uBGIxaDnu (ENTRADA), v~J2iv-Lf21p (ENTRADA), 8S4u~xPVvU0L (SALIDA), 8S4uySGXXmbz (SALIDA), v~J2-1BVX2aw (ENTRADA), 8S4uK_6k14dS (ENTRADA), v~J2kaQuqlOI (SALIDA), v~J2gn8WXu_a (SALIDA), 8S4uZN~VZbhE (ENTRADA), 8S4uoa1YkxAB (SALIDA), O4ovOKhOP-93 (SALIDA) | sí | GRUPO_UNICO_CON_PRINCIPAL, GRUPO_SIN_PRINCIPAL | ENTRADA_Y_SALIDA_ASOCIADAS_POR_GRUPO |
| Virtual Account Opening · initiateVirtualAccountAlias | MIXED | E1 | Lym7MFM_bghX | Lym73aaSHvWG (SALIDA), crk9zBS.cqKP (ENTRADA), Lym7F.wnzogC (SALIDA), Lym7AdEY2qvj (ENTRADA), Lym7KLx6atAh (ENTRADA) | sí | GRUPO_SIN_PRINCIPAL, GRUPO_UNICO_CON_PRINCIPAL | ENTRADA_Y_SALIDA_ASOCIADAS_POR_GRUPO |
| Virtual Account Opening ·   | TEMPLATE_OR_LEGEND | — | — | 5S7miUMHJ9NX (ENTRADA), 5S7mql1cFvkG (SALIDA), 5S7me1G2F0nw (ENTRADA), 5S7mrnOgteAf (SALIDA), 5S7mNjzx8sqE (SALIDA), 5S7mr0kxoQ6O (ENTRADA) | sí | SIN_GRUPO, GRUPO_SIN_PRINCIPAL | NO_APLICA_PAGINA_NO_EVALUABLE |
| Debit Card · Escenarios BDD | BDD_OR_REQUIREMENTS | — | — | ninguno | — | — | NO_APLICA_PAGINA_NO_EVALUABLE |
| Debit Card · asociatePreIssuedCardMediadoConsulta | MIXED | E2 | Mm89.RmJIaUx | Mm89msbQJceT (ENTRADA), Mm89g0L8mUcZ (SALIDA), Mm89UuK255X1 (ENTRADA), Mm89a8AVttyB (ENTRADA), Mm89f5d6J6vm (SALIDA), Mm89FxI7mbT2 (SALIDA), Mm89dnpC5Uw- (ENTRADA), Mm89C-Y7_JEp (SALIDA), Mm89tPD32uOw (SALIDA), Mm89LqEzIIwl (SALIDA), Mm89kLot-7hA (SALIDA) | sí | GRUPO_SIN_PRINCIPAL, SIN_GRUPO | FALTA_ENTRADA_Y_SALIDA_ASOCIADA |
| Debit Card · createCustomizedCardConsulta | MIXED | — | — | r8RfVSYoRd2v (ENTRADA), UZV9tch4M-rC (ENTRADA), 0.N_R6czBiwK (ENTRADA), Z0V92UhUzDIR (ENTRADA), AAztro5ipfaU (ENTRADA), AAztqblGmFWH (ENTRADA), AAzth3zzjE2s (SALIDA), 0.N_-k0GPbuk (SALIDA), AAzt0tC.jSA0 (SALIDA), AAztA8wtMf73 (SALIDA), c0V9tsFk9Rw3 (SALIDA), u0V9JYB1N2Sx (SALIDA), AAztGJ_NOsi9 (ENTRADA) | sí | SIN_GRUPO, GRUPO_SIN_PRINCIPAL | SIN_PRINCIPAL_RESUELTO |
| Debit Card · createVirtualCard | MIXED | — | — | BbYhvdvGKKuj (ENTRADA), BbYhZSCOuyJ_ (SALIDA), BbYh_bgv8l5T (SALIDA), BbYhPTvL3et7 (ENTRADA), BbYhuLIg7hl7 (ENTRADA), BbYhBLvJsuJq (ENTRADA), BbYh-cI-SQrC (SALIDA), BbYhWeqp-oNF (ENTRADA), BbYh-ODWyFRs (SALIDA), BbYh2n4fFWdi (ENTRADA), BbYhB3Z-JHet (SALIDA), BbYhTKBIJVJX (SALIDA), BbYhFJuVdlfq (ENTRADA) | sí | SIN_GRUPO, GRUPO_SIN_PRINCIPAL | SIN_PRINCIPAL_RESUELTO |
| Debit Card · createVirtualCardConsulta | MIXED | E2 | X389~K7.cPem | X389TIV1l8fu (SALIDA), X389jjKnm71g (SALIDA), X389.WhdQFX6 (SALIDA), X389UkrRWukc (SALIDA), X38939-ruuHp (ENTRADA), X389X50wJb-O (ENTRADA), X389lJYH-K8j (SALIDA), X389-3KcjIf. (SALIDA), X389tXS9iTDZ (ENTRADA), X3891ovV16av (ENTRADA), X389Taz6NJ-l (SALIDA) | sí | GRUPO_SIN_PRINCIPAL, SIN_GRUPO | FALTA_ENTRADA_Y_SALIDA_ASOCIADA |
| Mortgage · Escenarios BDD | BDD_OR_REQUIREMENTS | — | — | ninguno | — | — | NO_APLICA_PAGINA_NO_EVALUABLE |
| Mortgage · initiateMortgageLoanDisbursement | MIXED | E2 | D~c-RbmXqL8a | _NR7xDJsp1Wg (ENTRADA), llV7HenEMDAH (ENTRADA), llV7Xc~rAlLZ (SALIDA), D~c-UNyGfg1K (ENTRADA), _NR7JPfkrRz. (SALIDA), llV7kUlzPw9r (SALIDA), llV7~htYdUvE (SALIDA), D~c-MNURW_gE (SALIDA), llV7A23ubLTa (ENTRADA), llV7Uv-SOpY~ (ENTRADA) | sí | SIN_GRUPO, GRUPO_UNICO_CON_PRINCIPAL | ENTRADA_Y_SALIDA_ASOCIADAS_POR_GRUPO |
| Mortgage ·   | TEMPLATE_OR_LEGEND | — | — | 5S7miUMHJ9NX (ENTRADA), 5S7mql1cFvkG (SALIDA), 5S7me1G2F0nw (ENTRADA), 5S7mrnOgteAf (SALIDA), 5S7mNjzx8sqE (SALIDA), 5S7mr0kxoQ6O (ENTRADA) | sí | SIN_GRUPO, GRUPO_SIN_PRINCIPAL | NO_APLICA_PAGINA_NO_EVALUABLE |
| QR Payment · Escenarios BDD | BDD_OR_REQUIREMENTS | — | — | ninguno | — | — | NO_APLICA_PAGINA_NO_EVALUABLE |
| QR Payment · retrieveTransactionSummary | MIXED | E1 | qhn9N0Pfiowl | qhn936.caJt~ (ENTRADA), qhn90yYprwlQ (SALIDA) | sí | GRUPO_UNICO_CON_PRINCIPAL | ENTRADA_Y_SALIDA_ASOCIADAS_POR_GRUPO |
| QR Payment · retrieveDetailedTransactions | MIXED | E1 | sILy1ssGSKsW | sILyQ3WsDyJm (ENTRADA), sILyeu7eEFnP (SALIDA) | sí | GRUPO_UNICO_CON_PRINCIPAL | ENTRADA_Y_SALIDA_ASOCIADAS_POR_GRUPO |
| QR Payment · retrieveBasicTransactions | MIXED | E1 | vILyH3suBHac | vILyY_vgdFPC (ENTRADA), vILyrGe.tqUN (SALIDA) | sí | GRUPO_UNICO_CON_PRINCIPAL | ENTRADA_Y_SALIDA_ASOCIADAS_POR_GRUPO |
| QR Payment ·   | TEMPLATE_OR_LEGEND | — | — | 5S7miUMHJ9NX (ENTRADA), 5S7mql1cFvkG (SALIDA), 5S7me1G2F0nw (ENTRADA), 5S7mrnOgteAf (SALIDA), 5S7mNjzx8sqE (SALIDA), 5S7mr0kxoQ6O (ENTRADA) | sí | SIN_GRUPO, GRUPO_SIN_PRINCIPAL | NO_APLICA_PAGINA_NO_EVALUABLE |
| Escenario2 (nombreOperacion) · Escenarios BDD | BDD_OR_REQUIREMENTS | — | — | ninguno | — | — | NO_APLICA_PAGINA_NO_EVALUABLE |
| Escenario2 (nombreOperacion) · nombreOperacion1 | MIXED | E2 | 3gn9iRxfHfin | vZ6dFZA2eecS (SALIDA), vZ6dy.fTUzsf (ENTRADA), GNve9c4Dvwoi (ENTRADA), 7hweT1ddY70T (ENTRADA), Hjz.Yo.uCOYv (SALIDA), 7hweOBYuLv1a (SALIDA), zZ6dVByYctlG (SALIDA), dR7m8~SY~IBH (SALIDA), Hjz.NRbRR_Fo (ENTRADA), 3gn9I_IwRDfz (SALIDA), GNveBNyQ~NJF (SALIDA), 3gn9~ESdjd3y (ENTRADA), zZ6dEP508~LZ (ENTRADA), dR7msMztZRb6 (ENTRADA) | sí | GRUPO_SIN_PRINCIPAL, SIN_GRUPO, GRUPO_UNICO_CON_PRINCIPAL | ENTRADA_Y_SALIDA_ASOCIADAS_POR_GRUPO |
| Escenario2 (nombreOperacion) · nombreOperacion2 | MIXED | E1 | qhn9N0Pfiowl | vBtVM9s.t25J (ENTRADA), b8xDDKouHi8z (SALIDA), b8xDW2wjwci6 (ENTRADA), qhn936.caJt~ (ENTRADA), b8xD1LChokyY (SALIDA), _AtVFMaoL0dW (SALIDA), qhn90yYprwlQ (SALIDA), _AtVDStAH6Sr (ENTRADA), b8xDm9~zb6gG (ENTRADA) | sí | GRUPO_SIN_PRINCIPAL, SIN_GRUPO, GRUPO_UNICO_CON_PRINCIPAL | ENTRADA_Y_SALIDA_ASOCIADAS_POR_GRUPO |
| Escenario2 (nombreOperacion) · nombreOperacion3 | TEMPLATE_OR_LEGEND | — | — | Mt5DT9s~fio7 (ENTRADA), j8udg4CgcZpF (SALIDA), j8udeuMNWYLM (SALIDA), SZ6dxHMslYL6 (ENTRADA), j8udMb7Gh3yP (SALIDA), Mt5DqBLeT_zK (SALIDA), j8udx-4bpfsM (ENTRADA), j8udCnxzHcIp (ENTRADA), SZ6d02gTmHHQ (SALIDA), j8udswWOuTBe (ENTRADA) | sí | SIN_GRUPO, GRUPO_SIN_PRINCIPAL | NO_APLICA_PAGINA_NO_EVALUABLE |
| Escenario2 (nombreOperacion) ·   | TEMPLATE_OR_LEGEND | — | — | 5S7miUMHJ9NX (ENTRADA), 5S7mql1cFvkG (SALIDA), 5S7me1G2F0nw (ENTRADA), 5S7mrnOgteAf (SALIDA), 5S7mNjzx8sqE (SALIDA), 5S7mr0kxoQ6O (ENTRADA) | sí | SIN_GRUPO, GRUPO_SIN_PRINCIPAL | NO_APLICA_PAGINA_NO_EVALUABLE |
| Escenario2 (nombreOperacion) · Page 6 | TEMPLATE_OR_LEGEND | — | — | L.JFDJGPJJ~B (SALIDA), L.JFzuwkXzcU (ENTRADA), Z.JFbjxZB6gG (ENTRADA), Z.JFG01NP0U8 (SALIDA) | sí | SIN_GRUPO, GRUPO_SIN_PRINCIPAL | NO_APLICA_PAGINA_NO_EVALUABLE |

## Figuras con el texto «Modelo de …» (etiquetas, no datos)

| Blueprint · página | ID | Clase | Texto | `architecturalType` en el compacto |
|---|---|---|---|---|
| Oski · msDebitAccountPayment | woiBJBn2yUAj | DefaultSquareBlock | Modelo de Salida | MODELO |
| Oski · msDebitAccountPayment | woiBrdf7Ctj_ | DefaultSquareBlock | Modelo de Lectura | MODELO |
| Currency Exchange · executeTransactionCurrencyExchange | fH6NmAQKCsb2 | DefaultSquareBlock | Modelo de Salida | MODELO |
| Currency Exchange · executeTransactionCurrencyExchange | fH6NDcN7ySjk | DefaultSquareBlock | Modelo de Lectura | MODELO |
| Virtual Account Opening · initiateVirtualAccount | 8S4uzeYlitMg | DefaultSquareBlock | Modelo de Salida | MODELO |
| Virtual Account Opening · initiateVirtualAccount | 8S4u7Jd4sg4e | DefaultSquareBlock | Modelo de Lectura | MODELO |
| Virtual Account Opening · initiateVirtualAccountAlias | Lym7AiwLDww7 | DefaultSquareBlock | Modelo de Salida | MODELO |
| Virtual Account Opening · initiateVirtualAccountAlias | Lym7Mbxave9R | DefaultSquareBlock | Modelo de Lectura | MODELO |
| Virtual Account Opening ·   | 5S7miUMHJ9NX | BPMNActivity | Modelo de Lectura | MODELO |
| Virtual Account Opening ·   | 5S7m~o12UNz3 | DefaultSquareBlock | Modelo de Salida | MODELO |
| Virtual Account Opening ·   | 5S7mrnOgteAf | BPMNActivity | Modelo de Salida | MODELO |
| Virtual Account Opening ·   | 5S7mJPaQb2Tj | DefaultSquareBlock | Modelo de Lectura | MODELO |
| Virtual Account Opening ·   | 5S7mNjzx8sqE | BPMNActivity | Modelo de Salida | MODELO |
| Virtual Account Opening ·   | 5S7mr0kxoQ6O | BPMNActivity | Modelo de Lectura | MODELO |
| Debit Card · asociatePreIssuedCardMediadoConsulta | Mm89r5~YZ7M3 | DefaultSquareBlock | Modelo de Salida | MODELO |
| Debit Card · asociatePreIssuedCardMediadoConsulta | Mm898PpPKUdx | DefaultSquareBlock | Modelo de Lectura | MODELO |
| Debit Card · createCustomizedCardConsulta | AAztPfW9Ne3J | DefaultSquareBlock | Modelo de Salida | MODELO |
| Debit Card · createCustomizedCardConsulta | AAztS_d4NKDI | DefaultSquareBlock | Modelo de Lectura | MODELO |
| Debit Card · createVirtualCard | BbYhUxIyoI5R | DefaultSquareBlock | Modelo de Lectura | MODELO |
| Debit Card · createVirtualCard | BbYhvr3n.K5u | DefaultSquareBlock | Modelo de Salida | MODELO |
| Debit Card · createVirtualCardConsulta | X389KGwrHzh6 | DefaultSquareBlock | Modelo de Lectura | MODELO |
| Debit Card · createVirtualCardConsulta | X389yQxkw21C | DefaultSquareBlock | Modelo de Salida | MODELO |
| Mortgage · initiateMortgageLoanDisbursement | fH6NmAQKCsb2 | DefaultSquareBlock | Modelo de Salida | MODELO |
| Mortgage · initiateMortgageLoanDisbursement | fH6NDcN7ySjk | DefaultSquareBlock | Modelo de Lectura | MODELO |
| Mortgage ·   | 5S7miUMHJ9NX | BPMNActivity | Modelo de Lectura | MODELO |
| Mortgage ·   | 5S7m~o12UNz3 | DefaultSquareBlock | Modelo de Salida | MODELO |
| Mortgage ·   | 5S7mrnOgteAf | BPMNActivity | Modelo de Salida | MODELO |
| Mortgage ·   | 5S7mJPaQb2Tj | DefaultSquareBlock | Modelo de Lectura | MODELO |
| Mortgage ·   | 5S7mNjzx8sqE | BPMNActivity | Modelo de Salida | MODELO |
| Mortgage ·   | 5S7mr0kxoQ6O | BPMNActivity | Modelo de Lectura | MODELO |
| QR Payment · retrieveTransactionSummary | b8xDeYI6.scr | DefaultSquareBlock | Modelo de Lectura | MODELO |
| QR Payment · retrieveTransactionSummary | b8xDQ92Dh7f~ | DefaultSquareBlock | Modelo de Salida | MODELO |
| QR Payment · retrieveDetailedTransactions | sILyXFd.q~0O | DefaultSquareBlock | Modelo de Lectura | MODELO |
| QR Payment · retrieveDetailedTransactions | sILy70v6E.f0 | DefaultSquareBlock | Modelo de Salida | MODELO |
| QR Payment · retrieveBasicTransactions | vILy221yVSz~ | DefaultSquareBlock | Modelo de Salida | MODELO |
| QR Payment · retrieveBasicTransactions | vILyNTUiBVKX | DefaultSquareBlock | Modelo de Lectura | MODELO |
| QR Payment ·   | 5S7miUMHJ9NX | BPMNActivity | Modelo de Lectura | MODELO |
| QR Payment ·   | 5S7m~o12UNz3 | DefaultSquareBlock | Modelo de Salida | MODELO |
| QR Payment ·   | 5S7mrnOgteAf | BPMNActivity | Modelo de Salida | MODELO |
| QR Payment ·   | 5S7mJPaQb2Tj | DefaultSquareBlock | Modelo de Lectura | MODELO |
| QR Payment ·   | 5S7mNjzx8sqE | BPMNActivity | Modelo de Salida | MODELO |
| QR Payment ·   | 5S7mr0kxoQ6O | BPMNActivity | Modelo de Lectura | MODELO |
| Escenario2 (nombreOperacion) · nombreOperacion1 | GNve9c4Dvwoi | BPMNActivity | Modelo de Lectura | MODELO |
| Escenario2 (nombreOperacion) · nombreOperacion1 | 7hweT1ddY70T | BPMNActivity | Modelo de Lectura | MODELO |
| Escenario2 (nombreOperacion) · nombreOperacion1 | Hjz.Yo.uCOYv | BPMNActivity | Modelo de Salida | MODELO |
| Escenario2 (nombreOperacion) · nombreOperacion1 | fH6NmAQKCsb2 | DefaultSquareBlock | Modelo de Salida | MODELO |
| Escenario2 (nombreOperacion) · nombreOperacion1 | 7hweOBYuLv1a | BPMNActivity | Modelo de Salida | MODELO |
| Escenario2 (nombreOperacion) · nombreOperacion1 | fH6NDcN7ySjk | DefaultSquareBlock | Modelo de Lectura | MODELO |
| Escenario2 (nombreOperacion) · nombreOperacion1 | zZ6dVByYctlG | BPMNActivity | Modelo de Salida | MODELO |
| Escenario2 (nombreOperacion) · nombreOperacion1 | dR7m8~SY~IBH | BPMNActivity | Modelo de Salida | MODELO |
| Escenario2 (nombreOperacion) · nombreOperacion1 | Hjz.NRbRR_Fo | BPMNActivity | Modelo de Lectura | MODELO |
| Escenario2 (nombreOperacion) · nombreOperacion1 | GNveBNyQ~NJF | BPMNActivity | Modelo de Salida | MODELO |
| Escenario2 (nombreOperacion) · nombreOperacion1 | zZ6dEP508~LZ | BPMNActivity | Modelo de Lectura | MODELO |
| Escenario2 (nombreOperacion) · nombreOperacion1 | dR7msMztZRb6 | BPMNActivity | Modelo de Lectura | MODELO |
| Escenario2 (nombreOperacion) · nombreOperacion2 | b8xDeYI6.scr | DefaultSquareBlock | Modelo de Lectura | MODELO |
| Escenario2 (nombreOperacion) · nombreOperacion2 | b8xDQ92Dh7f~ | DefaultSquareBlock | Modelo de Salida | MODELO |
| Escenario2 (nombreOperacion) · nombreOperacion2 | b8xDDKouHi8z | BPMNActivity | Modelo de Salida | MODELO |
| Escenario2 (nombreOperacion) · nombreOperacion2 | b8xDW2wjwci6 | BPMNActivity | Modelo de Lectura | MODELO |
| Escenario2 (nombreOperacion) · nombreOperacion2 | b8xD1LChokyY | BPMNActivity | Modelo de Salida | MODELO |
| Escenario2 (nombreOperacion) · nombreOperacion2 | b8xDm9~zb6gG | BPMNActivity | Modelo de Lectura | MODELO |
| Escenario2 (nombreOperacion) · nombreOperacion3 | Mt5DT9s~fio7 | BPMNActivity | Modelo de Lectura | MODELO |
| Escenario2 (nombreOperacion) · nombreOperacion3 | M.mf_MbfZpVJ | DefaultSquareBlock | Modelo de Lectura | MODELO |
| Escenario2 (nombreOperacion) · nombreOperacion3 | j8udeuMNWYLM | BPMNActivity | Modelo de Salida | MODELO |
| Escenario2 (nombreOperacion) · nombreOperacion3 | SZ6dxHMslYL6 | BPMNActivity | Modelo de Lectura | MODELO |
| Escenario2 (nombreOperacion) · nombreOperacion3 | j8udMb7Gh3yP | BPMNActivity | Modelo de Salida | MODELO |
| Escenario2 (nombreOperacion) · nombreOperacion3 | M.mf2EtAKqNG | DefaultSquareBlock | Modelo de Salida | MODELO |
| Escenario2 (nombreOperacion) · nombreOperacion3 | Mt5DqBLeT_zK | BPMNActivity | Modelo de Salida | MODELO |
| Escenario2 (nombreOperacion) · nombreOperacion3 | j8udx-4bpfsM | BPMNActivity | Modelo de Lectura | MODELO |
| Escenario2 (nombreOperacion) · nombreOperacion3 | SZ6d02gTmHHQ | BPMNActivity | Modelo de Salida | MODELO |
| Escenario2 (nombreOperacion) · nombreOperacion3 | j8udswWOuTBe | BPMNActivity | Modelo de Lectura | MODELO |
| Escenario2 (nombreOperacion) ·   | 5S7miUMHJ9NX | BPMNActivity | Modelo de Lectura | MODELO |
| Escenario2 (nombreOperacion) ·   | 5S7m~o12UNz3 | DefaultSquareBlock | Modelo de Salida | MODELO |
| Escenario2 (nombreOperacion) ·   | 5S7mrnOgteAf | BPMNActivity | Modelo de Salida | MODELO |
| Escenario2 (nombreOperacion) ·   | 5S7mJPaQb2Tj | DefaultSquareBlock | Modelo de Lectura | MODELO |
| Escenario2 (nombreOperacion) ·   | 5S7mNjzx8sqE | BPMNActivity | Modelo de Salida | MODELO |
| Escenario2 (nombreOperacion) ·   | 5S7mr0kxoQ6O | BPMNActivity | Modelo de Lectura | MODELO |
| Escenario2 (nombreOperacion) · Page 6 | L.JFDJGPJJ~B | BPMNActivity | Modelo de Salida | MODELO |
| Escenario2 (nombreOperacion) · Page 6 | L.JFzuwkXzcU | BPMNActivity | Modelo de Lectura | MODELO |
