# Matriz de reconciliación 41 → 37 reglas — 26/10/2026

Solo lectura. Columnas completas en el CSV homónimo. Clases de evidencia: **A** directa · **B** derivable · **C** ambigua · **D** ausente del contrato · **E** imposible de certificar con los datos originales · **F** declaración de la analista. Grupos: OBLIG (cambio normativo obligatorio) · OPER (mejora operativa) · TEC (cambio técnico) · PEND (decisión pendiente). Prioridad: P0 bloquea cualquier implementación · P1 necesaria para evaluar correctamente · P2 mejora · P3 posterior.

| ID nuevo | ID anterior | Cambio | Evidencia | Decisión humana | Prior. | Grupo | Obligación funcional (nueva) |
|---|---|---|---|---|---|---|---|
| CNT-001 | CNT-001 | Cambio real de obligación | B/C | Q6 persiste | P1 | OBLIG | Existencia de los dominios obligatorios del patrón E1/E2/E3 (INTEGRACIÓN y/o DOMINIO PRODUCTOR), con cualquier nombre si la clasificación está certificada. |
| CNT-002 | CNT-002 | Cambio real de obligación | B/C | Ninguna | P1 | OBLIG | Existe un único hijo principal, con nombre visible específico, ubicado en el dominio que exige E1/E3 (productor) o E2 (INTEGRACIÓN). No exige Inicio ni evalúa el contenido del hijo. |
| CNT-003 | CNT-003 | Cambio real de obligación | C/D | D4 | P1 | OBLIG | Listas cerradas de contenido permitido/prohibido en INTEGRACIÓN en dos niveles (padre e hijo principal); el contenido de auxiliares se evalúa en EXT-001. |
| CNT-004 | CNT-004 | Cambio real de obligación | C/D | D4 | P1 | OBLIG | Igual que CNT-003 para el DOMINIO PRODUCTOR (API y auxiliares prohibidos a nivel padre). |
| CNT-005 | CNT-005 | Cambio real de obligación | C/D | D4 | P1 | OBLIG | Contenido permitido directamente en SISTEMAS EXTERNOS (sin eventos de integración, gestores, capas ni elementos BPMN operativos). |
| EXT-001 | EXT-001 | Cambio real de obligación | B/C | D9 | P2 | OBLIG | Todo auxiliar tiene nombre no vacío y encapsula solo API, servicios, pendientes, conceptos, anotaciones (y capas MCI/Federado si está en el nivel padre de INTEGRACIÓN). Gestores y eventos de |
| EXT-002 | — (nueva en nuestro catálogo) | Regla nueva | B | D11 | P2 | OBLIG | Un auxiliar con EVC/EPC/LDC en el nombre que encapsula una API debe estar en el nivel padre de INTEGRACIÓN. |
| GW-001 | GW-001 | Cambio real de obligación | A | Ninguna | P2 | OBLIG | Coherencia entre el texto de la compuerta y las etiquetas de sus caminos; sin texto ni etiquetas también cumple. |
| API-001 | API-001 | Cambio real de obligación | B/C | D13 | P1 | OBLIG | Nombre de API: formato corporativo completo en INTEGRACIÓN; solo nombre funcional/específico en SISTEMAS EXTERNOS. |
| API-002 | API-002 | Cambio real de obligación | B/C | D13 | P1 | OBLIG | Operación en camelCase e inglés (INTEGRACIÓN) o funcional específica (SISTEMAS EXTERNOS). |
| API-003 | API-003 | Cambio real de obligación | B/C | Ninguna | P1 | OBLIG | Tercera sección `tipo - modelo` en minúsculas (private/public/partner y entidad/utilidad/tarea) en INTEGRACIÓN; información funcional en SISTEMAS EXTERNOS. La exposición declarada por la ana |
| API-004 | API-004 | Cambio real de obligación | B/F | Ninguna | P1 | OBLIG | API principal declarada MCI: private→Capa de Arquitectura+Flujo; partner→Capa; public→nada; no MCI→nada. Invocadas excluidas. |
| SRV-001 | SRV-001 | Sin cambio textual | C | D1 | P0 | PEND | Sin cambio textual; el analista lo declara pendiente. |
| SRV-002 | SRV-002 | Sin cambio textual | C | D1 | P0 | PEND | Sin cambio textual; pendiente. |
| SRV-003 | SRV-003 | Cambio real de obligación | E | D4 | P1 | OBLIG | Modelo `entidad|utilidad|tarea` solo para servicios invocados certificados; el hijo principal queda excluido expresamente. |
| SRV-004 | — (nueva) | Regla nueva | B/F | Ninguna | P1 | OBLIG | En E1/E2 el hijo principal declarado MCI debe tener Capa de Arquitectura y Flujo Transaccional asociados; E3 no se evalúa. |
| EVT-001 | EVT-001 | Cambio real de obligación | D | D4 | P1 | OBLIG | Nombre del evento de integración `Producto - Capacidad_vX.Y.Z` con caracteres e idioma controlados. |
| EVT-002 | EVT-002 | Cambio real de obligación | D | D4 | P1 | OBLIG | Operación camelCase en inglés, funcional y específica. |
| EVT-003 | EVT-003 | Cambio real de obligación | D | D4 | P1 | OBLIG | Tercera sección `Tipo - Clasificacion` exacta; ya no se acepta la equivalencia de tilde. |
| EVT-004 | EVT-005 | Renumerada y modificada | D | D4 | P1 | OBLIG | Cada evento de integración tiene exactamente una Capa de Tópicos asociada. |
| EVT-005 | EVT-006 | Renumerada y modificada | D | D4 | P1 | OBLIG | Cantidad y roles p/s de tópicos según Query/Command/Event; capa no vacía. |
| EVT-006 | EVT-007 | Renumerada y modificada | C/D | D4 | P1 | OBLIG | Nombre de cada tópico `p|s.producto.capacidad[.codigo].vX` en minúsculas, sin ceros iniciales. |
| EVT-007 | EVT-008 | Renumerada y modificada | E/F | D3 | P1 | OBLIG | Conexiones del evento: p ← Señal de Envío, s → Señal de Recepción, terminaciones CircleOpen/Generalization; extremos alternativos (capa de tópicos o de despliegue). |
| CA-001 | CA-001 | Cambio real de obligación | A/B | Ninguna | P1 | OBLIG | Solo el nombre `Capa de Arquitectura - tipo` de las capas existentes; la obligatoriedad pasa a API-004/SRV-004/MQ-002. |
| FT-001 | FT-001 | Cambio real de obligación | A/B | Ninguna | P1 | OBLIG | Solo el nombre `Flujo Transaccional - tipo` de los flujos existentes (`no-monetario` es un valor). |
| E1-001 | E1-001 | Cambio real de obligación | B/E | D6 | P1 | OBLIG | API principal en INTEGRACIÓN, hijo principal en DOMINIO PRODUCTOR, Inicio certificado en el hijo y conexión None→Arrow desde la API. |
| E2-001 | E2-001 | Cambio real de obligación | B/E | D6 | P1 | OBLIG | API e hijo principal separados en INTEGRACIÓN, Inicio certificado, conexión None→Arrow. |
| E3-001 | E3-001 | Cambio real de obligación | B/E | D6 | P1 | OBLIG | Componente principal e hijo principal en el mismo DOMINIO PRODUCTOR, separados, Inicio certificado, conexión None→Arrow. |
| MOD-001 | MOD-001 | Cambio real de obligación | A/C/D | D5 | P1 | PEND | Entrada y salida asociadas inequívocamente a la API principal (E1/E2), al componente principal (E3) y a eventos de integración en INTEGRACIÓN según roles p/s; el hijo y los invocados no tien |
| COM-001 | COM-001 | Refinamiento (misma obligación, más precisa) | B/C | Ninguna | P2 | OBLIG | Nombre de comando en español: infinitivo + complemento; candidato por relación con API, servicio, gestor o auxiliar. |
| COM-002 | COM-002 | Refinamiento (misma obligación, más precisa) | B/E | D4 | P2 | OBLIG | Dos conexiones comando↔API invocada con CircleOpen en origen y Generalization en destino; APIs encapsuladas incluidas. |
| COM-003 | COM-003 | Refinamiento (misma obligación, más precisa) | B/E | D4 | P2 | OBLIG | Igual con servicio invocado. |
| COM-004 | COM-004 | Refinamiento (misma obligación, más precisa) | A/B | Ninguna | P2 | OBLIG | Igual con gestor de colas. |
| COM-005 | — (nueva) | Regla nueva | B/C | Ninguna | P2 | OBLIG | Comando conectado a un auxiliar sin atribución inequívoca a una API/servicio encapsulado. |
| MQ-001 | MQ-001 | Cambio real de obligación | A | Ninguna | P1 | OBLIG | Toda figura UMLActiveClassBlock es un gestor de colas y requiere nombre específico. Convierte en regla la convención técnica. |
| MQ-002 | MQ-003 + MQ-004 | Renumerada y modificada | B/D | D4 | P1 | OBLIG | Gestor en INTEGRACIÓN con Capa de Despliegue MCI (Capa+Flujo) o Federada (valor exacto `Federado`). |
| MQ-003 | MQ-005 | Renumerada y modificada | B/E | D3 | P2 | OBLIG | Conexiones gestor-gestor (bidireccional), servicio→gestor (uni o bidireccional) y evento Mensaje→gestor. |
| — (CNT-006 retirada) | CNT-006 | Eliminada | — | Ninguna | P1 | OBLIG | Eliminada: su contenido pasa a controles previos de integridad del JSON (IDs únicos, referencias, ciclos, padre/cadena coherentes). Cierra Q7. |
| — (EXT-002 retirada) | EXT-002 | Eliminada | — | Ninguna | P1 | OBLIG | La antigua EXT-002 (conexiones con auxiliar) se elimina; sus conexiones pasan a COM-002..005 y MQ-003. El ID EXT-002 se reutiliza para otra obligación. |
| — (EVT-004 retirada) | EVT-004 | Eliminada | — | Ninguna | P1 | OBLIG | La antigua EVT-004 (despliegue del evento) se elimina; el ID EVT-004 se reutiliza (Capa de Tópicos). |
| — (CA-002 retirada) | CA-002 | Eliminada | — | Ninguna | P1 | OBLIG | Eliminada: la asociación se evalúa en API-004, SRV-004 o MQ-002. |
| — (FT-002 retirada) | FT-002 | Eliminada | — | Ninguna | P1 | OBLIG | Eliminada: ídem. |
| — (MQ-002 retirada) | MQ-002 | Eliminada | — | Ninguna | P1 | OBLIG | La antigua MQ-002 (ubicación del gestor) se elimina; absorbida por CNT-003/004/005 y EXT-001. El ID MQ-002 se reutiliza (Capa de Despliegue). |

Totales: cambio real 22 · refinamiento 4 · nuevas 3 · renumeradas y modificadas 6 · sin cambio textual 2 · eliminadas 6 (nuevas 37 + eliminadas 6).
