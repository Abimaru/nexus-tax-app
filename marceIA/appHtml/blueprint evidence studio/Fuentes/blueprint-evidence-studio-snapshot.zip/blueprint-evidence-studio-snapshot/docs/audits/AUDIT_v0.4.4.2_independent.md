# Auditoría independiente — Evidence Studio v0.4.4.2 con Virtual Account Opening

Fecha: 2026-10-22. Rama: `feature/evidence-studio-v0.4.4.2-private`, HEAD `d1ca5f8`. Auditoría de solo lectura: sin modificar código ni publicar información corporativa. El único cambio sin seguimiento en el repositorio es el directorio `Blueprints_ejemplos/Virtual Account Opening/`, que ya existía.

## Veredicto: APTO CON RESERVAS para pruebas formales de la analista

La estructura de Virtual Account Opening se reconstruyó desde el JSON original y coincide en las dos operaciones. Las reservas son tres:
- El motor llama "candidato" a un icono de API y deja las parejas Flujo/Capa sin propietario.
- Una operación real con un marcador sin rellenar puede degradarse a plantilla.
- El E1 se confirma apoyándose en una inferencia.

## 1. Verificación del motor

- El HTML usa el núcleo esperado: reconstruido con esbuild desde `ui/` y `src/`, sale idéntico byte a byte a `dist/BlueprintEvidenceStudio.html`. Los hashes del HTML y del ZIP de la Skill coinciden con `REGRESSION_v0.4.4.2.md`.
- Sin URLs remotas en el HTML.
- La descarga de la UI es igual a la salida del motor (`contract: copilot-factual-v0.4.4.2`, `version: 0.4.4.2`), cargando el JSON y el SVG en la UI.
- Preservación sin diferencias: figuras, líneas, grupos, capas, conexiones (extremos y etiquetas) y textos de las 4 páginas son idénticos al original. Las 6 líneas con extremo nulo de la operación Alias se conservan como `PARTIAL`. Un padre directo por figura; sin dictámenes (`normativeEvaluation:null`).
- Pruebas: `npm test` 36/36 y `test:e2e` 3/3.

## 2 y 3. Jerarquías, dominios y E1 estructural

Reconstrucción independiente sobre el original (raíz estructural = contenedor sin padre; dominio efectivo = contenedor arquitectónico más cercano):

| Elemento | Operación 1 | Operación 2 |
|---|---|---|
| API (`UMLClassBlock`, 3.ª sección "Entidad") | `8S4uZBWnl~74`: padre INTEGRACIÓN `8S4uWKNx7SdQ`, sin más ancestros | `Lym7MFM_bghX`: padre INTEGRACIÓN `Lym7Uf1c-xWD`, sin más ancestros |
| Evento (`BPMNEvent` sin texto) | `8S4uk3eGI_Px`: padre hijo `8S4u74NmLpa2`, cadena CORE GLOBAL ACCOUNT `8S4uExzgId93` > hijo | `Lym7Osm1iZ_m`: padre hijo `Lym7WQZ~U4V3`, cadena CORE GLOBAL ACCOUNT `Lym7ntV6NQR5` > hijo |
| Hijo (`RectangleContainerBlock`) | `user_ms`, padre CORE GLOBAL ACCOUNT | `user_ms (PENDIENTE)`, padre CORE GLOBAL ACCOUNT |

- INTEGRACIÓN es INTEGRATION por nombre exacto declarado. CORE GLOBAL ACCOUNT es PRODUCER solo por `CORPORATE_PARENT_DOMAIN_CONVENTION`; ninguna figura ni `customData` lo declara productor.
- Conexión: `8S4u2s~XnOuy` / `Lym73fLTpRP5`, de la API (terminación `None`) al evento (terminación `Arrow`).
- **E1 estructural independiente:** API en INTEGRACIÓN, conexión orientada al evento, evento dentro del hijo, hijo bajo un dominio productor distinto. Coincide con el motor (`E1`, `STRUCTURALLY_CONFIRMED`, `mainApi`) en ambas operaciones. La etiqueta "confirmado" descansa en la convención (`inferenceUsed:true`): debe leerse como "E1 con productor inferido".
- `PENDIENTE`: `mainChildServiceName` conserva `"user_ms (PENDIENTE)"` literal; no hay campo de validez ni estado del nombre.
- Página, API, operación e hijo quedan como valores distintos (`initiateVirtualAccount` / "Virtual Account Opening - Virtual Account v2.1.0" / `initiateVirtualAccount` / `user_ms`).

## 4. Capas MCI

- **Declarada (JSON):** las API tienen como único padre INTEGRACIÓN. Ni el Flujo ni la Capa de esa operación las contienen. La Capa contiene solo un `BPMNEvent` sin texto, sin conexiones y sin grupo (`8S4uq7oryhaH`, `Lym77XxCIuCA`).
- **Geométrica (SVG):** el SVG solo trae trazados, sin textos ni IDs de figura (solo `lucid:page-tab-id`). Renderizado y leído visualmente (la operación 2 con el SVG de la carpeta anterior), en ambas la caja de la API aparece dentro de la "Capa de Arquitectura - Composición", dentro del "Flujo Transaccional - No Monetario", dentro de INTEGRACIÓN.
- **Icono de API:** el icono verde con triángulo en la esquina de la API es el mismo de la leyenda "API"; es muy probable que sea el `BPMNEvent` sin texto de la pareja.
- **Hipótesis (no demostrada):** el grupo de la API (API + modelos ENTRADA/SALIDA) está declarado en INTEGRACIÓN y no en el Flujo, y los modelos quedan fuera de la Capa; es consistente con que Lucid evalúa la contención por grupo.

| Nivel | Estado |
|---|---|
| Pertenencia declarada | INTEGRACIÓN solamente |
| Contención geométrica verificable | Observada visualmente; no demostrable por ID desde el SVG |
| Asociación visual probable | API ↔ Flujo/Capa, apoyada por el icono |
| Propiedad arquitectónica certificada | Ninguna; `resolvedOwnerId` es `null` en todas las parejas |

El motor no atribuye capas ni declara incumplimiento. En la operación 1 existe además la pareja vacía `Mp62…`.

## 5. Clasificación de páginas

| Página | `pageClassification` | Escenario |
|---|---|---|
| Escenarios BDD | `UNRESOLVED` | `null` |
| initiateVirtualAccount | `MIXED` (50 figuras de leyenda) | E1 |
| initiateVirtualAccountAlias | `MIXED` | E1 |
| Sin nombre (`" "`) | `TEMPLATE_OR_LEGEND` | `null` (`PAGE_TEMPLATE_OR_LEGEND`) |

Ninguna plantilla genera E1 falso, tampoco las de las otras fuentes.

## 6. Skill v11.1.1

- Las 41 reglas están intactas: mismos IDs, archivos de reglas `01` a `07` sin cambios; el único cambio en el CSV es la reparación de comillas de CNT-002 con el mismo contenido. El ZIP coincide archivo a archivo con `skills/`.
- F-13 no se resolvió: la Skill sigue marcando las reglas afectadas como No verificable.
- Productor personalizado, raíz frente a dominio y escenario frente a cumplimiento están incorporados (`SKILL.md`, `00-procedimiento.md`, `INSTRUCCIONES-AGENTE-V11.md`); `STRUCTURALLY_CONFIRMED` nunca es `Cumple` y se pide citar la convención cuando `inferenceUsed:true`.
- **Brecha:** la Skill no distingue nombre de página, operación de la API y nombre del servicio hijo (sin mención de `pageName`, `mainComponentOperation` ni `mainChildServiceName`).

## 7. Regresiones

- Oski y Currency Exchange no empeoran: `structuralScenario`, padre inmediato y cadena de las 126 y 99 figuras, y roles de dominio, son idénticos a v0.4.4.1.
- Cambios intencionales frente a v0.4.4.1: Debit p2/p3 pasan de E1 `SUPPORTED` a `null`; las plantillas ya no dan E1 confirmado; una variante como "INTEGRACIÓN - MCI" deja el rol sin resolver; un envolvente sobre INTEGRACIÓN conserva E2.
- Varias páginas con los mismos IDs en un único JSON: E2 y E1 por página sin contaminarse. Principal dentro del hijo: escenario `null`.
- Siguen confirmando: dos cajas INTEGRACIÓN con la API en una y el evento en otra (E2); un único envolvente productor sin INTEGRACIÓN (E3); una API con "Private" en dominio productor (`mainService`, sin contradicción marcada).

## 8. Defectos y limitaciones reproducibles

| ID | Sev. | Hallazgo | Evidencia |
|---|---|---|---|
| V-1 | Media | Un icono de API (BPMNEvent sin texto) sale como único candidato de la pareja | Ambas operaciones; `relatedCandidates` del par |
| V-2 | Media | Una operación real con un marcador sin rellenar pasa a `TEMPLATE_OR_LEGEND` y pierde el escenario | Probado con `nombreFuncionalMetodo` y `Nombre API` como operación; `src/page-classifier.js` |
| V-3 | Media | `STRUCTURALLY_CONFIRMED` con productor inferido se lee como confirmado | `inferenceUsed:true` en ambas operaciones |
| V-4 | Baja | Dos cajas INTEGRACIÓN y un envolvente productor sin INTEGRACIÓN dan escenario confirmado | Contraejemplos sintéticos |
| V-5 | Baja | La contradicción solo se marca contra `ms-`, no contra el token de exposición | "Private" en dominio productor → `mainService` |
| V-6 | Baja | La página BDD es `UNRESOLVED`, no un tipo no operacional propio | Página 0 |
| V-7 | Baja | Un contenedor vacío con nombre libre sale como dominio PRODUCER | Contraejemplo con "Basura" |

Limitaciones: E3 solo tiene un fixture sintético; el SVG no permite certificar contención por ID.

## 9. Incorporación a la regresión

Agregar Virtual Account Opening con estas expectativas: dos páginas operativas E1 con los IDs de este informe, página BDD sin escenario, página sin nombre como plantilla, parejas Flujo/Capa con `resolvedOwnerId:null` y `user_ms (PENDIENTE)` sin cambios. El JSON es idéntico al que ya existe en `Currency Exchange Transaction Pricing/`; solo cambia el SVG de la operación 1 (misma página), así que basta una de las dos copias.

## Cambios recomendados

**Obligatorios antes de pruebas formales**
1. Avisar a la analista de V-1 y V-3, o corregirlos en el motor.
2. Añadir a la Skill la distinción entre página, operación de la API y servicio hijo.

**Opcionales**
3. V-2, V-4, V-5, V-6 y V-7.
