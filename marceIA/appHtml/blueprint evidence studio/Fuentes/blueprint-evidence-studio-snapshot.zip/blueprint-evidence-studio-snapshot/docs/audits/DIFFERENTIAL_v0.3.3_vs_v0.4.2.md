# Auditoría diferencial v0.3.3, v0.4.1 y v0.4.2

Fecha: 2026-10-21. La comparación v0.3.3/v0.4.1 es estática sobre sus HTML y reproducible sobre sus exportadores inline. La salida v0.4.2 entregada fue reproducida por la auditoría independiente. No existen artefactos intermedios v0.3.4–v0.4.0.

## Conclusión

v0.3.3 facilitaba la lectura porque entregaba juntos un árbol compacto, rutas con nombres, conexiones resumidas, inventario y matriz de hallazgos. Su JSON estaba más cerca de la evidencia cruda y tenía menos secciones derivadas contradictorias. v0.4.1 añadió semántica, modelos y reconciliación, pero replicó el mismo hecho en clasificadores con criterios diferentes. v0.4.2 añadió un núcleo conservador, aunque el HTML nunca lo ejecutó: las pruebas y el producto eran motores distintos.

La ventaja de v0.3.3 no fue “tener menos campos”, sino una jerarquía narrativa única y campos próximos a la fuente. No se debe recuperar su inferencia de E1/E2 por nombre de dominio ni su selección heurística de padre.

| Área | v0.3.3 | v0.4.1 / HTML v0.4.2 | Decisión v0.4.3 |
|---|---|---|---|
| Contención | Árbol compacto; elige candidato por profundidad | Padre inmediato/ancestros más rigurosos, pero export duplicado | Único grafo conservador, conflicto sin selección |
| Dominios | Reconoce nombres amplios; puede inferir E1/E2 | Raíces y roles parcialmente contradictorios | Separar raíz estructural de dominio arquitectónico |
| Componentes | `api-o-servicio`, prudente | `api` en una sección y `apiOrService` en otra | Clasificador único con tipo, evidencia, rol y estado |
| Secciones | Conserva `textAreas` | Clasificación no usa sistemáticamente la tercera | Conservar secciones 1/2/3 y usarlas como señales |
| Conexiones | IDs, extremos y `textAreas` | JSON Copilot pierde etiquetas y datos crudos | Copia exacta, incluido `linkedData` y atributos extra |
| Flujo/Capa | Aparecen en árbol, sin propietario fuerte | Propiedad por ancestría/descarte; pares sin dueño desaparecen | `deploymentPairs[]`, candidatos completos, dueño no inventado |
| NOTACIÓN | Detecta contenedor y descendientes | Detección parcial/ruidosa | Membresía `contains` y grupos originales, exclusión operativa explícita |
| Modelos | Inventario cercano al dato | Más asociaciones, también warnings redundantes | Modelos factuales; warning solo ante contradicción real |
| Salida Copilot | Compacta y nominal | Grande, redundante y contradictoria | Proyección compacta desde el mismo resultado normalizado |
| Diagnóstico | Mezclado con factual | Contrato separado solo en `src/` | Proyección diagnóstica del mismo motor |
| Versionado | Archivo 0.3.3, JSON interno 0.3.2 | Título/contratos 0.3.7/0.4.1/0.4.2 | Una constante `VERSION` |

## Evidencia cuantitativa y funcional

- v0.3.3 `connectionSummary()` conserva terminaciones y el reporte conserva `connections[].textAreas`; v0.4.2 HTML elimina etiquetas en la proyección Copilot: 6 en Currency Exchange, 21 en Debit, 12 en Oski, 20 en Mortgage y 8 en QR, según la auditoría independiente.
- v0.3.3 exporta `hierarchy.mainTree`, `evaluationContext` y rutas nominales cercanas; v0.4.1 agrega clasificadores paralelos (`componentSemantics`, `componentTypeEvidence`, `architectureItems`) que pueden discrepar.
- El build v0.4.2 solo reemplaza cadenas en v0.4.1; el diff funcional con el kit es nulo. Por tanto, sus ocho pruebas de `src/` no demostraban el HTML.
- En E2 están declaradas tres parejas Flujo/Capa. El HTML posterior asigna o descarta candidatos; el resultado correcto conserva las tres y deja `x6OM…` ambiguo.

## Algoritmos a recuperar

- Proyección Copilot compacta con nombres, rutas y conexiones legibles.
- Preservación próxima a fuente de `textAreas` y jerarquía navegable.
- Identificación de leyenda mediante contención verificable.

## Algoritmos a sustituir

- Selección de padre por profundidad/clase.
- Escenario candidato por literal INTEGRACIÓN/PRODUCTOR.
- API por exclusión de prefijo `ms-`.
- Propietario Flujo/Capa por ancestro compartido o descarte.
- Cualquier build que copie un motor inline distinto al probado.

## Calidad de evidencia

| Categoría | Ejemplo | Tratamiento |
|---|---|---|
| Hecho | línea, extremos, texto Sí/No | Copia exacta |
| Inferencia sustentada | cadena única de `contains` | `DERIVED`, con ruta |
| Ambigüedad | varios candidatos en `x6OM…` | todos los candidatos, sin dueño |
| Contradicción | varios padres inmediatos | conflicto explícito |
| Pérdida v0.4.2 | etiquetas de líneas | corregir y comparar exactamente |

Las pruebas de v0.4.3 deben descargar desde el HTML y comparar con el núcleo; una prueba exclusiva de módulos no cierra F-01.
