# Auditoría independiente de cierre — Evidence Studio v0.4.6.1 y Skill v11.2.1

Contrato auditado: `copilot-factual-v0.4.6.1`.
Alcance: solo lectura. No modifiqué código, Skill, catálogo ni pruebas durante esta fase. No hice commits, push ni PR.

> Este veredicto mide la preparación para pruebas funcionales. No es una certificación y no sustituye la prueba real con Copilot.

---

## A. Veredicto

**APTO CON RESERVAS** para iniciar la primera prueba funcional con la analista.

Lo que lo sostiene:
- H-01 y H-02 están corregidos de verdad. Comparé `customData` figura por figura en las 2 585 figuras reales (0 diferencias) y comprobé que los campos que la Skill manda consultar existen en un compacto real.
- Los 41 IDs y sus obligaciones no cambiaron. Solo difieren CNT-002, E1-001 y E3-001, los textos de F-13.
- Los cuatro estados y la fórmula son consistentes en toda la documentación vigente. Los casos de métrica dan el resultado esperado.
- Los siete escenarios y las asociaciones Flujo/Capa se reproducen desde los JSON originales.
- No quedan clasificaciones definitivas contradictorias: 0 de 2 585 componentes tienen `domainRole` y `possibleDomainRoles` a la vez.

Reservas (detalle en las secciones D e I):
1. **La prueba con Copilot sigue sin ejecutarse.** No hay agente con la Skill instalada en este entorno.
2. **El diccionario del compacto está incompleto (N-01).** No documenta `groups`, `pageClassification`, `counts`, `name`, `operation`, `lucidchartType` ni `containedComponentIds`. Las anomalías de grupos solo se ven en `groups[].conflicts`.
3. **La rama pública incluye la matriz de reglas** (`RULE_EVIDENCE_MATRIX_v11.2.md`, que lista las 41 familias de IDs) **y nombres de blueprints corporativos en `CHANGELOG.md`** (N-06). Hace falta una decisión tuya antes de cualquier publicación.

---

## B. Integridad

| Elemento | Resultado |
|---|---|
| Rama privada | `feature/evidence-studio-v0.4.6.1-private`, HEAD `81b7542`. Mismo contenido que los commits `ca59126`, `ee7fa26` y `81b7542` |
| Rama pública | `public/evidence-studio-v0.4.6.1`, `1a69e4a`, un solo commit. `fcc67ac` no es ancestro y no hay ancestro común con la privada |
| HTML | SHA-256 `A93F293D…A247`: coincide con lo informado. La reconstrucción es idéntica byte a byte. La reconstrucción desde la rama pública da el mismo hash |
| ZIP | El ZIP **comprometido en HEAD** da `C44D5DB4…3AB5`: coincide con lo informado. El ZIP **en el árbol de trabajo** es otro (`825E7747…46FD`) porque lo regeneré tras los ajustes documentales autorizados (sección F.4). Extraje ambos y comparé los 16 archivos de la Skill por hash contra `skills/`: 0 diferencias en el actual |
| ZIP portable | 18 entradas, todas con `/`, 2 de directorio |
| Motor único | `ui/app.js` solo importa `../src/index.js`. El HTML de la rama pública y el de la privada son idénticos |
| Sin red | 0 URLs `http(s)`, 0 `fetch`/XHR/WebSocket/`src=`/`href=`, 0 peticiones no locales en la interfaz real |
| 41 IDs | CSV con 41 filas e IDs únicos; 41 encabezados en los `.md`, sin huérfanos |

Pruebas ejecutadas por mí (resultado real):

| Batería | Resultado |
|---|---|
| `npm test` | 54/54 |
| `npm run audit` | sin incidencias |
| `npm run build` | OK, 67 359 bytes, hash idéntico |
| `npm run test:e2e` (Edge) | 5/5 |
| Pruebas públicas (`git archive` en carpeta temporal) | 1/1 |
| E2E público | 1/1 |
| `skill:zip:validate` | 18 entradas portables |

Total de las baterías existentes: **61, igual que lo informado por Codex**. Hay que notar que la suite pública pasó de 7 a 1 prueba (N-09).

Pruebas propias, unas **300 comprobaciones**:
- 31 casos BPMN.
- 27 de grupos (21 sintéticos y 6 nuevos de proyección).
- 22 nombres `ms`, 10 textos funcionales, 11 `BPMNGroup` y 9 dominios.
- 96 en la interfaz con descargas reales, más 9 adicionales.
- 12 de métrica.
- Comparación de `customData` en 2 585 figuras y 608 líneas.
- Invariantes sobre 40 páginas y 2 596 componentes.
- 37 páginas de escenarios.
- La comparación celda a celda del CSV.

La comprobación de UI "C10" marca un fallo cosmético de mi propio oráculo: dos IDs coinciden entre los archivos originales de dos blueprints (`oYQoZjumg1I2`, `8yDPK._1wQJK`), no hay fuga entre cargas.

---

## C. Matriz H-01 a H-18

| ID | Estado v0.4.6.0 | Resultado v0.4.6.1 | Evidencia | Veredicto |
|---|---|---|---|---|
| H-01 | `customData` solo en `BPMNEvent` | Se exporta literal si la figura lo declara; ausente sigue ausente; `[]` sigue `[]` | 2 585 figuras, 0 diferencias (2 375 con `[]`, 210 con contenido); 13 actividades `ENTRADA`/`SALIDA` de Oski idénticas al original y ninguna con `architecturalType:"MODELO"`; descarga real de Oski con 0 diferencias | **CORREGIDO** |
| H-02 | Skill sin diccionario | ZIP con `CONTRATO-COMPACTO`, `MATRIZ-EVIDENCIA-41`, `GUIA-TEXTAREAS`; las estructuras del diagnóstico quedan marcadas como opcionales | Cada campo citado existe en un compacto real; los valores de `architecturalType`, `role` y `domainRole` coinciden con el contrato. Ver N-01 para huecos del diccionario | **CORREGIDO** |
| H-03 | 441/2 585 con rol y posibles roles | 0/2 585 | Corpus completo y `custom-domain.json` | **CORREGIDO** |
| H-04 | `SERVICE` | Solo `SERVICIO` | E3 sintético y corpus: 8 `SERVICIO`, 0 `SERVICE` | **CORREGIDO** |
| H-05 | `CONFIRMADO` con declaraciones dudosas | Cualquier declaración de clave admitida no reconocida, vacía, negativa o no textual impide confirmar | START+RESTART, START+vacío, START+negativa, START+END, arreglo, objeto, número y `null`: todos `HIPOTESIS`/`NO_VERIFICABLE` | **CORREGIDO** |
| H-06 | API `ms-` con rol firme; `INVOCADO` por cualquier línea | `ms-main-api` queda sin tipo ni rol con contradicción visible; `INVOCADO` exige entrada orientada y ninguna salida | Reproducido. `ms-transfer-service-context`: `SERVICIO`, rol `null` (sus dos líneas van en sentidos opuestos). Ver N-05 | **CORREGIDO** |
| H-07 | Instrucciones contradictorias | Cuatro estados, encabezados v11.2.1, referencias al diagnóstico marcadas como tales | Revisión de los 6 documentos del agente; `NORMATIVE_DIFF` ahora indica 3 cambios y 38 intactos, como en el CSV | **CORREGIDO** |
| H-08 | Anomalías de grupos sin aviso | Ciclo, autorreferencia, miembro inexistente, pertenencia múltiple y contención↔grupo producen `AMBIGUOUS_*` y dejan el componente sin asociar | 27 casos. Quedan N-02, N-03 y N-04 | **PARCIALMENTE CORREGIDO** |
| H-09 | Sin guía para componentes sin tipo | `GUIA-TEXTAREAS.md` con ejemplos genéricos | Presente y sin contradicciones. Es una guía textual, no una verificación | **CORREGIDO** |
| H-10 | Compacto de 3,3 a 4,5× | Igual: 3,4 a 4,6× | Tabla de la sección E | **PENDIENTE** (mejora futura aceptada) |
| H-11 | Análisis con 0 páginas | Bloqueado con "Seleccione al menos una página para analizar." | UI real | **CORREGIDO** |
| H-12 | Plantillas preseleccionadas | Solo `OPERATIONAL` y `MIXED`; BDD y plantillas aparecen en `omittedPages` | Virtual Account Opening y `Escenario2_Original.json` | **CORREGIDO** |
| H-13 | Gancho `window.__BES__` | Ahora no enumerable, de solo lectura y sin configurar; sigue presente | `ui/app.js`, `HANDOFF.md` lo declara | **PARCIALMENTE CORREGIDO** (no mutable, pero presente) |
| H-14 | Residuos públicos | `RECAUDOS` eliminado; el HTML público coincide con el privado | Grep en la rama pública. Persisten nombres en `CHANGELOG` (N-06) | **CORREGIDO** con residuo en N-06 |
| H-15 | `customData` malformado hacía fallar el análisis | Se conserva literal y se registra `MALFORMED_CUSTOM_DATA` o `…_ENTRY`; no falla | Entrada `null`, objeto, texto, `null` y entrada arreglo. Ver N-10 | **CORREGIDO** |
| H-16 | Conflicto de productores solo en diagnóstico | `CONFLICTING_MULTIPLE_PRODUCERS` aparece en `scenario.conflicts` | Dos productores sintéticos | **CORREGIDO** |
| H-17 | Sin pregunta para `NO_DETERMINADO` | `SKILL.md` paso 5 y `GUIA-TEXTAREAS.md`: explicar la incertidumbre y pedir solo el dato faltante | Revisión de los textos | **CORREGIDO** |
| H-18 | Encabezados v11.1 mezclados | Todos v11.2.1; el CHANGELOG de la Skill quedó reducido | Revisión | **CORREGIDO** |

Del conjunto: 15 corregidos, 2 parciales, 1 pendiente y 0 regresiones. Las regresiones anteriores A-1, A-2, A-3, M-1, M-2, M-5, M-6 y M-8 se mantienen cerradas (repetí sus pruebas).

---

## D. Nuevos hallazgos

| ID | Sev. | Hallazgo | Reproducción y evidencia | Impacto | Recomendación |
|---|---|---|---|---|---|
| N-01 | P2 | El diccionario no cubre campos que la Skill manda leer | `SKILL.md` paso 4 pide `groups`. `CONTRATO-COMPACTO.md` no tiene filas para `groups`, `pageClassification`, `counts`, `name`, `operation`, `lucidchartType`, `containedComponentIds`; solo aparecen en la matriz o ninguna parte. `00-procedimiento.md` paso 1 dice "plantilla pura" sin nombrar `pageClassification.kind`. `issues` no incluye las anomalías de grupos | El agente no sabe dónde mirar los conflictos de grupos ni cómo reconocer una plantilla | Añadir esas filas, indicar que los conflictos de grupos están en `groups[].conflicts` y que `pageClassification.kind` decide plantillas |
| N-02 | P3 | `deploymentAssociations` de página no expone `conflicts`; el componente tampoco muestra los pares sin resolver | Corpus: 50 pares de página, ninguno con campo `conflicts`. Caso "contención dice a2, grupo dice a1": el estado es `AMBIGUOUS_CONFLICTING_EVIDENCE`, pero `groups[].conflicts` e `issues` van vacíos y no se publican los IDs en conflicto. `components[].deploymentAssociations` omite las parejas sin componente | El agente ve el estado, no el detalle | Copiar `conflicts` a la proyección de página |
| N-03 | P3 | Una asociación sin resolver informa `source:"JSON.contains"` | 13 de 50 pares reales, p. ej. la pareja `AwQGL8iVQ5bP`/`AwQGN0rfikTW` de Currency: `associatedComponentId:null` y `source:"JSON.contains"`. Causa: `resolved===directResolved` cuando ambos son `null` | Puede leerse como asociación por contención | `source:null` si no hay componente |
| N-04 | P3 | Una capa que contiene dos componentes directos se resuelve por grupo a uno de ellos sin aviso | Sintético: capa contiene `a1` y `a2`, el grupo superior apunta a `a1`: `RESOLVED_BY_EXPLICIT_SUPERIOR_GROUP` | La contención incompleta no se señala | Marcar `AMBIGUOUS` o añadir conflicto |
| N-05 | P3 | `INVOCADO` es inalcanzable en el corpus real | 0 componentes con ese rol en 2 596. Las líneas de comando son bidireccionales (`COM-002`: API↔comando), así que ningún componente cumple "solo entrada" | Postura conservadora y coherente con lo pedido; los servicios invocados dependen de `GUIA-TEXTAREAS` | Decisión funcional: confirmar que `null` es lo esperado para invocados |
| N-06 | P2 (decisión) | Rama pública con contenido a revisar | `docs/contracts/RULE_EVIDENCE_MATRIX_v11.2.md` lista las 41 familias de IDs y el CSV; `AGENTS.md` prohíbe incluir normativa. `CHANGELOG.md` línea 74 cita Currency Exchange, Oski y Debit Card | Posible exposición de estructura normativa y nombres de blueprints | Decidir si la matriz es publicable; neutralizar el `CHANGELOG` |
| N-07 | P3 | `summarizeEvaluations` devuelve porcentaje aunque el resultado sea inválido y `summarizeBlueprint` no valida | 42 filas con ID duplicado: `valid:false` pero `compliancePercentage:51,85`. Un resumen de página con 1 fila entra en el total | Solo afecta al validador, no al agente | Devolver `null` si `valid:false` y propagar la validez |
| N-08 | P3 | Tamaño del compacto | Ver sección E | Posible presión de contexto | Mejora futura |
| N-09 | P3 | Reducción de la suite pública | 7 pruebas → 1 | Menos cobertura en la rama pública | Reponer comprobaciones sintéticas |
| N-10 | P3 | `customData` con una entrada nula junto a START válido sigue confirmando | `[null,{EVENT_TYPE:START}]` → `CONFIRMADO`, con `MALFORMED_CUSTOM_DATA_ENTRY` en `issues` | La incidencia no cambia la certeza | Degradar a `HIPOTESIS` si hay entradas malformadas |

---

## E. Contrato compacto

**Cobertura de las 41 reglas.** Contrasté `MATRIZ-EVIDENCIA-41.md` con un compacto real:
- Todos los campos de la matriz existen.
- No hay dependencias del diagnóstico para una evaluación ordinaria.
- `00-procedimiento.md` cita `rootContainers`, `groupStructure`, `deploymentPairs`, `architecturalRoleCandidates` y `structuralScenario`, pero solo para declararlos opcionales.

Pérdidas de evidencia (separadas de limitaciones del export):

| Dato | Tipo |
|---|---|
| `linkedData` de 2 figuras y de 608 líneas (todas vacías en las líneas), `linkUrl` (7) e `image` (4) | No conservados; ninguna regla los usa |
| Subtipo de evento de Inicio | Limitación del export: 0 de 341 `BPMNEvent` reales traen `customData`, así que todo escenario real es `HIPOTESIS` |
| Detalle de conflictos de asociación | Pérdida parcial (N-02) |

Valores observados en el corpus:
- `architecturalType`: `null` (1 912), `EVENTO` (343), `MODELO` (125), `SERVICIO_HIJO` (34), `API` (15), `SERVICIO` (8), `GESTOR_COLAS` (6), `FLUJO` (50), `CAPA` (50), `SISTEMA_EXTERNO_AUXILIAR` (53).
- `role`: `PRINCIPAL` (17), `HIJO_PRINCIPAL` (17), `null`.

Preguntas humanas: MCI del principal, MCI del hijo y exposición. La matriz las marca en API-003, API-004, EVT-004, E1/E2/E3 y MQ-003.

Tamaño (relación compacto/original de las páginas seleccionadas):

| Caso | Mi medición | Codex |
|---|---:|---:|
| Currency Exchange | 4,18× | 3,84× |
| Oski | 3,55× | 3,30× |
| Debit Card Issuance | 3,40× | 3,33× |
| Rango del corpus | 3,40 – 4,56× | — |

No reproduje las cifras de Codex; la diferencia depende del denominador. Fuentes de redundancia en Currency: `architecturalDomain` 16 138 B, `rootContainer` 14 280 B y `structuralParent` 12 605 B, sobre 92 168 B de `components`. Propuesta futura, no bloqueante: una tabla de contenedores por página con referencias por ID; cambiaría el contrato y exigiría actualizar el diccionario y las pruebas. No se demostró una limitación de contexto.

---

## F. Skill

1. **Cuatro estados.** Cumple, No cumple, No verificable y No aplica. "Parcialmente cumple" no aparece como estado vigente en ningún documento activo: solo en una frase que dice que la evidencia parcial es No verificable y en las pruebas que lo rechazan. El CSV y los `.md` de reglas no lo mencionan.
2. **Fórmula.** `Cumple / (Cumple + No cumple + No verificable)`.

| Caso | Resultado |
|---|---|
| 13/0/13/15 | 50 % (26 aplicables) |
| 41 No aplica | no calculable |
| 41 No verificable | 0 % |
| Dos páginas (13/26 y 20/30) | 58,93 % ponderado (33/56); el promedio simple sería 58,33 % |
| 40 filas, ID duplicado, ID desconocido, estado ajeno o `cumple` en minúscula | inválido, con el código de error correspondiente |

3. **Reutilización condicional de MCI/exposición.** Las cuatro fuentes (`SKILL.md`, procedimiento, `CONTRATO-COMPACTO`, `AGENTS.md`) coinciden. `INSTRUCCIONES-AGENTE-V11.md` es compatible.
4. **Cambios documentales que realicé por autorización** (siguen sin commit, junto al estado Git):
   - `AGENTS.md`: añadí cinco viñetas (versión de la Skill y contrato, cuatro estados, métrica, preguntas con reutilización condicional y no usar descarte).
   - `SKILL.md`: reutilización con confirmación explícita.
   - `references/00-procedimiento.md`: ídem.
   - `references/CONTRATO-COMPACTO.md`: la fila de `omittedPages` ahora dice "no trasladar respuestas sin confirmación explícita".
   - `dist/validar-blueprint-integracion-v11.2.1.zip`: regenerado.
   
   Todos son cambios editoriales u operativos; ninguno toca un ID ni una obligación normativa.
5. **Normativa.** Comparado con v11.1: solo CNT-002, E1-001 y E3-001 difieren (F-13). E2-001 y CNT-004 no cambiaron. Frente a v11.2.0, los `.md` de reglas solo cambiaron en el encabezado de versión. La conexión directa frente a declarada sigue pendiente.

---

## G. Escenarios (reevaluados contra los originales)

| Caso | Resultado | Principal / hijo | Dominios | Evento y conexión |
|---|---|---|---|---|
| Currency Exchange | E2 HIPOTESIS | `tQ7mFTFbJ1SW` (API, PRINCIPAL, INTEGRACIÓN) / `TJ7m.cKnR-~v` | INTEGRACIÓN / INTEGRACIÓN | `None→Arrow`, evento sin subtipo declarado |
| Oski | E1 HIPOTESIS | API de INTEGRACIÓN / hijo en el productor | productor inferido por estructura | ídem |
| Virtual Account Opening, op. 1 y op. 2 | E1 HIPOTESIS | API de INTEGRACIÓN / hijo en el productor | ídem | ídem |
| nombreOperacion1 | E2 HIPOTESIS | `3gn9iRxfHfin` / `TJ7m.cKnR-~v` | INTEGRACIÓN / INTEGRACIÓN | ídem |
| nombreOperacion2 | E1 HIPOTESIS | | productor declarado | ídem |
| E3 sintético con evento genérico | E3 HIPOTESIS | | | |
| E3 con Inicio inequívoco | E3 CONFIRMADO | | | `BPMN_EVENT_TYPE=START` |

- 0 escenarios sobre BDD o plantillas en las 37 páginas reales.
- `ms-main-api` ambiguo queda `NO_DETERMINADO`, sin inventar principal.
- Conexión invertida, `None–None` y sin conexión: `NO_DETERMINADO`.
- `PROPOSED_CLOSED_CATALOG` sigue declarado como propuesta técnica en el motor y en la Skill.
- La ausencia de claves BPMN no genera incumplimiento.

---

## H. Asociaciones

**Currency Exchange**
- El gestor `4Oc~oPj98AFn` pertenece a INTEGRACIÓN. Su cadena es `lI7ms82nd2~F → 4Oc~UAg.ChZ2 → 4Oc~STvzS7WZ`.
- El flujo contiene la capa y el gestor; la capa contiene el gestor.
- Sus 4 líneas originales están preservadas.
- Estado `RESOLVED_BY_DIRECT_CONTAINMENT` con evidencia de contención y del grupo `4Oc~Xod2f2AN`.
- No se le atribuye ninguna de las otras dos parejas: la del hijo `TJ7m.cKnR-~v` y la pareja `AwQG…`, que queda pendiente.

**nombreOperacion1** (conservado respecto de v0.4.6.0)
- API `3gn9iRxfHfin` por el grupo superior `3gn9Z0fP~kxr`.
- Hijo `TJ7m.cKnR-~v` por contención.
- Gestor `~ez.jtoEp~8-` por contención.
- La pareja `Th5D…` queda pendiente.

**Consistencia entre las dos proyecciones**
- 37 asociaciones a nivel de componente frente a 50 pares de página.
- 0 diferencias en flujo, capa, componente, fuente, estado y evidencia.
- La proyección de página no incluye `conflicts` y la de componente sí (N-02). No lo marco como defecto por sí solo: el estado de página basta para saber que hay conflicto.

**Negativos:** autorreferencia, ciclo, miembro inexistente, padres múltiples, pertenencia a grupos incompatibles y contención contradictoria dejan el componente sin asociar. Persiste N-04 (capa con dos componentes directos resuelta por grupo).

---

## I. Riesgos pendientes

| Categoría | Elementos |
|---|---|
| **Bloqueantes** | Ninguno de código. La prueba funcional con Copilot es el requisito previo para considerar la Skill utilizable |
| **No bloqueantes** | N-01 (diccionario), N-02 a N-04 (asociaciones), N-07, N-09, N-10, tamaño del compacto, gancho `__BES__` presente |
| **Decisiones funcionales** | N-05 (rol de invocados `null`), N-06 (publicar o no la matriz y el `CHANGELOG`), conexión directa frente a declarada, catálogo BPMN real |
| **Mejoras futuras** | Tabla de contenedores por página, reponer pruebas públicas, validar el resumen de métricas en el agente |

Riesgo que no se puede medir aquí: el comportamiento real del agente (cumplimiento de la plantilla de 41 filas, uso de las preguntas, lectura del diccionario). **No lo ejecuté.**

---

## J. Recomendación para Codex

1. **N-01**: completar `CONTRATO-COMPACTO.md` con `groups`, `pageClassification`, `counts`, `name`, `operation`, `lucidchartType` y `containedComponentIds`, e indicar dónde se leen los conflictos de grupos y qué campo decide las plantillas.
   - Prueba: todo campo de primer nivel de `pages[]` y de `components[]` tiene fila en el diccionario.
2. **N-02 y N-03**: añadir `conflicts` a `pages[].deploymentAssociations`; `source:null` si no hay componente.
   - Pruebas: los casos de grupos con detalle y los 13 pares sin resolver del corpus.
3. **N-04 y N-10**: marcar ambigüedad cuando la capa contiene dos componentes y degradar `CONFIRMADO` ante entradas malformadas.
4. **N-06**: tras tu decisión, retirar o conservar la matriz pública y neutralizar el `CHANGELOG`.
5. **N-07 y N-09**: opcionales.

No tocar los 41 textos, el catálogo, las expectativas de las pruebas existentes ni la decisión de la conexión directa frente a declarada.

**Resumen:** unas 300 comprobaciones propias más 61 de las suites existentes. Defectos nuevos: 0 P0, 0 P1, 2 P2 (N-01 y N-06, este último una decisión), 8 P3. Riesgo principal: la Skill no se ha probado con un agente real.
