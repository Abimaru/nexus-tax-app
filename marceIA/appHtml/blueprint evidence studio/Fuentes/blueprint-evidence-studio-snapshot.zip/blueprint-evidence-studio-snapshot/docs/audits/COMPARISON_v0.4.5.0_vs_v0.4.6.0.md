# Comparación v0.4.5.0 → v0.4.6.0

| Área | v0.4.5.0 | v0.4.6.0 |
|---|---|---|
| Selección | Solo metadatos; `pages[]` completo | `pages[]` contiene únicamente selección |
| Copilot | Modelo técnico extenso y duplicado | Inventario consolidado compacto |
| Clasificación funcional | Campo exportado | Eliminado; `textAreas` intactos |
| BPMN Inicio | Texto o cualquier `customData` | Clave/valor exactos de catálogo cerrado |
| Despliegue | Grupo superior; contención quedaba pendiente | Contención directa o grupo inequívoco |
| Dominio reservado vacío | Podía omitirse | Conserva rol declarado |
| Skill | v11.1.2, F-13 pendiente | v11.2.0, F-13 sincronizado |
| ZIP | Barras invertidas | Rutas internas `/` validadas |

La jerarquía estructural, IDs, conexiones, grupos, JSON multipágina, núcleo único y ausencia de red permanecen compatibles.
