# Auditoría independiente — Blueprint Evidence Studio v0.4.5.0 y Skill v11.1.2

Fecha: 2026-10-22. Rama `feature/evidence-studio-v0.4.5.0-private`, HEAD `182cf7d`. Auditoría de solo lectura: no se modificó código, documentos, fixtures ni Skill; sin commits ni push. Este informe es el único archivo creado. Es privado: cita IDs y nombres de blueprints corporativos.

## 1. Resumen ejecutivo

**Veredicto: NO APTO para pruebas con Copilot tal como está entregado.** Tres defectos reproducibles lo impiden y se corrigen con poco esfuerzo (A-1, A-2, A-3). Con ellos corregidos, el veredicto sería **APTO CON RESERVAS**.

Lo que sí está bien:
- **Jerarquía.** Padre inmediato, ancestros y raíz coinciden con una reconstrucción independiente en las 2.484 figuras de las 35 páginas de las 9 fuentes (0 diferencias). Ningún grupo altera `structuralParent` ni `containerChainIds` (probado quitando los grupos de cada página). Ninguna figura tiene dos padres directos.
- **Escenarios.** Los seis casos pedidos dan el resultado esperado y coinciden con mi lectura de las relaciones originales (§2).
- **Asociaciones de grupo.** En `nombreOperacion1`, la pareja de la API principal se asocia solo por el grupo superior `3gn9Z0fP~kxr`; las otras tres quedan pendientes, sin atribución por proximidad ni descarte (§3).
- **Entregables.** El HTML se reconstruye idéntico byte a byte desde `ui/` y `src/`, sin URLs remotas, sin solicitudes de red en la prueba de carga. Los hashes SHA-256 coinciden con `REGRESSION_v0.4.5.0.md`.
- **Pruebas.** `npm test` 40/40 y `test:e2e` 3/3.

Lo que bloquea:
- **A-1.** Desmarcar una operación no la excluye del JSON, y los metadatos se contradicen con el contenido.
- **A-2.** Cualquier aparición de "inicio" o "start" en texto o `customData` de un evento lo certifica como Inicio y sube el escenario a `CONFIRMADO`.
- **A-3.** El ZIP de la Skill se genera con barras invertidas en las rutas internas, lo que puede dejar la Skill sin instalar en un cargador estricto.

## 2. Matriz E1/E2/E3

Ejecución del motor (la misma del HTML) y contraste con las relaciones originales de Lucidchart. Todas las conexiones son `None→Arrow`, con terminaciones verificadas, y todos los eventos son `BPMNEvent` genéricos (`subtype:null`, `UNVERIFIED_START_EVENT`), salvo el sintético.

| Caso (página) | Principal | Operación / hijo | Padre y ancestros del principal | Cadena del evento | Dominios (principal / evento) | Resultado |
|---|---|---|---|---|---|---|
| nombreOperacion1 | `3gn9iRxfHfin` "API PRINCIPAL" | `nombreOperacion1` / `TJ7m.cKnR-~v` "NOMBRE SERVICIO" | INTEGRACIÓN `lI7ms82nd2~F` | INTEGRACIÓN > Flujo `x6OMy7H_BdmL` > Capa `x6OMFCgq99Xl` > hijo | INTEGRATION / INTEGRATION, ambos por nombre declarado | **E2 HIPOTESIS** |
| Oski (msDebitAccountPayment) | `wniB5n~8CzU8` | `debitAccountPayment` / `20QoxCoCdtvE` "msDebitAccountPayment" | INTEGRACIÓN | Recaudos `20QoN3lLcXy.` > hijo | INTEGRATION / PRODUCER (RECAUDOS por `STRUCTURAL_CHILD_EVENT_MAIN_PATH`, `inferenceUsed:true`) | **E1 HIPOTESIS** |
| Currency Exchange | `tQ7mFTFbJ1SW` | `executeTransactionCurrencyExchange` / `TJ7m.cKnR-~v` | INTEGRACIÓN | INTEGRACIÓN > Flujo > Capa > hijo | INTEGRATION / INTEGRATION; EVC Transferencias queda `NO_DETERMINADO` | **E2 HIPOTESIS** |
| initiateVirtualAccount | `8S4uZBWnl~74` | `initiateVirtualAccount` / `8S4u74NmLpa2` "user_ms" | INTEGRACIÓN `8S4uWKNx7SdQ` | CORE GLOBAL ACCOUNT `8S4uExzgId93` > hijo | INTEGRATION / PRODUCER (estructural) | **E1 HIPOTESIS** |
| initiateVirtualAccountAlias | `Lym7MFM_bghX` | `initiateVirtualAccountAlias` / `Lym7WQZ~U4V3` "user_ms (PENDIENTE)" | INTEGRACIÓN `Lym7Uf1c-xWD` | CORE GLOBAL ACCOUNT `Lym7ntV6NQR5` > hijo | INTEGRATION / PRODUCER (estructural) | **E1 HIPOTESIS** |
| E3 sintético | `service` "ms-main-service" | `runMainService` / `child` | CUSTOM PRODUCER DOMAIN | CUSTOM PRODUCER DOMAIN > hijo | PRODUCER / PRODUCER (estructural) | **E3 CONFIRMADO**, con evento de texto `INICIO` (ver A-2) |

Conexiones: `gT7m.rKo0qu-`→`iQ7mp2EXtgT-` (nombreOperacion1 y Currency), `wniB.7Dl~hrs`→`wniBqOut_oya` (Oski), `8S4u2s~XnOuy`→`8S4uk3eGI_Px` (VA1), `Lym73fLTpRP5`→`Lym7Osm1iZ_m` (VA2). El nombre de la página (`msDebitAccountPayment`, `nombreOperacion1`) no se confunde con la operación de la API (`debitAccountPayment`); `bddEvidenceUsed:false`. Alterar la página BDD no cambia el resultado (probado por el test existente y por casos propios).

Otras páginas de las fuentes: las de BDD salen `BDD_OR_REQUIREMENTS`, las de plantilla `TEMPLATE_OR_LEGEND`; ambas con `NO_DETERMINADO` y conflicto `PAGE_NOT_OPERATIONAL`. `nombreOperacion2` sale E1 HIPOTESIS con `DOMINIO PRODUCTOR` declarado. `nombreOperacion3` sale plantilla.

**E3 no está certificado sobre un blueprint corporativo real.** Solo existe el fixture sintético y su CONFIRMADO depende de la misma regla débil de A-2.

Contraejemplos de dominio (sintéticos, contra la definición funcional del Word):

| Caso | Resultado | Conforme |
|---|---|---|
| E1 con productor "Pagos" + otro contenedor "Otro" | E1; "Otro" = EXTERNAL_SYSTEM | Sí (§6, §16.1) |
| E2 + contenedor "Otro" | E2; "Otro" = NO_DETERMINADO | Sí (§6, §16.2) |
| E3 + "Otro" | "Otro" = EXTERNAL_SYSTEM | Según §6 y §16.3; contradice §12 (ver §10) |
| Destino llamado `SISTEMAS EXTERNOS` con hijo y evento | rol conservado, escenario `NO_DETERMINADO` | **No**: no se registra la inconsistencia (M-3) |
| Dos productores candidatos | ambos `NO_DETERMINADO` | Sí |
| Envolvente sobre INTEGRACIÓN y productor | `NO_DETERMINADO` (`NESTED_ARCHITECTURAL_DOMAIN`) | Sí, aunque el envolvente aparece como PRODUCER |
| Variante "Integración Core" | no es INTEGRATION | Sí |
| API en INTEGRACIÓN A, hijo en INTEGRACIÓN B | E2 HIPOTESIS | **No**: §16.2 pide el mismo contenedor (M-5) |

## 3. Matriz de asociaciones de grupos (nombreOperacion1)

Reconstruidos desde `Escenario2_Original.json` (13 grupos). Los grupos de leyenda (`RrvdRD4qbL9i`) no intervienen.

| Pareja Flujo/Capa | Grupo de la pareja | Grupo superior común | Relación que la sustenta o rechaza | Resultado del motor | Excel CONCLUSIONES |
|---|---|---|---|---|---|
| Flujo `3gn9R~iEY5k0` / Capa `3gn9Z.KytA17` | `3gn9KcIquAF8` | `3gn9Z0fP~kxr`, que contiene también `3gn9dZVeQSQU` (API `3gn9iRxfHfin` + `3gn9~ESdjd3y` + `3gn9I_IwRDfz`) y el `BPMNEvent` `3gn9gx1rPObC` | **Confirmada:** grupo superior específico que une el grupo de la pareja con el grupo de la API y sus modelos | `RESOLVED_BY_EXPLICIT_SUPERIOR_GROUP`, `resolvedOwnerId = 3gn9iRxfHfin`, modelos exactos | Coincide con el docx §17.4 |
| Flujo `x6OMy7H_BdmL` / Capa `x6OMFCgq99Xl` | `x6OM65TToMCK` | Ninguno | **No se confirma por grupo.** Ambas contienen por `JSON.contains` el hijo `TJ7m.cKnR-~v`, el evento `iQ7mp2EXtgT-` y 5 actividades | Pendiente, candidatos `[hijo, evento]` | El Excel dice que es del hijo. El motor expone el contenido pero no la relación explícita (M-8) |
| Flujo `rj5DdIid4PNd` / Capa `rj5DOZHCQ3wi` | `rj5Dw-V.hbb2` | Ninguno | Gestor `~ez.jtoEp~8-` contenido en la Capa y el Flujo por `JSON.contains`, sin grupo superior | Pendiente, candidato `QUEUE_MANAGER` | El Excel dice que se puede validar. Requiere decisión (M-8) |
| Flujo `Th5D2YVNxril` / Capa `Th5DIQfVNRIO` | `Th5DjjWdQFLe` | Ninguno | Solo contiene un `BPMNEvent` sin texto; el grupo `vZ6dP_37bn-S` (REUSO 2 API + modelos) no comparte superior | Pendiente, candidato `BPMN_EVENT` | Coincide: sin forma de identificar la capa y el flujo de la API reutilizada |

Otros grupos de componentes (`zZ6dxZEaevvA` servicio en Federado, `GNvecQ_Ab~VV` y `7hweTm8f6H9r` APIs en sistema externo, `dR7mNt2cV4j5` en SISTEMAS EXTERNOS, `Hjz.5NWc~Wqp` en DOMINIO PRODUCTOR): se exponen en `groupStructure` sin asociación inventada. Sus modelos quedan fuera de la agrupación, como indica el Excel.

Resultado en las demás fuentes: Oski, Currency Exchange, VA1/VA2 y Debit no resuelven ninguna pareja (no tienen grupo superior). Las páginas de la plantilla Nombre Producto API, Mortgage y QR resuelven una. En VA1/VA2 el SVG muestra la API dentro de la Capa y el Flujo, y el JSON no lo declara ni por contención ni por grupo; el motor lo deja pendiente, que es lo correcto (ver `AUDIT_v0.4.4.2_independent.md`).

**P-02 (reproducido y refinado).** Contraejemplos propios sobre `groupDeploymentAssociations()`:

| Caso | Resultado | Valoración |
|---|---|---|
| Un componente elegible sin modelos | Resuelto, `modelIds:[]` | Confirmado: no exige modelos. Es coherente con `GROUP_ASSOCIATIONS.md`, pero es una decisión de diseño |
| Un componente y dos parejas bajo un mismo superior | Ambas resueltas al mismo componente | **Defecto** M-6: no es inequívoco |
| Dos componentes, o dos en el mismo grupo | Ambiguo | Correcto |
| Solo modelos / evento / hijo / pareja y API en un único grupo / API suelta bajo el superior / abuelo | Pendiente | Correcto, conservador |
| Grupo de la pareja con dos grupos superiores | Resuelto aunque el grafo está en conflicto | **Defecto** M-6 |
| Gestor (`QUEUE_MANAGER`) en grupo hermano | Resuelto | Correcto |

La pertenencia a grupo, la agrupación superior, la asociación de despliegue, la contención y el cumplimiento MCI quedan separados en los campos (`GROUP_MEMBERSHIP`, `flowLayerRelationship`, `DEPLOYMENT_ASSOCIATION`); no hay cumplimiento MCI.

## 4. Validación de jerarquía

- 35 páginas / 2.484 figuras: **0** diferencias de padre, cadena y raíz frente a mi oráculo (subconjunto de reclamaciones `contains`).
- Dominio efectivo con nombre reservado: 1 diferencia, la de M-1 (`-X6dFN1Afu6A`).
- Robustez: ciclo de contención, referencia inexistente, figura con dos padres no relacionados, IDs duplicados y elementos nulos quedan sin resolver o marcados. Una página de 5.000 figuras / 2.000 conexiones se analiza en ~0,2 s; 1.000 grupos anidados en ~0,6 s; anidación de profundidad 100, en 22 ms.
- Grupos: un ciclo `g1↔g2` y un grupo miembro de sí mismo quedan `RESOLVED` (L-3).

## 5. Resultados de pruebas

| Prueba | Resultado |
|---|---|
| `npm test` | 40/40 PASS |
| `npm run test:e2e` (Edge, HTML distribuido) | 3/3 PASS |
| Reconstrucción de `dist/` | Idéntica byte a byte; 55.008 bytes; 0 URLs |
| SHA-256 HTML | `22ca8114…3a28`, coincide con el informe de Codex |
| SHA-256 ZIP | `ec783854…ef1d`, coincide |
| Prueba en el navegador | Carga del JSON; `Limpiar`; nombre y ID obligatorios; sin solicitudes de red; el JSON descargado coincide con el motor |
| Cobertura que falta | Ninguna prueba cubre selección de páginas (A-1), ni casos negativos de Inicio (A-2), ni instalación del ZIP (A-3) |

## 6. Hallazgos

Líneas sobre el código actual (las fuentes son compactas; una "línea" suele ser una función).

### Alta

**A-1 — La selección de páginas no filtra (P-01, confirmado).**
- `src/exporter.js:14` procesa `document.pages.map(...)`, todas. `selectedPageIds` y `omittedPages` solo van a `metadata` (`:48`). `ui/app.js` (línea 7) pasa la selección sin filtrar nada.
- Reproducción en el HTML: cargué `Escenario2_Original.json`, dejé solo `nombreOperacion1` marcada, analicé y descargué `…-ENRIQUECIDO.json`:
  - `pages[]` trae las **6** páginas y `metadata.pageCount:6`;
  - `metadata.selectedPageIds` = solo la de nombreOperacion1;
  - `metadata.omittedPages` lista 5 páginas como `NOT_SELECTED_BY_ANALYST`, que sí están en `pages[]`;
  - la tabla de la interfaz y las métricas (352 figuras, 31 conexiones) cuentan las 6.
- Causa: el filtro nunca se implementó.
- Impacto en Copilot: la Skill manda leer `selectedPageIds` y `omittedPages`; el agente no puede saber si debe analizar o ignorar esas páginas. Es contradictorio y no se puede evaluar solo lo que la analista eligió.

**A-2 — El evento "Inicio" se certifica por texto libre (P-04, confirmado).**
- `src/roles.js:47`: `/\b(INICIO|START)\b/i` sobre el texto del evento, o `/START|INICIO/i` sobre `${key} ${value}` de cualquier `customData` (sin límite de palabra). Con eso `startDeclared` pasa el estado a `CERTIFIED_BY_EXPLICIT_EVENT_EVIDENCE` y `identifyStructuralScenario` (`:62`) devuelve `CONFIRMADO`.
- Casos negativos que dan `CONFIRMADO`:

| Evento | Resultado |
|---|---|
| Texto "Inicio" | CONFIRMADO |
| "Fin del inicio de sesión" | CONFIRMADO |
| "No es un evento de inicio" | CONFIRMADO |
| "Start-up failed (end)" | CONFIRMADO |
| `customData` clave `restart_policy` | CONFIRMADO |
| `customData` valor `iniciosesion` | CONFIRMADO |
| Texto "FIN" y `customData` "INICIO: no aplica" | CONFIRMADO |

- Causa: una señal textual se trata como certificación BPMN. `BPMNEvent` agrupa inicio, intermedio y fin, y el JSON de Lucidchart no distingue el subtipo; solo el SVG lo dibuja, y no se interpreta. No existe ninguna prueba negativa.
- Impacto: Copilot recibe `CONFIRMADO` con `event.subtype:"START"` sin que haya evidencia de Inicio, y el subtipo es justo lo que la normativa exige verificar. Falso positivo directo sobre el único atributo que separa HIPOTESIS de CONFIRMADO.

**A-3 — El ZIP de la Skill usa barras invertidas (P-05, confirmado).**
- `scripts/package-skill.ps1:8` usa `Compress-Archive` de PowerShell 5.1. Lectura directa del directorio central: las **13** entradas llevan `\` y ninguna `/`. `unzip` advierte "appears to use backslashes as path separators". La especificación ZIP exige `/`.
- Un extractor estricto (Python/Java/Node en Linux, muchos cargadores en la nube) crea archivos planos con nombres como `validar-blueprint-integracion\SKILL.md` y no encuentra `SKILL.md` en la carpeta ni `references/`. `unzip` y Windows lo corrigen al extraer.
- Compatibilidad local comprobada: `SKILL.md` existe, el YAML lleva `name` y `description`, las tres rutas `references/…` que cita existen tras normalizar, el CSV tiene 41 filas únicas × 10 columnas, y la Skill contiene 13 archivos. **No se comprobó la instalación efectiva en Copilot.**
- Impacto: la Skill podría no cargarse, o cargarse sin referencias, en la prueba con Copilot.

### Media

**M-1 — Un contenedor reservado vacío pierde su rol.** `src/containment.js:27` (`isDomainContainer`) exige contenido (`hasContent`) también para nombres reservados. En `nombreOperacion3` el contenedor `-X6dFN1Afu6A` "SISTEMAS EXTERNOS (Opcional)", sin contenido, sale `ARCHITECTURAL_DOMAIN` con rol `null` y no figura en `rootContainers`. Pruebas propias: INTEGRACIÓN, SISTEMAS EXTERNOS y DOMINIO PRODUCTOR vacíos desaparecen. Contradice la solicitud ("conservar su rol, incluyendo (OPCIONAL)") y el docx §3 y §5 (clasificación por nombre literal). Afecta E3, donde puede haber INTEGRACIÓN vacía.

**M-2 — `NO_DETERMINADO` sin tipos posibles.** El docx §2, §4.3 y §6 exigen "indicando como tipos posibles DOMINIO_PRODUCTOR y SISTEMAS_EXTERNOS". En `src/containment.js:34` solo se asigna `roleStatus:'NO_DETERMINADO'`; no existe campo de tipos posibles (`grep` de "possible/posible" en `src/` sin resultados). `CORPORATE_DOMAIN_CONVENTION.md` afirma que se emiten.

**M-3 — Inconsistencia de SISTEMAS EXTERNOS no registrada.** Docx §5.2 pide registrar que el contenedor llamado SISTEMAS EXTERNOS contiene un hijo con evento. El motor conserva el rol, pero `rootContainers[].conflicts`, `domainConflicts`, `contradictions` e `issues` quedan vacíos; el escenario sale `NO_COMPLETE_STRUCTURAL_ROLE_CANDIDATE`. El agente no puede ver la contradicción.

**M-4 — Faltan el rol INVOCADO y gestionado/no gestionado.** Docx §9, §10–12 y §16.6: principal con tipo y rol PRINCIPAL; hijo con tipo SERVICIO, rol INVOCADO y condición gestionado/no gestionado; resto de APIs/servicios INVOCADO. `src/` no emite `INVOCADO` ni gestionado (`grep` sin resultados); solo `mainApi`/`mainService` y el nombre del hijo.

**M-5 — Varias INTEGRACIÓN en una página.** El motor da E2 HIPOTESIS con la API en una INTEGRACIÓN y el hijo en otra (`src/roles.js:37` compara solo roles, no el ID de dominio). Docx §16.2 exige el mismo contenedor. Es el caso "varias integraciones por página".

**M-6 — Asociación de despliegue no siempre inequívoca.** `src/groups.js:24-26`: un componente con dos parejas bajo el mismo superior resuelve ambas al mismo componente; un grupo de pareja con dos grupos superiores resuelve ignorando el conflicto `CONFLICTING_MULTIPLE_PARENTS`.

**M-7 — Contratos y Skill con restos de v0.4.4.2 (P-03).** Ver §7.

**M-8 — Parejas del hijo y del gestor frente al Excel.** CONCLUSIONES (filas 2 y 8) dice que se puede saber que la pareja `x6OM…` es del hijo y que la del gestor le pertenece. El motor las deja `PENDING_NO_COMMON_SUPERIOR_GROUP` y propone como candidato al hijo **y** al evento que contiene; `AGENTS.md` y esta auditoría prohíben inferir por contener un único elemento. Es un conflicto de requisitos que debe decidir la analista: o se expone la relación explícita de contención (pareja → hijo; pareja → gestor) como evidencia sin propietario, o se mantiene pendiente.

**M-9 — `domainResolution` contradice el escenario.** Con `DOMINIO PRODUCTOR` declarado (nombreOperacion2, E1), `domainResolution` sale `NO_DETERMINADO` con `producerDomainId:null` porque solo analiza dominios sin nombre. La Skill pide aceptar un productor según `domainResolution.status`.

### Baja

- **L-1.** `ui/app.js` (línea 3, `normalizeBlueprintName`) elimina todo salvo letras, números, `_` y `-`: "Virtual Account V2.1.0 [x] (final)" → `VirtualAccountV210xfinal`. El ejemplo del solicitante se cumple (`NMD-BP-Collections_Bill_Payments-Pay_BillU-ENRIQUECIDO.json`), pero la pérdida de puntos cambia el sentido de las versiones; trunca a 140 sin aviso.
- **L-2.** SVG: sin SVG el análisis procede (el enunciado pide entre uno y diez); al elegir 11 se truncan a 10 sin mensaje.
- **L-3.** Un ciclo de grupos y un grupo miembro de sí mismo quedan `RESOLVED`.
- **L-4.** El E2E compara el JSON de la UI con el motor (mismo oráculo; incluso toma `selectedPageIds` del resultado de la UI) y no prueba selección de páginas ni falsos positivos de Inicio.
- **L-5.** Rama pública (§8): residuos menores.
- **L-6.** El emparejamiento SVG↔página es por `lucid:page-tab-id`; las páginas de plantilla repiten ID entre blueprints (`5S7mo.81mgSU`, `KLbWZxhT5HMn`), así que un SVG de otro blueprint puede figurar como `MATCHED_BY_PAGE_ID`. Sin riesgo en páginas operativas, cuyos IDs son únicos.
- **L-7.** En `nombreOperacion2` la API principal lleva título de plantilla ("Nombre Producto - Nombre API vX.0.0") y aun así sale E1 HIPOTESIS, mientras `pageClassification` excluye ese origen de las rutas operativas. Es coherente con un blueprint plantilla, pero la lógica de página y la de rol difieren.

## 7. Contratos y Skill frente al comportamiento (P-03)

**Diferencias que cambiarían el comportamiento de Copilot**

| Documento | Texto heredado | Código actual |
|---|---|---|
| `skills/.../SKILL.md` (línea 17) | `CORPORATE_PARENT_DOMAIN_CONVENTION` "permite inferir como productor" un padre personalizado | La convención se eliminó; el rol personalizado queda `NO_DETERMINADO` salvo estructura |
| `SKILL.md` (línea 21) | Un productor personalizado solo se acepta con `domainResolution.status` demostrado | Contradice la línea 17 del mismo archivo |
| `references/INSTRUCCIONES-AGENTE-V11.md` (líneas 13–14) | Aceptar PRODUCER por `CORPORATE_PARENT_DOMAIN_CONVENTION`; `STRUCTURALLY_CONFIRMED` | Estados `CONFIRMADO`/`HIPOTESIS`/`NO_DETERMINADO` |
| `references/CHANGELOG-V11.md` | Declara `STRUCTURALLY_CONFIRMED` y la convención | Idem |
| `ARCHITECTURAL_ROLE_CANDIDATES.md` | "otros nombres válidos se infieren PRODUCER mediante `CORPORATE_PARENT_DOMAIN_CONVENTION`"; "`BPMNEvent` no certifica Inicio"; "solo se completa `scenario` cuando el estado es `STRUCTURALLY_CONFIRMED`" | El código certifica Inicio por texto (A-2) y emite `scenario` también en `HIPOTESIS` |
| `COPILOT_JSON_CONTRACT.md` | "padres personalizados válidos se infieren PRODUCER por `CORPORATE_PARENT_DOMAIN_CONVENTION`"; `pageClassification` sin `BDD_OR_REQUIREMENTS`; `resolvedOwnerId` "salvo evidencia explícita" sin describir la resolución por grupo | El código emite `BDD_OR_REQUIREMENTS` y resuelve propietarios por grupo superior |
| `CORPORATE_DOMAIN_CONVENTION.md` | Dice emitir "posibles roles productor/externo" | No se emite (M-2) |

El nombre `CORPORATE_PARENT_DOMAIN_CONVENTION` ya no existe como fuente en el código (las fuentes son `DECLARED_DOMAIN_NAME`, `STRUCTURAL_CHILD_EVENT_MAIN_PATH`, `SCENARIO_REMAINDER_AFTER_UNIQUE_PRODUCER`); los documentos de la Skill siguen mandando buscarla. `SKILL.md` también cita una ruta que no viaja en el ZIP (`docs/audits/NORMATIVE_CORRECTION_PROPOSAL_v11.1.md`).

**Diferencias solo documentales:** nombre del archivo `CORPORATE_DOMAIN_CONVENTION.md`; `GROUP_ASSOCIATIONS.md` correcto y compatible; `ADR 0003` correcto.

## 8. Skill v11.1.2, riesgo Copilot y seguridad

**Skill.** Las 41 reglas y los archivos `01`–`07` no cambian respecto a `fcc67ac`; el único cambio de catálogo es el entrecomillado de CNT-002 (contenido idéntico, 10 columnas). Distingue bien `GROUP_MEMBERSHIP`, `DIRECT_CONTAINMENT`, `ANCESTOR_CONTAINMENT` y `DEPLOYMENT_ASSOCIATION`, y declara que `CONFIRMADO` no es `Cumple` y que `normativeEvaluation:null` obliga a evaluar las 41 reglas. No convierte HIPOTESIS en certeza ni omite reglas. Falla en: la contradicción de productor y los restos de v0.4.4.2 (M-7), y no explica `domainResolution` para productores declarados (M-9).

**Riesgos de interpretación por Copilot** (ordenados): A-2 (CONFIRMADO falso); A-1 (páginas omitidas que siguen en `pages[]`); A-3 (Skill sin instalar); la contradicción de productor en la Skill; `NO_DETERMINADO` sin tipos posibles (M-2); la inconsistencia de SISTEMAS EXTERNOS invisible (M-3).

**Seguridad.** HTML sin URLs ni solicitudes de red; el SVG ya no se renderiza (solo se lee `lucid:page-tab-id`); el contenido de JSON se inserta con escape o `textContent` (el `escapeHtml` usa `&quot` sin `;`, sin efecto práctico en los datos probados).

**Rama sanitizada `public/evidence-studio-v0.4.5.0`.** Historia independiente de 8 commits; `fcc67ac` no es ancestro; sin `Blueprints_ejemplos/`, `skills/`, ZIP, `Solicitud Ajustes/` ni auditorías. Búsqueda de `accountId` (solo como palabra en `PUBLIC_DISTRIBUTION.md`), nombres de blueprints, IDs, `Bancolombia`, `MCI - BP`, `catalogo-reglas`: sin coincidencias de material corporativo. Residuos que conviene revisar antes de publicar:
- `CHANGELOG.md` menciona "E2 Currency Exchange", un nombre de blueprint real.
- `fixtures/synthetic/custom-domain.json` usa `RECAUDOS`, nombre de dominio real del blueprint Oski.
- `AGENTS.md` y `docs/PUBLIC_DISTRIBUTION.md`, públicos, citan `Blueprints_ejemplos/`, `skills/`, `artifacts/private-evidence/` y `fcc67ac`.
- `docs/contracts/` y `dist/BlueprintEvidenceStudio.html` incluyen las convenciones INTEGRACIÓN / DOMINIO PRODUCTOR / SISTEMAS EXTERNOS y la lógica E1/E2/E3: podría considerarse "arquitectura interna". Decisión del propietario.

No se ejecutó la verificación completa de 5 pasos de `PUBLIC_DISTRIBUTION.md` sobre el árbol final.

## 9. Impacto en Copilot (resumen)

| Hallazgo | Efecto probable |
|---|---|
| A-1 | Páginas excluidas por la analista se evalúan igual, o se ignoran páginas incluidas; metadatos inconsistentes |
| A-2 | `CONFIRMADO` y `subtype:"START"` sin evidencia de Inicio; se salta la verificación normativa del evento |
| A-3 | La Skill no se instala o carece de `references/` |
| M-1, M-2, M-3 | Pérdida o ocultación de evidencia que el agente necesita para tratar como "No verificada" lo no determinado |
| M-4 | Faltan rol y gestionado/no gestionado que exige §16.6 |
| M-5, M-6 | Falsos positivos de escenario y de asociación |
| M-7 | La Skill se contradice sobre cuándo aceptar un productor |

## 10. Riesgos normativos pendientes

**F-13 (P-06) — contradicción en «fuera del dominio productor».** Texto que choca con las definiciones aprobadas:
- `05-reglas-escenarios.md` (E1-001, línea 9) y E3-001 (línea 39): hijo con dominio raíz "fuera del dominio productor"; también el resumen y los criterios de los mismos IDs; el CSV (E1-001, E3-001, CNT-002) lo repite; `00-procedimiento.md` (líneas 30 y 32) dice "no gestionado bajo el dominio productor"; `01-reglas-estructura.md` (CNT-002) lo repite.
- `CNT-004` dice que el dominio productor **contiene** el hijo de E1/E3.
- Definiciones funcionales aprobadas (docx §10, §12, §16.1, §16.3): el hijo es un servicio **no gestionado ubicado dentro de Dominio Productor**.
- Conflicto: "fuera del" es lo contrario de "dentro de". Un agente que aplicara el texto literal de E1-001/E3-001 daría No cumple a una estructura correcta (hijo dentro del productor), o daría Cumple a un hijo fuera de él. El motor sigue la definición aprobada: hijo dentro del productor.
- Alcance: E1-001, E3-001, CNT-002, CNT-004 y `00-procedimiento.md`, más los resúmenes del CSV. La Skill instruye marcar esas reglas como No verificable; con eso el agente no pierde el aviso, pero se desactivan cuatro reglas.
- Propuesta (pendiente de autorización, `NORMATIVE_CORRECTION_PROPOSAL_v11.1.md`): E1 y E3, hijo no gestionado en el dominio productor; E2, hijo gestionado en INTEGRACIÓN; alinear CNT-002 y CNT-004. No se modificó ninguna de las 41 reglas.

**Otros riesgos del contexto funcional:**
- El docx se contradice en E3: §12 deja los demás contenedores personalizados en `NO_DETERMINADO`, mientras §6 y §16.3 los clasifican como SISTEMAS_EXTERNOS. El motor sigue §6/§16.3.
- La decisión "conexión directa" frente a "declarada" sigue abierta: el docx pide "directamente" en los tres escenarios; E1-001 y E2-001 dicen "declarada" y E3-001 "directa".
- Solo hay evidencia de E3 sintética.
- El motor no puede certificar el subtipo Inicio desde el JSON; solo el SVG lo dibuja y no se interpreta.

## 11. Correcciones

**Obligatorias antes de pruebas con Copilot**
1. A-1: filtrar `pages[]` por `selectedPageIds` y ajustar `pageCount`, `selectedPageIds`, `omittedPages` y la tabla/métricas de la interfaz; añadir prueba de selección.
2. A-2: no certificar Inicio por texto libre; dejar `HIPOTESIS` salvo una señal estructurada y acotada que el propietario apruebe. Añadir pruebas negativas.
3. A-3: generar el ZIP con rutas `/`; añadir una prueba que lea el directorio central.
4. M-7: limpiar la Skill y los contratos de `CORPORATE_PARENT_DOMAIN_CONVENTION`, `STRUCTURALLY_CONFIRMED` y la contradicción de productor.

**Recomendadas**
5. M-1, M-2, M-3, M-4, M-5, M-6, M-9.
6. M-8: decisión de la analista antes de tocar el código.

**Opcionales**
7. L-1 a L-7; revisar los residuos de la rama pública.

## 12. Recomendaciones precisas para Codex (sin implementar)

1. **A-1** — En `analyzeBlueprint` (`src/exporter.js`), filtrar `document.pages` por `options.selectedPageIds` antes de `map`, o calcular `omittedPages` como las no incluidas realmente. `pageCount` debe igualar `pages.length`. Probar con una selección parcial, una vacía y un ID inexistente, y con el HTML.
2. **A-2** — En `deriveArchitecturalRoleCandidates` (`src/roles.js`, línea 47), retirar el regex sobre texto y `customData`. Si se necesita una señal explícita, definirla por clave y valor exactos (por ejemplo `customData` con clave de tipo de evento y valor `START`) y documentarla. Casos negativos mínimos: los siete de §6 A-2.
3. **A-3** — En `scripts/package-skill.ps1`, sustituir `Compress-Archive` por una librería o herramienta que escriba `/` (por ejemplo `System.IO.Compression.ZipArchive` con nombres normalizados, o `tar -a`). Prueba: leer los nombres crudos del directorio central y exigir 0 barras invertidas.
4. **M-1** — En `isDomainContainer` (`src/containment.js`, línea 27), exigir contenido solo para nombres no reservados.
5. **M-2/M-3** — Añadir `possibleTypes:['DOMINIO_PRODUCTOR','SISTEMAS_EXTERNOS']` a cada contenedor `NO_DETERMINADO`, y un conflicto explícito cuando un contenedor externo explícito contenga un hijo con evento.
6. **M-4** — Emitir `functionalRole:'PRINCIPAL'|'INVOCADO'` y `managed:true|false|null` para el principal y el hijo, y `INVOCADO` para los componentes consumidos.
7. **M-5** — Para E2, exigir mismo ID de dominio entre origen y destino; si difieren, `HIPOTESIS` con conflicto, o `NO_DETERMINADO`.
8. **M-6** — En `groupDeploymentAssociations`, no resolver si el componente queda asociado a más de una pareja bajo el mismo superior ni si el grupo de la pareja tiene `CONFLICTING_MULTIPLE_PARENTS`.
9. **M-9** — Con productor declarado por nombre, dejar `domainResolution.status` como `DECLARED` o similar, en vez de `NO_DETERMINADO`.
10. **M-7** — Alinear `SKILL.md`, `INSTRUCCIONES-AGENTE-V11.md`, `CHANGELOG-V11.md` y los tres contratos con el comportamiento real; no citar rutas que no viajan en el ZIP.
11. **Pruebas** — Ampliar el E2E: selección de páginas, nombre/ID obligatorios, SVG sin correspondencia y vacío, descarga con nombre normalizado, y un oráculo independiente del motor (comparar el JSON descargado con el original, no solo con el motor).
12. **No hacer** — Modificar las 41 reglas ni resolver F-13; esas decisiones son de la analista.
