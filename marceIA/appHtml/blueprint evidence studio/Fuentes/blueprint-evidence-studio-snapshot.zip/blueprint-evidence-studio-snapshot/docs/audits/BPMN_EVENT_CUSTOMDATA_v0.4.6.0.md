# Eventos BPMN y customData

Los JSON corporativos inspeccionados no muestran una convención estable de subtipo en `customData` de BPMNEvent. Por eso sus eventos permanecen `NO_VERIFICABLE` y los escenarios estructuralmente únicos quedan `HIPOTESIS`.

Se implementó un catálogo cerrado propuesto para evidencia futura/sintética: claves exactas `BPMN_EVENT_TYPE`, `EVENT_TYPE` o `TIPO_EVENTO_BPMN`; valores exactos START/INICIO, END/FIN, SIGNAL/SEÑAL, RECEIVE/RECEPCIÓN y EXCEPTION/EXCEPCIÓN. Declaraciones incompatibles producen `CONFLICTING_CUSTOM_DATA`.

Texto libre, nombres, descripciones, `restart_policy`, coincidencias parciales y frases negativas nunca certifican subtipo. El catálogo permanece propuesto hasta que un export real demuestre la clave corporativa oficial.
