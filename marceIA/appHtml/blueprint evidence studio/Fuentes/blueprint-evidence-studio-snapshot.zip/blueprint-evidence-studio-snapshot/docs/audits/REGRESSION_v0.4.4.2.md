# Regresión v0.4.4.2

## Matriz funcional

| Caso | Esperado |
|---|---|
| Oski | E1 / STRUCTURALLY_CONFIRMED; RECAUDOS por convención |
| Currency Exchange | E2 / STRUCTURALLY_CONFIRMED; ambos dominios INTEGRATION |
| E3 sintético | E3 / STRUCTURALLY_CONFIRMED; no extrapolable a blueprint real |
| Envolvente sobre INTEGRACIÓN | Conserva E2; envolvente conflictivo, dominio efectivo INTEGRATION |
| Principal dentro del hijo | `scenario:null`; conflicto explícito en E1/E2/E3 |
| Destino externo o sin dominio | `scenario:null`; UNRESOLVED/AMBIGUOUS |
| Reservado con sufijo | rol sin resolver; no PRODUCER |
| Cuatro páginas de plantilla | TEMPLATE_OR_LEGEND; sin candidato ni escenario |
| Operación con NOTACIÓN | MIXED; analiza solo ruta operativa |
| Orientación ambigua | candidato conservado; `scenario:null` |
| `ms-` propuesto como mainApi | conflicto conservado; no confirmado |
| BDD alterado | sin impacto en candidatura ni escenario |
| Evidencia original | figuras, conexiones, modelos y grupos idénticos |
| Compatibilidad v0.4.4.1 | padre inmediato y cadena idénticos; raíz y dominio separados sin reparentar |
| Conflicto de contención | candidatos preservados; padre, raíz, dominio y rol sin inventar |

## Resultados

- Unitarias: 36/36 PASS.
- Auditoría: 25 páginas de 7 fuentes procesadas; 0 incidencias estructurales en el inventario final.
- E2E Edge sobre `dist/BlueprintEvidenceStudio.html`: 3/3 PASS.
- Skill: validación PASS y ZIP v11.1.1 generado.
- HTML: 40.188 bytes; SHA-256 `EF732B8797A55E8A2ADDF9E46C7CB9DA2C36ED0E14637EB37F0ED4991DCBE751`; 0 referencias HTTP(S).
- ZIP Skill: 19.628 bytes; SHA-256 `B57BBCED19D06D9B7E62640A8DB048E8809CB1BCFCBAB8516B01CD134BDB976F`.

## Riesgos residuales

- E3 solo dispone de fixture sintético.
- F-13 continúa contradictorio en la normativa oficial.
- La decisión conexión directa frente a conexión declarada continúa abierta.
- La clasificación de plantilla es conservadora y debe revisarse si aparecen nuevas convenciones de placeholders.
