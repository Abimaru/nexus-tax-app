# Auditoría independiente — Blueprint Evidence Studio v0.4.2 / Skill v11.1

Fecha: 2026-10-21. Rama: `feature/evidence-studio-v0.4.2` (commit `fcc67ac`). Auditoría de solo lectura: sin modificar originales, sin commits ni push.

## 1. Resumen ejecutivo

**Veredicto: NO APTO** para liberar como "v0.4.2 con núcleo modular", y no publicable en el estado actual (F-07).

- El HTML entregado (`dist/BlueprintEvidenceStudio.html`) es el HTML v0.4.1 con la versión reemplazada por texto; **no usa `src/`**. Las 8 pruebas PASS solo cubren `src/`, no el producto entregado.
- Lo que el HTML hace bien: contención correcta, endpoints exactos, SVG seguro, sin red, compilación reproducible.
- Defectos que impiden la aceptación: pérdida de datos de conexiones, atribución de Capa/Flujo por ancestría o descarte, señales contradictorias (`api` frente a `apiOrService`), versiones incoherentes y material prohibido por `AGENTS.md` dentro del commit con remoto público.

## 2. Matriz de hallazgos

| ID | Sev. | Estado | Hallazgo |
|---|---|---|---|
| F-01 | Crítica | Confirmado | HTML ≠ núcleo; dos contratos divergentes |
| F-02 | Alta | Confirmado | El JSON Copilot descarta las etiquetas de conexión; no existe `evidence.lines` |
| F-03 | Alta | Confirmado | `deploymentOwnership` asigna propietario por ancestría o descarte |
| F-04 | Alta | Confirmado | `componentType:"api"` frente a `apiOrService` sin resolver |
| F-07 | Alta | Riesgo latente | Commit con `Blueprints_ejemplos/`, `skills/` y ZIP; remoto PÚBLICO |
| F-05 | Media | Confirmado | Pares Flujo/Capa sin propietario no se exponen |
| F-06 | Media | Confirmado | Clasificación ignora la 3.ª sección; eventos tipados `apiOrService` |
| F-08 | Media | Confirmado | Versiones incoherentes (v0.3.7 / 0.4.1 / 0.4.2) |
| F-09 | Media | Confirmado | `childRootContainerId` apunta a un contenedor que no es dominio |
| F-10 | Media | Riesgo | Leyenda NOTACIÓN indistinguible; `MODEL_UNASSOCIATED` ruidoso |
| F-11 | Media | Confirmado | El núcleo no reconoce dominios raíz personalizados |
| F-12 | Media | Confirmado | CSV del catálogo: fila CNT-002 con 12 columnas frente a 10 |
| F-13 | Media | Conflicto normativo | E1/E3 "fuera del dominio productor" contradice CNT-004 |
| F-14 | Baja | Confirmado | Robustez y rendimiento del núcleo |
| F-15 | Baja | Observación | `skill:validate` con ruta fija; ~90 blobs de SVG por análisis |

## 3. Evidencia reproducible

**F-01.** `scripts/build.mjs:2-7` copia `BlueprintEvidenceStudio_v0.4.1_Kit/…v0.4.1.html`, aplica `replaceAll('v0.4.1','v0.4.2')` e inyecta `<meta name="evidence-studio-source" content="modular-core-v0.4.2">`, que es falsa. El `diff` kit↔dist solo difiere en 4 líneas (5, 309, 321, 488), todas de versión. `test/*.js` solo importa `../src/index.js`. Contratos: HTML `copilot-factual-evidence-v1.3`; núcleo `copilot-factual-v0.4.2`; `docs/contracts/COPILOT_JSON_CONTRACT.md` describe el del núcleo. `REGRESSION_v0.4.2.md:13` y `HANDOFF.md` lo admiten parcialmente; `README`, `CHANGELOG` y `ARCHITECTURE` no.

**F-02.** Cargando JSON+SVG en la UI y descargando el JSON Copilot, se pierden los `textAreas` de las líneas (etiquetas Sí/No de compuertas): E2 6, Debit 21, Oski 12, Mort 20, QR 8. Tampoco están en el diagnóstico. El contrato promete copias sin pérdida, pero `evidence.lines/shapes/layers` no existen en el export (`dist` línea 484).

**F-03** (`dist` línea 445).
- Debit: la Capa `VlfVVAdoAiu3` contiene la API `AAztOn0-kSAP` y el `BPMNEvent` `AAztqXQ4T3aC`; el HTML lista solo la API (los eventos no entran en `elements`); el núcleo marca `UNRESOLVED_OWNER`.
- E2: el par `x6OM…` queda con `ownerComponentId = TJ7m.cKnR-~v` (`DERIVED_FROM_JSON_CHAIN`), siendo el hijo solo descendiente; el núcleo da `UNRESOLVED_OWNER` con 6 candidatos. v11.1 admite Flujo/Capa como ancestros intermedios.
- Mismo hecho, dos vocabularios: `layerAssociations.status = DECLARED_IN_JSON_CHAIN` (línea 466) frente a `associationStatus = DERIVED_FROM_JSON_CHAIN`.

**F-04.** En E2, Oski, Mort y QR: `modelAssociations[].componentType="api"` (`confirmed`, `high`) mientras `componentTypeInference.technicalType="apiOrService"` (`UNRESOLVED`). Causa: dos clasificadores en el HTML; línea 230 devuelve `'api'` para todo `UMLClassBlock` sin `ms-`, líneas 355-360 devuelven `apiOrService`.

**F-05.** Pares fuera de `deploymentOwnership`: E2 `4Oc~` y `AwQG`; Mort `D~c-S13J0kce`; Debit Capa vacía `-lfVs_o9_V3G`; Oski y QR, ninguno.

**F-06.** `ms-` se trata como señal convencional (`INFERRED_BY_NAMING_CONVENTION`, confianza media), no como requisito; el resto queda `apiOrService`. La 3.ª sección no se usa: Oski, la API principal con "Tarea" (modelo de servicio) queda sin resolver; Debit, `D.iUw4g5X.8K` ("Empresarial - Event") y `AAztk.iHW87X` ("Empresarial - Query") son eventos y salen `apiOrService`. La API principal de E2 (`tQ7mFTFbJ1SW`) trae "Entidad": evidencia del blueprint (API-003), no error del extractor.

**F-07.** `git ls-files`: 20 archivos de `Blueprints_ejemplos/`, `skills/` y el ZIP en `fcc67ac`. `gh repo view`: `PUBLIC`. La rama no está en `origin`, por lo que no hay fuga demostrada; hay que reescribir historial o separar el repositorio antes de cualquier push.

**F-08.** `<title>` y encabezado dicen v0.3.7 (3 ocurrencias); el export lleva `version:'0.4.2'` con `metadata.extractionVersion:'0.4.1'`.

**F-09.** Debit: el hijo `AAztE7-ReJ9u` reporta `childRootContainerId = iy.SVb3uZRsH` (contenedor sin nombre ni dominio) con `STRUCTURAL_PATH_AVAILABLE`; `rootContainers` solo lista INTEGRACIÓN; el núcleo da `PARTIAL`.

**F-10.** E2: ~51 de 99 componentes pertenecen al grupo de leyenda `RrvdRD4qbL9i` con el mismo `operationalScope` que los reales (textos "API", "Evento", "Privada"…). `MODEL_UNASSOCIATED` con `reviewRequired:true`: E2 4, Debit 19, Oski 14, Mort 11.

**F-11.** Raíz nula en el núcleo pero resuelta en el HTML: Oski "Recaudos" 67 componentes; QR "NEPA - NUEVAS EXPERIENCIAS" 26. `roleStatus` distinto entre ambos.

**F-12.** `csv.reader` da 12 columnas en CNT-002 (comas sin comillas en evidencia) y 10 en el resto; `test/skill.test.js` solo cuenta IDs con regex. El `.md` correspondiente es correcto.

**F-13.** `E1-001`/`E3-001`: hijo "fuera del dominio productor"/"no gestionado bajo" él; `CNT-004`: el dominio productor "contiene el hijo de E1/E3". E3 pide "conexión directa" al evento de Inicio; E1/E2 "declarada".

**F-14.** Contención aplanada de profundidad 40/60/80: 85 ms / 627 ms / 2,7 s (≈ n⁵), sin manifestarse con ejemplos reales. `null` en `shapes[]` lanza `TypeError`; IDs duplicados sin `issue`; conexión a ID inexistente queda `DECLARED`.

## 4. Confirmados frente a no demostrados

- **Confirmados:** F-01–F-06, F-08, F-09, F-11, F-12, F-14.
- **Riesgo no demostrado:** F-07 (sin fuga), F-10 (no se probó un dictamen erróneo), blobs de F-15 (no se verificó su revocación).
- **Verificados sin defecto:** 0 URLs `http(s)`; sin `fetch`/XHR; ningún doble padre directo; ningún ancestro presentado como padre inmediato; `scenario:null` y `normativeCompliance:null`; `bpmnStartSubtypeCertified:false`; recuentos sin regresión (99/20, 170/78, 126/30, 138/46, 85/15).

## 5. Contención y despliegue

**Contención.** Contra una prueba independiente (subconjunto de reclamaciones `contains`) HTML y núcleo dan 0 diferencias en 618 figuras de 5 operaciones; sin ciclos ni referencias ausentes en datos reales. Limitación: usa la misma fuente (`contains`); el SVG solo trae trazados, sin textos ni IDs salvo `lucid:page-tab-id`, por lo que no corrobora. Es consistencia, no prueba independiente.

**Despliegue E2.**

| Pareja | Contenido | Estado |
|---|---|---|
| `4Oc~UAg.ChZ2` / `4Oc~STvzS7WZ` | Solo el gestor `CQMGRIBMICORP01` (`4Oc~oPj98AFn`) | Derivada, no certificada |
| `AwQGL8iVQ5bP` / `AwQGN0rfikTW` | Solo el `BPMNEvent` genérico `A2QoPi1ZvH9t` | Derivada, no certificada |
| `x6OMy7H_BdmL` / `x6OMFCgq99Xl` | El hijo `TJ7m` con su flujo BPMN | Sin propietario certificado (ancestro del hijo) |

Los grupos (`4Oc~Xod2f2AN`, `AwQGA8IADXwI`, `x6OM65TToMCK`) solo contienen Flujo+Capa. La API principal `tQ7mFTFbJ1SW` solo tiene como contenedor INTEGRACIÓN, y su grupo es API+ENTRADA+SALIDA: **no existe pareja asociable por JSON ni SVG**; solo quedaría geometría, prohibida.

## 6. Interfaz (E2E)

Verificado con el navegador integrado: carga JSON/SVG, análisis de 5 ejemplos, descarga de JSON Copilot y diagnóstico (10 archivos, JSON válido), multi-operación con SVG sintéticos de QR (3 páginas, sin fuga de IDs), cambio de operación, rechazo de SVG con `page-tab-id` ajeno y SVG hostil (script, `onload`, `foreignObject`, recursos externos, XXE) con 0 peticiones salientes.

## 7. Criterios de aceptación

| Criterio | Resultado |
|---|---|
| HTML usa el núcleo | Falla (F-01) |
| Build reproducible | Cumple (desde el kit v0.4.1) |
| Aislamiento y SVG seguro | Cumple |
| Contención | Cumple |
| Endpoints conservados | Cumple |
| Datos conservados | Falla (F-02) |
| Despliegue sin atribución por descarte | Falla (F-03) |
| Contrato sin señales contradictorias | Falla (F-03, F-04, F-08) |
| Skill: 41 IDs y ZIP idéntico | Cumple |
| Skill: CSV íntegro | Falla (F-12) |
| Skill: coherencia normativa | Parcial (F-13) |
| `AGENTS.md` (no publicar ejemplos/skills) | En riesgo (F-07) |

`npm test` 8/8, `npm run audit` y `npm run build` exit 0, `skill:validate` válido.

## 8. Recomendaciones para v0.4.3 (por prioridad)

1. Incrustar `src/` en el HTML desde `build.mjs` (o retirar las afirmaciones de "núcleo") y probar `dist/` comparando el export descargado con el del núcleo (F-01).
2. Un único clasificador; eliminar el fallback `'api'` (F-04).
3. Exportar `textAreas`, `customData` y `linkedData` de líneas, con `deepEqual` sobre el export descargado (F-02).
4. `deploymentPairs[]` explícito con candidatos (incluidos gestores y eventos) y estado `UNRESOLVED`/`DERIVED_UNIQUE`; nunca propietario al hijo ni a un ancestro (F-03, F-05).
5. Emitir como hechos los tokens de la 3.ª sección (entidad/utilidad/tarea, private/public/partner, Query/Event/Command); `ms-` solo como señal secundaria (F-06).
6. Marcar la leyenda por membresía de grupo con "NOTACIÓN"; `childRootContainerId` solo para dominios declarados (F-09, F-10).
7. Unificar versiones; corregir comillas del CSV y probar 10 columnas por fila (F-08, F-12).
8. Aclarar con el dueño de la norma el texto E1/E3 frente a CNT-004 (F-13).
9. Mantener el material fuera del remoto público y añadir prueba de ausencia de URLs en `dist/` (F-07).
10. Núcleo: raíces personalizadas, memoizar `reaches`, guardas contra `null`, `DUPLICATE_ID` y conexiones con extremos inexistentes (F-11, F-14).
