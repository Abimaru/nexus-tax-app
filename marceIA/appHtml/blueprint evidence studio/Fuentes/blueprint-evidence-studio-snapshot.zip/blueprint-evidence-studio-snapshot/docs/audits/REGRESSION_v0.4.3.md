# Regresión v0.4.3

Fecha: 2026-10-21.

## Hallazgos independientes

| Hallazgo | Resultado v0.4.3 |
|---|---|
| F-01 HTML desconectado | Corregido; bundle importa `src/index.js`, E2E compara descarga exacta |
| F-02 pérdida de conexiones | Corregido; `evidence.lines` es `deepEqual` al original |
| F-03/F-05 despliegue | Corregido con `deploymentPairs[]`, candidatos y propietario no inventado |
| F-04/F-06 clasificadores | Corregido; uno solo, tres secciones y `ms-` como señal |
| F-07 publicación | Mitigado localmente; rama pública debe tener historia independiente |
| F-08 versión | Corregido con `src/version.js` |
| F-09/F-11 raíces | Corregido: raíz estructural distinta de dominio; RECAUDOS/NEPA quedan personalizados |
| F-10 NOTACIÓN | Corregido por `contains` y grupos |
| F-12 CSV | Corregido; 41 filas × 10 columnas con parser real |
| F-13 norma | Pendiente de aprobación; propuesta trazable creada |
| F-14 robustez | Corregido para nulos, duplicados, referencias y cierre de descendientes iterativo |

## Resultados

- Unitarias/integridad: 13 PASS.
- E2E Edge: 3 PASS; incluye descarga HTML↔núcleo, 99/20, 170/78, 126/30, multipágina, fixture de dominio personalizado y SVG no correspondiente.
- Skill: validación estructural PASS; conflicto F-13 señalado como pendiente.
- Build: HTML autocontenido, sin URLs de red.

Los JSON Copilot y diagnóstico de cada blueprint se generan localmente en `artifacts/private-evidence/` y están excluidos de Git por sensibilidad.

## Revisión de estabilización adicional

- Corregida la promoción de candidato único a propietario de Flujo/Capa. Casos con un BPMNEvent, un contenedor hijo o varios componentes conservan candidatos y estado pendiente; `resolvedOwnerId` permanece `null`.
- Corregida la promoción de `Entidad/Utilidad/Tarea` a servicio y `Private/Public/Partner` a API. Se conservan como clasificación funcional e inferencia no confirmada.
- La propuesta F-13 fue reemplazada: E1/E3 no gestionados en dominio productor; E2 gestionado en INTEGRACIÓN. Conexión directa/declarada sigue pendiente por separado.
- Las capacidades visuales perdidas y su recuperación gradual están documentadas en `UI_RECOVERY_PROPOSAL_v0.4.3.md`.
