# Comparación v0.4.4 / v0.4.4.1

| Área | v0.4.4 | v0.4.4.1 |
|---|---|---|
| Dominio personalizado | No productor sin declaración | PRODUCER solo después de validar padre arquitectónico, fuente corporativa explícita |
| Rol principal | Candidatura contextual | Candidatura más escenario estructural separado |
| BDD | Asociada como evidencia auxiliar | No participa en rol ni escenario |
| Evento Inicio | No certificado | No requerido para identificación estructural; queda para norma |
| Nombres | Operación disponible | Página, componente, operación e hijo formalmente separados |
| Prefijo ms | guion/guion bajo/espacio | añade camel case `msX` sin aceptar `mservice` |
| Resultado | INFERRED/CANDIDATE | además STRUCTURALLY_CONFIRMED/SUPPORTED/AMBIGUOUS/UNRESOLVED |

No cambian el motor único, evidencia original, despliegue sin propietario inventado, multipágina, export diagnóstico ni las 41 reglas.
