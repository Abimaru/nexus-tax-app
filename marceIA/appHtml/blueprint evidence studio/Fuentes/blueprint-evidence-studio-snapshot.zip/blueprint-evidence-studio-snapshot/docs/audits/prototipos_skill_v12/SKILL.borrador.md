---
name: validar-blueprint-integracion
description: Valida por página blueprints de integración con el contrato compacto de Evidence Studio y las 37 reglas activas del catálogo normativo.
---

# Validador de blueprints de integración

Este archivo solo ordena el trabajo. Lo que se evalúa lo define cada regla; cómo se resuelven estados, precedencias, preguntas y métrica lo define `references/procedimiento.md`. No resumir ni reformular el texto de una regla: citarlo por ID.

## Lectura previa (completa, en este orden)

1. `references/procedimiento.md`
2. `references/contrato-compacto.md` y `references/guia-textareas.md`
3. `references/indice-reglas.md`, que indica en qué archivo está cada una de las 37 reglas y qué campos del contrato la sustentan
4. Todos los archivos de reglas que enumera el índice

## Pasos

1. **Validar contrato y páginas.** Aceptar la versión del contrato que declara el procedimiento; evaluar solo `metadata.selectedPageIds`; reconocer `metadata.omittedPages`; clasificar cada página y aplicar los controles previos de integridad (`procedimiento.md`).
2. **Identificar las reglas aplicables.** Cada página evaluable recibe las 37 reglas; la población de cada una la fija su propio texto.
3. **Consultar la regla.** Leer su bloque completo en el archivo indicado por el índice.
4. **Obtener la evidencia.** Usar los campos del contrato que enumera el índice y la «Evidencia mínima» de la regla. Un campo ausente, `null`, candidato o ambiguo no es evidencia positiva.
5. **Preguntar solo lo autorizado.** Las preguntas permitidas están en `procedimiento.md`. Registrar cada respuesta como `DECLARADO_POR_ANALISTA`.
6. **Emitir 37 resultados por página evaluable**, uno por ID, con los cuatro estados que define el procedimiento.
7. **Justificar cada resultado:** población evaluada, evidencia citada (campo e ID del componente), estado y dato pendiente.
8. **Calcular la métrica** con la fórmula del procedimiento.
9. **Informar lo pendiente:** reglas con criterio pendiente, evidencia faltante y preguntas sin responder.

## Autocomprobación antes de responder

37 IDs únicos por página evaluable; solo los cuatro estados; suma de estados igual a 37; cada resultado con su justificación; ningún ID que no figure en el índice.
