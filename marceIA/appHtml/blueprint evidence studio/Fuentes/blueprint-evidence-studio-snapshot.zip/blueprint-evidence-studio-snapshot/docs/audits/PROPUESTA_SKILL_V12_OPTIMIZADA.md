# PROPUESTA — SKILL V12 OPTIMIZADA (diseño; no se crea ZIP)

> Candidato, no aprobado. No modifica las reglas de la analista, la Skill v11.2.3, Evidence Studio, `AGENTS.md` ni el contrato compacto. C-01…C-13 siguen abiertas; esta propuesta no resuelve ninguna.
> Sustituye y concreta `ESTRUCTURA_SKILL_V12_PROPUESTA.md` con las medidas de `COMPARACION_ARQUITECTURAS.md`.

## 1. Arquitectura recomendada

**Siete archivos de reglas por familia (alternativa A), bloques de regla literales, un índice generado y un `SKILL.md` de 2,3 KB que no repite ninguna regla.** Evidencia: `COMPARACION_ARQUITECTURAS.md` §6.

### Tres capas de autoridad (para que lo operativo no cree normas)

| Capa | Quién la escribe | Contenido | Se edita en el repo |
|---|---|---|---|
| **N — Normativa** | La analista | 37 reglas (296 campos), principios generales, glosario, procedimiento de la analista | **No**: solo se importa de un paquete nuevo de la analista |
| **O — Operativa** | Evidence Studio | Cómo leer el contrato `copilot-factual-v0.4.6.1` (diccionario, `textAreas`, `pageClassification`, procedencia del dominio) | Sí, a mano, sin definir criterios de estado |
| **D — Derivada** | Scripts | Índice de reglas, hashes, trazabilidad, matrices de cobertura, ZIP | **Nunca** |

## 2. Contenido del ZIP (15 archivos, ≈ 142 KB, ≈ 39 600 tokens)

| Archivo | Capa | Origen | Bytes aprox. |
|---|---|---|---:|
| `SKILL.md` | O | Manual; borrador en `prototipos_skill_v12/SKILL.borrador.md` | 2 291 |
| `references/procedimiento.md` | N | Procedimiento de la analista (importado); encabezado regenerado | 6 658 |
| `references/operacion-evidence-studio.md` | O | Nuevo: lectura del contrato (tipo ≠ rol, procedencia de `domainRole`, `HIPOTESIS`/`CONFIRMADO` no son estados, `pageClassification` **[tratamiento sujeto a C-11, punto 9]**) | ≈ 3 000 |
| `references/contrato-compacto.md` | O | Diccionario vigente del repo, con «37 filas» | 5 319 |
| `references/guia-textareas.md` | O | Guía del repo; sin la «modalidad de API» (vive en API-001…003, una vez verificada la equivalencia) | 1 508 |
| `references/glosario-normativo.md` | N | Extraído literal del `MANIFEST` de la analista («Lenguaje normativo vigente», «Respuestas humanas autorizadas») | 1 351 |
| `references/indice-reglas.md` | D | Generado: ID, título, archivo, campos del contrato, pregunta a la analista, estado de la norma | ≈ 6 700 |
| `references/reglas-01-estructura.md` | N | CNT-001…005, EXT-001/002, GW-001 | ≈ 23 700 |
| `references/reglas-02-api-servicios.md` | N | API-001…004, SRV-001…004 | ≈ 20 900 |
| `references/reglas-03-eventos.md` | N | EVT-001…007 | ≈ 22 000 |
| `references/reglas-04-despliegue.md` | N | CA-001, FT-001 | ≈ 6 000 |
| `references/reglas-05-escenarios.md` | N | E1-001, E2-001, E3-001 | ≈ 11 200 |
| `references/reglas-06-modelos-comandos.md` | N | MOD-001, COM-001…005 | ≈ 19 500 |
| `references/reglas-07-gestores-colas.md` | N | MQ-001…003 | ≈ 9 600 |
| `references/obligaciones.sha256.txt` | D | 37 líneas: hash de los 8 campos de cada regla | 2 729 |

Sin carpetas de código, sin rutas fuera de `references/`, sin referencias a archivos externos al paquete.

## 3. Solo repositorio (no viajan en el ZIP)

| Elemento | Motivo |
|---|---|
| `norma/fuente-analista/` (7 archivos, procedimiento, `MANIFEST`, `SHA-256` del ZIP de origen) | Fuente única; solo lectura |
| `norma/estado-normativo.json` | Por ID: estado de definición, decisiones C-xx, aprobación; no es texto normativo |
| `norma/decisiones.md` (C-01…C-13) y `trazabilidad/ids-41-a-37.csv` | Historia y decisiones abiertas |
| `MATRIZ_NORMA_EVIDENCIA_37.csv`, cobertura, verificabilidad | Análisis técnico |
| Las 148 pruebas y las 99 fichas sintéticas | Verificación |
| `CHANGELOG`, `historico/v11.x/` | Aislar los 41 |
| `obligaciones-campos.sha256.json` (296 hashes) | Verificación previa al empaquetado; en el ZIP solo viaja el hash por regla |
| Scripts de importación, generación y verificación | Construcción |

## 4. Se generan automáticamente

`indice-reglas.md` · `obligaciones.sha256.txt` · `obligaciones-campos.sha256.json` · encabezados de los siete archivos de reglas · `trazabilidad/ids-41-a-37.csv` (a partir del mapeo manual) · `cobertura.csv` · el ZIP.
**Se mantienen a mano:** `SKILL.md`, `operacion-evidence-studio.md`, `contrato-compacto.md`, `guia-textareas.md`, `norma/estado-normativo.json`, `norma/decisiones.md`, el mapeo 41→37 y las fichas de prueba.

## 5. Contenido duplicado que puede eliminarse

| Elemento | Bytes | Por qué es seguro |
|---|---:|---|
| `catalogo-reglas-v11.2.csv` | 16 141 | 41 reglas históricas; copia de las reglas |
| `MATRIZ-EVIDENCIA-37.md` | 10 164 | Se sustituye por el índice (no parafrasea la evidencia mínima) |
| Inventario y cambios 41→37 del `MANIFEST` | ≈ 6 000 | Derivable / histórico (queda en el repo) |
| Estados, métrica, preguntas, precedencias, controles de integridad en `SKILL.md` | ≈ 3 600 | Ya están en el procedimiento |
| `INSTRUCCIONES-AGENTE-V11.md` | 1 059 | Repite `SKILL.md`/procedimiento y dice «41 filas» |
| `CHANGELOG-V11.md` | 885 | Historia |
| Modalidad de API en `GUIA-TEXTAREAS` | ≈ 1 200 | Triplicada en API-001…003 y procedimiento §7 (verificar equivalencia antes) |

**No se elimina:** ninguna de las 28 frases que se repiten dentro de las reglas (≈ 7,6 KB): son texto normativo literal de cada regla.

## 6. Fuente canónica: cómo mantener cada elemento

| Elemento | Dónde vive | Cómo se garantiza |
|---|---|---|
| 37 IDs | Encabezados de los bloques de `norma/fuente-analista/` | El índice, el inventario y los conteos se calculan; ningún número se escribe a mano |
| 296 campos | Mismos bloques | Hash por campo (`obligaciones-campos.sha256.json`); la prueba de empaquetado compara los archivos generados con esos hashes |
| Hash por obligación | `obligaciones.sha256.txt` (ZIP) | Permite a la analista comprobar el paquete instalado |
| Decisiones abiertas | `norma/decisiones.md` + `estado-normativo.json` | El índice marca `pendiente`/`condicionada`; la Skill las informa, no las resuelve |
| Historial 41→37 | `trazabilidad/ids-41-a-37.csv` | 41 filas, un ID histórico cada una; prueba de que ningún ID retirado se usa como vigente |
| Pruebas de aceptación | `pruebas/` | Las fichas referencian reglas por ID; la prueba falla si el ID no existe |

**Una sola fuente editable:** el repositorio no contiene un segundo catálogo de reglas editable. Para cambiar una regla se importa un paquete nuevo de la analista (la importación rechaza cualquier cambio que no venga de ella y recalcula los hashes). Los archivos de reglas del ZIP son una copia generada, no una fuente.

## 7. `SKILL.md` propuesto

Borrador completo en `docs/audits/prototipos_skill_v12/SKILL.borrador.md` (2 291 bytes, ≈ 640 tokens). Estructura:

1. **Lectura previa en orden:** procedimiento → contrato y guía → índice → archivos de reglas que enumera el índice.
2. **Nueve pasos** exactamente como se pidió: validar contrato y páginas; identificar reglas aplicables; consultar la regla; obtener evidencia; preguntar solo lo autorizado; emitir 37 resultados por página evaluable; justificar; calcular la métrica; informar lo pendiente.
3. **Autocomprobación:** 37 IDs únicos, cuatro estados, suma 37, justificación, ningún ID fuera del índice.

Propiedades: no copia ninguna frase de las reglas (comprobado con el verificador, prueba M7); no menciona IDs retirados (M4); no nombra archivos de reglas concretos, de modo que el mismo `SKILL.md` sirve para la arquitectura A, B o C; no define estados, métrica ni preguntas: remite al procedimiento.

Tres puntos del borrador dependen de decisiones abiertas y se marcan, no se resuelven: **tratamiento de plantillas y de `UNRESOLVED`** (C-11 punto 9, `operacion-evidence-studio.md`); **resultado de SRV-001 y SRV-002** (C-01; el paso 9 las informa como pendientes); **nombre y versión del paquete** (C-02).

## 8. Correcciones que la v12 exige y que no tocan la norma

| Archivo de origen | Corrección | Quién la aprueba |
|---|---|---|
| Procedimiento de la analista | Título «v11.2.1»; añadir `pageClassification` (hoy ausente) | Analista (es su archivo) — si no, se resuelve en `operacion-evidence-studio.md` |
| `contrato-compacto.md` | «41 filas» → «37 filas»; mantener `pageClassification`, `groups`, `containedComponentIds` | Andrés |
| Encabezados de reglas | Quitar «v11.2.1» | Generación |
| `operacion-evidence-studio.md` | **No** heredar de v11.2.3: la exigencia de Inicio «no se extiende a CNT-002», «CA-001: existencia y nombre», «duda de población», CNT-006 | Andrés |
| `validate-skill-zip.mjs`, `package-skill.ps1`, `test/skill.test.js`, `qa/skill.lock.json` | Dejar de exigir CSV y matriz de 41; validar 37 IDs, hashes y referencias | Andrés (cuando se implemente) |

## 9. Respuestas a las preguntas finales

- **Permanecen en el ZIP:** los 15 archivos de la §2.
- **Solo repositorio:** los de la §3.
- **Se generan:** los de la §4.
- **Duplicado eliminable:** la §5 (≈ 39 KB, 24 % del paquete de la analista).
- **Riesgos de compatibilidad:** `PLAN_PRUEBAS_CARGA_REFERENCIAS.md` §4.
- **Pruebas pendientes en Copilot:** `PLAN_PRUEBAS_CARGA_REFERENCIAS.md` §3 (T-01…T-12).

## 10. Condiciones previas a generar el ZIP

1. C-02: nombre y versión del paquete.
2. C-01: qué hace la Skill con SRV-001/002.
3. C-11 (puntos 1–9): erratas y presentación de plantillas.
4. Catálogo aprobado por la analista, con hash fijado.
5. Resultado favorable de T-01…T-05 en el Copilot (la arquitectura A depende de que lea `references/` bajo demanda).
6. Andrés aprueba el plan de migración del QA y actualiza `AGENTS.md`.
