# RECONCILIACIÓN DE CORRECCIONES — Iteración 3.1

> Candidato, no aprobado. Fecha 26/10/2026. Sin cambios en las obligaciones de la analista, en la Skill v11.2.3, en `src/`, `ui/`, `AGENTS.md` ni en el contrato compacto. Sin ZIP, sin evaluador, sin commit/push/merge/PR. Ninguna versión se declara estable.

## 1. Documentos corregidos

`CATALOGO_NORMATIVO_37_CANDIDATO.md`, `MATRIZ_NORMA_EVIDENCIA_37.csv`, `DECISIONES_Y_PRUEBAS_PENDIENTES.md` (regenerados desde datos únicos), `CONTRATO_EVIDENCIA_OBJETIVO.md` (se añade EC-11), `AUDITORIA_CANONICA_37.md`, `MATRIZ_COBERTURA_PROPUESTA.md`, `PRUEBAS_EJECUTABLES_CANDIDATAS.md`, `PLAN_MIGRACION_QA_41_A_37.md`, `ESTRUCTURA_SKILL_V12_PROPUESTA.md`. Nuevo: `INVESTIGACION_CNT002_2026-10-26.md`.

## 2. Hallazgo → corrección

| Hallazgo de la auditoría | Corrección aplicada |
|---|---|
| Dependencias C-01…C-13 faltantes o incorrectas | Una sola fuente (el registro de decisiones, ampliado con las dependencias que el texto literal justifica); C-02 y C-03 pasan a columna «condiciones globales». Tabla de cambios abajo |
| COM-002: campo JSON inexistente | No había campo inexistente; abreviaturas sustituidas por `endpoint1.style`, `endpoint2.style`, `connectedTo`; `DECLARADO_POR_ANALISTA` marcado como registro de la Skill |
| IDs históricos absorbidos sin trazabilidad | `id_historico` ampliado (CNT-006, EXT-002, EVT-004, CA-002, FT-002, MQ-002, MQ-003, MQ-004 antiguos) y anexo 41 → 37 en el catálogo |
| Verificabilidad sobrestimada | 5 / 16 / 14 / 2 con cobertura de población (tabla de movimientos) |
| Conteos de pruebas incorrectos | Derivados de un solo módulo para los tres documentos: 72 / 25 / 51 |
| Alcance de cobertura por población | Atributo `cobertura_poblacion` por regla (catálogo, matriz, MATRIZ_COBERTURA) |
| Texto literal | No tocado: 296/296 campos idénticos (auditor independiente) |

### 2.1 Cambios de etiquetas de decisión (específicas de la regla)

| Regla | Antes | Ahora |
|---|---|---|
| API-003 | C-04 | C-04, C-09, C-11 |
| SRV-003 | C-05, C-04 | C-04, C-05, C-09, C-11 |
| EVT-002 | C-04, C-06 | C-04, C-06, C-09 |
| COM-002 | C-05, C-04, C-12 | C-04, C-05 |
| COM-003 | C-05, C-04, C-12 | C-04, C-05 |
| COM-004 | C-12 | — |
| MQ-003 | C-05, C-07 | C-04, C-05, C-07 |

Justificación textual: C-06 figuraba en el catálogo para EVT-001/002/003/007 pero faltaba en el registro; se añadió al registro (su obligación recae sobre el «evento de integración»). En la tabla sólo aparecen las reglas cuyo conjunto cambió (C-02/C-03 se retiran de las etiquetas por regla y pasan a la columna global). API-003 y SRV-003 → C-09 («específica, no genérica», «texto de plantilla»); API-003 → C-11; COM-002/003/004 sin C-12 (el texto usa «figura que la represente inequívocamente», no «relación identificable»). Si la analista considera que C-12 también cubre COM-002/003, basta añadir esas filas al registro: no afecta a ningún otro valor.

## 3. Investigación CNT-002

Ver `INVESTIGACION_CNT002_2026-10-26.md`. Resumen: la afirmación «inalcanzable por HIPOTESIS» es **falsa**; el nombre ausente/vacío/espacios/genérico/plantilla es demostrable con escenario `E1/HIPOTESIS`. «No existe hijo», «existe más de uno» y «dominio distinto» no se demuestran hoy porque el motor pierde el patrón cuando el hijo es defectuoso: **B (limitación del motor) + D (ambigüedad normativa)**, no A. La circularidad está en el motor, no en la norma. Brecha propuesta: EC-11. Sin exigir Inicio.

## 4. Verificabilidad definitiva

| Nivel | Reglas |
|---|---|
| VERIFICABLE_HOY | 5 |
| VERIFICABLE_PARCIAL | 16 |
| CON_BRECHA | 14 |
| PENDIENTE_NORMATIVO | 2 |
| **Total** | **37** (cada regla una vez; grupos excluyentes) |

Movimientos respecto del cuadro de la Iteración 2 (12 / 8 / 15 / 2):

| Regla | Antes | Ahora | Cobertura |
|---|---|---|---|
| CNT-002 | VERIFICABLE_HOY | VERIFICABLE_PARCIAL | PARCIAL |
| API-001 | VERIFICABLE_HOY | VERIFICABLE_PARCIAL | PRINCIPAL |
| API-002 | VERIFICABLE_HOY | VERIFICABLE_PARCIAL | PRINCIPAL |
| API-003 | VERIFICABLE_HOY | VERIFICABLE_PARCIAL | PRINCIPAL |
| COM-001 | VERIFICABLE_HOY | VERIFICABLE_PARCIAL | SUBPOBLACION |
| COM-004 | VERIFICABLE_HOY | VERIFICABLE_PARCIAL | SUBPOBLACION |
| MQ-001 | VERIFICABLE_HOY | VERIFICABLE_PARCIAL | COMPLETA |
| MQ-002 | CON_BRECHA | VERIFICABLE_PARCIAL | SUBPOBLACION |

Respaldo de las cinco `VERIFICABLE_HOY` (cobertura COMPLETA para su población normativa; la ausencia de candidatas sin prefijo de CA-001/FT-001 sólo afecta a No aplica, que queda «con reserva»):

| Regla | Cobertura | Cumple | No cumple | No verificable | No aplica |
|---|---|---|---|---|---|
| GW-001 | COMPLETA | DEFINITIVA | DEFINITIVA | DEFINITIVA | DEFINITIVA |
| API-004 | COMPLETA | DEFINITIVA | DEFINITIVA | DEFINITIVA | DEFINITIVA |
| SRV-004 | COMPLETA | DEFINITIVA | DEFINITIVA | DEFINITIVA | DEFINITIVA |
| CA-001 | COMPLETA | DEFINITIVA | DEFINITIVA | BLOQUEADA_POR_CONTRATO | CON_RESERVA |
| FT-001 | COMPLETA | DEFINITIVA | DEFINITIVA | BLOQUEADA_POR_CONTRATO | CON_RESERVA |

## 5. Pruebas (148 = 37 × 4)

| Categoría | Pruebas |
|---|---|
| EJECUTABLE_DEFINITIVA | 72 |
| BLOQUEADA_POR_CONTRATO | 4 |
| EJECUTABLE_CON_RESERVA | 25 |
| BLOQUEADA_POR_DECISION_NORMATIVA | 21 |
| BLOQUEADA_POR_CONVENCION | 26 |
| **Ejecutables** | **97** (72 definitivas + 25 con reserva) |
| **Bloqueadas** | **51** |

Frente a la cifra esperada 74 / 23 / 51: **72 / 25 / 51**. La diferencia son PA-CA-001-NA y PA-FT-001-NA: el motor reconoce Capas y Flujos sólo por prefijo de nombre, así que «sin Capas ni candidatas» no puede demostrarse (C-03) y pasan a «con reserva». Las 51 bloqueadas no cambian.

Hay 99 fichas para 97 combinaciones (CNT-002-NC y API-004-NV tienen dos variantes). **Las 99 reproducen sus precondiciones contra el motor actual**; eso no equivale a un resultado normativo aprobado: la expectativa sigue siendo candidata hasta que la analista la apruebe y la Skill la confirme. No se fijó ninguna expectativa para SRV-001/002 ni para C-01…C-13.

## 6. Validación de consistencia (`validate-iter31.mjs`, 17 comprobaciones)

| Comprobación | Resultado |
|---|---|
| 1. 37 IDs únicos (catálogo = matriz = datos, mismo orden) | OK |
| 2. Bloques A/B/C por regla | OK |
| 2b. 296 campos normativos idénticos a la fuente (auditor independiente, 100 831 caracteres) | **0 diferencias** |
| 3. Verificabilidad 5/16/14/2; HOY ⇒ cobertura COMPLETA; NINGUNA ⇒ brecha o pendiente | OK |
| 4. Dependencias C-xx idénticas en catálogo, matriz, registro y documento de decisiones; C-02/C-03 sólo globales | OK |
| 5. Trazabilidad: 41 IDs únicos; cada ID vigente es destino; absorbidos en `id_historico`; anexo de 41 filas | OK |
| 6. Campos JSON: sólo quedan 5 identificadores que no son clave de los compactos (valores de enumeración `BPMNGateway`, `SISTEMA_EXTERNO_AUXILIAR`, `INVOCADO`; registro de la Skill `DECLARADO_POR_ANALISTA`) | OK, marcados |
| 7. 148 combinaciones; mismas cifras en pruebas y decisiones; SRV-001/002 bloqueadas | OK |
| 8. Sin cifras obsoletas (118/98, 74/23) en los documentos candidatos | OK |
| `src/`, `ui/`, `skills/`, `qa/`, `AGENTS.md` | Sin modificación en esta iteración (marcas de tiempo del 23–25/10; ningún archivo de esas rutas con cambio en las últimas 6 horas) |

Nota: DEFINIDA / CONDICIONADA / PENDIENTE se mantiene como en la Iteración 2 (23 / 12 / 2); depende de si la decisión puede cambiar la obligación, no de la presencia de una etiqueta C-xx.

## 7. Condiciones para crear una Skill v12 candidata

Ver `ESTRUCTURA_SKILL_V12_PROPUESTA.md` §5 (11 condiciones). Las que no dependen de este trabajo: C-02, C-01, C-11, C-03, aprobación del catálogo corregido, actualización de `AGENTS.md`, EC-08, plan de migración del QA.

## 8. Veredicto

**PENDIENTE_DE_DECISION_NORMATIVA**

- Los documentos candidatos son internamente consistentes (§6, sin fallos; texto literal 296/296), así que no corresponde NO_APTO_POR_INCONSISTENCIA.
- No puede declararse APTO_PARA_EMPAQUETADO_CANDIDATO porque el paquete exige decisiones que no se resuelven por inferencia: **C-02** (nombre y versión del paquete; `AGENTS.md` sigue hablando de 41 reglas), **C-01** (SRV-001/002 en esqueleto: el paquete llevaría dos reglas sin criterio), **C-11** (erratas, incluida la presentación de plantillas, que hoy contradice el SKILL de la analista) y la **aprobación del catálogo corregido** con su hash.
- Queda además una pregunta nueva para la analista vinculada a C-03 (CNT-001/CNT-002 con hijo o dominio defectuoso) y una brecha de extractor propuesta (EC-11).
