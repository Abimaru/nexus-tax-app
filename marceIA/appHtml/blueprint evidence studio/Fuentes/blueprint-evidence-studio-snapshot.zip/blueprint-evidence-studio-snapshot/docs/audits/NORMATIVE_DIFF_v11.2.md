# Matriz de modificaciones normativas v11.2.0, corregida en v11.2.1

La comparación celda a celda confirma 41 IDs: tres obligaciones cambiaron por F-13 y 38 permanecieron literalmente intactas.

| ID | Cambio textual autorizado |
|---|---|
| CNT-002 | E1/E3: hijo no gestionado dentro del DOMINIO PRODUCTOR; E2: gestionado dentro de INTEGRACIÓN |
| E1-001 | Hijo no gestionado con dominio efectivo DOMINIO PRODUCTOR |
| E3-001 | Principal e hijo no gestionados dentro del mismo DOMINIO PRODUCTOR |

E2-001 y CNT-004 no cambiaron de texto. Están relacionados conceptualmente con F-13, pero no se contabilizan como modificaciones. Los otros 38 IDs conservan sus obligaciones. v11.2.1 solo cambia procedimiento y métricas al modelo de cuatro estados; no reescribe ninguna obligación.

La decisión conexión directa frente a conexión declarada permanece pendiente y no se reinterpreta.
