# Comparación v0.4.4.2 → v0.4.5.0

| Área | v0.4.4.2 | v0.4.5.0 |
|---|---|---|
| Productor personalizado | Convención general | Único por operación y evidencia estructural |
| Escenario con evento genérico | STRUCTURALLY_CONFIRMED | HIPOTESIS |
| Evento Inicio explícito | Sin efecto | CONFIRMADO |
| Grupos | Evidencia cruda | Grafo factual consultable |
| Flujo/Capa | Siempre pendiente | Resuelto solo por grupo superior inequívoco |
| UI | JSON/SVG básicos | Metadatos, hasta 10 SVG, páginas, detalles y Limpiar |
| Skill | 11.1.1 | 11.1.2 operativa; normativa intacta |

No se certifican colores, formas o iconos desde SVG. La geometría no sustituye IDs ni grupos.
