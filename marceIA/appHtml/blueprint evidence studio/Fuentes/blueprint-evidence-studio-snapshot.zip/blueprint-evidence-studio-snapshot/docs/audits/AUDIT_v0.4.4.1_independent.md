# Auditoría independiente — Blueprint Evidence Studio v0.4.4.1

Fecha: 2026-10-22. Rama: `feature/evidence-studio-v0.4.4.1-private`, HEAD `24d3848`. Auditoría de solo lectura: sin modificar código, sin commits y sin publicar. Los scripts de prueba viven fuera del repositorio.

## 1. Resumen ejecutivo

**Veredicto: APTO CON RESERVAS** para pruebas funcionales supervisadas de Copilot con blueprints E1/E2 reales. **E3 no está certificado**: solo existe un fixture sintético.

Se sostiene:
- Los casos reales Oski (E1) y Currency Exchange (E2) coinciden con una reconstrucción independiente hecha desde las relaciones originales de Lucidchart (contención, extremos de la conexión y clase de cada figura).
- Integridad factual confirmada en las 25 páginas de las 7 fuentes: figuras, líneas, grupos, capas, conexiones (extremos, etiquetas, `customData`) y secciones de texto idénticos al original. No hay dictámenes de cumplimiento calculados. Cada figura tiene un único padre directo.
- El HTML distribuible es el motor probado: reconstruido con `ui/`, `src/` y esbuild sale idéntico byte a byte a `dist/BlueprintEvidenceStudio.html`; sin URLs remotas; declara v0.4.4.1.
- Pruebas: `npm test` 26/26 y `test:e2e` 3/3 sobre el HTML.

No se sostiene:
- Existen contraejemplos que producen un escenario falso, incluso `STRUCTURALLY_CONFIRMED` (§3).
- La Skill v11.1 contradice la convención corporativa de productor.
- Páginas de plantilla/leyenda salen como E1 confirmado en 4 de las 7 fuentes.

## 2. Matriz de validación E1/E2/E3

| Caso | Reconstrucción independiente | Resultado del motor | ¿Coincide? |
|---|---|---|---|
| E1 Oski | `wniB5n~8CzU8` (`None`) → `wniB.7Dl~hrs` → evento `wniBqOut_oya` (`Arrow`). Origen INTEGRACIÓN. Evento en `20QoxCoCdtvE`, hijo de `20QoN3lLcXy.` ("Recaudos") | E1, `STRUCTURALLY_CONFIRMED`, `mainApi`, Recaudos = PRODUCER por `CORPORATE_PARENT_DOMAIN_CONVENTION`, `inferenceUsed:true` | Sí |
| E2 Currency | `tQ7mFTFbJ1SW` → `gT7m.rKo0qu-` → `iQ7mp2EXtgT-` dentro de `TJ7m.cKnR-~v` (cadena INTEGRACIÓN > Flujo > Capa). Origen y destino INTEGRACIÓN | E2, `STRUCTURALLY_CONFIRMED`, `mainApi`, `inferenceUsed:false` | Sí |
| E3 | Solo fixture sintético | E3 confirmado con servicio, evento e hijo en el mismo dominio productor personalizado | No certificable sobre blueprint real |

Comprobaciones adicionales:
- Oski conserva por separado `pageName=msDebitAccountPayment`, `mainComponentOperation=debitAccountPayment`, `mainComponentName="CollectionBillPayment - payBill 1.0.0"` y `mainChildServiceName=msDebitAccountPayment`.
- BDD: `bddEvidenceUsed:false`; `extractBddEvidence` no se invoca; alterar la página BDD no cambia resultados.
- Evento BPMN: genérico (`subtype:null`, `subtypeStatus:NOT_REQUIRED_FOR_STRUCTURAL_IDENTIFICATION`); ninguno se certifica como Inicio.
- Parejas Flujo/Capa de E2: `resolvedOwnerId` es `null` en las tres, incluso con candidato único (`4Oc~` → gestor, `AwQG` → evento); `x6OM` con múltiples candidatos.
- Barrido de las 7 fuentes: un oráculo propio (`None→Arrow` entre una clase UML que no sea Query/Command/Event y un `BPMNEvent`) coincide con el motor en las 25 páginas (un candidato por página operativa).

Dominios (clase original y rol): INTEGRACIÓN → INTEGRATION; RECAUDOS, EVC Transferencias y NEPA - NUEVAS EXPERIENCIAS → PRODUCER por convención; SISTEMAS EXTERNOS → EXTERNAL_SYSTEM; todos `UMLRectangleContainerBlock`. Ningún Flujo, Capa, hijo, grupo auxiliar ni elemento de NOTACIÓN se clasificó como productor en los ejemplos.

## 3. Hallazgos por severidad

| ID | Sev. | Hallazgo | Evidencia |
|---|---|---|---|
| H-1 | Alta | `scenario` y `mainRole` se emiten (`SUPPORTED`) sin dominio destino resuelto o con destino en SISTEMAS EXTERNOS | `src/roles.js:34`: `null !== 'INTEGRATION'` basta para plantear E1 (`support:PRODUCER_UNVERIFIED`). Reproducido en Debit p2/p3 |
| H-2 | Alta | El patrón se confirma con el componente principal **dentro** del hijo | `roles.js:30-35,48` no lo exige; `05-reglas-escenarios.md:9,39` dice "fuera del hijo". Contraejemplo sintético: E2 y E3 `CONFIRMED` |
| H-3 | Alta | Un contenedor envolvente sobre INTEGRACIÓN se vuelve la única raíz (PRODUCER) y E2 pasa a E3 confirmado | `src/containment.js:47,61-62` |
| H-4 | Alta | "INTEGRACIÓN - MCI" o "Integración (nuevo)" se tratan como PRODUCER y dan E3 confirmado | `containment.js:59-62` compara solo nombres exactos |
| H-5 | Media | Páginas de plantilla/leyenda (título `" "`, con NOTACIÓN y un "Nombre Servicio") salen E1 `CONFIRMED` | `5S7mT.gJDf1y` en VA p3, Ejemplo_BP p3, Mortgage p2, QR p4 |
| H-6 | Media | `inferredArchitecturalType` (`api`/`service`) deriva de la topología, no de la clasificación funcional | `ms-pagos`/"Utilidad" en INTEGRACIÓN→INTEGRACIÓN sale `mainApi`/E2 `CONFIRMED`; Oski ("Tarea") y E2 ("Entidad") salen `api` |
| H-7 | Media | Orientación ambigua o `None↔None` produce `scenario` poblado con `SUPPORTED` y conflicto | `roles.js:22-24,48` |
| H-8 | Media | Contratos y Skill contradictorios | `COPILOT_JSON_CONTRACT.md` aún dice "dominios personalizados quedan `UNCLASSIFIED`"; la convención dice PRODUCER |
| H-9 | Baja | `NOTACION` se busca como subcadena: "Anotación de cuenta" queda como `OTHER` | `lucidchart.js:44`, `containment.js:49` |
| H-10 | Baja | Con candidatos múltiples el resultado es `AMBIGUOUS` aunque solo uno tenga orientación válida (falla segura, puede ocultar la API principal) | `roles.js:47` |
| H-11 | Baja | `normativeEvaluation` no existe cuando el escenario es `UNRESOLVED`/`AMBIGUOUS` | `roles.js:46-47` (las 7 páginas BDD) |
| H-12 | Baja | `MS-`, `Ms-`, `MS_` en mayúsculas ya no cuentan como señal; `ms-` vacío sí | `src/classifier.js:31` (v0.4.3 era case-insensitive) |
| H-13 | Baja | `package.json` dice `0.4.4-1`, el motor `0.4.4.1` | `package.json` vs `src/version.js` |

Lo que resiste: inverso (`None` en el evento) sin candidato; evento inexistente → `UNRESOLVED`; NOTACIÓN y Query/Command/Event excluidos; orígenes en dominios distintos en E3 → `UNRESOLVED`; mayúsculas, tildes y espacios normalizados; componentes sin 3.ª sección sin resolver; `ms-`, `ms_`, `ms `, `msCamel` como señal sin exigirla; la inferencia del principal no se extiende a otros UML (los invocados quedan `CLASS_IDENTIFIED_ROLE_UNRESOLVED`).

## 4. Falsos positivos y negativos

- **Falsos positivos:** H-1 a H-7.
- **Falsos negativos:** H-9; H-10 (un servicio invocado con `None→Arrow` a otro evento deja la página en `AMBIGUOUS`); un hijo dibujado como `UMLRectangleContainerBlock` en vez de `RectangleContainerBlock` no se reconocería como hijo.

## 5. Riesgos de interpretación por Copilot

- La Skill (`SKILL.md:17`, `INSTRUCCIONES-AGENTE-V11.md:13`) prohíbe llamar productor a un dominio personalizado sin evidencia; el motor lo hace por convención. Los anexos propuestos no están incorporados.
- `scenario:"E1"` con `SUPPORTED` se puede leer como hallazgo aunque falte el dominio destino (H-1).
- `00-procedimiento.md` trata el diagnóstico derivado solo como advertencia, así que Copilot probablemente ignore `structuralScenario`.
- F-13 sigue pendiente: el texto "hijo fuera del dominio productor" de E1-001/E3-001 choca con CNT-004. El motor ubica el hijo dentro del productor, coherente con la definición confirmada en `NORMATIVE_CORRECTION_PROPOSAL_v11.1.md`, no con el texto oficial.

## 6. Revisión de la Skill

- Hoy no menciona `rootContainers`, `architecturalRoleCandidates`, `structuralScenario` ni `STRUCTURALLY_CONFIRMED`; desde `fcc67ac` solo cambió `SKILL.md` (nota F-13) y el CSV.
- Con el contrato actual, sin cambios, Copilot recalculará E1/E2/E3 por su cuenta y tratará el escenario del motor como advertencia. No se rompe nada, pero se pierde el valor del contrato.
- Cambios operativos obligatorios (sin tocar las 41 reglas ni resolver F-13): reconciliar la frase sobre dominio personalizado con `CORPORATE_PARENT_DOMAIN_CONVENTION`; declarar que `STRUCTURALLY_CONFIRMED` no es cumplimiento; citar la fuente de inferencia cuando `inferenceUsed:true`; indicar que páginas de plantilla/leyenda no son operaciones.

## 7. Cambios recomendados

**Obligatorios antes de pruebas funcionales amplias**
1. H-1: no emitir `scenario`/`mainRole` si el destino no tiene rol resuelto o es SISTEMAS EXTERNOS; dejar solo la hipótesis.
2. H-2: exigir componente principal fuera del hijo.
3. H-3 y H-4: excluir de la convención las raíces envolventes que contienen otro dominio y las variantes no exactas de INTEGRACIÓN/SISTEMA EXTERNO (sin resolver, no PRODUCER).
4. H-5: marcar páginas con contenedor NOTACIÓN (`pageKind`/`containsNotationLegend`) y no confirmar escenarios en ellas.
5. H-8: actualizar `COPILOT_JSON_CONTRACT.md` y la Skill.

**Opcionales**
6. H-6: separar `inferredArchitecturalType` (topológico) de la clasificación funcional o marcar la divergencia.
7. H-7, H-9, H-11, H-12, H-13.
8. Añadir al E2E un oráculo independiente del motor, además de comparar UI contra núcleo.

## 8. Resultados de pruebas ejecutadas

| Prueba | Resultado |
|---|---|
| `npm test` | 26/26 PASS |
| `npm run test:e2e` (Edge, HTML distribuible) | 3/3 PASS |
| Reconstrucción de `dist/` | Idéntica byte a byte |
| URLs remotas en `dist/` | 0 |
| Integridad vs originales (25 páginas) | Sin diferencias; solo H-11 (`normativeEvaluation` ausente en escenarios sin candidato) |
| Contraejemplos sintéticos | 33 casos; los falsos positivos son H-1 a H-4, H-6 y H-7 |
