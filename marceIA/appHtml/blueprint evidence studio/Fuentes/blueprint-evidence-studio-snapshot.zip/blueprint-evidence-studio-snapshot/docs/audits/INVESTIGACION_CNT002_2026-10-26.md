# Investigación CNT-002 — «la rama No cumple es inalcanzable porque el escenario está en HIPOTESIS»

> Candidato, no aprobado. No cambia el texto de CNT-002, no introduce el Inicio certificado en CNT-002 y no resuelve C-01…C-13.

## 1. Veredicto sobre la afirmación

**La afirmación es falsa tal como se formuló.** El escenario en `HIPOTESIS` no es un obstáculo: CNT-002 no pide escenario confirmado, sino «patrón estructural E1, E2 o E3 identificable» (Evidencia, Cumple y No cumple), y las decisiones R-02 y R-20 lo confirman («aunque el cumplimiento integral del escenario no esté confirmado»; «No se requiere identificar ni certificar un evento BPMN de Inicio»). `HIPOTESIS` es precisamente «patrón identificado, escenario sin confirmar».

Lo que sí es cierto es otra cosa, más acotada: **tres de las cuatro familias de la viñeta No cumple no pueden demostrarse hoy** porque el motor deja de identificar el patrón cuando el hijo es defectuoso.

## 2. Texto literal que gobierna (sin modificar)

- **No cumple:** «El patrón estructural aplicable y la cobertura del inventario están certificados, y se demuestra al menos una de las siguientes situaciones: no existe un contenedor hijo principal; existe más de uno; el único hijo principal está ubicado en un dominio arquitectónico diferente del exigido; o su nombre está ausente, vacío, compuesto únicamente por espacios, es genérico o corresponde a un texto de plantilla.»
- **No verificable:** incluye «no puede certificarse cuál es el hijo principal» y «existen varios candidatos sin que pueda determinarse cuál cumple ese rol».

## 3. Resultados medidos en el motor (fixtures sintéticos, `src/` sin modificar)

| # | Fixture mínimo | Escenario publicado | Hijo principal | Ramas de No cumple |
|---|---|---|---|---|
| 1 | API en INTEGRACIÓN; hijo `ms-payment-status` ⊃ evento en DOMINIO PRODUCTOR; línea api→evento | E1 / HIPOTESIS | `child` (`HIJO_PRINCIPAL`) | base (Cumple) |
| 8 | ídem, nombre del hijo vacío | E1 / HIPOTESIS | `child` | **nombre ausente: demostrable** |
| – | ídem, nombre `   ` (sólo espacios) | E1 / HIPOTESIS | `child` | **nombre sólo espacios: demostrable** |
| 9 | ídem, nombre `Service` | E1 / HIPOTESIS | `child` | **genérico: demostrable con criterio (C-09)** |
| – | ídem, nombre `NOMBRE SERVICIO` | E1 / HIPOTESIS | `child` | **plantilla: demostrable con lista cerrada (C-09)** |
| 2 | sin hijo (INTEGRACIÓN con API; productor vacío) | `NO_DETERMINADO`, `NO_COMPLETE_STRUCTURAL_ROLE_CANDIDATE`, página `UNRESOLVED` | ninguno | «no existe»: **no demostrable** |
| 6 | dos hijos con evento y línea desde la API, ambos en el productor | `NO_DETERMINADO`, `MULTIPLE_STRUCTURAL_CANDIDATES` | ninguno | «más de uno»: **no demostrable** (el patrón se pierde) |
| 7 | dos contenedores en el productor, sólo uno con evento y línea | E1 / HIPOTESIS | `child`; `child2` queda sin rol | «más de uno»: **ambiguo** (¿`child2` es candidato?) |
| 3 | hijo con evento en SISTEMAS EXTERNOS | `NO_DETERMINADO`, `NO_COMPLETE_STRUCTURAL_ROLE_CANDIDATE` | ninguno (el contenedor figura como `SERVICIO_HIJO` con dominio SISTEMAS EXTERNOS) | «dominio distinto»: **no demostrable** |
| 4 | hijo con evento fuera de todo dominio | `NO_DETERMINADO` | ninguno (`possibleDomainRoles` PRODUCER/EXTERNAL_SYSTEM) | dominio indeterminado → No verificable |
| 5 | API en el productor, hijo en INTEGRACIÓN | `NO_DETERMINADO` | ninguno | «dominio distinto»: **no demostrable** |
| 10 | hijo sin evento ni línea | `NO_DETERMINADO`, página `UNRESOLVED` | ninguno | patrón no identificable |
| 11 | sin API | `NO_DETERMINADO`, página `UNRESOLVED` | ninguno | patrón no identificable |

Las pruebas candidatas PA-CNT-002-NC1 y PA-CNT-002-NC2 (nombre vacío y plantilla) reproducen sus precondiciones en `PRUEBAS_EJECUTABLES_CANDIDATAS.md`.

## 4. ¿Dependencia circular?

**Sí, en la implementación; en la norma queda una ambigüedad.**

- El motor deriva el patrón (E1/E2/E3) y el hijo principal por un único camino: la API principal, la línea hacia el evento y el contenedor que lo contiene. Si el hijo falta, está duplicado o está en un dominio no exigido, no se publica ni el patrón ni el rol: sólo `conflicts` (`NO_COMPLETE_STRUCTURAL_ROLE_CANDIDATE`, `MULTIPLE_STRUCTURAL_CANDIDATES`). Pero la rama No cumple exige «patrón certificado» **antes** de demostrar el defecto del hijo.
- La norma no precisa cómo se identifica el patrón cuando el hijo es defectuoso, ni qué figuras cuentan como «candidatos a hijo principal».

## 5. Clasificación

| Rama de No cumple / No verificable | A. Imposible por falta de datos | B. Limitación del motor | C. Expectativa mal construida | D. Ambigüedad normativa |
|---|---|---|---|---|
| Nombre ausente, vacío o sólo espacios | no | no | **la afirmación previa era incorrecta** | no |
| Nombre genérico / plantilla | no | no | no | C-09 (lista cerrada de plantilla y criterio de genérico) |
| «No existe un hijo principal» | **no** (el JSON contiene la estructura) | **sí** | no | **sí**: cómo se identifica el patrón sin hijo |
| «Existe más de uno» | no | **sí** (se pierde el patrón: fixture 6) | no | **sí**: qué es un candidato (fixture 7) |
| Hijo en dominio distinto | no | **sí** (fixtures 3 y 5) | no | **sí**: el patrón con el hijo mal ubicado |
| Cobertura del inventario | no | parcial (C-03) | no | C-03 |

No hay imposibilidad real por falta de datos (A) en ninguna rama: en los fixtures 3, 5 y 6 el JSON original contiene el contenedor, su evento, su línea y su dominio.

## 6. Brecha del extractor y propuesta (futura, no implementada)

**EC-11 (propuesta).** Publicar, aunque el escenario sea `NO_DETERMINADO`, (a) los contenedores candidatos a hijo con su dominio y su vínculo con la API, y (b) el patrón estructural candidato por candidato, sin certificar. Con ello la Skill podría distinguir «no existe», «existe más de uno» y «dominio distinto» **sin usar el Inicio** y sin inferir. Hasta que exista: esas tres ramas permanecen en No verificable (conforme a la viñeta «no puede certificarse cuál es el hijo principal»).

## 7. Pregunta para la analista (propuesta; no se numera como decisión nueva)

Vinculada a C-03: «Para CNT-002, ¿cuándo se considera identificable el patrón estructural si el hijo falta, está duplicado o está en un dominio no exigido? ¿Qué figura es un candidato a hijo principal (cualquier contenedor, o el que tiene un evento conectado con la API)?»

## 8. Efecto en los documentos

- CNT-002: verificabilidad `VERIFICABLE_PARCIAL`, cobertura `PARCIAL`; la brecha ya no afirma que «No existe hijo» y «existe más de uno» sean «indistinguibles», sino que el motor no publica el patrón en esos casos.
- Pruebas: PA-CNT-002-NC (nombre) ejecutables; PA-CNT-002-NA bloqueada.
- Corrección de mi enunciado previo: «la rama No cumple es inalcanzable» → «sólo tres de las cuatro familias no se pueden demostrar hoy; la causa es el motor, no el estado `HIPOTESIS`».
