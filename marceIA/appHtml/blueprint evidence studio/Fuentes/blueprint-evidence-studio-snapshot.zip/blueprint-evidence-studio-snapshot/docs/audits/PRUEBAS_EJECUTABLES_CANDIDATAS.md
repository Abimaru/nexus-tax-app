# PRUEBAS_EJECUTABLES_CANDIDATAS (Iteración 3.1)

> Candidatas, no aprobadas. No fijan expectativas para C-01…C-13. El evaluador **no** se ejecutó.

## 0. Qué prueba cada cosa

| Nivel | Qué establece | Estado hoy |
|---|---|---|
| Precondiciones | El motor (src/ sin modificar) publica, para el fixture, exactamente la evidencia que la ficha declara | **99/99** fichas reproducidas (`scratchpad/run-tests-spec.mjs`) |
| Resultado normativo | Que la Skill, aplicando el texto literal, concluya el estado esperado | **No comprobado**: requiere ejecutar la Skill y aprobación de la analista |

Una ficha con precondiciones reproducidas **no** es una evaluación normativa aprobada: el «esperado» es una expectativa candidata derivada del texto literal.

## 1. Reconciliación de las 148 pruebas candidatas

| Categoría | Pruebas |
|---|---|
| EJECUTABLE_DEFINITIVA | 72 |
| BLOQUEADA_POR_CONTRATO | 4 |
| EJECUTABLE_CON_RESERVA | 25 |
| BLOQUEADA_POR_DECISION_NORMATIVA | 21 |
| BLOQUEADA_POR_CONVENCION | 26 |
| **Ejecutables (definitiva + con reserva)** | **97** |
| **Bloqueadas** | **51** |

- EJECUTABLE_DEFINITIVA: expectativa derivable del texto literal, sin decisión abierta que la cambie.
- EJECUTABLE_CON_RESERVA: reproducible; el resultado depende de una decisión abierta o de una cobertura no demostrable. No usar como oráculo.
- BLOQUEADA_POR_CONVENCION / DECISION_NORMATIVA / CONTRATO: no reproducible con el contrato actual.
- Dos fichas adicionales por variante (CNT-002-NC1/NC2, API-004-NV1/NV2) cubren la misma combinación regla–estado; 99 fichas ↔ 97 combinaciones.
- Diferencia con la cifra esperada 74/23/51: **72/25/51**. PA-CA-001-NA y PA-FT-001-NA pasan a «con reserva» (C-03): el motor sólo reconoce Capas/Flujos por prefijo de nombre, por lo que no puede demostrarse la ausencia de candidatas con otro nombre.

## 2. Bases sintéticas

| Base | Estructura |
|---|---|
| BASE-E1 | INTEGRACIÓN ⊃ API `api`; DOMINIO PRODUCTOR ⊃ hijo `child` ⊃ evento `ev`; línea `api→ev` (None→Arrow) |
| BASE-E1D | BASE-E1 + Flujo ⊃ Capa ⊃ API en INTEGRACIÓN (contención explícita) |
| BASE-E1H | BASE-E1 con el hijo dentro de Flujo ⊃ Capa en el productor |
| BASE-E2 | API e hijo (con evento) ambos en INTEGRACIÓN |
| BASE-E3 | DOMINIO PRODUCTOR ⊃ servicio principal `svc` (ms-…) + hijo + evento; línea `svc→ev` |

API: `UMLClassBlock` Title «Payments - Payment Status v1.0.0», Text1 «getPaymentStatus», Text2 «private - entidad».

## 3. Fichas (9 campos) de las pruebas ejecutables

Campos: ID · Regla · Entrada (base + delta) · Evidencia exacta · Esperado (candidato) · Justificación · Campos JSON · Dependencias · Invalidantes.

### PA-CNT-001-C — Cumple — EJECUTABLE_DEFINITIVA

1. **Regla:** CNT-001
2. **Entrada:** base E1D; delta: Sin cambios sobre BASE-E1D
3. **Evidencia exacta (precondiciones, reproducidas):** patrón E1 identificado; INTEGRACIÓN resuelta; DOMINIO PRODUCTOR resuelto
4. **Esperado (candidato, no aprobado):** Cumple
5. **Justificación:** CNT-001 «Cumple»: patrón identificable y ambos dominios obligatorios con clasificación certificada
6. **Campos:** scenario, components[].architecturalDomain, domainRole
7. **Dependencias:** C-03 (cobertura)
8. **Invalidantes:** Si C-03 exige otra definición de inventario completo

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
l1: api(None) → ev(Arrow)
```
</details>

### PA-CNT-001-NV — No verificable — EJECUTABLE_DEFINITIVA

1. **Regla:** CNT-001
2. **Entrada:** base E1D; delta: Segundo hijo `child2` con evento `ev2` en el productor y línea `api→ev2`
3. **Evidencia exacta (precondiciones, reproducidas):** escenario NO_DETERMINADO; MULTIPLE_STRUCTURAL_CANDIDATES
4. **Esperado (candidato, no aprobado):** No verificable
5. **Justificación:** CNT-001 «No verificable»: no existe evidencia suficiente para determinar el patrón estructural
6. **Campos:** scenario.status, scenario.conflicts, scenario.alternativeCandidateIds
7. **Dependencias:** —
8. **Invalidantes:** —

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
child2: RectangleContainerBlock «ms-other» ⊂ prod
ev2: BPMNEvent ⊂ prod,child2
l1: api(None) → ev(Arrow)
l2: api(None) → ev2(Arrow)
```
</details>

### PA-CNT-002-C — Cumple — EJECUTABLE_DEFINITIVA

1. **Regla:** CNT-002
2. **Entrada:** base E1D; delta: Sin cambios
3. **Evidencia exacta (precondiciones, reproducidas):** hijo HIJO_PRINCIPAL; hijo en PRODUCER
4. **Esperado (candidato, no aprobado):** Cumple
5. **Justificación:** CNT-002 «Cumple»: hijo único, nombre específico, dominio exigido por E1
6. **Campos:** role, name, architecturalDomain, scenario.mainChildServiceId
7. **Dependencias:** C-03, C-09
8. **Invalidantes:** Si C-09 define «específico» de otra forma

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
l1: api(None) → ev(Arrow)
```
</details>

### PA-CNT-002-NC1 — No cumple — EJECUTABLE_CON_RESERVA

1. **Regla:** CNT-002
2. **Entrada:** base E1D; delta: El contenedor hijo `child` queda sin texto
3. **Evidencia exacta (precondiciones, reproducidas):** patrón E1 y hijo HIJO_PRINCIPAL; hijo sin nombre
4. **Esperado (candidato, no aprobado):** No cumple
5. **Justificación:** CNT-002 «No cumple»: el nombre del hijo está ausente o vacío, con patrón y cobertura certificados
6. **Campos:** role, name, textAreas
7. **Dependencias:** C-03; reserva: reproducible; el resultado depende de C-09 (lista de plantillas)
8. **Invalidantes:** —

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock ⊂ prod
ev: BPMNEvent ⊂ prod,child
l1: api(None) → ev(Arrow)
```
</details>

### PA-CNT-002-NC2 — No cumple — EJECUTABLE_CON_RESERVA

1. **Regla:** CNT-002
2. **Entrada:** base E1D; delta: Texto del hijo = `NOMBRE SERVICIO` (plantilla)
3. **Evidencia exacta (precondiciones, reproducidas):** patrón E1 y hijo HIJO_PRINCIPAL
4. **Esperado (candidato, no aprobado):** No cumple
5. **Justificación:** CNT-002 «No cumple»: el nombre corresponde a un texto de plantilla
6. **Campos:** role, name, textAreas
7. **Dependencias:** C-09 (lista de plantillas); reserva: reproducible; el resultado depende de C-09 (lista de plantillas)
8. **Invalidantes:** Si la lista cerrada de plantillas (C-09) no incluye ese texto

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «NOMBRE SERVICIO» ⊂ prod
ev: BPMNEvent ⊂ prod,child
l1: api(None) → ev(Arrow)
```
</details>

### PA-CNT-002-NV — No verificable — EJECUTABLE_DEFINITIVA

1. **Regla:** CNT-002
2. **Entrada:** base E1D; delta: Igual que PA-CNT-001-NV
3. **Evidencia exacta (precondiciones, reproducidas):** escenario NO_DETERMINADO; sin HIJO_PRINCIPAL
4. **Esperado (candidato, no aprobado):** No verificable
5. **Justificación:** CNT-002 «No verificable»: existen varios candidatos y no puede certificarse cuál es el hijo principal
6. **Campos:** scenario.conflicts, components[].role
7. **Dependencias:** —
8. **Invalidantes:** —

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
child2: RectangleContainerBlock «ms-other» ⊂ prod
ev2: BPMNEvent ⊂ prod,child2
l1: api(None) → ev(Arrow)
l2: api(None) → ev2(Arrow)
```
</details>

### PA-GW-001-C — Cumple — EJECUTABLE_DEFINITIVA

1. **Regla:** GW-001
2. **Entrada:** base E1D; delta: Compuerta `gw1` sin texto en el hijo; líneas `ev→gw1`, `gw1→ev3`, `gw1→ev4` sin etiqueta
3. **Evidencia exacta (precondiciones, reproducidas):** gw1 es BPMNGateway; sin texto; patrón E1 intacto
4. **Esperado (candidato, no aprobado):** Cumple
5. **Justificación:** GW-001 «Cumple»: la compuerta no contiene texto y sus caminos tampoco tienen etiquetas
6. **Campos:** lucidchartType, textAreas, connections[].textAreas
7. **Dependencias:** C-09
8. **Invalidantes:** —

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
gw1: BPMNGateway ⊂ child
ev3: BPMNEvent ⊂ child
ev4: BPMNEvent ⊂ child
l1: api(None) → ev(Arrow)
g1: ev(None) → gw1(Arrow)
g2: gw1(None) → ev3(Arrow)
g3: gw1(None) → ev4(Arrow)
```
</details>

### PA-GW-001-NC — No cumple — EJECUTABLE_DEFINITIVA

1. **Regla:** GW-001
2. **Entrada:** base E1D; delta: Compuerta con texto «Is the payment approved?»; las dos salidas se etiquetan «Yes» y «Yes»
3. **Evidencia exacta (precondiciones, reproducidas):** texto de la compuerta publicado; dos líneas con etiqueta «Yes»
4. **Esperado (candidato, no aprobado):** No cumple
5. **Justificación:** GW-001 «No cumple»: las etiquetas no permiten distinguir los caminos cuando hay varias alternativas
6. **Campos:** textAreas, pages[].connections[].textAreas
7. **Dependencias:** C-09
8. **Invalidantes:** Si la analista considera distinguibles dos etiquetas idénticas por otro rasgo

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
gw1: BPMNGateway «Is the payment approved?» ⊂ child
ev3: BPMNEvent ⊂ child
ev4: BPMNEvent ⊂ child
l1: api(None) → ev(Arrow)
g1: ev(None) → gw1(Arrow)
g2: gw1(None) → ev3(Arrow) «Yes»
g3: gw1(None) → ev4(Arrow) «Yes»
```
</details>

### PA-GW-001-NV — No verificable — EJECUTABLE_DEFINITIVA

1. **Regla:** GW-001
2. **Entrada:** base E1D; delta: Compuerta con texto; salidas sin etiqueta
3. **Evidencia exacta (precondiciones, reproducidas):** texto publicado; ninguna salida con etiqueta
4. **Esperado (candidato, no aprobado):** No verificable
5. **Justificación:** GW-001 «No verificable»: la compuerta contiene una pregunta pero faltan las respuestas o etiquetas
6. **Campos:** textAreas, connections[].textAreas
7. **Dependencias:** —
8. **Invalidantes:** —

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
gw1: BPMNGateway «Is the payment approved?» ⊂ child
ev3: BPMNEvent ⊂ child
ev4: BPMNEvent ⊂ child
l1: api(None) → ev(Arrow)
g1: ev(None) → gw1(Arrow)
g2: gw1(None) → ev3(Arrow)
g3: gw1(None) → ev4(Arrow)
```
</details>

### PA-GW-001-NA — No aplica — EJECUTABLE_DEFINITIVA

1. **Regla:** GW-001
2. **Entrada:** base E1D; delta: Sin cambios (no hay compuertas)
3. **Evidencia exacta (precondiciones, reproducidas):** ninguna BPMNGateway
4. **Esperado (candidato, no aprobado):** No aplica
5. **Justificación:** GW-001 «No aplica»: la página no contiene compuertas ni candidatas
6. **Campos:** lucidchartType
7. **Dependencias:** —
8. **Invalidantes:** —

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
l1: api(None) → ev(Arrow)
```
</details>

### PA-API-001-C — Cumple — EJECUTABLE_DEFINITIVA

1. **Regla:** API-001
2. **Entrada:** base E1D; delta: Sin cambios (API principal con las tres secciones correctas)
3. **Evidencia exacta (precondiciones, reproducidas):** API principal tipada; en INTEGRACIÓN
4. **Esperado (candidato, no aprobado):** Cumple
5. **Justificación:** API-001 «Cumple»: la primera sección cumple las condiciones de la modalidad INTEGRACIÓN
6. **Campos:** architecturalType, role, textAreas, architecturalDomain
7. **Dependencias:** C-04 (sólo población invocada), C-09 (inglés)
8. **Invalidantes:** Si C-09 cambia el criterio de idioma

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
l1: api(None) → ev(Arrow)
```
</details>

### PA-API-001-NC — No cumple — EJECUTABLE_DEFINITIVA

1. **Regla:** API-001
2. **Entrada:** base E1D; delta: primera sección = «Payments - Payment Status»
3. **Evidencia exacta (precondiciones, reproducidas):** API principal tipada; primera sección publicada
4. **Esperado (candidato, no aprobado):** No cumple
5. **Justificación:** API-001 «No cumple»: la primera sección incumple una condición de la modalidad INTEGRACIÓN
6. **Campos:** textAreas, architecturalType, architecturalDomain
7. **Dependencias:** C-09
8. **Invalidantes:** —

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
l1: api(None) → ev(Arrow)
```
</details>

### PA-API-001-NV — No verificable — EJECUTABLE_DEFINITIVA

1. **Regla:** API-001
2. **Entrada:** base E1D; delta: El contenedor de la API se llama «ZONA X» (dominio no reconocido)
3. **Evidencia exacta (precondiciones, reproducidas):** la API no queda certificada; dominio de la API no resuelto
4. **Esperado (candidato, no aprobado):** No verificable
5. **Justificación:** API-001 «No verificable»: no puede certificarse la clasificación como API ni el dominio (INTEGRACIÓN o SISTEMAS EXTERNOS)
6. **Campos:** architecturalType, architecturalDomain.status
7. **Dependencias:** —
8. **Invalidantes:** —

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «ZONA X»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
l1: api(None) → ev(Arrow)
```
</details>

### PA-API-002-C — Cumple — EJECUTABLE_DEFINITIVA

1. **Regla:** API-002
2. **Entrada:** base E1D; delta: Sin cambios (API principal con las tres secciones correctas)
3. **Evidencia exacta (precondiciones, reproducidas):** API principal tipada; en INTEGRACIÓN
4. **Esperado (candidato, no aprobado):** Cumple
5. **Justificación:** API-002 «Cumple»: la segunda sección cumple las condiciones de la modalidad INTEGRACIÓN
6. **Campos:** architecturalType, role, textAreas, architecturalDomain
7. **Dependencias:** C-04 (sólo población invocada), C-09 (inglés)
8. **Invalidantes:** Si C-09 cambia el criterio de idioma

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
l1: api(None) → ev(Arrow)
```
</details>

### PA-API-002-NC — No cumple — EJECUTABLE_DEFINITIVA

1. **Regla:** API-002
2. **Entrada:** base E1D; delta: segunda sección = «GetPaymentStatus»
3. **Evidencia exacta (precondiciones, reproducidas):** API principal tipada; segunda sección publicada
4. **Esperado (candidato, no aprobado):** No cumple
5. **Justificación:** API-002 «No cumple»: la segunda sección incumple una condición de la modalidad INTEGRACIÓN
6. **Campos:** textAreas, architecturalType, architecturalDomain
7. **Dependencias:** C-09
8. **Invalidantes:** —

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | GetPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
l1: api(None) → ev(Arrow)
```
</details>

### PA-API-002-NV — No verificable — EJECUTABLE_DEFINITIVA

1. **Regla:** API-002
2. **Entrada:** base E1D; delta: El contenedor de la API se llama «ZONA X» (dominio no reconocido)
3. **Evidencia exacta (precondiciones, reproducidas):** la API no queda certificada; dominio de la API no resuelto
4. **Esperado (candidato, no aprobado):** No verificable
5. **Justificación:** API-002 «No verificable»: no puede certificarse la clasificación como API ni el dominio (INTEGRACIÓN o SISTEMAS EXTERNOS)
6. **Campos:** architecturalType, architecturalDomain.status
7. **Dependencias:** —
8. **Invalidantes:** —

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «ZONA X»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
l1: api(None) → ev(Arrow)
```
</details>

### PA-API-003-C — Cumple — EJECUTABLE_DEFINITIVA

1. **Regla:** API-003
2. **Entrada:** base E1D; delta: Sin cambios (API principal con las tres secciones correctas)
3. **Evidencia exacta (precondiciones, reproducidas):** API principal tipada; en INTEGRACIÓN
4. **Esperado (candidato, no aprobado):** Cumple
5. **Justificación:** API-003 «Cumple»: la tercera sección cumple las condiciones de la modalidad INTEGRACIÓN
6. **Campos:** architecturalType, role, textAreas, architecturalDomain
7. **Dependencias:** C-04 (sólo población invocada), C-09 (inglés)
8. **Invalidantes:** Si C-09 cambia el criterio de idioma

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
l1: api(None) → ev(Arrow)
```
</details>

### PA-API-003-NC — No cumple — EJECUTABLE_DEFINITIVA

1. **Regla:** API-003
2. **Entrada:** base E1D; delta: tercera sección = «entidad»
3. **Evidencia exacta (precondiciones, reproducidas):** API principal tipada; tercera sección publicada
4. **Esperado (candidato, no aprobado):** No cumple
5. **Justificación:** API-003 «No cumple»: la tercera sección incumple una condición de la modalidad INTEGRACIÓN
6. **Campos:** textAreas, architecturalType, architecturalDomain
7. **Dependencias:** C-09
8. **Invalidantes:** —

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
l1: api(None) → ev(Arrow)
```
</details>

### PA-API-003-NV — No verificable — EJECUTABLE_DEFINITIVA

1. **Regla:** API-003
2. **Entrada:** base E1D; delta: El contenedor de la API se llama «ZONA X» (dominio no reconocido)
3. **Evidencia exacta (precondiciones, reproducidas):** la API no queda certificada; dominio de la API no resuelto
4. **Esperado (candidato, no aprobado):** No verificable
5. **Justificación:** API-003 «No verificable»: no puede certificarse la clasificación como API ni el dominio (INTEGRACIÓN o SISTEMAS EXTERNOS)
6. **Campos:** architecturalType, architecturalDomain.status
7. **Dependencias:** —
8. **Invalidantes:** —

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «ZONA X»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
l1: api(None) → ev(Arrow)
```
</details>

### PA-API-004-C — Cumple — EJECUTABLE_DEFINITIVA

1. **Regla:** API-004
2. **Entrada:** base E1D; delta: Sin cambios + declaración de la analista: MCI de la API principal = sí; exposición `private` (tercera sección); respuesta de la analista: MCI API principal: sí
3. **Evidencia exacta (precondiciones, reproducidas):** API principal; asociación Flujo+Capa a la API
4. **Esperado (candidato, no aprobado):** Cumple
5. **Justificación:** API-004 «Cumple»: API private declarada MCI con Capa y Flujo asociados
6. **Campos:** role, textAreas, deploymentAssociations, DECLARADO_POR_ANALISTA
7. **Dependencias:** —
8. **Invalidantes:** La declaración no sustituye la asociación

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
l1: api(None) → ev(Arrow)
```
</details>

### PA-API-004-NC — No cumple — EJECUTABLE_DEFINITIVA

1. **Regla:** API-004
2. **Entrada:** base E1; delta: BASE-E1 (sin Flujo ni Capa en la página) + MCI = sí; respuesta de la analista: MCI API principal: sí
3. **Evidencia exacta (precondiciones, reproducidas):** API principal; sin asociaciones; ninguna Capa ni Flujo en la página
4. **Esperado (candidato, no aprobado):** No cumple
5. **Justificación:** API-004 «No cumple»: API private declarada MCI sin Capa ni Flujo, con cobertura certificada
6. **Campos:** deploymentAssociations, components[].architecturalType
7. **Dependencias:** C-03 (candidatos y cobertura)
8. **Invalidantes:** Si aparece una Capa/Flujo candidata sin asociar

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
l1: api(None) → ev(Arrow)
```
</details>

### PA-API-004-NV1 — No verificable — EJECUTABLE_DEFINITIVA

1. **Regla:** API-004
2. **Entrada:** base E1; delta: BASE-E1 sin declaración MCI; respuesta de la analista: (sin respuesta)
3. **Evidencia exacta (precondiciones, reproducidas):** API principal
4. **Esperado (candidato, no aprobado):** No verificable
5. **Justificación:** API-004 «No verificable»: falta la declaración de su condición MCI
6. **Campos:** DECLARADO_POR_ANALISTA
7. **Dependencias:** —
8. **Invalidantes:** —

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
l1: api(None) → ev(Arrow)
```
</details>

### PA-API-004-NV2 — No verificable — EJECUTABLE_DEFINITIVA

1. **Regla:** API-004
2. **Entrada:** base E1; delta: Flujo `flujo` ⊃ Capa `capa` en INTEGRACIÓN pero sin contener ni agrupar la API; MCI = sí; respuesta de la analista: MCI API principal: sí
3. **Evidencia exacta (precondiciones, reproducidas):** API principal; sin asociación publicada; Capa y Flujo existen
4. **Esperado (candidato, no aprobado):** No verificable
5. **Justificación:** API-004 «No verificable»: existe una Capa y un Flujo candidatos pero no puede certificarse su asociación
6. **Campos:** deploymentAssociations, architecturalType
7. **Dependencias:** —
8. **Invalidantes:** —

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
l1: api(None) → ev(Arrow)
```
</details>

### PA-API-004-NA — No aplica — EJECUTABLE_DEFINITIVA

1. **Regla:** API-004
2. **Entrada:** base E1; delta: BASE-E1 + MCI = no; respuesta de la analista: MCI API principal: no
3. **Evidencia exacta (precondiciones, reproducidas):** API principal
4. **Esperado (candidato, no aprobado):** No aplica
5. **Justificación:** API-004 «No aplica»: la API principal está declarada como no MCI
6. **Campos:** DECLARADO_POR_ANALISTA
7. **Dependencias:** —
8. **Invalidantes:** —

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
l1: api(None) → ev(Arrow)
```
</details>

### PA-SRV-004-C — Cumple — EJECUTABLE_DEFINITIVA

1. **Regla:** SRV-004
2. **Entrada:** base E1H; delta: El hijo está contenido en Capa ⊂ Flujo del productor; MCI hijo = sí; respuesta de la analista: MCI hijo principal: sí
3. **Evidencia exacta (precondiciones, reproducidas):** hijo principal; asociación publicada para el hijo
4. **Esperado (candidato, no aprobado):** Cumple
5. **Justificación:** SRV-004 «Cumple»: hijo de E1 declarado MCI con Capa y Flujo asociados
6. **Campos:** scenario, role, deploymentAssociations
7. **Dependencias:** —
8. **Invalidantes:** La asociación por grupos no se publica para el hijo (EC-04)

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
flujoH: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ prod
capaH: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ prod,flujoH
child: RectangleContainerBlock «ms-payment-status» ⊂ prod,flujoH,capaH
ev: BPMNEvent ⊂ prod,child
l1: api(None) → ev(Arrow)
```
</details>

### PA-SRV-004-NC — No cumple — EJECUTABLE_DEFINITIVA

1. **Regla:** SRV-004
2. **Entrada:** base E1; delta: BASE-E1 (sin Flujo/Capa) + MCI hijo = sí; respuesta de la analista: MCI hijo principal: sí
3. **Evidencia exacta (precondiciones, reproducidas):** hijo principal; sin asociación; sin Capa ni Flujo en la página
4. **Esperado (candidato, no aprobado):** No cumple
5. **Justificación:** SRV-004 «No cumple»: falta Capa y Flujo del hijo declarado MCI, con cobertura certificada
6. **Campos:** deploymentAssociations
7. **Dependencias:** C-03
8. **Invalidantes:** Si existen grupos que asocien Capa/Flujo al hijo (EC-04)

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
l1: api(None) → ev(Arrow)
```
</details>

### PA-SRV-004-NV — No verificable — EJECUTABLE_DEFINITIVA

1. **Regla:** SRV-004
2. **Entrada:** base E1; delta: BASE-E1 sin declaración MCI del hijo; respuesta de la analista: (sin respuesta)
3. **Evidencia exacta (precondiciones, reproducidas):** hijo principal
4. **Esperado (candidato, no aprobado):** No verificable
5. **Justificación:** SRV-004 «No verificable»: falta la declaración MCI del hijo
6. **Campos:** DECLARADO_POR_ANALISTA
7. **Dependencias:** —
8. **Invalidantes:** —

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
l1: api(None) → ev(Arrow)
```
</details>

### PA-SRV-004-NA — No aplica — EJECUTABLE_DEFINITIVA

1. **Regla:** SRV-004
2. **Entrada:** base E1; delta: BASE-E1 + MCI hijo = no; respuesta de la analista: MCI hijo principal: no
3. **Evidencia exacta (precondiciones, reproducidas):** hijo principal
4. **Esperado (candidato, no aprobado):** No aplica
5. **Justificación:** SRV-004 «No aplica»: el hijo principal está declarado no MCI
6. **Campos:** DECLARADO_POR_ANALISTA
7. **Dependencias:** —
8. **Invalidantes:** —

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
l1: api(None) → ev(Arrow)
```
</details>

### PA-CA-001-C — Cumple — EJECUTABLE_DEFINITIVA

1. **Regla:** CA-001
2. **Entrada:** base E1D; delta: Sin cambios (`Capa de Arquitectura - sistema`)
3. **Evidencia exacta (precondiciones, reproducidas):** CAPA tipada
4. **Esperado (candidato, no aprobado):** Cumple
5. **Justificación:** CA-001 «Cumple»
6. **Campos:** architecturalType, name
7. **Dependencias:** —
8. **Invalidantes:** —

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
l1: api(None) → ev(Arrow)
```
</details>

### PA-CA-001-NC — No cumple — EJECUTABLE_DEFINITIVA

1. **Regla:** CA-001
2. **Entrada:** base E1D; delta: Nombre = `Capa de Arquitectura - Sistema` (tipo con mayúscula)
3. **Evidencia exacta (precondiciones, reproducidas):** CAPA tipada
4. **Esperado (candidato, no aprobado):** No cumple
5. **Justificación:** CA-001 «No cumple»: mayúsculas no permitidas en el tipo
6. **Campos:** architecturalType, name
7. **Dependencias:** —
8. **Invalidantes:** —

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - Sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
l1: api(None) → ev(Arrow)
```
</details>

### PA-CA-001-NA — No aplica — EJECUTABLE_CON_RESERVA

1. **Regla:** CA-001
2. **Entrada:** base E1; delta: BASE-E1 (sin Capa)
3. **Evidencia exacta (precondiciones, reproducidas):** sin figuras CAPA
4. **Esperado (candidato, no aprobado):** No aplica
5. **Justificación:** CA-001 «No aplica»: sin Capas ni candidatas
6. **Campos:** architecturalType
7. **Dependencias:** —; reserva: C-03: una Capa candidata con otro nombre no es detectable, por lo que la ausencia de Capas no se demuestra
8. **Invalidantes:** —

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
l1: api(None) → ev(Arrow)
```
</details>

### PA-FT-001-C — Cumple — EJECUTABLE_DEFINITIVA

1. **Regla:** FT-001
2. **Entrada:** base E1D; delta: Sin cambios (`Flujo Transaccional - no-monetario`)
3. **Evidencia exacta (precondiciones, reproducidas):** FLUJO tipado
4. **Esperado (candidato, no aprobado):** Cumple
5. **Justificación:** FT-001 «Cumple»
6. **Campos:** architecturalType, name
7. **Dependencias:** —
8. **Invalidantes:** —

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
l1: api(None) → ev(Arrow)
```
</details>

### PA-FT-001-NC — No cumple — EJECUTABLE_DEFINITIVA

1. **Regla:** FT-001
2. **Entrada:** base E1D; delta: Nombre = `Flujo Transaccional - no monetario` (sin guion en el valor)
3. **Evidencia exacta (precondiciones, reproducidas):** FLUJO tipado
4. **Esperado (candidato, no aprobado):** No cumple
5. **Justificación:** FT-001 «No cumple»: valor fuera del catálogo
6. **Campos:** architecturalType, name
7. **Dependencias:** —
8. **Invalidantes:** —

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
l1: api(None) → ev(Arrow)
```
</details>

### PA-FT-001-NA — No aplica — EJECUTABLE_CON_RESERVA

1. **Regla:** FT-001
2. **Entrada:** base E1; delta: BASE-E1 (sin Flujo)
3. **Evidencia exacta (precondiciones, reproducidas):** sin figuras FLUJO
4. **Esperado (candidato, no aprobado):** No aplica
5. **Justificación:** FT-001 «No aplica»
6. **Campos:** architecturalType
7. **Dependencias:** —; reserva: C-03: un Flujo candidato con otro nombre no es detectable, por lo que la ausencia de Flujos no se demuestra
8. **Invalidantes:** —

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
l1: api(None) → ev(Arrow)
```
</details>

### PA-COM-001-C — Cumple — EJECUTABLE_CON_RESERVA

1. **Regla:** COM-001
2. **Entrada:** base E1D; delta: Gestor `qm1` en INTEGRACIÓN; comando `c1` «Consultar saldo» en el hijo; dos líneas `CircleOpen→Generalization` entre `c1` y `qm1`
3. **Evidencia exacta (precondiciones, reproducidas):** gestor certificado; c1 es BPMNActivity; patrón E1 intacto
4. **Esperado (candidato, no aprobado):** Cumple
5. **Justificación:** COM-001 «Cumple»: candidato a comando por relación con un gestor; infinitivo + complemento
6. **Campos:** lucidchartType, name, connections
7. **Dependencias:** C-12, C-09; reserva: reproducible; el resultado depende de C-12, C-09
8. **Invalidantes:** Si C-12 define «relación» de otro modo

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
qm1: UMLActiveClassBlock «Payments Queue Manager» ⊂ integ
c1: BPMNActivity «Consultar saldo» ⊂ child
l1: api(None) → ev(Arrow)
qa: c1(CircleOpen) → qm1(Generalization)
qb: qm1(CircleOpen) → c1(Generalization)
```
</details>

### PA-COM-001-NC — No cumple — EJECUTABLE_CON_RESERVA

1. **Regla:** COM-001
2. **Entrada:** base E1D; delta: Igual, con el comando «Consultar» (sólo verbo)
3. **Evidencia exacta (precondiciones, reproducidas):** gestor certificado; nombre de una palabra
4. **Esperado (candidato, no aprobado):** No cumple
5. **Justificación:** COM-001 «No cumple»: nombre formado únicamente por el verbo, sin complemento
6. **Campos:** name, connections
7. **Dependencias:** C-09, C-12; reserva: reproducible; el resultado depende de C-09, C-12
8. **Invalidantes:** Si C-09 discute el reconocimiento del infinitivo

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
qm1: UMLActiveClassBlock «Payments Queue Manager» ⊂ integ
c1: BPMNActivity «Consultar» ⊂ child
l1: api(None) → ev(Arrow)
qa: c1(CircleOpen) → qm1(Generalization)
qb: qm1(CircleOpen) → c1(Generalization)
```
</details>

### PA-COM-001-NV — No verificable — EJECUTABLE_CON_RESERVA

1. **Regla:** COM-001
2. **Entrada:** base E1D; delta: Comando `c1` bidireccional con `ext1` (`UMLClassBlock` sin tipo, candidata a API/servicio)
3. **Evidencia exacta (precondiciones, reproducidas):** ext1 sin tipo
4. **Esperado (candidato, no aprobado):** No verificable
5. **Justificación:** COM-001 «No verificable»: no puede identificarse una relación suficiente con una API/servicio certificados
6. **Campos:** architecturalType, connections
7. **Dependencias:** C-04, C-12; reserva: reproducible; el resultado depende de C-04, C-12
8. **Invalidantes:** Si se aprueba un reconocimiento de API (C-04)

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
ext1: UMLClassBlock «Ledger - Account Balance v1.0.0 | getBalance | Entidad» ⊂ integ
c1: BPMNActivity «Consultar saldo» ⊂ child
l1: api(None) → ev(Arrow)
xa: c1(CircleOpen) → ext1(Generalization)
xb: ext1(CircleOpen) → c1(Generalization)
```
</details>

### PA-COM-001-NA — No aplica — EJECUTABLE_DEFINITIVA

1. **Regla:** COM-001
2. **Entrada:** base E1D; delta: Sin cambios (no hay actividades)
3. **Evidencia exacta (precondiciones, reproducidas):** sin BPMNActivity
4. **Esperado (candidato, no aprobado):** No aplica
5. **Justificación:** COM-001 «No aplica»: sin actividades relacionadas ni relaciones pendientes
6. **Campos:** lucidchartType
7. **Dependencias:** —
8. **Invalidantes:** —

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
l1: api(None) → ev(Arrow)
```
</details>

### PA-COM-004-C — Cumple — EJECUTABLE_DEFINITIVA

1. **Regla:** COM-004
2. **Entrada:** base E1D; delta: Igual que PA-COM-001-C
3. **Evidencia exacta (precondiciones, reproducidas):** gestor certificado; dos líneas con estilos CircleOpen/Generalization
4. **Esperado (candidato, no aprobado):** Cumple
5. **Justificación:** COM-004 «Cumple»: ambos sentidos con CircleOpen en el origen y Generalization en el destino
6. **Campos:** connections, endpoint styles, lucidchartType
7. **Dependencias:** C-12
8. **Invalidantes:** —

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
qm1: UMLActiveClassBlock «Payments Queue Manager» ⊂ integ
c1: BPMNActivity «Consultar saldo» ⊂ child
l1: api(None) → ev(Arrow)
qa: c1(CircleOpen) → qm1(Generalization)
qb: qm1(CircleOpen) → c1(Generalization)
```
</details>

### PA-COM-004-NC — No cumple — EJECUTABLE_DEFINITIVA

1. **Regla:** COM-004
2. **Entrada:** base E1D; delta: Sólo la línea `c1→qm1`
3. **Evidencia exacta (precondiciones, reproducidas):** gestor certificado; una única línea comando-gestor
4. **Esperado (candidato, no aprobado):** No cumple
5. **Justificación:** COM-004 «No cumple»: falta uno de los dos sentidos, con cobertura certificada
6. **Campos:** connections
7. **Dependencias:** C-03
8. **Invalidantes:** —

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
qm1: UMLActiveClassBlock «Payments Queue Manager» ⊂ integ
c1: BPMNActivity «Consultar saldo» ⊂ child
l1: api(None) → ev(Arrow)
qa: c1(CircleOpen) → qm1(Generalization)
```
</details>

### PA-COM-004-NV — No verificable — EJECUTABLE_DEFINITIVA

1. **Regla:** COM-004
2. **Entrada:** base E1D; delta: Dos líneas con `Arrow` en ambos extremos
3. **Evidencia exacta (precondiciones, reproducidas):** gestor certificado; orientación no verificable
4. **Esperado (candidato, no aprobado):** No verificable
5. **Justificación:** COM-004 «No verificable»: dirección y terminaciones indeterminadas
6. **Campos:** connections, endpoint styles
7. **Dependencias:** —
8. **Invalidantes:** —

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
qm1: UMLActiveClassBlock «Payments Queue Manager» ⊂ integ
c1: BPMNActivity «Consultar saldo» ⊂ child
l1: api(None) → ev(Arrow)
q1: c1(Arrow) → qm1(Arrow)
q2: qm1(Arrow) → c1(Arrow)
```
</details>

### PA-COM-004-NA — No aplica — EJECUTABLE_DEFINITIVA

1. **Regla:** COM-004
2. **Entrada:** base E1D; delta: Sin cambios
3. **Evidencia exacta (precondiciones, reproducidas):** sin gestores
4. **Esperado (candidato, no aprobado):** No aplica
5. **Justificación:** COM-004 «No aplica»: sin gestores relacionados con comandos
6. **Campos:** lucidchartType
7. **Dependencias:** —
8. **Invalidantes:** —

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
l1: api(None) → ev(Arrow)
```
</details>

### PA-MQ-001-C — Cumple — EJECUTABLE_DEFINITIVA

1. **Regla:** MQ-001
2. **Entrada:** base E1D; delta: Gestor `qm1` «Payments Queue Manager» en INTEGRACIÓN
3. **Evidencia exacta (precondiciones, reproducidas):** gestor certificado
4. **Esperado (candidato, no aprobado):** Cumple
5. **Justificación:** MQ-001 «Cumple»
6. **Campos:** lucidchartType, architecturalType, name
7. **Dependencias:** C-09
8. **Invalidantes:** —

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
qm1: UMLActiveClassBlock «Payments Queue Manager» ⊂ integ
l1: api(None) → ev(Arrow)
```
</details>

### PA-MQ-001-NC — No cumple — EJECUTABLE_CON_RESERVA

1. **Regla:** MQ-001
2. **Entrada:** base E1D; delta: Gestor con el texto de plantilla «Nombre Gestor de Colas»
3. **Evidencia exacta (precondiciones, reproducidas):** gestor certificado
4. **Esperado (candidato, no aprobado):** No cumple
5. **Justificación:** MQ-001 «No cumple»: nombre de plantilla
6. **Campos:** name
7. **Dependencias:** C-09 (lista de plantillas); reserva: reproducible; el resultado depende de C-09 (lista de plantillas)
8. **Invalidantes:** Si la lista cerrada de C-09 no incluye ese texto

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
qm1: UMLActiveClassBlock «Nombre Gestor de Colas» ⊂ integ
l1: api(None) → ev(Arrow)
```
</details>

### PA-MQ-001-NA — No aplica — EJECUTABLE_DEFINITIVA

1. **Regla:** MQ-001
2. **Entrada:** base E1D; delta: Sin cambios
3. **Evidencia exacta (precondiciones, reproducidas):** sin UMLActiveClassBlock
4. **Esperado (candidato, no aprobado):** No aplica
5. **Justificación:** MQ-001 «No aplica»
6. **Campos:** lucidchartType
7. **Dependencias:** —
8. **Invalidantes:** —

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
l1: api(None) → ev(Arrow)
```
</details>

### PA-MQ-003-C — Cumple — EJECUTABLE_DEFINITIVA

1. **Regla:** MQ-003
2. **Entrada:** base E1D; delta: Dos gestores con dos líneas `CircleOpen→Generalization` en sentidos opuestos
3. **Evidencia exacta (precondiciones, reproducidas):** dos gestores
4. **Esperado (candidato, no aprobado):** Cumple
5. **Justificación:** MQ-003 «Cumple» (subpoblación gestor↔gestor)
6. **Campos:** connections, lucidchartType
7. **Dependencias:** C-05 (otras subpoblaciones)
8. **Invalidantes:** Cubre sólo gestor↔gestor

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
qm1: UMLActiveClassBlock «Payments Queue Manager» ⊂ integ
qm2: UMLActiveClassBlock «Settlement Queue Manager» ⊂ integ
l1: api(None) → ev(Arrow)
ma: qm1(CircleOpen) → qm2(Generalization)
mb: qm2(CircleOpen) → qm1(Generalization)
```
</details>

### PA-MQ-003-NC — No cumple — EJECUTABLE_DEFINITIVA

1. **Regla:** MQ-003
2. **Entrada:** base E1D; delta: Sólo la línea `qm1→qm2`
3. **Evidencia exacta (precondiciones, reproducidas):** dos gestores
4. **Esperado (candidato, no aprobado):** No cumple
5. **Justificación:** MQ-003 «No cumple»: falta alguno de los sentidos obligatorios entre dos gestores
6. **Campos:** connections
7. **Dependencias:** C-03
8. **Invalidantes:** —

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
qm1: UMLActiveClassBlock «Payments Queue Manager» ⊂ integ
qm2: UMLActiveClassBlock «Settlement Queue Manager» ⊂ integ
l1: api(None) → ev(Arrow)
ma: qm1(CircleOpen) → qm2(Generalization)
```
</details>

### PA-MQ-003-NV — No verificable — EJECUTABLE_CON_RESERVA

1. **Regla:** MQ-003
2. **Entrada:** base E1D; delta: Gestor relacionado con `ext1` (`UMLClassBlock` sin tipo; candidata a servicio invocado)
3. **Evidencia exacta (precondiciones, reproducidas):** gestor certificado; ext1 sin tipo
4. **Esperado (candidato, no aprobado):** No verificable
5. **Justificación:** MQ-003 «No verificable»: no puede certificarse el participante como servicio invocado
6. **Campos:** architecturalType, role, connections
7. **Dependencias:** C-05, C-04; reserva: reproducible; el resultado depende de C-05, C-04
8. **Invalidantes:** Si se aprueba la certificación de invocados

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
qm1: UMLActiveClassBlock «Payments Queue Manager» ⊂ integ
ext1: UMLClassBlock «Ledger - Account Balance v1.0.0 | getBalance | Entidad» ⊂ integ
l1: api(None) → ev(Arrow)
ma: ext1(CircleOpen) → qm1(Generalization)
mb: qm1(CircleOpen) → ext1(Generalization)
```
</details>

### PA-MQ-003-NA — No aplica — EJECUTABLE_DEFINITIVA

1. **Regla:** MQ-003
2. **Entrada:** base E1D; delta: Gestor sin conexiones
3. **Evidencia exacta (precondiciones, reproducidas):** gestor certificado; sin líneas al gestor
4. **Esperado (candidato, no aprobado):** No aplica
5. **Justificación:** MQ-003 «No aplica»: sin gestores relacionados con gestores, servicios o eventos
6. **Campos:** connections
7. **Dependencias:** —
8. **Invalidantes:** —

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
qm1: UMLActiveClassBlock «Payments Queue Manager» ⊂ integ
l1: api(None) → ev(Arrow)
```
</details>

### PA-MQ-002-C — Cumple — EJECUTABLE_DEFINITIVA

1. **Regla:** MQ-002
2. **Entrada:** base E1D; delta: Gestor `qm1` contenido en Capa ⊂ Flujo dentro de INTEGRACIÓN (variante MCI)
3. **Evidencia exacta (precondiciones, reproducidas):** gestor certificado; asociación publicada para el gestor
4. **Esperado (candidato, no aprobado):** Cumple
5. **Justificación:** MQ-002 «Cumple» (modalidad MCI): Capa y Flujo asociados inequívocamente
6. **Campos:** structuralParent, deploymentAssociations
7. **Dependencias:** C-06 (sólo modalidad Federada)
8. **Invalidantes:** No cubre Federada

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
flujoQ: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capaQ: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujoQ
qm1: UMLActiveClassBlock «Payments Queue Manager» ⊂ integ,flujoQ,capaQ
l1: api(None) → ev(Arrow)
```
</details>

### PA-MQ-002-NC — No cumple — EJECUTABLE_DEFINITIVA

1. **Regla:** MQ-002
2. **Entrada:** base E1D; delta: Gestor en INTEGRACIÓN sin Capa, Flujo ni `Federado`
3. **Evidencia exacta (precondiciones, reproducidas):** gestor certificado; sin asociación; sin texto Federado en la página
4. **Esperado (candidato, no aprobado):** No cumple
5. **Justificación:** MQ-002 «No cumple»: el gestor ubicado en INTEGRACIÓN no tiene Capa de Despliegue
6. **Campos:** deploymentAssociations, textAreas
7. **Dependencias:** C-03
8. **Invalidantes:** Si existe una Capa/Federado candidata

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
qm1: UMLActiveClassBlock «Payments Queue Manager» ⊂ integ
l1: api(None) → ev(Arrow)
```
</details>

### PA-MQ-002-NV — No verificable — EJECUTABLE_CON_RESERVA

1. **Regla:** MQ-002
2. **Entrada:** base E1D; delta: Gestor sin Capa + contenedor `fed` con el texto «Federado» que no lo contiene
3. **Evidencia exacta (precondiciones, reproducidas):** gestor certificado; literal Federado presente; sin asociación
4. **Esperado (candidato, no aprobado):** No verificable
5. **Justificación:** MQ-002 «No verificable»: existe un valor `Federado` candidato pero no puede demostrarse que pertenezca al gestor
6. **Campos:** textAreas, structuralParent
7. **Dependencias:** C-06; reserva: reproducible; el resultado depende de C-06
8. **Invalidantes:** Si C-06 define la asociación de Federado

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
qm1: UMLActiveClassBlock «Payments Queue Manager» ⊂ integ
fed: UMLRectangleContainerBlock «Federado» ⊂ integ
l1: api(None) → ev(Arrow)
```
</details>

### PA-MQ-002-NA — No aplica — EJECUTABLE_DEFINITIVA

1. **Regla:** MQ-002
2. **Entrada:** base E1D; delta: Contenedor `sysext` «SISTEMAS EXTERNOS» ⊃ gestor `qm1`
3. **Evidencia exacta (precondiciones, reproducidas):** gestor certificado; gestor en SISTEMAS EXTERNOS
4. **Esperado (candidato, no aprobado):** No aplica
5. **Justificación:** MQ-002 «No aplica»: gestor certificadamente ubicado fuera de INTEGRACIÓN
6. **Campos:** architecturalDomain, domainRole
7. **Dependencias:** —
8. **Invalidantes:** —

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
sysext: UMLRectangleContainerBlock «SISTEMAS EXTERNOS» ⊂ integ
qm1: UMLActiveClassBlock «Payments Queue Manager» ⊂ sysext
l1: api(None) → ev(Arrow)
```
</details>

### PA-CNT-003-C — Cumple — EJECUTABLE_CON_RESERVA

1. **Regla:** CNT-003
2. **Entrada:** base E1D; delta: Sin cambios (INTEGRACIÓN contiene Flujo, Capa y API principal)
3. **Evidencia exacta (precondiciones, reproducidas):** componentes tipados
4. **Esperado (candidato, no aprobado):** Cumple
5. **Justificación:** CNT-003 «Cumple»: todos los componentes certificados están permitidos en el nivel padre
6. **Campos:** architecturalType, structuralParent
7. **Dependencias:** C-06, C-11; reserva: reproducible; el resultado depende de C-06, C-11
8. **Invalidantes:** Si C-06 aporta nuevas categorías prohibidas

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
l1: api(None) → ev(Arrow)
```
</details>

### PA-CNT-003-NC — No cumple — EJECUTABLE_DEFINITIVA

1. **Regla:** CNT-003
2. **Entrada:** base E1D; delta: Compuerta `gw1` directamente en INTEGRACIÓN
3. **Evidencia exacta (precondiciones, reproducidas):** gw1 BPMNGateway en INTEGRACIÓN
4. **Esperado (candidato, no aprobado):** No cumple
5. **Justificación:** CNT-003 «No cumple»: las compuertas no se permiten en el nivel padre
6. **Campos:** lucidchartType, structuralParent
7. **Dependencias:** C-11
8. **Invalidantes:** —

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
gw1: BPMNGateway ⊂ integ
l1: api(None) → ev(Arrow)
```
</details>

### PA-CNT-003-NV — No verificable — EJECUTABLE_DEFINITIVA

1. **Regla:** CNT-003
2. **Entrada:** base E1D; delta: Un segundo contenedor `prod2` también contiene a `api`
3. **Evidencia exacta (precondiciones, reproducidas):** padre de api en conflicto
4. **Esperado (candidato, no aprobado):** No verificable
5. **Justificación:** CNT-003 «No verificable»: no puede determinarse el nivel de un componente
6. **Campos:** structuralParent.status, issues
7. **Dependencias:** —
8. **Invalidantes:** —

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa,prod2
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
prod2: UMLRectangleContainerBlock «OTRO CONTENEDOR»
l1: api(None) → ev(Arrow)
```
</details>

### PA-CNT-003-NA — No aplica — EJECUTABLE_DEFINITIVA

1. **Regla:** CNT-003
2. **Entrada:** base E3; delta: BASE-E3 (sólo DOMINIO PRODUCTOR)
3. **Evidencia exacta (precondiciones, reproducidas):** patrón E3; sin dominio INTEGRACIÓN
4. **Esperado (candidato, no aprobado):** No aplica
5. **Justificación:** CNT-003 «No aplica»: la página no contiene INTEGRACIÓN
6. **Campos:** architecturalDomain
7. **Dependencias:** —
8. **Invalidantes:** —

<details><summary>Fixture completo</summary>

```
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
svc: UMLClassBlock «ms-payment-orchestrator | runPaymentOrchestration | tarea» ⊂ prod
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
l1: svc(None) → ev(Arrow)
```
</details>

### PA-CNT-004-NC — No cumple — EJECUTABLE_DEFINITIVA

1. **Regla:** CNT-004
2. **Entrada:** base E1D; delta: Compuerta `gw1` directamente en el DOMINIO PRODUCTOR
3. **Evidencia exacta (precondiciones, reproducidas):** gw1 en prod
4. **Esperado (candidato, no aprobado):** No cumple
5. **Justificación:** CNT-004 «No cumple»: compuerta en el nivel padre del productor
6. **Campos:** lucidchartType, structuralParent
7. **Dependencias:** C-11
8. **Invalidantes:** —

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
gw1: BPMNGateway ⊂ prod
l1: api(None) → ev(Arrow)
```
</details>

### PA-CNT-004-NV — No verificable — EJECUTABLE_DEFINITIVA

1. **Regla:** CNT-004
2. **Entrada:** base E1D; delta: Un segundo contenedor contiene también al hijo
3. **Evidencia exacta (precondiciones, reproducidas):** padre del hijo en conflicto
4. **Esperado (candidato, no aprobado):** No verificable
5. **Justificación:** CNT-004 «No verificable»: no puede determinarse si un componente está fuera o dentro del hijo
6. **Campos:** structuralParent.status
7. **Dependencias:** —
8. **Invalidantes:** —

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod,prod2
ev: BPMNEvent ⊂ prod,child
prod2: UMLRectangleContainerBlock «OTRO CONTENEDOR»
l1: api(None) → ev(Arrow)
```
</details>

### PA-CNT-004-NA — No aplica — EJECUTABLE_DEFINITIVA

1. **Regla:** CNT-004
2. **Entrada:** base E2; delta: BASE-E2 (sin DOMINIO PRODUCTOR)
3. **Evidencia exacta (precondiciones, reproducidas):** patrón E2; sin dominio PRODUCER
4. **Esperado (candidato, no aprobado):** No aplica
5. **Justificación:** CNT-004 «No aplica»
6. **Campos:** architecturalDomain
7. **Dependencias:** —
8. **Invalidantes:** —

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ
child: RectangleContainerBlock «ms-payment-status» ⊂ integ
ev: BPMNEvent ⊂ integ,child
l1: api(None) → ev(Arrow)
```
</details>

### PA-CNT-005-C — Cumple — EJECUTABLE_CON_RESERVA

1. **Regla:** CNT-005
2. **Entrada:** base E1D; delta: Contenedor `sysext` «SISTEMAS EXTERNOS» ⊃ auxiliar `aux1` «Core System» ⊃ anotación `n1`
3. **Evidencia exacta (precondiciones, reproducidas):** aux1 auxiliar; dominio EXTERNAL_SYSTEM
4. **Esperado (candidato, no aprobado):** Cumple
5. **Justificación:** CNT-005 «Cumple»: sólo contenido permitido (auxiliar); lo encapsulado se evalúa en EXT-001
6. **Campos:** architecturalType, architecturalDomain, structuralParent
7. **Dependencias:** C-06; reserva: reproducible; el resultado depende de C-06
8. **Invalidantes:** —

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
sysext: UMLRectangleContainerBlock «SISTEMAS EXTERNOS»
aux1: BPMNGroup «Core System» ⊂ sysext
n1: BPMNTextAnnotation «External core» ⊂ aux1
l1: api(None) → ev(Arrow)
```
</details>

### PA-CNT-005-NC — No cumple — EJECUTABLE_CON_RESERVA

1. **Regla:** CNT-005
2. **Entrada:** base E1D; delta: Gestor `qm1` directamente en «SISTEMAS EXTERNOS»
3. **Evidencia exacta (precondiciones, reproducidas):** gestor en EXTERNAL_SYSTEM
4. **Esperado (candidato, no aprobado):** No cumple
5. **Justificación:** CNT-005 «No cumple»: los gestores de colas no se permiten en SISTEMAS EXTERNOS
6. **Campos:** architecturalType, domainRole
7. **Dependencias:** C-10 (consecuencia para gestores externos); reserva: reproducible; el resultado depende de C-10 (consecuencia para gestores externos)
8. **Invalidantes:** Si C-10 permite gestores externos

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
sysext: UMLRectangleContainerBlock «SISTEMAS EXTERNOS»
qm1: UMLActiveClassBlock «Payments Queue Manager» ⊂ sysext
l1: api(None) → ev(Arrow)
```
</details>

### PA-CNT-005-NA — No aplica — EJECUTABLE_DEFINITIVA

1. **Regla:** CNT-005
2. **Entrada:** base E1D; delta: Sin cambios
3. **Evidencia exacta (precondiciones, reproducidas):** sin dominio EXTERNAL_SYSTEM
4. **Esperado (candidato, no aprobado):** No aplica
5. **Justificación:** CNT-005 «No aplica»
6. **Campos:** architecturalDomain
7. **Dependencias:** —
8. **Invalidantes:** —

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
l1: api(None) → ev(Arrow)
```
</details>

### PA-EXT-001-C — Cumple — EJECUTABLE_DEFINITIVA

1. **Regla:** EXT-001
2. **Entrada:** base E1D; delta: Auxiliar `aux1` «Core System» ⊃ anotación `n1` en INTEGRACIÓN
3. **Evidencia exacta (precondiciones, reproducidas):** aux1 auxiliar con contenido
4. **Esperado (candidato, no aprobado):** Cumple
5. **Justificación:** EXT-001 «Cumple»: nombre no vacío y contenido permitido
6. **Campos:** architecturalType, name, containedComponentIds
7. **Dependencias:** C-10
8. **Invalidantes:** —

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
aux1: BPMNGroup «Core System» ⊂ integ
n1: BPMNTextAnnotation «External core» ⊂ aux1
l1: api(None) → ev(Arrow)
```
</details>

### PA-EXT-001-NC — No cumple — EJECUTABLE_CON_RESERVA

1. **Regla:** EXT-001
2. **Entrada:** base E1D; delta: Auxiliar `aux1` ⊃ gestor `qm1`
3. **Evidencia exacta (precondiciones, reproducidas):** aux1 auxiliar; contiene el gestor
4. **Esperado (candidato, no aprobado):** No cumple
5. **Justificación:** EXT-001 «No cumple»: contiene un componente certificado en categoría no permitida
6. **Campos:** containedComponentIds, architecturalType
7. **Dependencias:** C-10; reserva: reproducible; el resultado depende de C-10
8. **Invalidantes:** Si C-10 permite gestores en auxiliares

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
aux1: BPMNGroup «Core System» ⊂ integ
qm1: UMLActiveClassBlock «Payments Queue Manager» ⊂ aux1
l1: api(None) → ev(Arrow)
```
</details>

### PA-EXT-001-NV — No verificable — EJECUTABLE_DEFINITIVA

1. **Regla:** EXT-001
2. **Entrada:** base E1D; delta: Auxiliar `aux1` sin contenido
3. **Evidencia exacta (precondiciones, reproducidas):** aux1 auxiliar vacío
4. **Esperado (candidato, no aprobado):** No verificable
5. **Justificación:** EXT-001 «No verificable»: el auxiliar no encapsula componentes
6. **Campos:** containedComponentIds
7. **Dependencias:** —
8. **Invalidantes:** —

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
aux1: BPMNGroup «Core System» ⊂ integ
l1: api(None) → ev(Arrow)
```
</details>

### PA-EXT-001-NA — No aplica — EJECUTABLE_DEFINITIVA

1. **Regla:** EXT-001
2. **Entrada:** base E1D; delta: Sin cambios
3. **Evidencia exacta (precondiciones, reproducidas):** sin auxiliares
4. **Esperado (candidato, no aprobado):** No aplica
5. **Justificación:** EXT-001 «No aplica»
6. **Campos:** architecturalType
7. **Dependencias:** —
8. **Invalidantes:** —

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
l1: api(None) → ev(Arrow)
```
</details>

### PA-EXT-002-NV — No verificable — EJECUTABLE_CON_RESERVA

1. **Regla:** EXT-002
2. **Entrada:** base E1D; delta: Auxiliar `aux1` «EVC Payments» ⊃ `ext1` (`UMLClassBlock` sin tipo)
3. **Evidencia exacta (precondiciones, reproducidas):** aux1 auxiliar; ext1 sin tipo
4. **Esperado (candidato, no aprobado):** No verificable
5. **Justificación:** EXT-002 «No verificable»: no puede certificarse que el componente encapsulado sea una API
6. **Campos:** name, containedComponentIds, architecturalType
7. **Dependencias:** C-04; reserva: reproducible; el resultado depende de C-04
8. **Invalidantes:** Si C-04 permite certificar la API

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
aux1: BPMNGroup «EVC Payments» ⊂ integ
ext1: UMLClassBlock «Ledger - Account Balance v1.0.0 | getBalance | Entidad» ⊂ aux1
l1: api(None) → ev(Arrow)
```
</details>

### PA-EXT-002-NA — No aplica — EJECUTABLE_DEFINITIVA

1. **Regla:** EXT-002
2. **Entrada:** base E1D; delta: Auxiliar «EVC Payments» ⊃ sólo una anotación
3. **Evidencia exacta (precondiciones, reproducidas):** aux1 auxiliar; sin UMLClassBlock dentro
4. **Esperado (candidato, no aprobado):** No aplica
5. **Justificación:** EXT-002 «No aplica»: existen auxiliares EVC pero se certifica que no contienen API
6. **Campos:** name, containedComponentIds
7. **Dependencias:** —
8. **Invalidantes:** —

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
aux1: BPMNGroup «EVC Payments» ⊂ integ
n1: BPMNTextAnnotation «External core» ⊂ aux1
l1: api(None) → ev(Arrow)
```
</details>

### PA-MOD-001-NC — No cumple — EJECUTABLE_DEFINITIVA

1. **Regla:** MOD-001
2. **Entrada:** base E1D; delta: Sin cambios (no hay modelos en la página)
3. **Evidencia exacta (precondiciones, reproducidas):** sin figuras ENTRADA/SALIDA; API principal
4. **Esperado (candidato, no aprobado):** No cumple
5. **Justificación:** MOD-001 «No cumple»: falta el modelo de entrada y de salida de la API principal, con cobertura certificada
6. **Campos:** customData, groups
7. **Dependencias:** C-03
8. **Invalidantes:** Si hay candidatos de modelo en la página

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
l1: api(None) → ev(Arrow)
```
</details>

### PA-MOD-001-NV — No verificable — EJECUTABLE_DEFINITIVA

1. **Regla:** MOD-001
2. **Entrada:** base E1D; delta: Modelos `in1` (ENTRADA) y `out1` (SALIDA) en INTEGRACIÓN, sin grupo con la API
3. **Evidencia exacta (precondiciones, reproducidas):** modelos con customData; sin grupos
4. **Esperado (candidato, no aprobado):** No verificable
5. **Justificación:** MOD-001 «No verificable»: existen modelos candidatos pero no puede demostrarse su asociación a la API
6. **Campos:** customData, groups, structuralParent
7. **Dependencias:** C-13 (sólo si se acepta el grupo como asociación)
8. **Invalidantes:** —

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
in1: BPMNActivity «paymentRequest { id }» customData=["ENTRADA"] ⊂ integ
out1: BPMNActivity «paymentResponse { status }» customData=["SALIDA"] ⊂ integ
l1: api(None) → ev(Arrow)
```
</details>

### PA-COM-005-NV — No verificable — EJECUTABLE_CON_RESERVA

1. **Regla:** COM-005
2. **Entrada:** base E1D; delta: Comando `c1` bidireccional con el auxiliar `aux1`, que contiene dos `UMLClassBlock`
3. **Evidencia exacta (precondiciones, reproducidas):** aux1 auxiliar con dos internos
4. **Esperado (candidato, no aprobado):** No verificable
5. **Justificación:** COM-005 «No verificable»: existen varios componentes internos y no puede atribuirse la conexión a uno
6. **Campos:** connections, containedComponentIds
7. **Dependencias:** C-12; reserva: reproducible; el resultado depende de C-12
8. **Invalidantes:** Si C-12 define atribución distinta

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
aux1: BPMNGroup «Core System» ⊂ integ
ext1: UMLClassBlock «Ledger - Account Balance v1.0.0 | getBalance | Entidad» ⊂ aux1
ext2: UMLClassBlock «Ledger - Account Owner v1.0.0 | getOwner | Entidad» ⊂ aux1
c1: BPMNActivity «Consultar saldo» ⊂ child
l1: api(None) → ev(Arrow)
aa: c1(CircleOpen) → aux1(Generalization)
ab: aux1(CircleOpen) → c1(Generalization)
```
</details>

### PA-COM-005-NA — No aplica — EJECUTABLE_DEFINITIVA

1. **Regla:** COM-005
2. **Entrada:** base E1D; delta: Sin cambios
3. **Evidencia exacta (precondiciones, reproducidas):** sin auxiliares
4. **Esperado (candidato, no aprobado):** No aplica
5. **Justificación:** COM-005 «No aplica»
6. **Campos:** architecturalType
7. **Dependencias:** —
8. **Invalidantes:** —

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
l1: api(None) → ev(Arrow)
```
</details>

### PA-COM-002-NV — No verificable — EJECUTABLE_CON_RESERVA

1. **Regla:** COM-002
2. **Entrada:** base E1D; delta: Igual que PA-COM-001-NV
3. **Evidencia exacta (precondiciones, reproducidas):** ext1 sin tipo ni rol
4. **Esperado (candidato, no aprobado):** No verificable
5. **Justificación:** COM-002 «No verificable»: no puede certificarse la API invocada
6. **Campos:** architecturalType, role, connections
7. **Dependencias:** C-04, C-05; reserva: reproducible; el resultado depende de C-04, C-05
8. **Invalidantes:** Si se aprueba certificar invocados

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
ext1: UMLClassBlock «Ledger - Account Balance v1.0.0 | getBalance | Entidad» ⊂ integ
c1: BPMNActivity «Consultar saldo» ⊂ child
l1: api(None) → ev(Arrow)
xa: c1(CircleOpen) → ext1(Generalization)
xb: ext1(CircleOpen) → c1(Generalization)
```
</details>

### PA-COM-002-NA — No aplica — EJECUTABLE_DEFINITIVA

1. **Regla:** COM-002
2. **Entrada:** base E1D; delta: Sin cambios
3. **Evidencia exacta (precondiciones, reproducidas):** sin comandos
4. **Esperado (candidato, no aprobado):** No aplica
5. **Justificación:** COM-002 «No aplica»: sin APIs invocadas relacionadas con comandos
6. **Campos:** lucidchartType
7. **Dependencias:** —
8. **Invalidantes:** —

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
l1: api(None) → ev(Arrow)
```
</details>

### PA-COM-003-NV — No verificable — EJECUTABLE_CON_RESERVA

1. **Regla:** COM-003
2. **Entrada:** base E1D; delta: Comando `c1` bidireccional con `svc1` «ms-ledger»
3. **Evidencia exacta (precondiciones, reproducidas):** svc1 SERVICIO; rol no INVOCADO
4. **Esperado (candidato, no aprobado):** No verificable
5. **Justificación:** COM-003 «No verificable»: no puede certificarse el servicio como invocado
6. **Campos:** architecturalType, role, connections
7. **Dependencias:** C-05; reserva: reproducible; el resultado depende de C-05
8. **Invalidantes:** Si C-05 redefine «invocado»

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
svc1: UMLClassBlock «ms-ledger | postEntry | Entidad» ⊂ integ
c1: BPMNActivity «Consultar saldo» ⊂ child
l1: api(None) → ev(Arrow)
sa: c1(CircleOpen) → svc1(Generalization)
sb: svc1(CircleOpen) → c1(Generalization)
```
</details>

### PA-COM-003-NA — No aplica — EJECUTABLE_DEFINITIVA

1. **Regla:** COM-003
2. **Entrada:** base E1D; delta: Sin cambios
3. **Evidencia exacta (precondiciones, reproducidas):** sin comandos
4. **Esperado (candidato, no aprobado):** No aplica
5. **Justificación:** COM-003 «No aplica»
6. **Campos:** lucidchartType
7. **Dependencias:** —
8. **Invalidantes:** —

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
l1: api(None) → ev(Arrow)
```
</details>

### PA-SRV-003-NV — No verificable — EJECUTABLE_CON_RESERVA

1. **Regla:** SRV-003
2. **Entrada:** base E1D; delta: Igual que PA-COM-003-NV
3. **Evidencia exacta (precondiciones, reproducidas):** svc1 SERVICIO sin rol INVOCADO
4. **Esperado (candidato, no aprobado):** No verificable
5. **Justificación:** SRV-003 «No verificable»: no puede certificarse su rol como invocado
6. **Campos:** architecturalType, role
7. **Dependencias:** C-05; reserva: reproducible; el resultado depende de C-05
8. **Invalidantes:** Si C-05 redefine «invocado»

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
svc1: UMLClassBlock «ms-ledger | postEntry | Entidad» ⊂ integ
c1: BPMNActivity «Consultar saldo» ⊂ child
l1: api(None) → ev(Arrow)
sa: c1(CircleOpen) → svc1(Generalization)
sb: svc1(CircleOpen) → c1(Generalization)
```
</details>

### PA-SRV-003-NA — No aplica — EJECUTABLE_DEFINITIVA

1. **Regla:** SRV-003
2. **Entrada:** base E1D; delta: Sin cambios (el hijo principal no hace aplicable la regla)
3. **Evidencia exacta (precondiciones, reproducidas):** sin SERVICIO; hijo principal presente
4. **Esperado (candidato, no aprobado):** No aplica
5. **Justificación:** SRV-003 «No aplica»: sin servicios invocados ni candidatos; el hijo no la hace aplicable
6. **Campos:** architecturalType, role
7. **Dependencias:** —
8. **Invalidantes:** —

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
l1: api(None) → ev(Arrow)
```
</details>

### PA-E1-001-NV — No verificable — EJECUTABLE_DEFINITIVA

1. **Regla:** E1-001
2. **Entrada:** base E1D; delta: Sin cambios (el evento no declara subtipo)
3. **Evidencia exacta (precondiciones, reproducidas):** E1/HIPOTESIS; subtipo no certificado; línea None->Arrow
4. **Esperado (candidato, no aprobado):** No verificable
5. **Justificación:** E1-001 «No verificable»: si el único dato pendiente es el subtipo Inicio, la regla permanece No verificable
6. **Campos:** scenario.event.subtypeStatus, scenario.connection.orientation
7. **Dependencias:** C-07
8. **Invalidantes:** Si se certifica el Inicio

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
l1: api(None) → ev(Arrow)
```
</details>

### PA-E1-001-NA — No aplica — EJECUTABLE_DEFINITIVA

1. **Regla:** E1-001
2. **Entrada:** base E2; delta: BASE-E2
3. **Evidencia exacta (precondiciones, reproducidas):** E2/HIPOTESIS
4. **Esperado (candidato, no aprobado):** No aplica
5. **Justificación:** E1-001 «No aplica»: el patrón certificado es E2 y no hay candidatos E1
6. **Campos:** scenario.scenario
7. **Dependencias:** —
8. **Invalidantes:** —

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ
child: RectangleContainerBlock «ms-payment-status» ⊂ integ
ev: BPMNEvent ⊂ integ,child
l1: api(None) → ev(Arrow)
```
</details>

### PA-E2-001-NV — No verificable — EJECUTABLE_DEFINITIVA

1. **Regla:** E2-001
2. **Entrada:** base E2; delta: BASE-E2 (API y hijo separados en INTEGRACIÓN; evento sin subtipo)
3. **Evidencia exacta (precondiciones, reproducidas):** E2/HIPOTESIS; subtipo no certificado
4. **Esperado (candidato, no aprobado):** No verificable
5. **Justificación:** E2-001 «No verificable»: Inicio no certificado
6. **Campos:** scenario.event
7. **Dependencias:** C-07
8. **Invalidantes:** Si se certifica el Inicio

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ
child: RectangleContainerBlock «ms-payment-status» ⊂ integ
ev: BPMNEvent ⊂ integ,child
l1: api(None) → ev(Arrow)
```
</details>

### PA-E2-001-NA — No aplica — EJECUTABLE_DEFINITIVA

1. **Regla:** E2-001
2. **Entrada:** base E1D; delta: BASE-E1D
3. **Evidencia exacta (precondiciones, reproducidas):** E1/HIPOTESIS
4. **Esperado (candidato, no aprobado):** No aplica
5. **Justificación:** E2-001 «No aplica»: el patrón certificado es E1
6. **Campos:** scenario.scenario
7. **Dependencias:** —
8. **Invalidantes:** —

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
l1: api(None) → ev(Arrow)
```
</details>

### PA-E3-001-NV — No verificable — EJECUTABLE_DEFINITIVA

1. **Regla:** E3-001
2. **Entrada:** base E3; delta: BASE-E3 (servicio principal e hijo en el productor; evento sin subtipo)
3. **Evidencia exacta (precondiciones, reproducidas):** patrón E3; subtipo no certificado
4. **Esperado (candidato, no aprobado):** No verificable
5. **Justificación:** E3-001 «No verificable»: Inicio no certificado
6. **Campos:** scenario.event
7. **Dependencias:** C-07
8. **Invalidantes:** Si se certifica el Inicio

<details><summary>Fixture completo</summary>

```
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
svc: UMLClassBlock «ms-payment-orchestrator | runPaymentOrchestration | tarea» ⊂ prod
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
l1: svc(None) → ev(Arrow)
```
</details>

### PA-E3-001-NA — No aplica — EJECUTABLE_DEFINITIVA

1. **Regla:** E3-001
2. **Entrada:** base E1D; delta: BASE-E1D
3. **Evidencia exacta (precondiciones, reproducidas):** E1/HIPOTESIS
4. **Esperado (candidato, no aprobado):** No aplica
5. **Justificación:** E3-001 «No aplica»: el patrón certificado es E1
6. **Campos:** scenario.scenario
7. **Dependencias:** —
8. **Invalidantes:** —

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
l1: api(None) → ev(Arrow)
```
</details>

### PA-EVT-001-NV — No verificable — EJECUTABLE_CON_RESERVA

1. **Regla:** EVT-001
2. **Entrada:** base E1D; delta: Figura `evt1` (`UMLClassBlock`, tercera sección «Empresarial - Event») en INTEGRACIÓN
3. **Evidencia exacta (precondiciones, reproducidas):** evt1 sin tipo arquitectónico; tercera sección publicada
4. **Esperado (candidato, no aprobado):** No verificable
5. **Justificación:** EVT-001 «No verificable»: no puede certificarse que el componente sea un evento de integración
6. **Campos:** architecturalType, textAreas
7. **Dependencias:** C-04, C-06; reserva: reproducible; el resultado depende de C-04, C-06
8. **Invalidantes:** Si C-04/C-06 aprueban un reconocimiento del evento de integración

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
evt1: UMLClassBlock «Payments - Payment Created_v1.0.0 | onPaymentCreated | Empresarial - Event» ⊂ integ
l1: api(None) → ev(Arrow)
```
</details>

### PA-EVT-001-NA — No aplica — EJECUTABLE_DEFINITIVA

1. **Regla:** EVT-001
2. **Entrada:** base E1D; delta: Sin cambios (no hay eventos de integración ni candidatos)
3. **Evidencia exacta (precondiciones, reproducidas):** sin UMLClassBlock candidato
4. **Esperado (candidato, no aprobado):** No aplica
5. **Justificación:** EVT-001 «No aplica»: sin eventos de integración ni candidatos
6. **Campos:** lucidchartType, textAreas
7. **Dependencias:** —
8. **Invalidantes:** —

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
l1: api(None) → ev(Arrow)
```
</details>

### PA-EVT-002-NV — No verificable — EJECUTABLE_CON_RESERVA

1. **Regla:** EVT-002
2. **Entrada:** base E1D; delta: Figura `evt1` (`UMLClassBlock`, tercera sección «Empresarial - Event») en INTEGRACIÓN
3. **Evidencia exacta (precondiciones, reproducidas):** evt1 sin tipo arquitectónico; tercera sección publicada
4. **Esperado (candidato, no aprobado):** No verificable
5. **Justificación:** EVT-002 «No verificable»: no puede certificarse que el componente sea un evento de integración
6. **Campos:** architecturalType, textAreas
7. **Dependencias:** C-04, C-06; reserva: reproducible; el resultado depende de C-04, C-06
8. **Invalidantes:** Si C-04/C-06 aprueban un reconocimiento del evento de integración

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
evt1: UMLClassBlock «Payments - Payment Created_v1.0.0 | onPaymentCreated | Empresarial - Event» ⊂ integ
l1: api(None) → ev(Arrow)
```
</details>

### PA-EVT-002-NA — No aplica — EJECUTABLE_DEFINITIVA

1. **Regla:** EVT-002
2. **Entrada:** base E1D; delta: Sin cambios (no hay eventos de integración ni candidatos)
3. **Evidencia exacta (precondiciones, reproducidas):** sin UMLClassBlock candidato
4. **Esperado (candidato, no aprobado):** No aplica
5. **Justificación:** EVT-002 «No aplica»: sin eventos de integración ni candidatos
6. **Campos:** lucidchartType, textAreas
7. **Dependencias:** —
8. **Invalidantes:** —

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
l1: api(None) → ev(Arrow)
```
</details>

### PA-EVT-003-NV — No verificable — EJECUTABLE_CON_RESERVA

1. **Regla:** EVT-003
2. **Entrada:** base E1D; delta: Figura `evt1` (`UMLClassBlock`, tercera sección «Empresarial - Event») en INTEGRACIÓN
3. **Evidencia exacta (precondiciones, reproducidas):** evt1 sin tipo arquitectónico; tercera sección publicada
4. **Esperado (candidato, no aprobado):** No verificable
5. **Justificación:** EVT-003 «No verificable»: no puede certificarse que el componente sea un evento de integración
6. **Campos:** architecturalType, textAreas
7. **Dependencias:** C-04, C-06; reserva: reproducible; el resultado depende de C-04, C-06
8. **Invalidantes:** Si C-04/C-06 aprueban un reconocimiento del evento de integración

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
evt1: UMLClassBlock «Payments - Payment Created_v1.0.0 | onPaymentCreated | Empresarial - Event» ⊂ integ
l1: api(None) → ev(Arrow)
```
</details>

### PA-EVT-003-NA — No aplica — EJECUTABLE_DEFINITIVA

1. **Regla:** EVT-003
2. **Entrada:** base E1D; delta: Sin cambios (no hay eventos de integración ni candidatos)
3. **Evidencia exacta (precondiciones, reproducidas):** sin UMLClassBlock candidato
4. **Esperado (candidato, no aprobado):** No aplica
5. **Justificación:** EVT-003 «No aplica»: sin eventos de integración ni candidatos
6. **Campos:** lucidchartType, textAreas
7. **Dependencias:** —
8. **Invalidantes:** —

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
l1: api(None) → ev(Arrow)
```
</details>

### PA-EVT-004-NV — No verificable — EJECUTABLE_CON_RESERVA

1. **Regla:** EVT-004
2. **Entrada:** base E1D; delta: Figura `evt1` (`UMLClassBlock`, tercera sección «Empresarial - Event») en INTEGRACIÓN
3. **Evidencia exacta (precondiciones, reproducidas):** evt1 sin tipo arquitectónico; tercera sección publicada
4. **Esperado (candidato, no aprobado):** No verificable
5. **Justificación:** EVT-004 «No verificable»: no puede certificarse que el componente sea un evento de integración
6. **Campos:** architecturalType, textAreas
7. **Dependencias:** C-04, C-06; reserva: reproducible; el resultado depende de C-04, C-06
8. **Invalidantes:** Si C-04/C-06 aprueban un reconocimiento del evento de integración

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
evt1: UMLClassBlock «Payments - Payment Created_v1.0.0 | onPaymentCreated | Empresarial - Event» ⊂ integ
l1: api(None) → ev(Arrow)
```
</details>

### PA-EVT-004-NA — No aplica — EJECUTABLE_DEFINITIVA

1. **Regla:** EVT-004
2. **Entrada:** base E1D; delta: Sin cambios (no hay eventos de integración ni candidatos)
3. **Evidencia exacta (precondiciones, reproducidas):** sin UMLClassBlock candidato
4. **Esperado (candidato, no aprobado):** No aplica
5. **Justificación:** EVT-004 «No aplica»: sin eventos de integración ni candidatos
6. **Campos:** lucidchartType, textAreas
7. **Dependencias:** —
8. **Invalidantes:** —

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
l1: api(None) → ev(Arrow)
```
</details>

### PA-EVT-005-NV — No verificable — EJECUTABLE_CON_RESERVA

1. **Regla:** EVT-005
2. **Entrada:** base E1D; delta: Figura `evt1` (`UMLClassBlock`, tercera sección «Empresarial - Event») en INTEGRACIÓN
3. **Evidencia exacta (precondiciones, reproducidas):** evt1 sin tipo arquitectónico; tercera sección publicada
4. **Esperado (candidato, no aprobado):** No verificable
5. **Justificación:** EVT-005 «No verificable»: no puede certificarse que el componente sea un evento de integración
6. **Campos:** architecturalType, textAreas
7. **Dependencias:** C-04, C-06; reserva: reproducible; el resultado depende de C-04, C-06
8. **Invalidantes:** Si C-04/C-06 aprueban un reconocimiento del evento de integración

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
evt1: UMLClassBlock «Payments - Payment Created_v1.0.0 | onPaymentCreated | Empresarial - Event» ⊂ integ
l1: api(None) → ev(Arrow)
```
</details>

### PA-EVT-005-NA — No aplica — EJECUTABLE_DEFINITIVA

1. **Regla:** EVT-005
2. **Entrada:** base E1D; delta: Sin cambios (no hay eventos de integración ni candidatos)
3. **Evidencia exacta (precondiciones, reproducidas):** sin UMLClassBlock candidato
4. **Esperado (candidato, no aprobado):** No aplica
5. **Justificación:** EVT-005 «No aplica»: sin eventos de integración ni candidatos
6. **Campos:** lucidchartType, textAreas
7. **Dependencias:** —
8. **Invalidantes:** —

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
l1: api(None) → ev(Arrow)
```
</details>

### PA-EVT-006-NV — No verificable — EJECUTABLE_CON_RESERVA

1. **Regla:** EVT-006
2. **Entrada:** base E1D; delta: Figura `evt1` (`UMLClassBlock`, tercera sección «Empresarial - Event») en INTEGRACIÓN
3. **Evidencia exacta (precondiciones, reproducidas):** evt1 sin tipo arquitectónico; tercera sección publicada
4. **Esperado (candidato, no aprobado):** No verificable
5. **Justificación:** EVT-006 «No verificable»: no puede certificarse que el componente sea un evento de integración
6. **Campos:** architecturalType, textAreas
7. **Dependencias:** C-04, C-06; reserva: reproducible; el resultado depende de C-04, C-06
8. **Invalidantes:** Si C-04/C-06 aprueban un reconocimiento del evento de integración

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
evt1: UMLClassBlock «Payments - Payment Created_v1.0.0 | onPaymentCreated | Empresarial - Event» ⊂ integ
l1: api(None) → ev(Arrow)
```
</details>

### PA-EVT-006-NA — No aplica — EJECUTABLE_DEFINITIVA

1. **Regla:** EVT-006
2. **Entrada:** base E1D; delta: Sin cambios (no hay eventos de integración ni candidatos)
3. **Evidencia exacta (precondiciones, reproducidas):** sin UMLClassBlock candidato
4. **Esperado (candidato, no aprobado):** No aplica
5. **Justificación:** EVT-006 «No aplica»: sin eventos de integración ni candidatos
6. **Campos:** lucidchartType, textAreas
7. **Dependencias:** —
8. **Invalidantes:** —

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
l1: api(None) → ev(Arrow)
```
</details>

### PA-EVT-007-NV — No verificable — EJECUTABLE_CON_RESERVA

1. **Regla:** EVT-007
2. **Entrada:** base E1D; delta: Figura `evt1` (`UMLClassBlock`, tercera sección «Empresarial - Event») en INTEGRACIÓN
3. **Evidencia exacta (precondiciones, reproducidas):** evt1 sin tipo arquitectónico; tercera sección publicada
4. **Esperado (candidato, no aprobado):** No verificable
5. **Justificación:** EVT-007 «No verificable»: no puede certificarse que el componente sea un evento de integración
6. **Campos:** architecturalType, textAreas
7. **Dependencias:** C-04, C-06; reserva: reproducible; el resultado depende de C-04, C-06
8. **Invalidantes:** Si C-04/C-06 aprueban un reconocimiento del evento de integración

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
evt1: UMLClassBlock «Payments - Payment Created_v1.0.0 | onPaymentCreated | Empresarial - Event» ⊂ integ
l1: api(None) → ev(Arrow)
```
</details>

### PA-EVT-007-NA — No aplica — EJECUTABLE_DEFINITIVA

1. **Regla:** EVT-007
2. **Entrada:** base E1D; delta: Sin cambios (no hay eventos de integración ni candidatos)
3. **Evidencia exacta (precondiciones, reproducidas):** sin UMLClassBlock candidato
4. **Esperado (candidato, no aprobado):** No aplica
5. **Justificación:** EVT-007 «No aplica»: sin eventos de integración ni candidatos
6. **Campos:** lucidchartType, textAreas
7. **Dependencias:** —
8. **Invalidantes:** —

<details><summary>Fixture completo</summary>

```
integ: UMLRectangleContainerBlock «INTEGRACIÓN»
flujo: UMLRectangleContainerBlock «Flujo Transaccional - no-monetario» ⊂ integ
capa: UMLRectangleContainerBlock «Capa de Arquitectura - sistema» ⊂ integ,flujo
api: UMLClassBlock «Payments - Payment Status v1.0.0 | getPaymentStatus | private - entidad» ⊂ integ,flujo,capa
prod: UMLRectangleContainerBlock «DOMINIO PRODUCTOR»
child: RectangleContainerBlock «ms-payment-status» ⊂ prod
ev: BPMNEvent ⊂ prod,child
l1: api(None) → ev(Arrow)
```
</details>

## 4. Pruebas bloqueadas

| Prueba | Regla | Estado | Categoría | Motivo |
|---|---|---|---|---|
| PA-CNT-001-NC | CNT-001 | No cumple | BLOQUEADA_POR_CONTRATO | el contrato actual no publica la cobertura o la ausencia demostrada (C-03) |
| PA-CNT-001-NA | CNT-001 | No aplica | BLOQUEADA_POR_CONTRATO | el contrato actual no publica la cobertura o la ausencia demostrada (C-03) |
| PA-CNT-002-NA | CNT-002 | No aplica | BLOQUEADA_POR_DECISION_NORMATIVA | depende de C-09 |
| PA-CNT-004-C | CNT-004 | Cumple | BLOQUEADA_POR_DECISION_NORMATIVA | depende de C-11 |
| PA-CNT-005-NV | CNT-005 | No verificable | BLOQUEADA_POR_DECISION_NORMATIVA | depende de C-10 |
| PA-EXT-002-C | EXT-002 | Cumple | BLOQUEADA_POR_DECISION_NORMATIVA | depende de C-11 |
| PA-EXT-002-NC | EXT-002 | No cumple | BLOQUEADA_POR_DECISION_NORMATIVA | depende de C-11 |
| PA-API-001-NA | API-001 | No aplica | BLOQUEADA_POR_DECISION_NORMATIVA | depende de C-09 |
| PA-API-002-NA | API-002 | No aplica | BLOQUEADA_POR_DECISION_NORMATIVA | depende de C-09 |
| PA-API-003-NA | API-003 | No aplica | BLOQUEADA_POR_DECISION_NORMATIVA | depende de C-09, C-11 |
| PA-SRV-001-C | SRV-001 | Cumple | BLOQUEADA_POR_DECISION_NORMATIVA | C-01: regla en esqueleto; no se fija ninguna expectativa |
| PA-SRV-001-NC | SRV-001 | No cumple | BLOQUEADA_POR_DECISION_NORMATIVA | C-01: regla en esqueleto; no se fija ninguna expectativa |
| PA-SRV-001-NV | SRV-001 | No verificable | BLOQUEADA_POR_DECISION_NORMATIVA | C-01: regla en esqueleto; no se fija ninguna expectativa |
| PA-SRV-001-NA | SRV-001 | No aplica | BLOQUEADA_POR_DECISION_NORMATIVA | C-01: regla en esqueleto; no se fija ninguna expectativa |
| PA-SRV-002-C | SRV-002 | Cumple | BLOQUEADA_POR_DECISION_NORMATIVA | C-01: regla en esqueleto; no se fija ninguna expectativa |
| PA-SRV-002-NC | SRV-002 | No cumple | BLOQUEADA_POR_DECISION_NORMATIVA | C-01: regla en esqueleto; no se fija ninguna expectativa |
| PA-SRV-002-NV | SRV-002 | No verificable | BLOQUEADA_POR_DECISION_NORMATIVA | C-01: regla en esqueleto; no se fija ninguna expectativa |
| PA-SRV-002-NA | SRV-002 | No aplica | BLOQUEADA_POR_DECISION_NORMATIVA | C-01: regla en esqueleto; no se fija ninguna expectativa |
| PA-SRV-003-C | SRV-003 | Cumple | BLOQUEADA_POR_CONVENCION | la evidencia requerida no se publica o no existe en el original (C-04, C-05, C-09, C-11) |
| PA-SRV-003-NC | SRV-003 | No cumple | BLOQUEADA_POR_CONVENCION | la evidencia requerida no se publica o no existe en el original (C-04, C-05, C-09, C-11) |
| PA-EVT-001-C | EVT-001 | Cumple | BLOQUEADA_POR_CONVENCION | la evidencia requerida no se publica o no existe en el original (C-04, C-06, C-09) |
| PA-EVT-001-NC | EVT-001 | No cumple | BLOQUEADA_POR_CONVENCION | la evidencia requerida no se publica o no existe en el original (C-04, C-06, C-09) |
| PA-EVT-002-C | EVT-002 | Cumple | BLOQUEADA_POR_CONVENCION | la evidencia requerida no se publica o no existe en el original (C-04, C-06, C-09) |
| PA-EVT-002-NC | EVT-002 | No cumple | BLOQUEADA_POR_CONVENCION | la evidencia requerida no se publica o no existe en el original (C-04, C-06, C-09) |
| PA-EVT-003-C | EVT-003 | Cumple | BLOQUEADA_POR_CONVENCION | la evidencia requerida no se publica o no existe en el original (C-04, C-06) |
| PA-EVT-003-NC | EVT-003 | No cumple | BLOQUEADA_POR_CONVENCION | la evidencia requerida no se publica o no existe en el original (C-04, C-06) |
| PA-EVT-004-C | EVT-004 | Cumple | BLOQUEADA_POR_CONVENCION | la evidencia requerida no se publica o no existe en el original (C-06) |
| PA-EVT-004-NC | EVT-004 | No cumple | BLOQUEADA_POR_CONVENCION | la evidencia requerida no se publica o no existe en el original (C-06) |
| PA-EVT-005-C | EVT-005 | Cumple | BLOQUEADA_POR_CONVENCION | la evidencia requerida no se publica o no existe en el original (C-06, C-11) |
| PA-EVT-005-NC | EVT-005 | No cumple | BLOQUEADA_POR_CONVENCION | la evidencia requerida no se publica o no existe en el original (C-06, C-11) |
| PA-EVT-006-C | EVT-006 | Cumple | BLOQUEADA_POR_CONVENCION | la evidencia requerida no se publica o no existe en el original (C-06, C-11) |
| PA-EVT-006-NC | EVT-006 | No cumple | BLOQUEADA_POR_CONVENCION | la evidencia requerida no se publica o no existe en el original (C-06, C-11) |
| PA-EVT-007-C | EVT-007 | Cumple | BLOQUEADA_POR_CONVENCION | la evidencia requerida no se publica o no existe en el original (C-06, C-07, C-11) |
| PA-EVT-007-NC | EVT-007 | No cumple | BLOQUEADA_POR_CONVENCION | la evidencia requerida no se publica o no existe en el original (C-06, C-07, C-11) |
| PA-CA-001-NV | CA-001 | No verificable | BLOQUEADA_POR_CONTRATO | el contrato actual no publica la cobertura o la ausencia demostrada (C-03) |
| PA-FT-001-NV | FT-001 | No verificable | BLOQUEADA_POR_CONTRATO | el contrato actual no publica la cobertura o la ausencia demostrada (C-03) |
| PA-E1-001-C | E1-001 | Cumple | BLOQUEADA_POR_CONVENCION | la evidencia requerida no se publica o no existe en el original (C-07, C-08) |
| PA-E1-001-NC | E1-001 | No cumple | BLOQUEADA_POR_CONVENCION | la evidencia requerida no se publica o no existe en el original (C-07, C-08) |
| PA-E2-001-C | E2-001 | Cumple | BLOQUEADA_POR_CONVENCION | la evidencia requerida no se publica o no existe en el original (C-07, C-08) |
| PA-E2-001-NC | E2-001 | No cumple | BLOQUEADA_POR_CONVENCION | la evidencia requerida no se publica o no existe en el original (C-07, C-08) |
| PA-E3-001-C | E3-001 | Cumple | BLOQUEADA_POR_CONVENCION | la evidencia requerida no se publica o no existe en el original (C-07, C-08) |
| PA-E3-001-NC | E3-001 | No cumple | BLOQUEADA_POR_CONVENCION | la evidencia requerida no se publica o no existe en el original (C-07, C-08) |
| PA-MOD-001-C | MOD-001 | Cumple | BLOQUEADA_POR_DECISION_NORMATIVA | depende de C-13 |
| PA-MOD-001-NA | MOD-001 | No aplica | BLOQUEADA_POR_DECISION_NORMATIVA | depende de C-13 |
| PA-COM-002-C | COM-002 | Cumple | BLOQUEADA_POR_CONVENCION | la evidencia requerida no se publica o no existe en el original (C-04, C-05) |
| PA-COM-002-NC | COM-002 | No cumple | BLOQUEADA_POR_CONVENCION | la evidencia requerida no se publica o no existe en el original (C-04, C-05) |
| PA-COM-003-C | COM-003 | Cumple | BLOQUEADA_POR_CONVENCION | la evidencia requerida no se publica o no existe en el original (C-04, C-05) |
| PA-COM-003-NC | COM-003 | No cumple | BLOQUEADA_POR_CONVENCION | la evidencia requerida no se publica o no existe en el original (C-04, C-05) |
| PA-COM-005-C | COM-005 | Cumple | BLOQUEADA_POR_DECISION_NORMATIVA | depende de C-12 |
| PA-COM-005-NC | COM-005 | No cumple | BLOQUEADA_POR_DECISION_NORMATIVA | depende de C-12 |
| PA-MQ-001-NV | MQ-001 | No verificable | BLOQUEADA_POR_DECISION_NORMATIVA | depende de C-09 |

No se fija ningún resultado esperado para SRV-001/SRV-002 ni se resuelve C-01…C-13.
