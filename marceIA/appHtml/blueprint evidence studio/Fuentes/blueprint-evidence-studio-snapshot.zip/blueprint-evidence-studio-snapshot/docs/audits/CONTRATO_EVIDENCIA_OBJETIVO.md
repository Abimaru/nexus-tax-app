# Contrato de evidencia objetivo — capacidades actuales y evolución requerida de Evidence Studio

Estado: **candidato, sin implementar** · 26/10/2026 · Contrato vigente: `copilot-factual-v0.4.6.1` (sin cambios) · Motor v0.4.6.1 · Interfaz v0.4.7 candidata.

Este documento no modifica `src/`, `ui/`, la Skill ni el contrato. Describe qué evidencia necesitan las 37 reglas del [catálogo candidato](CATALOGO_NORMATIVO_37_CANDIDATO.md), qué publica hoy Evidence Studio, y qué cambios habría que aprobar. La trazabilidad regla por regla está en [`MATRIZ_NORMA_EVIDENCIA_37.csv`](MATRIZ_NORMA_EVIDENCIA_37.csv); las decisiones abiertas, en [`DECISIONES_Y_PRUEBAS_PENDIENTES.md`](DECISIONES_Y_PRUEBAS_PENDIENTES.md).

Principio rector: **la existencia de un campo JSON no es prueba de que contenga evidencia suficiente.** Cada fila de la sección 3 distingue qué se publica, con qué origen y qué impide certificar.

## 1. Principios de la evolución del contrato

1. **Aditiva primero.** Los campos nuevos se añaden sin cambiar los existentes; los cambios de comportamiento de un campo publicado (EC-01, EC-05, EC-07) se marcan como ruptura y exigen versión de contrato nueva.
2. **Sin estados normativos.** El contrato describe evidencia (literal, derivada, con fuente, certeza y conflictos). Nunca emite Cumple / No cumple / No verificable / No aplica; `normativeEvaluation` seguirá siendo `null`.
3. **Fuente y certeza en cada reconocimiento nuevo** (`source`, `status`, `conflicts`), igual que `architecturalDomain` hoy.
4. **El texto libre no certifica.** Un nombre, una posición o una forma no son subtipo ni tipo. Sólo `customData` inequívoco bajo una convención aprobada, o una clase Lucidchart inequívoca, pueden certificar.
5. **Literal preservado.** `textAreas`, `customData`, IDs, grupos y conexiones siguen exportándose tal como vienen del original.
6. **Ningún panel visual certifica.** Los paneles de v0.4.7 describen evidencia; no sustituyen la evaluación.
7. **Invariancia verificable.** Mientras no se apruebe un cambio, el compacto de los cuatro blueprints reales debe conservar sus firmas SHA-256 (Oski `4ac9bf74…`, Currency `96d277f9…`, Virtual Account `d5dc78c7…`, Debit Card `e18fca05…`) y el HTML su hash (`205cc88e…`).

## 2. Capacidades actuales (contrato `copilot-factual-v0.4.6.1`)

Verificado leyendo el motor y midiendo sobre los 7 blueprints reales (14 páginas operativas).

| Campo | Qué publica | Qué **no** certifica |
|---|---|---|
| `pages[].pageClassification.kind` | OPERATIONAL, MIXED, TEMPLATE_OR_LEGEND, BDD_OR_REQUIREMENTS, UNRESOLVED | BDD se decide por la palabra «BDD» del título |
| `scenario.*` | E1/E2/E3 y certeza; evento, conexión y orientación | Se determina sólo con un camino API/servicio→`BPMNEvent` hacia un hijo; varios candidatos o terminaciones distintas ⇒ NO_DETERMINADO |
| `scenario.event.{subtype,subtypeStatus}` | Subtipo del evento del escenario si hay `customData` bajo `PROPOSED_CLOSED_CATALOG` | Sólo el evento del escenario; sin Mensaje ni Señal de Envío; 0 de 260 eventos con `customData` |
| `components[].architecturalType` | API y SERVICIO sólo para el componente principal inferido (o `ms…`), SERVICIO_HIJO por la figura, GESTOR_COLAS, EVENTO (=`BPMNEvent`), SISTEMA_EXTERNO_AUXILIAR (`BPMNGroup` con nombre), CAPA/FLUJO por prefijo del nombre, MODELO por nombre, `null` | `null` es el valor mayoritario: 62 `UMLClassBlock` sin tipo; `EVENTO` no es «evento de integración» |
| `components[].role` | PRINCIPAL, HIJO_PRINCIPAL, INVOCADO | `INVOCADO` exige entrada y ninguna salida: 0 emitidos |
| `architecturalDomain`, `domainRole`, `possibleDomainRoles` | Dominio efectivo con fuente (`DECLARED_DOMAIN_NAME`, `STRUCTURAL_CHILD_EVENT_MAIN_PATH`) y conflictos | Nombres propios sólo se reconocen si son PRODUCER |
| `structuralParent`, `containerChainIds`, `rootContainer` | Contención de `JSON.contains` | Los grupos no son contención |
| `deploymentAssociations` | Pares Flujo+Capa asociados por contención o grupo superior común | Una Capa sola, `Federado` y el hijo por grupos no se publican |
| `groups` | Miembros, padres y conflictos | Asociación, no propiedad |
| `connections` / `pages[].connections[]` | IDs por componente; líneas con extremos, estilos y etiquetas | Sin sentido por componente; el sentido se lee en la línea |
| `customData`, `textAreas` | Literales del original | La tercera sección no tiene campo propio |
| `containedComponentIds` | Contenido de un `BPMNGroup` | Sólo para `BPMNGroup` |
| `issues` | Pérdidas y conflictos | No hay tabla issue→regla ni definición de cobertura |
| Respuestas de la analista | MCI, exposición (fuera del JSON) | No certifican estructura, tipo ni subtipo |

## 3. Matriz tema por tema (alineación con Evidence Studio)

Clases de suficiencia: **S** suficiente · **P** parcial · **I** insuficiente · **N** imposible con los datos originales. «EC» = cambio propuesto de la lista de la sección 4.

| # | Tema | Obligaciones | Evidencia requerida | Origen en Lucidchart | Campo existente | Suficiencia | Brecha | Cambio propuesto | Decisión |
|---|---|---|---|---|---|---|---|---|---|
| 1 | API invocada | API-001..003, EXT-002, COM-002 | Componente certificado como API y no principal | `UMLClassBlock` de 3 secciones | `architecturalType=API` sólo en la principal (12) | **I** | 62 `UMLClassBlock` sin tipo; 30 con «Entidad» solo | EC-06 | C-04 |
| 2 | Servicio invocado | SRV-003, COM-003, MQ-003 | Componente certificado como servicio no principal | `UMLClassBlock` con prefijo `ms…` | `SERVICIO` por prefijo (5) | **I** | Prefijo es convención, no regla | EC-06 | C-04, C-05 |
| 3 | Rol INVOCADO y bidireccionalidad | SRV-003, COM-002/003, MQ-003 | Relación del componente con un comando o gestor | Líneas `CircleOpen→Generalization` en ambos sentidos | `role=INVOCADO` | **N** (por diseño del campo) | Exige «ninguna saliente»: 0 emitidos; 56 pares bidireccionales frente a 5 de un sentido | EC-01 (comportamiento) | C-05 |
| 4 | Evento de integración | EVT-001..007, CNT-003/004, MOD-001 | Figura certificada como evento de integración | `UMLClassBlock` con 3.ª sección «Empresarial - Event/Query» (5 casos) | `name`, `textAreas`; `architecturalType=null` | **I** | `EVENTO` es `BPMNEvent` | EC-03 | C-04, C-06 |
| 5 | Evento BPMN | CNT-003/004/005, E1-3, EVT-007, MQ-003 | Identificar el evento, su contención y sus líneas | `BPMNEvent` | `architecturalType=EVENTO`, `structuralParent`, `connections` | **S** (identificación) | No dice qué subtipo es | — | — |
| 6 | Subtipo Inicio | E1-001, E2-001, E3-001 | Evento certificado como Inicio dentro del hijo | **No existe en el export** (claves del evento: `id, class, textAreas, customData, linkedData, linkUrl`) | `scenario.event.subtype/subtypeStatus` | **N** sin convención | 0 de 260 con `customData`; sólo se interpreta el evento del escenario | EC-02 | C-07 |
| 7 | Señal de Envío | EVT-007 | Evento certificado como Señal de Envío | No existe en el export | Catálogo: START, END, SIGNAL, RECEIVE, EXCEPTION | **N** | Falta SEND; sólo evento del escenario | EC-02 | C-07 |
| 8 | Señal de Recepción | EVT-007 | Evento certificado como Señal de Recepción | No existe en el export | `RECEIVE` en el catálogo | **N** | Sólo evento del escenario | EC-02 | C-07 |
| 9 | Mensaje | MQ-003 | Evento certificado como Mensaje | No existe en el export | Ninguno | **N** | Falta MESSAGE | EC-02 | C-07 |
| 10 | Capa de Tópicos | EVT-004..007, MOD-001 | Contenedor reconocido como Capa de Tópicos y asociado al evento | `UMLRectangleContainerBlock` con texto de tópicos (1 ocurrencia en todo el corpus) | `structuralParent`, `groups` | **I** | Sin tipo ni criterio | EC-03 | C-06 |
| 11 | Tópicos | EVT-005, EVT-006 | Texto del tópico, rol `p`/`s`, pertenencia a la capa | Texto `p.producto.capacidad.vX` | `name`, `textAreas` | **P** (texto sí; pertenencia no) | 0 patrones completos en el corpus | EC-03 | C-06 |
| 12 | `Federado` | MQ-002, CNT-003/004/005, EXT-001 | Literal exacto asociado al gestor / capa | `UMLRectangleContainerBlock` o `MinimalTextBlock` con el texto «Federado» (8 casos) | `name`, `textAreas` (sin tipo) | **P** | Asociación al gestor no definida ni publicada | EC-04 | C-06 |
| 13 | Capa y Flujo | CA-001, FT-001, API-004, SRV-004, MQ-002 | Reconocer la figura, su nombre y su asociación | `UMLRectangleContainerBlock` con prefijo | `architecturalType=CAPA/FLUJO` (37/37), `deploymentAssociations` | **P** | Prefijo mal escrito no se tipa; Capa sin Flujo no se publica | EC-04 (+ opcional candidatas) | — |
| 14 | Dominios con nombre propio | CNT-001..005, E1-3 | Clasificación certificada del dominio | `UMLRectangleContainerBlock` con nombre libre | `architecturalDomain` (3 productores por estructura) | **P** | INTEGRACIÓN/EXTERNOS con nombre propio no se reconocen; 1 contenedor sin resolver | EC-05 | C-03, R-05 |
| 15 | Modelos ENTRADA/SALIDA | MOD-001, CNT-003/004 | Reconocer el modelo y asociarlo | `BPMNActivity` con `customData` ENTRADA/SALIDA (160) | `customData`, `groups` | **P** | Asociación por grupo: 20 únicos con el principal, 59 sin él, 43 sin grupo | — | C-13 |
| 16 | Auxiliares | EXT-001/002, COM-005, CNT-003..005 | Nombre, contenido, ubicación | `BPMNGroup` con nombre | `SISTEMA_EXTERNO_AUXILIAR`, `containedComponentIds` (34; 28 sin nombre y vacíos) | **S** | El contenido (27 con `UMLClassBlock`, 21 con `BPMNEvent`, 11 con `BPMNActivity`) no se clasifica | EC-03 | C-10 |
| 17 | Comandos | COM-001..005, CNT-003/004 | `BPMNActivity` con relación a API/servicio/gestor/auxiliar | `BPMNActivity` | `lucidchartType`, `connections` | **P** | No hay tipo comando; comparte clase con los modelos (se separan por `customData`) | — | C-12 |

## 4. Evolución requerida (todo sujeto a aprobación)

| EC | Cambio | Tipo | Impacto en el contrato | Necesario para | Decisión | ¿Alternativa sin motor? |
|---|---|---|---|---|---|---|
| EC-01 | Redefinir `INVOCADO` (relación con un comando o gestor, no ser principal ni hijo) | Comportamiento de un campo publicado | Ruptura; versión nueva | SRV-003, COM-002/003, MQ-003 | C-05 | No |
| EC-02 | Subtipos BPMN (Inicio, Envío, Recepción, Mensaje) en **todos** los eventos; `components[].bpmnEvent{subtype,subtypeStatus,evidence}` | Aditivo | v0.5.0 | E1-3, EVT-007, MQ-003 | C-07 | La Skill lee `customData` literal (menos determinista) |
| EC-03 | Reconocimiento de figuras (evento de integración, Capa de Tópicos, tópico, concepto, pendiente, política, anotación) con `figureKind{kind,source,status}` | Aditivo | v0.5.0 | EVT-001..007, CNT-003..005 | C-04, C-06 | La Skill lee `textAreas`/`lucidchartType` |
| EC-04 | Publicar Capa sin Flujo, `Federado` y el hijo por grupos | Aditivo | v0.5.0 | API-004 (partner), SRV-004, MQ-002 | C-06 | Ninguna fiable |
| EC-05 | Dominios con nombre propio por `customData` (INTEGRATION y EXTERNAL_SYSTEM) | Comportamiento | Ruptura | CNT-001 con nombres propios | C-03 | Exigir nombres reservados |
| EC-06 | Clasificar API/servicio/evento en `UMLClassBlock` no principales | Según la opción de C-04 | Aditivo o ruptura | API-001..003 (invocadas), EXT-002, SRV-003, COM-002/003, EVT-001..003 | C-04 | Pregunta por componente a la analista |
| EC-07 | `BPMNGroup` sin nombre como auxiliar sin nombre | Comportamiento | Ruptura | — (0 casos reales con contenido) | C-10 | `lucidchartType` ya lo permite leer |
| EC-08 | `SKILL_VERSION` (`11.2.1` en `src/version.js`) | Metadato | Ninguno | Coherencia de versiones | Andrés | — |
| EC-09 | Capturar respuestas `DECLARADO_POR_ANALISTA` fuera del compacto | Interfaz | Ninguno | API-004, SRV-004 | Opcional | Capturarlas en el chat |
| EC-10 | Tabla issue→regla y definición de cobertura | Documental (Skill) | Ninguno | Casi todas | C-03 | — |
| EC-11 | Publicar los candidatos a hijo principal (con dominio y vínculo con la API) y el patrón candidato aunque el escenario sea `NO_DETERMINADO` | Aditivo | v0.5.0 | CNT-001 y CNT-002 (ramas «no existe», «más de uno», «dominio distinto»); sin depender del Inicio | Pregunta vinculada a C-03 (ver INVESTIGACION_CNT002_2026-10-26.md) | No |

**Forma ilustrativa (no aprobada) de los campos aditivos:** cada reconocimiento nuevo llevaría `source` (`CLASS`, `TEXT_LITERAL`, `CUSTOM_DATA`, `STRUCTURE`), `status` (`RESOLVED`, `AMBIGUOUS`, `UNRESOLVED`) y `conflicts`, como `architecturalDomain`. Un valor `null` seguiría sin ser evidencia positiva.

## 5. Qué se puede hacer sin nuevas decisiones

| Acción | ¿Necesita decisión? |
|---|---|
| Documentar este contrato, las capacidades actuales y los límites | No |
| Pruebas que fijan el comportamiento actual (p. ej. `INVOCADO` no se emite en el patrón bidireccional, `MODELO` por nombre, Capa por prefijo) | No |
| EC-08 (metadato) | Sólo la autorización de implementar |
| EC-10 (tabla issue→regla y cobertura) | Aprobación del texto (C-03) |
| EC-01..EC-07 | **Sí** (C-04..C-07, C-10) |

## 6. Criterios de aceptación del contrato objetivo

1. Cada regla de la matriz tiene origen Lucidchart, campo publicado y suficiencia documentados y comprobados contra al menos un blueprint real o un fixture sintético derivado.
2. Ningún campo nuevo emite un estado normativo ni infiere por descarte.
3. Todo cambio de comportamiento lleva versión de contrato nueva, nota de ruptura y regeneración de las firmas SHA-256.
4. Las firmas del compacto de los cuatro blueprints reales sólo cambian donde el cambio aprobado lo exige, y el cambio se explica campo a campo.
5. Los paneles de la interfaz siguen siendo descriptivos.
6. Hay una prueba por cada brecha cerrada (p. ej. `INVOCADO` con ambos sentidos de COM; Capa sin Flujo; `Federado` asociado; dominio con nombre propio; subtipo Mensaje).
