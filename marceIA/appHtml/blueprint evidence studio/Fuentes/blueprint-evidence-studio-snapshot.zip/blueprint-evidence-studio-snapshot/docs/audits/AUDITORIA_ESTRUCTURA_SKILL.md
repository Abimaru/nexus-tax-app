# AUDITORÍA DE ESTRUCTURA DE LA SKILL (preparación de la v12)

> Candidato, no aprobado. Solo lectura sobre la Skill vigente, el ZIP v11.2.3 y el paquete de la analista. No se creó ningún ZIP ni se modificó ninguna fuente. Las decisiones C-01…C-13 siguen abiertas.
> Estimación de tokens: bytes ÷ 3,6 (no hay tokenizador disponible). Sirve para comparar archivos y arquitecturas entre sí, no como cifra absoluta.

## 0. Hallazgo principal

Hay **dos paquetes distintos** y no se pueden confundir:

| Paquete | Reglas | Archivos | Bytes | Tokens est. | Qué es |
|---|---:|---:|---:|---:|---|
| ZIP `dist/…v11.2.3.zip` (repo) | 41 | 16 (+2 carpetas) | 71 822 | ≈ 19 700 | Skill vigente de Evidence Studio. Los 7 archivos de reglas (29 KB) son **resúmenes** de las reglas |
| Paquete de la analista `…v11.2.2.zip` (37 reglas) | 37 | 16 | 164 197 | ≈ 45 000 | Texto normativo completo de 8 campos por regla (110 KB), con restos de 41 reglas |

La v12 parte del paquete de la analista, no del ZIP v11.2.3. Pasar de 41 resúmenes a 37 textos completos **multiplica por ≈ 3,8 el texto de reglas** (29 → 110 KB): es el coste de la exactitud normativa y no se reduce comprimiendo archivos (§ COMPARACION_ARQUITECTURAS).

## 1. Inventario — ZIP v11.2.3 (repositorio)

Clases: OBL = OBLIGATORIO_EN_ZIP · CONV = CONVENIENTE_EN_ZIP · REPO = SOLO_REPOSITORIO · RED = REDUNDANTE · GEN = GENERADO. «Normativo / Operativo» indica qué contiene; «Citado por» = archivos del repositorio (Skill, scripts, tests) que nombran el archivo.

| Archivo | Bytes | Función | Normativo / Operativo | Duplicado con | Citado por | Necesario para evaluar | Solo desarrollo | Clase |
|---|---:|---|---|---|---:|---|---|---|
| `SKILL.md` | 4 373 | Entrada y procedimiento resumido | Operativo con criterios normativos reescritos (estados, No aplica, Inicio) | `00-procedimiento`, `INSTRUCCIONES` | 3 | Sí | No | OBL (rehacer breve) |
| `00-procedimiento.md` | 9 663 | Precedencia, páginas, estados, métrica, interpretación operativa | Mixto; incluye «Criterio operativo de CNT-006» (regla retirada) | `SKILL`, `INSTRUCCIONES` | 4 | Sí | No | OBL (rehacer) |
| `01…07-reglas-*.md` (7) | 29 346 | Reglas de las 41 | Normativo **resumido**: «Cumple: evidencia suficiente y criterio satisfecho» se repite 41 veces | `catalogo-reglas-v11.2.csv` (otra redacción de las mismas reglas, con deriva) | 1–2 c/u | Sí | No | OBL (regenerar con los 37 textos completos) |
| `catalogo-reglas-v11.2.csv` | 16 183 | Las 41 reglas en tabla | Normativo (segunda copia) | Los 7 archivos de reglas | 3 | No (nadie lo lee en la evaluación) | Sí (lo exige `validate-skill-zip.mjs`) | RED / GEN |
| `CONTRATO-COMPACTO.md` | 5 319 | Diccionario de `copilot-factual-v0.4.6.1` | Operativo | `GUIA-TEXTAREAS` (parcial) | 5 | Sí | No | OBL (actualizar «41 filas») |
| `GUIA-TEXTAREAS.md` | 1 508 | Lectura de `textAreas` | Operativo | Parte en el contrato | 2 | Sí | No | OBL |
| `MATRIZ-EVIDENCIA-41.md` | 3 235 | Regla → evidencia → campo → pregunta | Operativo (parafrasea la «Evidencia mínima») | Evidencia mínima de las reglas | 4 | Sí (localizar campos) | No | GEN (índice) |
| `INSTRUCCIONES-AGENTE-V11.md` | 2 293 | Recordatorio de reglas operativas | Operativo | `SKILL` y `00-procedimiento` casi línea a línea | 2 | No | No | RED |
| `MANIFEST.md` | 1 439 | Inventario 41 + recursos + IDs retirados | Inventario (derivable) | CSV, `SKILL` | 2 | No (el inventario se deriva) | Sí | GEN / REPO |
| `CHANGELOG-V11.md` | 3 414 | Historial v11.0–v11.2.3 | Informativo | — | 1 | No | Sí | REPO |

## 2. Inventario — paquete de la analista (37 reglas), base de la v12

| Archivo | Bytes | Tokens est. | Contenido | Estado | Clase propuesta |
|---|---:|---:|---|---|---|
| `SKILL.md` | 5 865 | 1 607 | Procedimiento completo en viñetas | Duplica `00-procedimiento` en estados, métrica, preguntas, precedencias | OBL (rehacer breve) |
| `00-procedimiento.md` | 6 658 | 1 828 | Precedencia, integridad, subtipos, Capa de Despliegue, preguntas, conexiones, flujo, estados, métrica | Título «v11.2.1»; **no** trata `pageClassification` | OBL |
| `01-reglas-estructura.md` | 23 135 | 6 341 | CNT-001…005, EXT-001/002, GW-001 | Título «v11.2.1» | OBL |
| `02-reglas-api-servicios.md` | 20 328 | 5 551 | API-001…004, SRV-001…004 | Ídem; SRV-001/002 con `##` y texto heredado | OBL |
| `03-reglas-eventos.md` | 21 475 | 5 838 | EVT-001…007 | Ídem | OBL |
| `04-reglas-despliegue.md` | 5 864 | 1 612 | CA-001, FT-001 | Ídem | OBL |
| `05-reglas-escenarios.md` | 10 988 | 3 013 | E1-001, E2-001, E3-001 | Ídem | OBL |
| `06-reglas-modelos-comandos.md` | 19 026 | 5 227 | MOD-001, COM-001…005 | Ídem | OBL |
| `07-reglas-gestores-colas.md` | 9 378 | 2 574 | MQ-001…003 | Ídem | OBL |
| `catalogo-reglas-v11.2.csv` | 16 141 | 4 410 | **Las 41 reglas históricas** | Idéntico (MD5 `878d5c34…`) al CSV del ZIP v11.2.3; el `MANIFEST` lo llama `catalogo-reglas-vigente.csv` | RED / GEN |
| `MATRIZ-EVIDENCIA-37.md` | 10 164 | 2 796 | 37 filas: evidencia, campo, respuesta humana | Parafrasea la «Evidencia mínima» (similitud léxica 0,10–0,67; ver §3, D11) | GEN (índice) |
| `CONTRATO-COMPACTO.md` | 3 076 | 847 | Diccionario | **Más antiguo que el del repositorio**: sin `pageClassification`, `groups`, `containedComponentIds`, `lucidchartType`; dice «41 filas» | OBL (usar la versión del repo, actualizada) |
| `GUIA-TEXTAREAS.md` | 2 725 | 743 | Lectura de `textAreas` + **modalidad de validación de API por ubicación** | La modalidad API es criterio normativo fuera de las reglas (§3, D10) | OBL (quitar la parte duplicada) |
| `MANIFEST.md` | 7 430 | 2 043 | Inventario 37, cambios 41→37, glosario, respuestas humanas, controles | Mezcla inventario (derivable), historia (repo) y glosario normativo (se conserva) | REPO + glosario OBL |
| `INSTRUCCIONES-AGENTE-V11.md` | 1 059 | 291 | Recordatorios | Dice «41 filas» | RED |
| `CHANGELOG-V11.md` | 885 | 242 | Historial | Cita 41 | REPO |

Información normativa que **no se elimina**: los 296 campos de las reglas; los principios generales del procedimiento; el glosario «Lenguaje normativo vigente» y las «Respuestas humanas autorizadas» del `MANIFEST`; la modalidad de API de `GUIA-TEXTAREAS` (hasta confirmar que está íntegra en API-001…003).

## 3. Duplicaciones

Criterio: **referencia legítima** = cita el ID o la sección sin repetir la condición; **definición duplicada** = vuelve a escribir la condición (riesgo de deriva).

| ID | Concepto | Dónde está | Veredicto | Acción propuesta |
|---|---|---|---|---|
| D1 | Definición de los cuatro estados | Procedimiento §8; `SKILL` analista; reglas (8 campos); `INSTRUCCIONES` | Duplicada en `SKILL` e `INSTRUCCIONES` | Una definición en el procedimiento; `SKILL` solo la cita |
| D2 | Fórmula de cumplimiento | Procedimiento §10; ambos `SKILL`; `INSTRUCCIONES`; procedimiento v11.2.3 | Duplicada (4–5 copias) | Solo procedimiento |
| D3 | Preguntas MCI / exposición | Procedimiento §5; `SKILL`; `INSTRUCCIONES`; glosario del `MANIFEST`; matriz (columna humana); API-004 y SRV-004 | Duplicada; el `SKILL` añade «en un único bloque», que el procedimiento no dice | Solo procedimiento §5; índice indica la regla afectada |
| D4 | Precedencia de conexiones COM/MQ | Procedimiento §6; `SKILL`; notas 41→37 del `MANIFEST`; poblaciones de COM-00x y MQ-003 | Duplicada en `SKILL` | Solo procedimiento §6 |
| D5 | Subtipos BPMN | Procedimiento §3; `SKILL`; E1-3-001, EVT-007, MQ-003 | Duplicada en `SKILL` | Solo procedimiento §3 |
| D6 | «Prevalece No cumple» | Procedimiento §8; `SKILL`; **7 veces** dentro de las reglas | En las reglas es texto normativo literal (se conserva); en `SKILL` es duplicada | Quitar de `SKILL` |
| D7 | Ausencia solo da No cumple con cobertura | Procedimiento §8; `SKILL`; reglas | Duplicada en `SKILL` | Solo procedimiento |
| D8 | Inventario de 37 IDs | `MANIFEST`; CSV; `MATRIZ-EVIDENCIA`; `SKILL`; encabezados | Cinco copias manuales | Generar el índice desde las reglas |
| D9 | Concepto «Capa de Despliegue» | Procedimiento §4; glosario del `MANIFEST`; API-004, SRV-004, MQ-002, CA-001, FT-001 | Definición repetida | Glosario único; el procedimiento lo cita |
| D10 | Modalidad de validación de API (INTEGRACIÓN / SISTEMAS EXTERNOS) | `GUIA-TEXTAREAS`; procedimiento §7; API-001…003 | **Triple**, y el procedimiento remite a la guía para una condición que ya están en las reglas | Verificar equivalencia con API-001…003 y conservar solo la regla |
| D11 | Evidencia mínima | Campo de cada regla vs. columna de la `MATRIZ-EVIDENCIA` | Paráfrasis (≈ 100 caracteres frente a 250–650) | El índice no parafrasea: enumera campos y remite al campo «Evidencia mínima» |
| D12 | Límites de la declaración humana | Procedimiento §1 y §5; `SKILL`; `MANIFEST` | Triple | Solo procedimiento |
| D13 | Controles de integridad | Procedimiento §2; `SKILL` | Duplicada | Solo procedimiento |
| D14 | Texto de las reglas (rendición doble) | 7 archivos `md` + CSV en v11.2.3 | **Dos redacciones con deriva** (p. ej. CNT-002 «padre inmediato puede ser Flujo…» solo en el `md`) | Una sola fuente |
| D15 | Estados por regla fuera de la regla | `SKILL`/`INSTRUCCIONES` v11.2.3: «E1-001, E2-001 y E3-001 no se declaran Cumple sin Inicio»; procedimiento v11.2.3 punto 5 | Criterio por regla en archivos operativos (3 copias) | Eliminar; vive en E1/E2/E3-001 y en C-07/C-08 |

Cuantificación con huella de frases (≥ 60 caracteres): paquete de la analista, 17 frases repetidas entre archivos distintos; ZIP v11.2.3, 2. Las repeticiones entre **reglas** (28 frases ≥ 3 veces, ≈ 7,6 KB) son texto normativo literal y **no se eliminan**.

## 4. Contradicciones

### 4.1 Actuales (verificadas)

| ID | Dónde | Contradicción | Gravedad |
|---|---|---|---|
| X1 | Paquete analista | `catalogo-reglas-v11.2.csv` contiene **41** reglas; el resto declara 37 | Alta |
| X2 | `MANIFEST` analista | «Recursos obligatorios» lista `catalogo-reglas-vigente.csv`, que no existe en el paquete | Media |
| X3 | `CONTRATO-COMPACTO` analista | «una página requiere 41 filas» y no incluye `pageClassification` ni `groups`, campos que el contrato v0.4.6.1 sí publica | Alta |
| X4 | `INSTRUCCIONES`, `CHANGELOG` analista | Hablan de 41 filas; los 7 archivos de reglas se titulan «v11.2.1» | Media |
| X5 | `SKILL` analista vs. procedimiento §7 | `SKILL`: «37 resultados por cada página seleccionada»; procedimiento: «confirmar que la página no es exclusivamente plantilla o leyenda» (relacionado con C-11, punto 9) | Alta; **no se resuelve aquí** |
| X6 | `MANIFEST` analista | SRV-001/002 «deben producir un resultado por página» pero su criterio está pendiente (C-01) | Alta; **no se resuelve aquí** |
| X7 | v11.2.3 (repo) | Procedimiento punto 5: la exigencia de Inicio «no se extiende a CNT-002 … sigue pendiente», frente a CNT-002 vigente («No se requiere … Inicio»; R-02) | Alta |
| X8 | v11.2.3 (repo) | Punto 6: «CA-001: existencia y nombre de la Capa»; CA-001 vigente valida solo el nombre | Alta |
| X9 | v11.2.3 (repo) | Procedimiento conserva «Criterio operativo de CNT-006», regla retirada | Media |
| X10 | v11.2.3 (repo) | `SKILL` y procedimiento: «la ausencia de una figura no basta» para No aplica; las reglas vigentes definen No aplica como «sin X ni candidatos» | Media; ver P3 |
| X11 | Defecto del texto fuente | EXT-002 se cita a sí misma; API-004 «presenta todo la capa» (C-11) | Baja; defecto de la analista, solo se registra |

### 4.2 Potenciales (introducibles por la v12)

| ID | Riesgo |
|---|---|
| P1 | Reescribir el texto de una regla en `SKILL.md` o en la matriz: dos redacciones con deriva (ya ocurre con el CSV y las reglas de v11.2.3) |
| P2 | Mantener rutas distintas para «las reglas» (archivos) y «el índice»: un ID que existe en uno y no en otro |
| P3 | Un archivo operativo que redefina «No aplica» o «candidato pendiente» y pise la definición de la regla |
| P4 | El procedimiento remite a `GUIA-TEXTAREAS` para la modalidad API: una regla dependiendo de un archivo no normativo |
| P5 | Encabezados «v11.2.1» en reglas de la v12: la versión del paquete deja de ser trazable (C-02) |
| P6 | `validate-skill-zip.mjs`, `package-skill.ps1` y `test/skill.test.js` exigen el CSV y la matriz de 41 y hashean 41 cuerpos: fallarán o validarán lo antiguo |

## 5. Referencias y dependencias

- Referencias **entre reglas**: 31, desde 17 reglas. Con la partición por familia del autor (7 archivos) 13 cruzan archivos; con 4 grupos, 10; con 1 archivo, 0.
- IDs retirados citados dentro del texto normativo: **ninguno** (los 296 campos están limpios).
- IDs retirados en archivos operativos: `CNT-006` y `ACT-001` (procedimiento y `MANIFEST` v11.2.3), `EVT-008`, `CA-002`, `FT-002`, `MQ-004/005` en `MANIFEST`/`CHANGELOG`.
- Dependencias del empaquetado: `scripts/package-skill.ps1`, `scripts/validate-skill-zip.mjs`, `test/skill.test.js`, `qa/skill.lock.json` y el banco QA fijan nombres y cuerpos del paquete de 41 reglas.

## 6. Resumen de la auditoría

| Medida | Valor |
|---|---|
| Archivos del paquete de la analista | 16 (164 KB) |
| Archivos redundantes o generables | CSV, matriz, `INSTRUCCIONES`, inventario del `MANIFEST` (≈ 35 KB) |
| Solo repositorio | `CHANGELOG`, historia 41→37 del `MANIFEST` |
| Duplicaciones registradas | 15 (D1–D15); las repeticiones dentro del texto de las reglas son normativas y se conservan |
| Contradicciones actuales | 11 (X1–X11); 6 de gravedad alta (X1, X3, X5, X6, X7, X8). X5 y X6 dependen de decisiones abiertas (C-11, C-01) y no se resuelven aquí; el resto desaparece al regenerar el paquete desde una fuente única |
| Normativa que no puede perderse | 296 campos + principios + glosario |
