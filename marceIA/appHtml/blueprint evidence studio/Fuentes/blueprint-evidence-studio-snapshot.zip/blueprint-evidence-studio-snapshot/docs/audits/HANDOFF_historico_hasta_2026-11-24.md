# HANDOFF — Blueprint Evidence Studio 0.8.3 / Skill v11.8.5

## VIGENTE — Studio 0.11.0 / Skill 12.2.0 (24/11/2026)

La línea nueva se fusionó en esta carpeta el 24/11/2026 (decisión del usuario). Ya no existe una carpeta aparte: `blueprint-evidence-studio-nueva` quedó archivada y la versión anterior (Studio 0.8.3, Skill 11.8.7) está en `../blueprint-evidence-studio-snapshot-respaldo-2026-11-24-antes-de-12.1.0.zip`. Versiones: Skill 12.1.0, Studio 0.10.0 (sin sufijos). Lo que sigue prevalece sobre las secciones antiguas de este documento.

- **0.11.0 / 12.2.0 (24/11/2026):** GW-001 solo evalúa compuertas exclusivas e inclusivas (sin etiqueta de subtipo se evalúa igual); `inventory.compuertas[].subtipo`. Incluye lo de 0.10.1 / 12.1.1: la Capa de Tópicos de un servicio con MQ en la figura se asocia también por el grupo de la figura (`asociadaPor: GRUPO`; varias capas = `capasTopicosCandidatas`, `No verificable`); SRV-006 excluye el principal de E3; el corpus de pruebas pasó a 34 BP (tests de conteo actualizados; 5 páginas de BP antiguos sin etiquetas quedan sin hijo certificado).
- **Catálogo: 38 reglas (24/11/2026 se agregó SRV-006, servicio consumido por colas: Capa de Tópicos y tópicos sin plantilla; ver CHANGELOG, sexta tanda).** COM-002 a COM-006 se fusionaron en **COM-002 «Conexiones del SERVICE_TASK»**; **COM-003** es `SYSTEM_TASK`/`SUB_PROCESS` (solo `None`/`Arrow`, solo con comandos, compuertas y eventos BPMN). Nuevas: **GEN-001** (operación principal = nombre de la página, camelCase, exacta) y **MOD-002** (modelos sin texto de plantilla). **EXT-002** se fusionó en CNT-003/004/005; EXT-001 solo valida el nombre.
- **Comandos y modelos por etiqueta de la figura** (`customData`): `SERVICE_TASK`, `SYSTEM_TASK`, `SUB_PROCESS`, `USER_TASK` (no permitido en el hijo), `BUSINESS_RULE`/`EXCEPTION`/`CONCEPT`, subtipos de evento (`eventSubtype`) y `figuraBiblioteca`/`figura` (grupo raíz de la biblioteca).
- **API-001:** `Nombre Producto - Nombre API_vMayor.Menor.Parche`. API externa = figura `THIRD_PARTY_API`. Toda figura `THIRD_PARTY_API`, `THIRD_PARTY_SERVICE` o `THIRD_PARTY_MQ_SERVICE` va en SISTEMAS EXTERNOS (en INTEGRACIÓN incumple CNT-003; en el PRODUCTOR, CNT-004).
- **EVC/EPC/LDC:** el auxiliar puede encapsular API, servicios y eventos de integración y entonces va en el nivel padre de INTEGRACIÓN. **Política, mensaje de excepción, concepto y anotación** se permiten también en el nivel padre.
- **HTML:** el JSON solo se bloquea si un conector tiene un extremo suelto (`connectionBlockers`). Las terminaciones no permitidas las evalúan las reglas; None–None y las líneas de anotaciones quedan exentas.
- **24/11/2026:** HTML con título «Blueprint Evidence Studio», encabezado negro con logo (SVG en el HTML) y versión solo en el pie, páginas BDD y TEMPLATE_OR_LEGEND ocultas, extremo conectado descrito por tipo y texto; escenarios escritos E1 (API directo al backend) / E2 (API con servicio de integración) / E3 (Servicio no gestionado); tercera sección vacía aceptada en API y servicios de SISTEMAS EXTERNOS.
- **Pruebas:** 169, 166 pasan; fallan 3 conteos del corpus que también fallan en la estable. E2E sin ejecutar (falta Edge); el HTML no se probó en navegador.
- **Entregables en `dist/`:** `BlueprintEvidenceStudio-v0.11.0.html`, `validar-blueprint-integracion-v12.2.0.zip` (11 archivos), `INSTRUCCIONES-AGENTE-v12.2.0.md`. Copias en `../docs/validacion_skill_analista/entrega-12.1.0/`.
- **Pendiente:** la analista revisa la lista de BP donde la capa no contiene al hijo (Mortgage Loan Payment Schedule, Currency Exchange Quote Information, Credit Limit information, Customer Relationships Data, Currency Exchange Transactions, Credit Card Administration); corrida con Copilot; correcciones de la biblioteca (OTHER_DOMAIN_SERVICE, ONW_, UMG_SERVICE, MODEL_GROUP); política para BP antiguos sin etiquetas. Detalle en `CHANGELOG.md` y `docs/decisions/0020-linea-nueva-reglas-por-etiqueta.md`.

---


Actualizado: 03/11/2026. Sustituye al handoff de v0.4.6.1 (archivado en `docs/audits/HANDOFF_historico_hasta_2026-10-28.md`; el detalle de cada versión está en `CHANGELOG.md`).

## 1. Qué es y cómo se reparte el trabajo

Dos piezas, con responsabilidades que no se mezclan (ADR-0004):

| Pieza | Hace | No hace |
|---|---|---|
| **Studio** (HTML autocontenido, `src/` + `ui/`) | Reconoce figuras del JSON de Lucidchart y emite un JSON enriquecido: tipo certificado, candidato o sin tipo; asociaciones; inventario. | No evalúa reglas, no emite veredictos, no hace preguntas. |
| **Skill** `validar-blueprint-integracion` (11 archivos, `skills/`) | Contiene las 38 reglas, las fichas operativas (`08-fichas.md`) y la doctrina de estados. | No reconoce figuras por su cuenta. |
| **Agente** (Copilot corporativo) | Hace las preguntas MCI, cierra cada regla y entrega el informe citando «Nombre (id)». | No corrige tipos ni los infiere por nombre, color o posición. |

Las instrucciones del agente van aparte (`dist/INSTRUCCIONES-AGENTE-v<versión>.md`) y solo dicen lo que la Skill no dice.

## 2. Estado vigente

- **Candidato, no estable.** Studio 0.8.3, Skill 11.8.5, contrato `copilot-factual-v0.4.6.1`. Falta una corrida con Copilot de este paquete. Interfaz con aviso de páginas no evaluables y descargas bloqueadas (ADR-0016): `docs/validacion_skill_analista/BlueprintEvidenceStudio-v0.8.3-aviso.html`, verificada por http en el panel del navegador (con `pocket.json` bloquea; con Real Time Payments no).
- `npm test`: 156 pruebas, 0 fallos. Las pruebas E2E (Playwright) no se han podido ejecutar en este entorno y el HTML no se ha abierto en un navegador desde 0.8.0 (en el panel del navegador de Claude los scripts de `file://` no corren).
- Entregables en `dist/`: `BlueprintEvidenceStudio.html` (118.704 bytes), `validar-blueprint-integracion-v11.8.5.zip` (11 archivos, SHA-256 `da0aa85c…`), `INSTRUCCIONES-AGENTE-v11.8.5.md`. El HTML sigue siendo el de 0.8.3.
- Copias para la analista: `../docs/validacion_skill_analista/` (HTML v0.8.3 y `-aviso`, ZIP y instrucciones 11.8.5, `pruebas-v11.8.3/` con 8 JSON y guía, dos anexos).
- Este directorio **no es un repositorio Git**. No hay commit, push ni PR. El remoto `Abimaru/blueprint-evidence-studio` es privado; no publicar blueprints, `skills/`, normativa ni arquitectura interna (ver `docs/PUBLIC_DISTRIBUTION.md`).

## 3. Cambios de este ciclo (11.8.0 → 11.8.3)

| Versión | Cambio | ADR |
|---|---|---|
| 0.8.0 | La leyenda de notación y los bloques de descripción de API no se exportan; el hijo es solo el contenedor del hijo principal; todo `BPMNGroup` en un dominio es auxiliar; evento de integración exige tipo y clasificación; auxiliar EVC/EPC/LDC → API; candidato o pendiente en la población → No verificable | 0005, 0011 |
| 0.8.1 | Tarjeta de descargas antes del «Resultado factual»; tipo `CAPA_TOPICOS` por contención; pregunta de exposición siempre; sin preguntas se continúa | 0006, 0007, 0012 |
| 0.8.2 | Homologación de la exposición solo para la pregunta; API-004 Cumple con capas resueltas aunque haya parejas sin propietario; `ACTIVIDAD_SIN_TIPO` y EXT-001 No verificable | 0007, 0008, 0009 |
| Skill 11.8.7 | Formato de la pregunta agrupada por API: nombre una vez y ids juntos «Nombre (id1 y id2)» (ADR-0019) | 0019 |
| Skill 11.8.6 | Preguntas MCI por nombre de API; hijo de E1 supuesto no MCI; E3 sin preguntas; contenido de capas en CNT; `nivel: OTRO` No verificable (Studio sin cambio) | 0019 |
| 0.8.5-unicidad | Principal con nombre de plantilla y única conexión certificada → página evaluable (`placeholderMainAccepted`); aviso informativo de flechas sueltas | 0018 |
| 0.8.4-bloqueo | JSON solo si todas las páginas seleccionadas son MIXED/OPERATIONAL; mensaje sin causa (JSON descargable idéntico) | 0017 |
| 0.8.3-aviso | Aviso naranja y descargas bloqueadas si una página seleccionada es `TEMPLATE_OR_LEGEND`; causa en `pageClassification.reason` (JSON descargable idéntico) | 0016 |
| 11.8.5 | SRV-005 solo para servicios invocados; el principal de E3 queda fuera (lo evalúa E3-001) | 0015 |
| 11.8.4 | API-003 en SISTEMAS EXTERNOS acepta `entidad`/`utilidad`/`tarea` (Studio sin cambios) | 0014 |
| 0.8.3 | Nombre de figura = primer texto no vacío (corrige el nombre del hijo en CNT-002); contenedores sin `operation` | 0010 |

## 4. Decisiones abiertas y límites conocidos

- **SRV-004 y MQ-002** conservan la regla de parejas sin propietario (No verificable). Solo API-004 se relajó (ADR-0008). Pendiente que la analista confirme si se extiende.
- **EXT-001** puede pasar de Cumple a No verificable en otros BP que tengan actividades BPMN sin tipo dentro de un auxiliar (ADR-0009). No se ha medido en todo el corpus; la analista debe confirmarlo.
- **Debit Card `createVirtualCard`**: el hijo sigue con nombre vacío (ambos textos vacíos; el texto suelto «createVirtualDebitCard» no se usa). CNT-002 queda No cumple, y es correcto.
- **Nombres de plantilla** («NOMBRE SERVICIO») ya salen con ese nombre en el hijo; CNT-002 los sigue rechazando (8 páginas).
- **Tópicos de Investment/Escenario2** con «Nombre Evento» quedan como candidatos `["CAPA_TOPICOS"]`; se certifican al nombrar el evento y completar su tercera sección.
- El agente puede discrepar de la Skill: en la corrida de 11.8.2 contestó que usaba `FloatingTitle` o `name` y no `Text`. El error estaba en el Studio, no en el agente (ADR-0010). Regla práctica: ante un veredicto «sin razón», primero comprobar el JSON enriquecido, después la Skill, al final el agente.

## 5. Cómo trabajar (resumen; detalle en `docs/processes/`)

1. `npm test` antes de tocar nada.
2. Cambiar `src/`, `ui/`, `skills/` según corresponda; guardar copia previa del archivo que se edita.
3. Regenerar el snapshot del corpus y compararlo con el anterior: **solo deben cambiar los campos previstos** (`PROCESO-control-regresion.md`).
4. Reconstruir HTML, volver a calcular la línea base de `ui-contract-invariance`, empaquetar el ZIP, validarlo y copiar a `../docs/validacion_skill_analista/`.
5. Documentar en `CHANGELOG.md`; si hay una decisión nueva, un ADR.

Ciclo con la analista (cómo se reciben observaciones, se analizan, se confirman y se aplican): `docs/processes/PROCESO-ciclo-con-la-analista.md`.

## 6. Dónde está cada cosa

| Tema | Lugar |
|---|---|
| Decisiones | `docs/decisions/0001`–`0016` |
| Procesos | `docs/processes/` |
| Arquitectura | `docs/architecture/ARCHITECTURE.md` |
| Cronología de la validación con la analista | `../docs/validacion_skill_analista/HISTORIAL-VALIDACION-v11.8.md` |
| Índice general de documentación | `../docs/INDICE_DOCUMENTACION.md` |
| Auditorías y handoffs anteriores | `docs/audits/` |

## 7. Próximos pasos sugeridos

1. La analista corre el paquete 11.8.3 con Copilot en: Real Time Payments `createKey`, `ms_account-register`, Debit Card `createVirtualCard`, y confirma CNT-002, API-004 y EXT-001.
2. Medir cuántas páginas del corpus cambian EXT-001 por `ACTIVIDAD_SIN_TIPO` (aún no medido).
3. Decidir con la analista el alcance de la excepción de API-004 sobre SRV-004 y MQ-002.
4. Ejecutar `npm run test:e2e` y abrir el HTML en un navegador real (pendiente desde 0.8.0).
5. Inicializar Git cuando se defina destino y alcance.
