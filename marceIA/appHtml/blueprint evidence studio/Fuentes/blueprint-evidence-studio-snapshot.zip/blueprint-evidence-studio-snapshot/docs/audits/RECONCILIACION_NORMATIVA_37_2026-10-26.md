# Reconciliación normativa independiente: catálogo de 41 reglas (Skill v11.2.3) frente al borrador de 37 reglas de la analista

Fecha: 26/10/2026 · Auditoría de solo lectura · Evidence Studio v0.4.7 candidata (motor v0.4.6.1, contrato `copilot-factual-v0.4.6.1`) · Skill v11.2.3 (no estable) · Repositorio privado.

**Qué se hizo y qué no.** Se leyeron todos los archivos del paquete de la analista y se contrastaron con la Skill v11.2.3, el contrato compacto, el motor y el corpus real. No se modificó ninguna regla (ni las 41 anteriores ni el texto de la analista), ni Evidence Studio, ni la Skill; no se ejecutó la batería del banco QA; no hubo commit, push, merge ni PR; ninguna versión se declara estable. Los únicos archivos creados son los documentos listados en la sección 10.

**Fuente analizada.** `C:\Users\ABIMARU\.claude\uploads\…\7e7b4e92-validar-blueprint-integracion-v11.2.2.zip` (48 473 B, SHA-256 `84364b68570a57492f5779c59a995d9ef370614941076f0f6c58c617080ef2c3`). Es el único material «nuevo de la analista» que recibí; trato su contenido como un **borrador en revisión** (el propio `MANIFEST.md` dice «Revisión normativa en curso»).

---

## 0. Resumen ejecutivo

1. **El borrador no es todavía una versión implementable.** Define 37 reglas activas (nuevas 3, eliminadas 6, 22 con cambio real de obligación, 4 refinadas, 6 renumeradas y modificadas, 2 sin cambio textual: SRV-001 y SRV-002, pendientes por decisión de la analista), pero el paquete arrastra restos de la versión anterior (sección 1.2). El catálogo CSV que contiene sigue siendo el de 41 reglas, idéntico byte a byte al nuestro.
2. **`compare-normative.mjs` no sirve con ese CSV** (reporta 0 cambios sobre 41 reglas). Se derivó un CSV literal desde los siete archivos de reglas (37 filas) y con él la herramienta detecta 2 nuevas, 6 retiradas, 33 modificadas y 2 sin cambio. La comparación **por ID es engañosa**: hay IDs reutilizados con otro significado (EXT-002, EVT-004..007, MQ-002, MQ-003). La reconciliación correcta es semántica (sección 2).
3. **El texto nuevo resuelve varias ambigüedades históricas** sin que nadie las decida: CNT-002 (ya no exige escenario certificado), CNT-004, API-003, el solapamiento API-004/CA-001/FT-001, directa vs declarada (E1/E2/E3 usan la misma redacción) y las poblaciones de MQ-001..004. Siguen abiertas: cobertura completa (CNT-001), SRV-001/002, la asociación por grupo en MOD-001 y la certificación de subtipos BPMN.
4. **El mayor riesgo técnico no es normativo sino de evidencia.** 19 de las 37 reglas dependen de evidencia que el contrato actual no tiene (D) o que los datos originales no permiten certificar (E): eventos de integración y Capa de Tópicos (EVT-001..006), subtipos BPMN Inicio/Señal/Mensaje (E1-3, EVT-007, MQ-003), servicios y APIs invocados (SRV-003, COM-002/003), el valor `Federado` (MQ-002) y varias categorías de contenido (CNT-003..005). Sin decisiones de la analista sobre cómo se representan en Lucidchart, esas reglas serán «No verificable» sistemáticamente.
5. **Las mejoras técnicas de v11.2.3 se conservan casi todas**, pero hay que adaptar cinco (sección 3), en particular: el hijo principal ahora es normativamente «el servicio principal», `UMLActiveClassBlock` pasa de convención técnica a regla (MQ-001) y la frase de v11.2.3 «no se extiende a CNT-002» queda sustituida por el texto nuevo.
6. **Hay un conflicto de diseño que requiere decisión humana:** el borrador evalúa 37 reglas «por cada página seleccionada» y declara las plantillas como «No aplica» regla a regla, mientras que la decisión aprobada en v11.2.2 las excluye sin filas ni porcentaje.
7. **Recomendación:** no implementar todavía. Pedir a la analista un paquete cerrado (CSV de 37 reglas coherente, SRV-001/002, convenciones de representación) y, entre tanto, preparar en una rama de trabajo la Skill **v12.0.0-rc** sobre el contrato actual aceptando No verificable donde falte evidencia, y el cambio aditivo de Evidence Studio sólo después de aprobar las convenciones (sección 8).

---

## 1. Inventario (Fase 1)

### 1.1 Qué se leyó
`AGENTS.md`; `PROJECT_CONTEXT_2026-10-26.md`; `HANDOFF.md`; la Skill v11.2.3 completa (16 archivos); el catálogo CSV de 41 reglas; `MATRIZ-EVIDENCIA-41.md`; `CONTRATO-COMPACTO.md`; los 16 archivos del paquete de la analista (SKILL, procedimiento, 7 archivos de reglas, manifiesto, contrato, matriz de 37, guía de `textAreas`, instrucciones, changelog, CSV); y los informes `CIERRE_ETAPA_2026-10-25`, `ITERACION_SKILL_V11.2.3`, `VALIDACION_FUNCIONAL_SKILL_V11.2.3`, `MOD001_VERIFICACION`, `CONTENEDORES_HIJO`, `PROPUESTA_CERTIFICACION_BPMN` y `DIFFERENCES_v0.4.6.1_vs_v0.4.7_CANDIDATE`. Adicionalmente se ejecutaron, en solo lectura, `analyzeBlueprint/copilotExport` sobre los 7 blueprints del corpus para medir tipos reales de figuras.

### 1.2 Estado del paquete de la analista (hechos verificados)
| # | Hallazgo | Evidencia |
|---|---|---|
| 1 | El CSV incluido tiene 41 reglas y es **idéntico** al catálogo v11.2 vigente; el manifiesto nombra `catalogo-reglas-vigente.csv`, que no existe | `cmp` byte a byte; lista del ZIP |
| 2 | `INSTRUCCIONES-AGENTE-V11.md` pide «41 resultados por página»; `CONTRATO-COMPACTO.md` dice «una página requiere 41 filas»; el changelog termina en v11.2.1 | lectura |
| 3 | Los encabezados de los 8 archivos de reglas/procedimiento dicen v11.2.1; el paquete se llama **v11.2.2**, nombre que ya usa nuestra Skill con otro contenido (SHA-256 distinto: `9b35a98e…` vs `84364b68…`) | hashes |
| 4 | La estructura del ZIP anida `validar-blueprint-integracion-v11.2.2/validar-blueprint-integracion/…` (nuestras Skills llevan una sola carpeta raíz `validar-blueprint-integracion/`) | lista del ZIP |
| 5 | El paquete parte de v11.2.1: **no contiene** lo añadido en v11.2.2 (clasificación de páginas plantilla/BDD/UNRESOLVED, protocolo de contradicción, poblaciones de «No aplica», diccionario ampliado con `pageClassification`, `counts`, `groups`) ni lo de v11.2.3 | comparación de textos |
| 6 | El diccionario del contrato del analista no define `name`, `operation`, `lucidchartType`, `containedComponentIds` ni `groups`, que su propia matriz cita | contrato vs `MATRIZ-EVIDENCIA-37.md` |
| 7 | SRV-001 y SRV-002 conservan el formato y el texto de la versión anterior («Servicios principal e invocados»), y la matriz las describe como «servicio invocado» | `02-reglas-api-servicios.md` vs matriz |
| 8 | EXT-002 se autorreferencia («sus conexiones se evalúan mediante EXT-002»), resto de la numeración antigua | `01-reglas-estructura.md` |
| 9 | En EVT-005/006/007 la viñeta «No aplica» termina describiendo un caso que queda «No verificable» (redacción contradictoria) | `03-reglas-eventos.md` |
| 10 | El manifiesto habla de una «antigua EXT-003», que **no existe** en nuestro catálogo de 41 | manifiesto vs CSV |
| 11 | El manifiesto cierra con una lista de verificaciones finales que el paquete aún no cumple (confirmar SRV-001/002, 37 IDs en todos los recursos, ninguna referencia a 41, nueva versión, validación de consistencia) | manifiesto |

Conclusión: el paquete es la **fuente normativa** de las reglas (los siete archivos de reglas son coherentes entre sí y con el manifiesto), pero no un artefacto de Skill ejecutable.

---

## 2. Comparación normativa (Fase 2)

### 2.1 Herramienta
| Ejecución | Resultado |
|---|---|
| `compare-normative.mjs` con el CSV del ZIP | 41 → 41, 0 cambios (el CSV es el viejo) |
| Con el CSV derivado de los siete archivos de reglas (`ANALISTA_CATALOGO_DERIVADO_37_2026-10-26.csv`; texto literal, solo reformateado) | 41 → 37: nuevas SRV-004 y COM-005; retiradas CNT-006, EVT-008, CA-002, FT-002, MQ-004, MQ-005; 33 modificadas; sin cambio SRV-001 y SRV-002; **0 renombres detectados** |
| Disponibilidad de evidencia (con la matriz de 37 y el contrato v11.2.3) | Las 35 reglas con cambio o nuevas figuran `DISPONIBLE_EN_CONTRATO` |

Límites que se confirman: (a) la herramienta compara por ID y no detecta que `EVT-005` nuevo es la `EVT-006` anterior; (b) `DISPONIBLE_EN_CONTRATO` sólo comprueba que el *nombre del campo* existe, no que haya evidencia suficiente (todas las reglas dan «disponible» y 19 tienen en realidad un hueco, sección 4); (c) no ve cambios entre reglas retiradas y reutilizadas.

### 2.2 Comparación semántica independiente
La matriz completa, con ID anterior/nuevo, resumen anterior y nuevo, obligación funcional, aplicabilidad, evidencia, condiciones de No cumple / No aplica / No verificable, preguntas, compatibilidad con el contrato y decisión humana, está en [`RECONCILIACION_MATRIZ_37_2026-10-26.csv`](RECONCILIACION_MATRIZ_37_2026-10-26.csv) y su resumen en [`RECONCILIACION_MATRIZ_37_2026-10-26.md`](RECONCILIACION_MATRIZ_37_2026-10-26.md).

Cambios que **sí son de obligación** (no solo de redacción):
- **Cobertura por patrón (CNT-001/002):** de «contenedores padre aplicables» a una enumeración cerrada por E1/E2/E3, con nombres libres válidos si la clasificación está certificada. CNT-002 incorpora nombre específico del hijo y unicidad.
- **Contenido por nivel (CNT-003/004/005):** listas cerradas de permitido/prohibido en dos niveles (padre e hijo principal); API prohibida en el dominio productor; el contenido de auxiliares se evalúa en EXT-001.
- **Dos modalidades de API según ubicación (API-001..003):** formato corporativo completo en INTEGRACIÓN; sólo nombre/operación/sección funcionales en SISTEMAS EXTERNOS. API-003 pasa a `tipo - modelo` en minúsculas.
- **Capa de Despliegue condicionada a MCI declarado (API-004, SRV-004 nueva, MQ-002):** la declaración MCI de la analista determina aplicabilidad; no prueba la existencia ni la asociación de la Capa/Flujo. CA-001 y FT-001 pasan a evaluar solo nombres.
- **Estrictez nueva:** EVT-003 deja de aceptar la equivalencia de tilde; el subtipo BPMN pasa a ser requisito explícito (Inicio en E1-3, Señal de Envío/Recepción en EVT-007, Mensaje en MQ-003).
- **Reglas de conexión reorganizadas:** una conexión se evalúa una sola vez; comandos en COM-002..005; gestor↔gestor, servicio↔gestor y Mensaje→gestor en MQ-003.
- **GW-001** cambia de semántica: coherencia entre texto de la compuerta y etiquetas de caminos (una compuerta sin texto ni etiquetas cumple).
- **MQ-001** convierte `UMLActiveClassBlock` en definición normativa de gestor de colas.
- **Principio general nuevo:** si hay un incumplimiento certificado, prevalece No cumple aunque otra condición sea no verificable (aparece en la mayoría de reglas y en el procedimiento §8).

Cambios de **redacción/precisión** sin obligación nueva: COM-001..004 (misma obligación, más exacta), GW-001 en parte, formatos de EVT-001/002.

**Trampas de numeración** (ID reutilizado con otro significado): `EXT-002` (antes conexiones; ahora ubicación EVC/EPC/LDC), `EVT-004` (antes despliegue; ahora Capa de Tópicos), `EVT-005..007` (corridas desde EVT-006..008), `MQ-002` (antes ubicación; ahora Capa de Despliegue), `MQ-003` (antes modelo/MCI; ahora conexiones). Cualquier artefacto que cite IDs viejos (expectativas del banco QA, informes, respuestas guardadas) cambia de significado sin cambiar de aspecto.

---

## 3. Reconciliación con la Skill v11.2.3 (Fase 3)

| Mejora previa | Decisión | Justificación |
|---|---|---|
| HIPOTESIS ≠ CONFIRMADO; no son estados normativos | **CONSERVAR** | El borrador mantiene que `scenario` describe el escenario (procedimiento §9) y que solo el Inicio certificado habilita E1/E2/E3-001. |
| «Sin Inicio certificado no se declara Cumple en E1/E2/E3-001» (v11.2.3 §5) | **CONSERVAR** (ahora es texto normativo) | El texto nuevo lo dice dentro de las tres reglas. Pasa de instrucción operativa a obligación. |
| «No se extiende a CNT-002» | **REEMPLAZAR** | El texto nuevo de CNT-002 elimina la dependencia de Inicio y del escenario certificado; la frase operativa ya no tiene objeto y puede inducir Cumple por razones equivocadas. |
| Cuatro estados y fórmula | **CONSERVAR** | Idénticos. |
| Prioridad «No cumple prevalece» | **ADAPTAR** (nueva) | Ya existe como principio del borrador; la Skill debe incorporarlo y alinearlo con v11.2.3 §7 (No cumple exige evidencia suficiente). |
| `SERVICIO_HIJO` (tipo) ≠ `HIJO_PRINCIPAL` (rol) | **CONSERVAR** en el contrato | Son propiedades distintas del JSON. |
| «Un hijo principal no equivale a SERVICIO/INVOCADO» (v11.2.3 §2) | **ADAPTAR** | Normativamente el hijo principal **representa el servicio principal** (SRV-003, SRV-004, manifiesto) y SRV-003 lo excluye por no ser invocado. Hay que reescribir §2: sigue sin ser `INVOCADO`, pero ya no se debe negar que represente el servicio principal. SRV-001/002 quedan pendientes. |
| `domainRole: PRODUCER` con procedencia, certeza y conflictos (v11.2.3 §3) | **CONSERVAR** | CNT-001/002 aceptan nombre libre «si la clasificación está certificada»; la procedencia es lo que permite decidir si una inferencia estructural cuenta como certificada (ver D7). |
| Contención ≠ asociación por grupo | **CONSERVAR** | El borrador prohíbe asociar por cercanía, alineación, superposición o contenedor; no dice nada de grupos (D5). |
| Eventos BPMN y subtipos (`PROPOSED_CLOSED_CATALOG`) | **ADAPTAR** | El catálogo propuesto (START, END, SIGNAL, RECEIVE, EXCEPTION) no contiene Señal de Envío ni Mensaje, que el borrador exige. Sin convención corporativa demostrada, no se amplía (D3). |
| `customData` ENTRADA/SALIDA para MOD-001 (no `MODELO`) | **CONSERVAR** | La `GUIA-TEXTAREAS` del analista lo confirma («evidencia literal… no la transforme en MODELO»). |
| MCI y exposición declarados | **ADAPTAR** | Cambia el conjunto de preguntas: MCI de la API principal (obligatoria), MCI del hijo solo en E1/E2 (obligatoria), exposición opcional y solo para API-004; en un único bloque; una declaración no corrige textos. Hay que actualizar `AGENTS.md` y el procedimiento. |
| Evidencia insuficiente ≠ incumplimiento demostrado | **CONSERVAR** | Es el eje del borrador, ahora con prioridades explícitas. |
| Evaluación independiente de reglas solapadas (API-004 / CA-001 / FT-001) | **ELIMINAR** (como instrucción) | Deja de hacer falta: el solapamiento desaparece del texto (existencia → API-004/SRV-004/MQ-002; CA-001/FT-001 solo nombres). Se sustituye por la regla «cada conexión se evalúa una sola vez» (COM/MQ). |
| Clasificación de páginas (OPERATIONAL/MIXED/TEMPLATE/BDD/UNRESOLVED), protocolo de contradicción | **CONSERVAR** (pendiente de decisión D2) | El borrador no la incluye y es incompatible en parte con ella. |
| `UMLActiveClassBlock` = «convención técnica, no regla» | **REEMPLAZAR** | MQ-001 lo hace normativo. Cambia `CONTRATO-COMPACTO`, `GUIA-TEXTAREAS` y una prueba existente. |
| Criterio operativo de CNT-006 | **ELIMINAR** | La regla desaparece; se sustituye por los controles previos de integridad del borrador. Cierra la decisión C15-Q3. |
| Poblaciones de «No aplica» (cuatro situaciones, v11.2.2) | **ADAPTAR** | El principio «la ausencia de una figura no basta por sí sola» sigue, pero cada regla nueva declara explícitamente cuándo es No aplica (p. ej. sin `UMLActiveClassBlock`), lo que cierra C15-Q1. |

---

## 4. Auditoría del contrato (Fase 4)

Clasificación por regla (detalle en la matriz): A directa · B derivable · C ambigua · D ausente · E imposible con los datos originales · F declaración de la analista.

| Clase dominante | Reglas |
|---|---|
| A / A-B (evidencia directa o derivable) | GW-001, MQ-001, CA-001, FT-001, COM-004, EXT-002 |
| B/C, B/F (derivable con ambigüedad o con declaración) | CNT-001, CNT-002, EXT-001, API-001..004, SRV-004, COM-001, COM-005 |
| C/D, D, E (hueco de contrato o de datos) | CNT-003/004/005, EVT-001..006, EVT-007, SRV-003, SRV-001/002 (pendientes), MOD-001 (parcial), E1-001/E2-001/E3-001, COM-002/003, MQ-002, MQ-003 |

Huecos concretos (medidos en el subconjunto de 7 blueprints, páginas OPERATIONAL/MIXED):
1. **Subtipos BPMN (E):** 235 `BPMNEvent` tipados `EVENTO`; ninguno trae `customData`. Inicio, Señal de Envío, Señal de Recepción y Mensaje no se pueden certificar; el catálogo propuesto no incluye Envío ni Mensaje. Afecta a E1/E2/E3-001, EVT-007 y MQ-003.
2. **Eventos de integración y Capa de Tópicos (D):** el contrato no tiene tipo para ellos. Hay 5 figuras con patrón `Aplicacion|Empresarial - Query|Command|Event` (todas `UMLClassBlock` con `architecturalType: null`) y un único texto de tópicos. EVT-001..006 y la parte de eventos de MOD-001 serán No verificable.
3. **APIs y servicios invocados (E):** el rol `INVOCADO` no se emite; solo 12 `UMLClassBlock` están tipados API y 5 SERVICIO; 62 quedan `null`. Afecta a SRV-003, COM-002, COM-003 y MQ-003 (y a API-001..003 para las API invocadas).
4. **Valor `Federado` (D):** no aparece en `src/`; MQ-002 y el contenido permitido (capas MCI o Federado) no tienen representación.
5. **Categorías de contenido sin tipo (D):** conceptos, pendientes, políticas, anotaciones, comandos y modelos fiables (el tipo `MODELO` se asigna por el nombre; 99 de 160 figuras ENTRADA/SALIDA son `null`). CNT-003/004/005 dependen de «clasificación certificada de los componentes evaluados».
6. **Capa y Flujo se tipan por prefijo del nombre** (`CAPA DE ARQUITECTURA…`, `FLUJO TRANSACCIONAL…`). CA-001/FT-001 evalúan el nombre: una figura con el prefijo mal escrito no se tipa y queda como candidata, es decir No verificable, no No cumple.
7. **Rama inalcanzable en CNT-002:** «no existe hijo principal» y «existe más de uno» exigen un patrón E1/E2/E3 que el motor solo determina si ya identificó un hijo principal; con escenario NO_DETERMINADO el resultado será No verificable.
8. **Asociación al principal (C):** MOD-001, API-004 y SRV-004 exigen asociación «inequívoca»; las asociaciones de despliegue vienen de contención explícita o grupo superior común, y los modelos de grupo compartido siguen sin resolverse (D5).
9. **Juicios semánticos:** idioma inglés, camelCase por palabra, «genérico/plantilla», infinitivo en español. No están en el contrato; los hace el evaluador. Es una fuente de variabilidad medida en la validación v11.2.3 (CNT-002/CNT-004).

Lo que **no** se debe hacer: convertir los paneles visuales de v0.4.7 en certificaciones. Los paneles (eventos con subtipo no certificado, productores, hijos, modelos) describen evidencia; ninguna regla puede apoyarse en ellos para declarar Cumple.

Efecto cuantitativo aproximado: 19 de las 37 reglas incluyen un componente D o E. En el estado actual, E1/E2/E3-001, EVT-001..007, SRV-003, COM-002/003, MQ-003 y parte de MOD-001 no pueden llegar a Cumple en blueprints reales.

---

## 5. Ambigüedades históricas (Fase 5)

| Tema | ¿La normativa nueva la resuelve? | Estado |
|---|---|---|
| **CNT-002** (lectura de «escenario certificado») | **Sí.** Evidencia mínima: patrón identificable, un hijo principal certificado, nombre y dominio; «no se requiere identificar ni certificar un evento BPMN de Inicio». HIPOTESIS no impide Cumple. | Cerrada por el texto |
| **CNT-004** | **Sí.** El criterio es contención por nivel; no depende de Inicio ni de escenario certificado. Queda la certeza de «clasificación del DOMINIO PRODUCTOR» y de los componentes. | Cerrada en lo normativo; residual C/D (tipos) |
| **MQ-001..004 antiguas** | **Sí.** MQ-001 y todas las reglas nuevas declaran No aplica cuando no hay figura ni candidatos. La antigua MQ-002/003/004 se reorganizan. | Cerrada (C15-Q1 para MQ, GW-001, EXT-001/002) |
| **SRV-001..003** | **Parcialmente.** SRV-003 queda definida (invocados; hijo excluido). SRV-001 y SRV-002 siguen con el texto antiguo y marcadas pendientes por la analista. | **Pendiente** (SRV-001/002) |
| **MOD-001** | **Parcialmente.** Define población (API principal E1/E2, principal E3, eventos de integración en INTEGRACIÓN), excluye hijo e invocados y exige asociación inequívoca; no dice si un grupo compartido lo es. | **Pendiente** (D5) |
| **CNT-001** | **Parcialmente.** Cierra la lista de dominios obligatorios; exige «inventario completo»/«cobertura» sin definirlos. | **Pendiente** (Q6: cobertura completa) |
| **CNT-006** | **Sí, por eliminación.** Se convierte en control previo de integridad; el criterio operativo de v11.2.2 ya no aplica. | Cerrada |
| **API-003** | **Sí.** Sección completa sin modelo = No cumple; la exposición declarada no la corrige. Coincide con el comportamiento observado. | Cerrada |
| **API-004 / CA-001 / FT-001** | **Sí.** Se separan: existencia en API-004/SRV-004/MQ-002; CA-001/FT-001 solo nombre. Desaparece el solapamiento. | Cerrada (Q8) |
| **E1/E2/E3 (directa vs declarada)** | **Sí en la redacción.** Las tres reglas dicen «conexión … terminación `None` … `Arrow`», sin «directa». | Cerrada en el texto (D6 abajo) |
| **E1/E2/E3 y Inicio certificado** | Sí: Inicio certificado es requisito de Cumple. | Cerrada; aparece un conflicto nuevo |
| **Conflicto nuevo (D6):** el principio «prevalece No cumple aunque otra condición sea no verificable» choca con la viñeta No cumple de E1/E2/E3-001, que **exige** el subtipo Inicio certificado: una violación estructural certificada con Inicio no certificado ¿es No cumple o No verificable? | No | **Pendiente** |
| **Nuevo conflicto (D2):** páginas plantilla/BDD: «No aplica» regla a regla vs exclusión sin filas | No | **Pendiente** |

Q-decisiones previas (Q1–Q10 del 25/10): Q1 sigue cerrada; Q2 (CNT-002) queda cerrada por el texto; Q3 queda cerrada por el texto; Q4 pasa a «solo SRV-001/002»; Q5 queda cerrada para MQ; Q6 persiste; Q7 desaparece; Q8 queda cerrada; Q9 y Q10 no dependen de la normativa.

---

## 6. Matriz final de reconciliación (Fase 6)

Estado por regla en [`RECONCILIACION_MATRIZ_37_2026-10-26.md`](RECONCILIACION_MATRIZ_37_2026-10-26.md). Resumen por grupo:

### 6.1 Cambios normativos obligatorios
- Sustituir el catálogo de 41 por el de 37 (IDs, numeración y textos) en la Skill: CSV, matriz de evidencia, siete archivos de reglas, manifiesto, instrucciones, contrato, guía de `textAreas`.
- Retirar CNT-006, EXT-002 antigua, EVT-004 antigua, EVT-008, CA-002, FT-002, MQ-002 antigua, MQ-004, MQ-005 y migrar sus criterios como indica el manifiesto; añadir EXT-002 (EVC/EPC/LDC), SRV-004 y COM-005.
- Incorporar el principio de prioridad (No cumple > No verificable > Cumple > No aplica) y los controles previos de integridad del JSON.
- Nuevo conjunto de preguntas (MCI API principal, MCI hijo en E1/E2, exposición opcional para API-004).
- `UMLActiveClassBlock` como definición normativa de gestor (MQ-001).

### 6.2 Mejoras operativas recomendadas (no normativas)
- Conservar de v11.2.3: HIPOTESIS/CONFIRMADO fuera de los estados; procedencia de `PRODUCER`; contención ≠ grupo; `customData` ENTRADA/SALIDA ≠ `MODELO`; una conexión se evalúa una sola vez.
- Reescribir la instrucción del hijo principal (§2 de v11.2.3) y retirar «no se extiende a CNT-002» y la instrucción de evaluar por separado API-004/CA-001/FT-001.
- Registrar la lectura que hace el evaluador de los juicios semánticos (idioma, genérico/plantilla) para medir variabilidad.

### 6.3 Cambios técnicos necesarios
- **Skill:** estructura portátil con una sola carpeta raíz; pruebas de 37 IDs y hash por regla; `validate-skill-zip` y `verify-skill-zip` (hoy fijan 41).
- **Banco QA:** el controlador exige 41 filas (`FILAS_41`), toma los IDs del CSV del ZIP, y las expectativas citan IDs que cambian de significado (MQ-002..005, EVT-004..008, CA-002, FT-002, CNT-006, COM-001…); hay que regenerar expectativas y casos (los 9 compactos actuales se pueden reutilizar).
- **Evidence Studio (solo tras aprobar convenciones, cambio aditivo):** tipado de evento de integración y de Capa de Tópicos con su procedencia, valor `Federado`, subtipos BPMN según la convención que se apruebe, `INVOCADO` con evidencia positiva, candidatos a Capa/Flujo/API sin tipar, y tipos de contenido (concepto, pendiente, política, anotación). Todos serían campos nuevos; el contrato seguiría siendo compatible hacia atrás.
- **Documentación del proyecto:** `AGENTS.md` (41 reglas, v11.2.3, preguntas MCI) y los contextos.

### 6.4 Decisiones pendientes
Ver sección 9.

---

## 7. Plan de implementación (Fase 7) — no se implementa en esta iteración

1. **Versión objetivo.** Skill **v12.0.0-rc.1** (cambio mayor: otro conjunto de IDs; evita colisionar con el paquete «v11.2.2» de la analista, que ya existe con otro contenido). Contrato `copilot-factual-v0.4.6.1` sin cambios en la primera entrega; si más tarde se aprueban campos nuevos, `copilot-factual-v0.5.0` aditivo. Ninguna se declara estable.
2. **Cambios normativos (Skill).** Partir del texto de los siete archivos de reglas **tal como los entregó la analista** (sin retocarlos), con un CSV de 37 reglas generado desde ellos, pinneado por hash; manifiesto y matriz alineados; regenerar el ZIP con carpeta raíz única.
3. **Cambios operativos.** Reincorporar lo de v11.2.3 que se conserva (sección 3), reescribir la instrucción del hijo principal, añadir preguntas nuevas y la precedencia de conexiones; mantener la clasificación de páginas si se decide D2.
4. **Cambios de contrato.** Ninguno obligatorio para la primera entrega (las reglas sin evidencia darán No verificable, que es un resultado correcto y trazable). Opcionales y condicionados a D3/D4: tipos y campos de la sección 6.3.
5. **Pruebas nuevas y regresiones.** (a) 37 IDs únicos y 14 familias con sus conteos; (b) hash de cuerpo de cada regla contra el archivo de la analista; (c) ningún ID retirado ni referencia a 41 reglas; (d) consistencia cruzada manifiesto–matriz–CSV–reglas; (e) pruebas de la herramienta de comparación con el CSV nuevo; (f) regresión del contrato y de las 4 firmas SHA-256 del compacto; (g) preflight y selftest del banco con las nuevas expectativas; (h) casos sintéticos por familia, derivados de las estructuras reales, incluidos los de la validación v11.2.3.
6. **Estrategia de validación con Copilot.** Primero banco QA aislado con v12.0.0-rc.1 (3 casos de la validación previa + 1 por familia nueva, una ejecución cada uno, comparando con v11.2.3 cuando la regla exista en ambas), luego sesión con la analista sobre un blueprint real y su propio resultado esperado, midiendo coincidencia por regla y registrando cada discrepancia como extracción, contrato, Skill, evaluador, controlador o decisión normativa.
7. **Criterios de aceptación.** Catálogo y recursos con los mismos 37 IDs; 0 referencias a reglas retiradas; pruebas verdes (`npm test`, `npm run audit`, `npm run build`, `skill:zip:validate`); compacto invariante para los 4 blueprints reales; sin regresión en los casos previos que no dependan de reglas cambiadas; toda diferencia con la analista clasificada y las normativas registradas como decisión (no como fallo); sin material corporativo fuera del repositorio privado.

---

## 8. Recomendación arquitectónica

1. **Tratar el paquete de la analista como fuente normativa y no como artefacto de Skill.** Construir la Skill nueva desde sus siete archivos de reglas, sin reescribirlos; todo lo demás (CSV, matriz, manifiesto, instrucciones, contrato) se regenera y valida automáticamente con pruebas, para que no vuelva a haber restos de 41 reglas.
2. **Separar tres capas con versiones propias:** normativa (qué se exige), procedimiento (cómo se evalúa) y contrato (qué evidencia entrega Evidence Studio). Hoy el paquete mezcla las tres y por eso se arrastraron inconsistencias.
3. **Aceptar «No verificable» como resultado correcto donde falte evidencia** en la primera entrega, y reducir esos huecos después con cambios aditivos del contrato aprobados por la analista (subtipos BPMN, eventos de integración, tópicos, `Federado`, invocados). Es más seguro que inferir.
4. **No convertir los paneles de v0.4.7 en certificación** y no introducir una convención `customData` sin evidencia corporativa.
5. **Reducir la variabilidad semántica** (idioma, genérico/plantilla): dejar los juicios documentados y medidos en el banco QA, no resolverlos con inferencias del motor.
6. **Orden:** (1) paquete normativo cerrado → (2) Skill v12.0.0-rc.1 sobre el contrato actual → (3) banco QA regenerado → (4) pruebas con la analista → (5) cambios aditivos de Evidence Studio → (6) re-validación.

---

## 9. Decisiones que requieren intervención (priorizadas)

| # | Decisión | Quién | Por qué es bloqueante |
|---|---|---|---|
| D1 | Entregar el paquete cerrado: CSV de 37 reglas coherente, criterio final de SRV-001 y SRV-002, versión nueva y estructura de carpeta única | Analista | Sin esto no hay catálogo único que implementar (P0) |
| D2 | Páginas plantilla/BDD/sin resolver: ¿se mantienen fuera (sin 37 filas ni porcentaje, decisión de v11.2.2) o se evalúan regla a regla con «No aplica»? | Andrés + analista | Cambia el contenido del informe y el total |
| D3 | Convención de subtipos BPMN: cómo se declaran Inicio, Señal de Envío, Señal de Recepción y Mensaje en Lucidchart (clave y valores de `customData`) | Analista | Sin ella, E1/E2/E3-001, EVT-007 y MQ-003 son No verificable siempre |
| D4 | Cómo se representan en Lucidchart: evento de integración, Capa de Tópicos y tópicos, `Federado`, concepto/pendiente/política/anotación, servicio y API invocados | Analista | Sin ello EVT-001..006, SRV-003, COM-002/003, MQ-002/003 y CNT-003/004/005 quedan limitadas |
| D5 | MOD-001: ¿un grupo compartido es una asociación inequívoca de un modelo con su componente? | Analista | Decide si MOD-001 puede dar Cumple o No cumple |
| D6 | E1/E2/E3-001: con una violación estructural certificada y el Inicio sin certificar, ¿No cumple o No verificable? | Analista | Contradicción entre el principio general y la viñeta de la regla |
| D7 | ¿Un dominio productor inferido por estructura cuenta como «clasificación certificada» (CNT-001/002/004)? (hoy Q1 cerrada en el motor) | Analista (confirmar) | Evita variabilidad entre ejecuciones |
| D8 | Definición verificable de «cobertura completa» (CNT-001 y casi todas las reglas) | Analista | Condiciona todo No cumple por ausencia |
| D9 | EXT-001: ante BPMNEvent dentro de un auxiliar la regla dice «requiere revisión manual del analista»: ¿pregunta del agente o simple No verificable? | Analista | Define el comportamiento del agente |
| D10 | Versionado: ¿v12.0.0-rc.1? ¿Se retira la etiqueta «v11.2.2» del paquete de la analista? ¿Se archiva v11.2.3 como histórica? | Andrés | Evita colisión de versiones |
| D11 | Confirmar que EXT-002 (EVC/EPC/LDC) es nueva y que no existió una «EXT-003» anterior | Analista | La historia del manifiesto no coincide con nuestro catálogo |
| D12 | Alcance de las preguntas: MCI del hijo solo en E1/E2 (E3 no se evalúa en SRV-004). Actualizar `AGENTS.md` | Andrés | Texto permanente del proyecto |
| D13 | Aceptar que los juicios de idioma/genérico/plantilla los hace el evaluador (variabilidad) o acordar criterios mínimos | Andrés + analista | Fuente de discrepancias en Copilot |

Autorizaciones adicionales de Andrés cuando corresponda: crear la rama de trabajo para v12.0.0-rc.1; qué categorías sube al `main` privado (ya pendiente desde el 25/10).

---

## 10. Artefactos generados y límites
Archivos nuevos (todos en `docs/audits/`): este informe; `RECONCILIACION_MATRIZ_37_2026-10-26.csv` y `.md`; `ANALISTA_CATALOGO_DERIVADO_37_2026-10-26.csv` (texto literal de los siete archivos de reglas del analista, reformateado en las columnas del catálogo). Extracción temporal del ZIP en la carpeta de trabajo de la sesión, fuera del repositorio; el original sigue intacto en `uploads`.

Límites: (1) trato el ZIP como la normativa nueva completa; si hay más documentos (Word, Excel) no los he visto. (2) La evidencia del contrato se midió sobre 7 blueprints y 14 páginas operativas, no sobre todo el corpus histórico. (3) Las clases A–F son juicio de auditoría; la comprobación automática solo verifica nombres de campos. (4) No ejecuté ningún modelo con la normativa nueva, así que no hay medición de su comportamiento real. (5) No se verificaron las pruebas E2E de v0.4.7 (fuera de alcance).
