# AUDITORÍA_CANÓNICA_37 (Iteración 3, revisada en la 3.1)

> Documento candidato, no aprobado. No modifica las reglas de la analista ni resuelve C-01…C-13. Esta revisión corrige errores de la primera versión de este mismo informe (§6).

## 1. Método

- Re-validación independiente del texto: 37 reglas × 8 campos normativos = **296 campos**, comparados con normalización de espacios contra el paquete original de la analista. **Resultado: 0 diferencias**, también sobre el catálogo regenerado en la 3.1.
- Revisión de los 12 aspectos por regla sobre `CATALOGO_NORMATIVO_37_CANDIDATO.md` y `MATRIZ_NORMA_EVIDENCIA_37.csv`.
- Comprobación mecánica de consistencia entre documentos (`validate-iter31.mjs`, resultado en `RECONCILIACION_CORRECCIONES_ITER31.md`).

## 2. Resultado por aspecto

| # | Aspecto | Resultado |
|---|---|---|
| 1 | ID único | 37/37 únicos |
| 2 | Coincidencia literal | 296/296 sin diferencia |
| 3 | Obligación delimitada | 35/37; SRV-001 y SRV-002 son esqueleto (C-01) |
| 4 | Población y dependencia | Declaradas; se añadió la **cobertura de población** como atributo propio |
| 5 | Aplicabilidad | Definida en 35; EXT-002 tiene una autorreferencia real en el texto fuente |
| 6 | Cuatro estados | Sólo Cumple / No cumple / No verificable / No aplica |
| 7 | Evidencia mínima | Presente; sobrestimada en 7 reglas (§4) |
| 8 | Dependencias entre reglas | Corregidas (§3, error 1) |
| 9 | Conflictos | Principio de prioridad coherente; el choque procedimiento §7 vs. «37 resultados por página seleccionada» queda en C-11 |
| 10 | Decisiones pendientes | C-01…C-13 intactas |
| 11 | Correspondencia con el contrato JSON | Sin campo inexistente; ver §3, error 2 |
| 12 | Trazabilidad histórica | Completa tras la corrección (§3, error 3) |

## 3. Errores reales en los documentos de la Iteración 2 (corregidos en la 3.1)

1. **Etiquetas de decisión.** El catálogo y el registro C-01…C-13 no coincidían. Resolución, apoyada en el texto literal de las reglas: C-06 figuraba en el catálogo para EVT-001/002/003/007 pero no en el registro: se añade al registro (su obligación recae sobre el «evento de integración», figura cuyo reconocimiento define C-06); C-09 a API-003 y SRV-003 («específica, no genérica», «texto de plantilla»); C-11 a API-003 (conflicto de capitalización con SRV-003); C-12 se retira de COM-002/003/004 (sus textos hablan de figura que «represente inequívocamente» el extremo, no de «relación identificable» ni de «atribución inequívoca» de COM-001/COM-005); C-03 y C-02 pasan a **condiciones globales** (columna propia). Se amplió el registro; el catálogo y la matriz se alinearon con él.
2. **Campos JSON.** Ningún campo inexistente. Se corrigieron abreviaturas: `endpoint1/2.style` y `endpoint`/`styles` → `endpoint1.style`, `endpoint2.style`, `connectedTo`; `DECLARADO_POR_ANALISTA` se aclara como registro de la Skill (no campo del JSON); `INVOCADO` se señala como valor definido con 0 emisiones.
3. **IDs históricos absorbidos.** CNT-006, EXT-002 antiguo, EVT-004 antiguo, CA-002, FT-002, MQ-002 antiguo, MQ-003 antiguo y MQ-004 figuran ahora en el `id_historico` de sus destinos, más un anexo con los 41 IDs.
4. **Verificabilidad.** Corregida y justificada (§4).
5. **Conteos de pruebas.** El documento de decisiones decía 118 definitivas y 98 ejecutables. Cifra reconciliada: **72 definitivas + 25 con reserva + 51 bloqueadas = 148** (§5 del informe de reconciliación).
6. **EXT-002.** Autorreferencia del texto fuente: defecto de la analista; sólo se registra.
7. **CNT-001/CNT-002.** La afirmación «No cumple inalcanzable» era incorrecta: ver `INVESTIGACION_CNT002_2026-10-26.md`.

Falsos positivos descartados: autorreferencias aparentes en API-003, EVT-005, MOD-001, COM-004.

## 4. Verificabilidad

| Nivel | Reglas |
|---|---|
| VERIFICABLE_HOY (5) | GW-001, API-004, SRV-004, CA-001, FT-001 |
| VERIFICABLE_PARCIAL (16) | CNT-001, CNT-002, CNT-003, CNT-004, CNT-005, EXT-001, EXT-002, API-001, API-002, API-003, MOD-001, COM-001, COM-004, COM-005, MQ-001, MQ-002 |
| CON_BRECHA (14) | SRV-003, EVT-001…EVT-007, E1-001, E2-001, E3-001, COM-002, COM-003, MQ-003 |
| PENDIENTE_NORMATIVO (2) | SRV-001, SRV-002 |

Movimientos respecto de la clasificación inicial (12/8/15/2): **7 rebajas** HOY → PARCIAL (CNT-002, API-001, API-002, API-003, COM-001, COM-004, MQ-001) y **1 subida** CON_BRECHA → PARCIAL (MQ-002). La primera versión de este informe decía «8 sobrestimadas y 2 subestimadas» y listaba CNT-002 dos veces; era incorrecto.

Motivos: API-001…003 y CNT-002 sólo certifican la población principal o el hijo único (C-04); COM-001/MQ-001 dependen de listas de plantilla (C-09) y de «relación» (C-12); COM-004 sólo cubre comandos relacionados con gestores.
Restricción aplicada: ninguna regla `VERIFICABLE_HOY` tiene cobertura distinta de `COMPLETA`, y ninguna con cobertura `NINGUNA` es HOY o PARCIAL.

## 5. Tres atributos separados

DEFINICIÓN_NORMATIVA, DISPONIBILIDAD_DE_EVIDENCIA y COBERTURA_DE_POBLACIÓN son atributos del catálogo; **no** son estados de resultado.

## 6. Errores de la primera versión de este informe

| Dónde | Error | Corrección |
|---|---|---|
| §3 | «CNT-002: la rama No cumple está bien: exige patrón certificado y hoy es HIPOTESIS» | Falso: sólo tres de cuatro familias no se demuestran y por el motor, no por HIPOTESIS |
| §4 | Lista de PARCIAL con CNT-002 duplicada; «8 sobrestimadas, 2 subestimadas» | 7 y 1 |
| §3 punto 4 | «74 definitivas + 23 con reserva» | 72 + 25 |
| §3 punto 2 | COM-002 con campo inexistente | No hay campo inexistente; había abreviaturas |
