# Propuesta normativa pendiente de aprobación

Estado: **no aprobada; no aplicar como norma oficial**.

F-13 demuestra una contradicción entre E1-001/E3-001/CNT-002 y CNT-004. La propuesta anterior fue incorrecta al describir algunos hijos como gestionados. Las definiciones confirmadas para esta revisión son: E1 y E3 tienen servicio hijo no gestionado en dominio productor; E2 tiene servicio hijo gestionado en INTEGRACIÓN.

Propuesta mínima:

- E1-001: API principal en INTEGRACIÓN; servicio hijo principal **no gestionado** en dominio productor.
- E2-001: API principal y servicio hijo principal gestionados en INTEGRACIÓN.
- E3-001: servicio hijo **no gestionado** en dominio productor.
- CNT-002/CNT-004: alinear su redacción con esas tres definiciones, usando el dominio arquitectónico raíz verificable y admitiendo Flujo/Capa intermedios, sin convertir cualquier dominio personalizado en productor.

La decisión sobre conexión **directa** frente a conexión meramente **declarada** queda separada y pendiente; no se deriva de las definiciones de gestión anteriores. No se propone modificar IDs, poblaciones ni otras obligaciones. La analista debe aprobar ambos asuntos antes de editar la normativa oficial.
