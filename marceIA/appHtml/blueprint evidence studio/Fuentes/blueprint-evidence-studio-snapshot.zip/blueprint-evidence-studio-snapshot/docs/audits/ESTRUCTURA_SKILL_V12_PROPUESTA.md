# ESTRUCTURA_SKILL_V12_PROPUESTA (diseño; no se crea versión ni ZIP)

> Candidato, revisado en la Iteración 3.1. No genera paquete instalable. No declara estable nada.

## 1. Principio rector

Una sola fuente normativa canónica. Todo lo demás (IDs, matrices, conteos, instrucciones, pruebas) se **deriva** de ella o la **referencia por ID**. Ningún documento operativo puede contener ni crear obligaciones.

## 2. Estructura propuesta

| Ruta | Contenido | Naturaleza |
|---|---|---|
| `norma/catalogo-normativo.md` | Texto literal de las 37 reglas (8 campos por regla) + principios generales de la analista | **Única fuente normativa** |
| `norma/estado-normativo.json` | Por ID: `estado_definicion` (definida/condicionada/pendiente), decisiones abiertas C-xx, `aprobada` (sí/no) | Metadatos; **fuera** del texto normativo |
| `norma/obligaciones.sha256.json` | SHA-256 de los 8 campos de cada regla y de los principios generales | Derivado (generado) |
| `SKILL.md` | Punto de entrada: contrato compacto, métrica, cuatro estados, referencias | Operativo |
| `operacion/procedimiento.md` | Orden de evaluación, páginas evaluables, prioridad de No cumple | Operativo (sólo cita IDs) |
| `operacion/contrato-evidencia.md` | Campo JSON por regla; marcado `existente` / `propuesta` | Operativo |
| `operacion/preguntas-analista.md` | MCI principal, MCI hijo, exposición; `DECLARADO_POR_ANALISTA` | Operativo |
| `trazabilidad/ids-41-a-37.csv` | Históricos, retirados, absorbidos, reutilizados | Derivado de la norma + historial |
| `trazabilidad/cobertura.csv` | Cobertura de población, verificabilidad, brechas | Derivado |
| `pruebas/` | Fichas y fixtures aprobados (sólo tras aprobación) | Verificación |
| `historico/v11.x/` | Catálogos de 41 reglas | Aislado; **excluido** del paquete |
| `historial.md` | Versiones y cambios | Informativo |

## 3. Cumplimiento de los requisitos de la Fase 6

| Requisito | Cómo lo cubre el diseño | Qué falta construir |
|---|---|---|
| Una sola fuente normativa | `norma/catalogo-normativo.md` | Eliminar los siete archivos `0x-reglas-*.md` como fuente paralela (pasan a vista generada) |
| Derivar el catálogo de IDs | Script lee los encabezados `## ID — título` | Script `derive-ids` |
| Generar matrices sin duplicación manual | `cobertura.csv` e `ids-41-a-37.csv` se generan de la norma y de `estado-normativo.json` | Scripts de generación; prohibido editar los CSV a mano |
| Verificar hashes de obligaciones | `obligaciones.sha256.json`; la prueba de empaquetado falla si cambia un solo campo | Prueba nueva (sustituye a la de 41 cuerpos de `test/skill.test.js`) |
| Mantener versiones históricas aisladas | `historico/` fuera del paquete, con prueba de que ningún ID retirado aparece en `norma/` ni en `operacion/` | Prueba de IDs retirados / reutilizados |
| Diferenciar normas aprobadas y pendientes | `estado-normativo.json` (`aprobada`, `estado_definicion`); SRV-001/002 con `pendiente` | Decisión C-02 sobre la etiqueta de paquete |
| Evitar que instrucciones operativas creen normas | Lint: los archivos de `operacion/` no pueden contener las viñetas Cumple / No cumple / No verificable / No aplica de una regla ni citar umbrales; sólo IDs | Lint nuevo |

## 4. Reglas de construcción

- Conteos (37, 5/16/14/2, 148 pruebas) calculados, nunca escritos a mano.
- Cobertura de población, definición normativa y disponibilidad de evidencia son atributos separados y ninguno es un estado de resultado.
- 37 resultados por página evaluable; plantillas y BDD puros no evaluables (decisión C-11 punto 9 pendiente).
- Las respuestas `DECLARADO_POR_ANALISTA` son un registro de la Skill, no un campo del JSON.

## 5. Condiciones necesarias para crear una Skill v12 candidata

| # | Condición | Responsable | Estado |
|---|---|---|---|
| 1 | C-02: nombre y versión del paquete (`v12.0.0-rc.1` u otro) y separación norma/procedimiento | Analista + Andrés | Abierta |
| 2 | C-01: criterio y población de SRV-001/SRV-002 (hoy esqueleto) | Analista | Abierta; sin ella el paquete lleva 2 reglas `pendiente` |
| 3 | C-11: lote de erratas y presentación de plantillas (R-07) | Analista | Abierta |
| 4 | C-03: definición de cobertura completa y tabla issue→regla (MATRIZ_COBERTURA_PROPUESTA) | Analista + Andrés | Abierta |
| 5 | Aprobar el catálogo candidato corregido (hash fijado) | Analista + Andrés | Pendiente |
| 6 | Andrés actualiza `AGENTS.md` (retirar F-13, 37 reglas, MCI-hijo sólo E1/E2, `UMLActiveClassBlock` como norma) | Andrés | Pendiente |
| 7 | Decisión sobre EC-08 (`SKILL_VERSION` en `src/version.js`, hoy `11.2.1`) | Andrés | Pendiente |
| 8 | Scripts de derivación, hash y lint construidos y probados (§3) | Implementación | No iniciada |
| 9 | Decidir qué reglas viajan como `pendiente` / `condicionada` y cómo las trata la Skill (No verificable con causa) | Analista + Andrés | Abierta |
| 10 | Plan de migración del banco QA aprobado (PLAN_MIGRACION_QA_41_A_37) | Andrés | Pendiente |
| 11 | Preguntas de la analista sobre CNT-002 (patrón con hijo defectuoso) | Analista | Propuesta |

No son condiciones para empaquetar un **candidato** (ver veredicto): C-04…C-10, C-12, C-13 y EC-01…EC-11, que se arrastran como `condicionada` / `con brecha` documentadas.
