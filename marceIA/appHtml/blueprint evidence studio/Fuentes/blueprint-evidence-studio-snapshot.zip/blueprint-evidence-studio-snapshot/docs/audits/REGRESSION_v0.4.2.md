# Auditoría de regresión v0.4.2

Fecha: 2026-10-21. Fuente: JSON originales locales. Inventario completo reproducible en `blueprint-inventory.json`.

| Operación | Figuras | Conexiones | Resultado |
|---|---:|---:|---|
| executeTransactionCurrencyExchange | 99 | 20 | Coincide con línea base |
| createCustomizedCardConsulta | 170 | 78 | Coincide con línea base |
| msDebitAccountPayment | 126 | 30 | Coincide con línea base |

E2 contiene las tres parejas esperadas. `4Oc~...` deriva como candidato el gestor `4Oc~oPj98AFn`; `x6OM...` mantiene varios candidatos y propiedad parcial; `AwQG...` deriva el evento `A2QoPi1ZvH9t`, sin atribuirlo a la API principal. Ninguna pareja produce dictamen normativo.

Se comprobaron preservación literal de líneas/endpoints, grupos, `ENTRADA`, `SALIDA`, `customData`, múltiples páginas, ausencia de despliegue, conflictos/ciclos y múltiples candidatos. No se ejecutó E2E de navegador porque no hay framework/navegador automatizado configurado; la sintaxis del script inline y ausencia de URLs de red sí fueron comprobadas.

Sensibilidad: los JSON contienen `accountId` de Lucidchart y textos funcionales; `apiKey` aparece como texto de seguridad del diagrama, no como una credencial material identificada. Deben tratarse como confidenciales.
