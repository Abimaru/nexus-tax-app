# Diferencias v0.4.6.1 → v0.4.7 candidato

Fecha: 25/10/2026 · Estado: candidato visual, no estable · Contrato conservado: `copilot-factual-v0.4.6.1`.

## Alcance implementado

La evolución modifica exclusivamente `ui/`, las pruebas, el HTML distribuible y la documentación de entrega. No modifica `src/`, la Skill v11.2.3, las 41 obligaciones, el contrato compacto, `issues`, clasificaciones, escenarios, inferencias ni métricas normativas.

Se incorporaron cuatro paneles descriptivos:

1. **Eventos BPMN con subtipo no certificado.** Lista cada `BPMNEvent` sin certificación publicada y distingue el evento relacionado con `scenario`. Muestra `customData` literal, conflictos y motivo. Nunca interpreta nombre, posición, forma, cercanía o texto libre como Inicio.
2. **Dominios productores.** Deduplica dominios efectivos con `domainRole:PRODUCER` y muestra si la procedencia ya publicada corresponde a declaración o inferencia estructural. No resuelve roles nuevos ni infiere por descarte.
3. **Contenedores hijo.** Presenta tipo, rol, padre inmediato, ancestros, nombre original, cantidad de hijos directos y estados existentes. `role:null` aparece como «Rol no determinado»; un contenedor sin nombre sigue sin nombre.
4. **Modelos de entrada/salida por evidencia original.** Detecta únicamente claves literales ENTRADA/SALIDA en `customData`; muestra grupos como asociación, padre y conflictos/pendientes. No usa `architecturalType:MODELO` como criterio ni asigna propiedad.

## Campos consumidos

| Panel | Campos del contrato vigente |
|---|---|
| Eventos BPMN | `page`, `pageClassification.kind`, `components[].id`, `lucidchartType`, `customData`, `connections`, `scenario.scenario`, `scenario.status`, `scenario.mainComponentId`, `scenario.event.{id,subtypeStatus,conflicts}` |
| Productor | `components[].domainRole`, `architecturalDomain.{id,name,source,roleSource,status,conflicts}`, `scenario.{sourceRootDomainId,destinationRootDomainId,mainComponentId,mainChildServiceId,event,connection,evidence}` |
| Contenedores hijo | `components[].{id,name,architecturalType,role,structuralParent,containerChainIds,architecturalDomain}`, `scenario.{mainChildServiceId,status}` |
| Entrada/salida | `components[].{id,lucidchartType,customData,structuralParent,deploymentAssociations}`, `groups[].{id,directMemberIds,relatedComponentIds,status,conflicts}`, `pageClassification.kind` |

El conteo de figuras de un contenedor se deriva contando componentes cuyo `structuralParent.id` coincide con el contenedor: solo hijos inmediatos, sin convertir ancestros o grupos en contención.

## Regresión e invariancia

- `npm test`: 69/69 PASS.
- `npm run test:e2e`: 8/8 PASS sobre `dist/BlueprintEvidenceStudio.html`.
- `npm run audit`: PASS; corpus auditado sin incidencias nuevas.
- `npm run build`: PASS.
- HTML autocontenido: 77.481 bytes; 0 URLs remotas.
- SHA-256: `205CC88EA198C175002E86D1A65696D3E2D7260A8E8B86BDCFDB98B68EAE93F5`.

La prueba de invariancia fija el SHA-256 de los bytes `JSON.stringify(copilotExport(...))` para las mismas selecciones reales:

| Caso | SHA-256 compacto, sin cambio |
|---|---|
| Oski | `4ac9bf74854e1e143251e61fda1089348774fb011a5e9da98fb25d722c0d592e` |
| Currency Exchange | `96d277f96ef635e33763173be4f5c908a9c4557d1b1987fe076030cb63d8cc8b` |
| Virtual Account Opening | `d5dc78c75e0ce929ac5c7a8d1a22290d385fc799e421ae0a43a3a21eb310306c` |
| Debit Card | `e18fca0576095832d73677f541a619f07f2603a108d88d21b93167bdce3b8a91` |

Los E2E verifican los cuatro casos reales, evidencia ausente, `[]`, conflictos, contenedores sin nombre, roles `null` y selección manual de páginas no evaluables sin porcentajes ni estados normativos.

## Riesgos pendientes

1. La procedencia del productor se explica con los campos existentes; si en el futuro se requieren rutas probatorias más detalladas, sería necesario ampliar el contrato. No se hizo en esta fase.
2. Para eventos ajenos a `scenario.event`, el compacto no publica un estado interpretado de subtipo. La UI muestra `SIN_CERTIFICACION_PUBLICADA`, que describe ausencia de certificación publicada y no una nueva clasificación.
3. El conteo de contenedores corresponde a hijos estructurales inmediatos, no a todos los descendientes.
4. Las asociaciones de modelos por grupo continúan siendo evidencia asociativa pendiente de interpretación; el panel no determina dueño.
5. La interfaz candidata requiere revisión visual y aceptación de la analista. No se declara estable.

No hubo commit, push, merge ni PR.
