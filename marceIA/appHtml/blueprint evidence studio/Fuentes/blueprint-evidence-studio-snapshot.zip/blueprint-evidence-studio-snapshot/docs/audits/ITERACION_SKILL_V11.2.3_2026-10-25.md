# Iteración operativa — Skill v11.2.3 y verificaciones de Evidence Studio

Fecha: 25/10/2026 · Skill v11.2.3 **preparada, no declarada estable** · Evidence Studio sin cambios (HTML SHA-256 `a93f293d…a47`, idéntico al de antes) · Sin commits, push ni PR.

## 1. Cambios Skill v11.2.2 → v11.2.3
Solo texto operativo; no se tocó ninguna regla. Archivos con cambio de contenido:

| Archivo | Cambio |
|---|---|
| `references/00-procedimiento.md` | Nueva sección «Interpretación operativa (v11.2.3)» con los 7 ajustes |
| `SKILL.md` | Eco breve en los pasos 6 y 7 y remisión a la sección |
| `references/INSTRUCCIONES-AGENTE-V11.md` | Dos viñetas nuevas |
| `references/CONTRATO-COMPACTO.md` | Párrafo de tipo vs. rol, procedencia de `PRODUCER` y certeza del Inicio (campos reales del exportador) |
| `references/CHANGELOG-V11.md`, `MANIFEST.md` | Entrada v11.2.3 y versión |
| `references/0[1-7]-reglas-*.md`, `INSTRUCCIONES`, `SKILL`, `00-procedimiento` | Solo el número de versión en el encabezado (línea 1) |

Ajustes implementados (los 7 solicitados): (1) `SERVICIO_HIJO` = tipo arquitectónico, `HIJO_PRINCIPAL` = rol en el escenario; (2) un hijo principal no equivale a `SERVICIO` ni `INVOCADO` y no amplía SRV-001..003; (3) `domainRole: PRODUCER` exige procedencia (`architecturalDomain.source`/`roleSource`), certeza (`status`) y conflictos (`architecturalDomain.conflicts`, `scenario.conflicts`); (4) HIPOTESIS/CONFIRMADO no son estados normativos; (5) E1-001, E2-001 y E3-001 no se declaran Cumple sin Inicio certificado (`scenario.event.subtype`/`subtypeStatus`); (6) API-004, CA-001 y FT-001 se evalúan por separado, con evidencia propia; (7) No cumple exige evidencia suficiente y la ausencia de una figura no basta.

No se hizo (por instrucción): no se extiende el requisito de Inicio a CNT-002; no se modificó la interpretación de API-003; no se tocaron cuatro estados, fórmula, F-13, preguntas MCI/exposición, reutilización condicional, `PROPOSED_CLOSED_CATALOG` ni la decisión directa/declarada.

## 2. Pruebas ejecutadas
| Prueba | Resultado |
|---|---|
| `npm test` (antes de cambiar) | 61/61 |
| `npm test` (después) | **68/68** (7 pruebas nuevas en `test/skill.test.js`) |
| `npm run audit` | OK, 0 incidencias |
| `npm run build` | OK; 67 359 B; SHA-256 sin cambio; 0 URL remotas |
| `npm run skill:pack` / `skill:zip:validate` | OK; 18 entradas portátiles |
| `node qa/tools/verify-skill-zip.mjs` | 17/17 comprobaciones, incluidas igualdad literal de las 41 obligaciones con v11.2.1 y v11.2.2 |
| Simulador: `selftest` | 118/118 |
| Simulador: `preflight --model opus` | 72/72 |
| `qa/tools/compare-normative.selftest.mjs` | 10/10 |
| E2E (`test:e2e`) y ejecución con modelo | **No ejecutados** (no se pidió); la v11.2.3 no se ha probado con el evaluador |

Cobertura de las pruebas nuevas: correspondencia de campos (los nombres citados existen en `src/`), ausencia de contradicciones (sin quinto estado, fórmula y pendiente directa/declarada intactos, Inicio no extendido a CNT-002 ni a su texto), 41 IDs, hash de cuerpos de reglas y CSV, YAML de `SKILL.md`, 16 archivos, contrato compacto y compatibilidad con el simulador (lock re-fijado a v11.2.3; v11.2.2 archivada).

## 3. ZIP
`dist/validar-blueprint-integracion-v11.2.3.zip` · 29 908 B · 16 archivos · SHA-256 `e15c8bda8bef0eb4913ea671c1bfc8ad97b10e026112a51c4455be8f75939330`.
Conservados: v11.2.2 (`dist/…v11.2.2.zip`, copia en `qa/skill-locks/`, SHA-256 `9b35a98e…c704d`, lock `qa/skill-locks/skill.lock.v11.2.2.json`) y v11.2.1 (`qa/skill-locks/`).

## 4. Estado de las 41 obligaciones
Sin cambios. 41 IDs únicos; los siete archivos de reglas coinciden en cuerpo (todo salvo la línea de versión) con v11.2.1 y v11.2.2, y el catálogo CSV es byte a byte el mismo (pin `a0520374…`). F-13 permanece en CNT-002, E1-001 y E3-001. Pendientes normativos sin tocar: directa/declarada, lectura de «escenario certificado» en CNT-002, población de SRV, gestores MQ, cobertura completa, población de CNT-006, reparto API-004/CA-001/FT-001, interpretación de API-003.

## 5. MOD-001 (solo lectura) — resultado
Reproducible: `node qa/tools/audit-mod001.mjs --out <archivo>`; detalle por página en [`MOD001_VERIFICACION_2026-10-25.md`](MOD001_VERIFICACION_2026-10-25.md). Alcance: 7 blueprints, 27 páginas (14 evaluables).

| Verificación | Resultado |
|---|---|
| Figuras con `customData` ENTRADA/SALIDA | 160 (todas clase `BPMNActivity`) |
| Preservación literal en el compacto (ID, clase, `customData`, `textAreas`) | **160/160** |
| Preservación de pertenencia a grupos | **160/160**, sin incidencias |
| Páginas evaluables con ENTRADA y SALIDA asociadas al principal por un grupo único | **10 de 14** |
| Páginas evaluables sin esa asociación (principal resuelto) | 2 (Debit Card · asociatePreIssuedCardMediadoConsulta y createVirtualCardConsulta) |
| Páginas evaluables sin principal resuelto | 2 (Debit Card · createCustomizedCardConsulta y createVirtualCard) |
| Modelos en páginas evaluables: grupo único con el principal / grupo sin el principal / sin grupo | 20 / 59 / 43 |
| Modelos referenciados por una línea | 1 de 160 |

Hallazgos:
1. **El tipo `MODELO` no identifica los modelos de datos.** `exporter.js:25` lo asigna cuando el nombre de la figura contiene «modelo»: lo reciben las etiquetas «Modelo de Salida/Lectura» (`DefaultSquareBlock`) y algunas figuras de plantilla; 99 de las 160 figuras con ENTRADA/SALIDA tienen `architecturalType: null`. La evidencia de MOD-001 es `customData` (clave `ENTRADA`/`SALIDA`) más grupos, y llega íntegra.
2. **Ambigüedad de propiedad.** La asociación al principal solo existe como pertenencia a un grupo (evidencia asociativa, no contención). 59 modelos están en grupos que no contienen al principal (presumiblemente de otros componentes) y 43 no están en ningún grupo; no se les asignó propietario. Si basta la pertenencia a un grupo para MOD-001 es una interpretación pendiente.
3. El «No cumple en 4/4» del piloto proviene de casos sintéticos sin modelos, no de pérdida de datos del exportador (resultado F, no B).
No se modificó la clasificación `MODELO` ni se creó ninguna asociación.

## 6. Contenedores hijo (solo lectura) — resultado
Reproducible: `node qa/tools/audit-child-containers.mjs --out <archivo>`; detalle en [`CONTENEDORES_HIJO_2026-10-25.md`](CONTENEDORES_HIJO_2026-10-25.md). 25 `RectangleContainerBlock`, 20 en páginas operativas.

| Condición (páginas operativas) | Cantidad |
|---|---|
| Sin nombre | 8 (todas en Debit Card) |
| Sin padre estructural | 6 |
| Anidado en otro contenedor hijo | 2 (`AAztE7-ReJ9u`, `BbYhfjREOgCH`) |
| Sin rol principal (`role: null`) | 8 |
| Página con escenario NO_DETERMINADO | 6 contenedores |

Los contenedores sin nombre agrupan entre 2 y 68 figuras; los de 21–68 funcionan como marcos amplios, no como un servicio nombrado. Todos reciben `SERVICIO_HIJO` por la figura.

Advertencias útiles (propuestas; sin implementar, sin reclasificar):
| Advertencia | Dónde | Texto sugerido |
|---|---|---|
| `CHILD_CONTAINER_UNNAMED` | contrato (`issues`) e interfaz | «Contenedor hijo sin nombre; contiene N figuras» |
| `CHILD_CONTAINER_WITHOUT_PARENT` | contrato e interfaz | «Sin padre estructural declarado» |
| `CHILD_CONTAINER_NESTED` | contrato e interfaz | «Anidado en otro contenedor hijo (ID)» |
| `MULTIPLE_CHILD_CONTAINERS_NO_MAIN` | interfaz | «Varios contenedores hijo y escenario NO_DETERMINADO: no se puede identificar el hijo principal» |
| `TYPE_BY_SHAPE_ONLY` | documentación del contrato | «`SERVICIO_HIJO` se asigna por la figura, no por el contenido» |
Impacto contractual: son campos informativos nuevos (cambio aditivo del compacto); requieren autorización y versión nueva. Riesgo: que se lean como incumplimiento; deben redactarse como evidencia incompleta.

## 7. Propuesta BPMN
[`PROPUESTA_CERTIFICACION_BPMN_2026-10-25.md`](PROPUESTA_CERTIFICACION_BPMN_2026-10-25.md): panel «Eventos BPMN con subtipo no certificado» y advertencia no bloqueante, construidos solo con campos existentes (`scenario.event.subtypeStatus`, `conflicts`, `customData`). Hechos de hoy: 260 `BPMNEvent` en los 7 blueprints, 0 con `customData`; los 12 escenarios son HIPOTESIS/NO_VERIFICABLE. No se implementa ninguna convención `customData` nueva; `PROPOSED_CLOSED_CATALOG` se mantiene.

## 8. Plantilla de comparación normativa
- Documento: `qa/templates/COMPARACION_NORMATIVA.md`; entrada: `qa/templates/catalogo-consolidado-NUEVO.plantilla.csv` (solo cabecera).
- Herramienta: `node qa/tools/compare-normative.mjs --new <consolidado.csv>`; detecta, por ID, reglas nuevas/retiradas/posibles renombres y cambios de **texto, aplicabilidad, evidencia y criterio**, e indica si la evidencia está `DISPONIBLE_EN_CONTRATO`, `CAMPO_NO_DOCUMENTADO` o `SIN_MAPEO`. No inventa reglas. Autoprueba 10/10, incluido que las 41 reglas vigentes se mapean a campos documentados.

## 9. Riesgos pendientes
1. La v11.2.3 no se ha ejecutado con el evaluador; sus efectos en las respuestas (p. ej., E1/E2/E3-001 ahora No verificable sin Inicio) solo se conocerán con un caso piloto autorizado.
2. Con escenario siempre HIPOTESIS, E1/E2/E3-001 no pueden llegar a Cumple en los blueprints reales hasta que el subtipo Inicio pueda certificarse.
3. `MODELO` por nombre puede confundir a un lector: la Skill debe apoyarse en `customData`/grupos (pendiente decidir si se documenta en la Skill).
4. SRV-001..003 siguen con población dudosa para el hijo principal (decisión analista).
5. El mapeo de preguntas del simulador es por palabras clave; la v11.2.3 no cambia preguntas, pero cualquier cambio de redacción puede dejar preguntas sin asignar.
6. Material corporativo en ramas privadas sigue sin destino privado autorizado.

## 10. Estado Git
- Rama `feature/evidence-studio-v0.4.6.1-private` (`81b7542`); ningún commit nuevo; remoto `origin` público y sin cambios; nada publicado.
- Modificados (sin confirmar): `AGENTS.md` (versión de la Skill), `CHANGELOG.md`, `HANDOFF.md`, `README.md`, `scripts/package-skill.ps1`, `scripts/validate-skill-zip.mjs`, `test/skill.test.js`, la Skill (`SKILL.md` y `references/`) y el ZIP v11.2.1 del working tree.
- Sin seguimiento: `dist/…v11.2.2.zip`, `dist/…v11.2.3.zip`, `PROJECT_CONTEXT_2026-10-25.md`, `docs/audits/` (informes de esta etapa y `AUDIT_v0.4.6.1_independent.md`), `qa/` (incluye `qa/templates/`, `qa/tools/audit-*.mjs`, `qa/tools/compare-normative*.mjs`, `qa/skill-locks/` v11.2.2, `qa/runs/` ignorado).
- Evidence Studio (`src/`, `ui/`, HTML): sin cambios en esta iteración.
- Nada de lo nuevo entra en la lista blanca de la rama pública (`qa/`, `skills/`, `docs/audits/` y los ZIP quedan fuera).
