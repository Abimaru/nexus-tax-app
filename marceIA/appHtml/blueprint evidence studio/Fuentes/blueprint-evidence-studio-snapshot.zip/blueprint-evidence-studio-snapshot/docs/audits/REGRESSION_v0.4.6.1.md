# Informe de regresión v0.4.6.1

## Resultado

- Unitarias/regresión: 54/54 PASS.
- E2E sobre `dist/BlueprintEvidenceStudio.html`: 5/5 PASS.
- Auditoría del corpus: 37 páginas, 0 incidencias estructurales reportadas.
- Skill: YAML/estructura PASS; ZIP con 18 entradas portátiles PASS.
- HTML autocontenido: 67.359 bytes; SHA-256 `A93F293D1E04FA0F874AE13F4A0E9C6309572C99F35D465EA7BFA5BF4D82A247`.
- Skill ZIP: SHA-256 `C44D5DB40FED5A3579D41BAB0E5200C0D554C05D83D5DB7945E6D3B8BD873AB5`.

## Hallazgos

H-01 y H-02 quedaron corregidos. También se corrigieron H-03, H-04, H-05, H-06, H-08, H-09, H-11, H-12, H-13, H-15, H-16, H-17 y H-18. H-10 queda como propuesta porque la tabla de contenedores sería un rediseño contractual. H-14 se aplicará en la rama pública sanitizada, donde corresponde.

La prueba funcional real en Copilot no se ejecutó y no se marca PASS. El producto no se declara estable.

## Escenarios y asociaciones

- Currency Exchange: E2 HIPOTESIS; gestor `4Oc~oPj98AFn` asociado exclusivamente a flujo `4Oc~UAg.ChZ2` y capa `4Oc~STvzS7WZ`.
- Oski: E1 HIPOTESIS; conserva 13 actividades con ENTRADA/SALIDA.
- Virtual Account Opening: E1 HIPOTESIS en sus dos operaciones.
- `nombreOperacion1`: E2 HIPOTESIS; asociación por grupo superior `3gn9Z0fP~kxr` conservada.
- E3 genérico: HIPOTESIS; E3 con Inicio inequívoco: CONFIRMADO.

## Tamaños JSON

| Fuente | Original | Compacto | Diagnóstico | Razón compacto/original |
|---|---:|---:|---:|---:|
| Currency Exchange | 30.568 | 117.440 | 280.549 | 3,84× |
| Oski | 53.130 | 175.159 | 403.617 | 3,30× |
| Debit Card Issuance | 183.974 | 612.443 | 1.542.445 | 3,33× |

La repetición principal permanece en objetos de jerarquía por componente. Se conserva el formato correcto para no perder estados, fuentes ni compatibilidad; queda propuesta una tabla de contenedores reconstruible para una versión contractual futura.

## Riesgos pendientes

- Instalación y ejecución real de la Skill en Copilot.
- Aprobación corporativa del catálogo BPMN, que continúa como `PROPOSED_CLOSED_CATALOG`.
- Decisión conexión directa frente a conexión declarada.
- Optimización de tamaño con demostración de equivalencia.
- Aprobación de la analista; esta versión no se declara estable.
