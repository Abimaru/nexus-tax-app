# Comparación v0.4.4.1 → v0.4.4.2

| Área | v0.4.4.1 | v0.4.4.2 |
|---|---|---|
| Destino de escenario | E1 parcial con destino nulo/externo | Solo patrones exactos E1/E2/E3; faltantes quedan sin escenario |
| Principal | Podía estar dentro del hijo | IDs y ancestros lo bloquean |
| Dominios anidados | Envolvente podía reemplazar el dominio | Raíz estructural y dominio efectivo separados; conflicto explícito |
| Reservados | Variantes podían convertirse en PRODUCER | Variantes reservadas quedan sin resolver |
| Página | Sin tipo explícito | OPERATIONAL, TEMPLATE_OR_LEGEND, MIXED o UNRESOLVED |
| Señales técnicas | Topología dominaba el resultado | Tipo Lucidchart, función, nombre, rol y escenario independientes |
| Estado no normativo | Campos ausentes en algunos estados | `normativeEvaluation:null` y `nonNormative:true` siempre |
| Skill | v11.1 no consumía el contrato nuevo | v11.1.1 lo contrasta con evidencia original; 41 reglas intactas |
| Padre inmediato | `structuralParentId` | Mismo ID más objeto `structuralParent` y fuente `JSON.contains` |
| Cadena | `containerChainIds` | Sin cambios de IDs ni orden |
| `rootContainerId` | Sobrecargado como dominio arquitectónico | Raíz estructural real; el dominio pasa a `architecturalDomainId` |
| Envolventes | Raíz y dominio podían confundirse | `rootContainer` y `architecturalDomain` divergen explícitamente |
| Conflicto de contención | Padre sin resolver | Padre, raíz, dominio y rol nulos; candidatos conservados |

No se reconstruyó el motor, no se incorporó un segundo clasificador y no se modificó la normativa oficial.

La regresión congela una jerarquía sintética equivalente a v0.4.4.1 y verifica que padre y cadena no cambien. La única diferencia intencional es semántica: el antiguo `rootContainerId` que apuntaba al dominio se divide en `rootContainerId` estructural y `architecturalDomainId`. No se reparenta ninguna figura.
