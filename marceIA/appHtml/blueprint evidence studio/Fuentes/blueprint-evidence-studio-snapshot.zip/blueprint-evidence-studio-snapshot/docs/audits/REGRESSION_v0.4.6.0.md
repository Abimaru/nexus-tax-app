# Regresión v0.4.6.0

## Resultados ejecutados

- Unitarias/integración: 46/46 PASS.
- E2E sobre `dist/BlueprintEvidenceStudio.html`: 4/4 PASS.
- Auditoría privada: 37 páginas, 10 fuentes JSON originales, 0 incidencias estructurales.
- Skill: validación YAML/estructura correcta; 41 IDs únicos; ZIP con 15 entradas portátiles y separadores `/`.
- HTML: 63.588 bytes, SHA-256 `88B92F52334118E14D4F36A2F1C88EC9A8C39F5503892C4B9F76D9570720085E`, 0 URLs HTTP(S).
- Skill ZIP: 21.551 bytes, SHA-256 `A281960181C2F4AEF0B2E86861EDB44276C1BB3D0B0EDAD73F293C7B2E876BF5`.

## Auditoría Claude validada

- A-1 corregido: selección filtra realmente el JSON compacto y sus métricas.
- A-2 corregido: texto libre y claves ajenas no certifican Inicio.
- A-3 corregido: ZIP estándar con `/` y comprobación automatizada.
- M-1 corregido: dominios reservados vacíos conservan rol.
- M-2 corregido: dominios personalizados no resueltos publican roles posibles.
- M-5 corregido: E2 exige la misma INTEGRACIÓN.
- M-6 corregido: varios padres o varias parejas bajo el superior impiden resolver por grupo.
- M-8 resuelto según decisión v0.4.6.0: contención directa acredita asociación factual sin convertirla en propiedad ni cumplimiento.

No se adoptaron inferencias no aprobadas de la auditoría. Los ciclos de grupos y la contradicción de un contenedor externo explícito con estructura productora continúan como endurecimiento residual.

Casos obligatorios: Currency Exchange E2 HIPOTESIS; Oski E1 HIPOTESIS; Virtual Account Opening con dos operaciones y selección individual; nombreOperacion1 E2 HIPOTESIS; E3 sintético genérico HIPOTESIS y con `customData` exacto CONFIRMADO.

Riesgos residuales: catálogo de claves BPMN propuesto por ausencia de convención real; pruebas funcionales de analista pendientes; decisión normativa de conexión directa frente a declarada pendiente; instalación real en Copilot no probada; ciclos de grupos aún no se elevan a conflicto; falta diagnóstico específico para externo reservado con estructura productora.
