# Consolidación normativa: reconciliación de las auditorías A y B, plan y riesgos

26/10/2026 · Solo lectura. No se modificó Evidence Studio (`src/`, `ui/`), la Skill, las reglas de la analista ni el catálogo de 41; no se creó ninguna versión; no hubo commit ni push; no se ejecutó la batería QA. Catálogo base: el derivado literalmente de los siete archivos normativos de la analista.

Entregables de esta iteración (en `docs/audits/`): este documento (planes C y riesgos D, comparación de auditorías, revisión de SRV-001/002) · [`MATRIZ_CONSOLIDADA_37_2026-10-26.csv`](MATRIZ_CONSOLIDADA_37_2026-10-26.csv) / [`.md`](MATRIZ_CONSOLIDADA_37_2026-10-26.md) (entregable A) · [`DECISIONES_DEPURADAS_2026-10-26.md`](DECISIONES_DEPURADAS_2026-10-26.md) (entregable B) · [`MAPEO_IDS_41_A_37_2026-10-26.csv`](MAPEO_IDS_41_A_37_2026-10-26.csv). Los siete archivos de la auditoría B quedaron copiados en `docs/audits/auditoria-B/`.

---

## 1. Comparación de las dos auditorías

### 1.1 Hallazgos coincidentes (los dos informes llegan a lo mismo por caminos distintos)
- El paquete de la analista está en borrador: CSV de 41 reglas, referencias a 41 en instrucciones y contrato, encabezados v11.2.1, manifiesto que pide un archivo inexistente, SRV-001/002 en esqueleto, EXT-002 autorreferenciada, viñetas «No aplica» con contenido de «No verificable» en EVT-005/006/007, etiqueta «v11.2.2» colisionando con la nuestra.
- Números: 37 reglas = 32 modificadas + 3 nuevas + 2 sin cambio; 41 → 34 sobreviven; 7 retiradas o fusionadas.
- Siete IDs cambian de significado (EXT-002, EVT-004..007, MQ-002, MQ-003).
- La normativa nueva resuelve en el texto casi todas las ambigüedades históricas (35 de 37); quedan SRV-001/002.
- Brechas de evidencia: eventos de integración y Capa de Tópicos sin tipo, subtipos BPMN sin catálogo suficiente, `Federado`, APIs/servicios no principales, Capa/Flujo reconocidos por prefijo.
- Conflictos nuevos: plantillas frente a «No aplica» (R-07), E1-E3 con Inicio sin certificar (C-08), `UMLActiveClassBlock` promovida a norma.

### 1.2 Hallazgos exclusivos
**Solo en B** (verificados por mí en el código o el corpus; todos se conservan):
| Hallazgo | Verificación |
|---|---|
| G-2: `INVOCADO` exige entrada y ninguna salida; el patrón bidireccional de COM-002/003 lo impide | Código (`exporter.js:37`) y corpus: `INVOCADO` 0; 56 pares bidireccionales frente a 5 de un sentido |
| G-5: `deploymentAssociations` solo publica pares Flujo+Capa (sin «Capa sin Flujo» ni `Federado`) | Código (`deployment.js`); no hay API `partner` en el corpus, así que no hay instancia real |
| G-7: dominios con nombre propio solo se reconocen si son PRODUCER con `customData` | Código (`containment.js`); en el corpus no hay INTEGRACIÓN con nombre propio, sí un contenedor «EVC … EPC …» sin resolver (Currency) |
| `MATRIZ-EVIDENCIA-37` apunta EVT-001..003 a `architecturalType`, que es `BPMNEvent` | Verificado: `EVENTO` = `BPMNEvent` |
| El motor acepta `CircleOpen→Generalization` como orientación válida del escenario; la norma de E1-E3 pide `None→Arrow` | Código (`roles.js`); en el corpus 12 de 12 son `None->Arrow`, sin impacto real hoy |
| EC-08: `SKILL_VERSION` en `src/version.js` dice `11.2.1` | Verificado |
| D-16 (EXT-002 subcadena), D-17 (capitalización), D-18 (COM «relación»), D-20, D-13 | Texto de las reglas |
| Esquema canónico de 17 atributos, arquitectura A..G de la Skill, 37 filas de pruebas de aceptación | Propuesta; ver §3 |

**Solo en A:**
- Medición sobre 7 blueprints reales (B afirma que no los tenía): 235 `BPMNEvent` sin `customData`, 5 eventos de integración, 12 APIs tipadas y 62 `UMLClassBlock` sin tipo, 160 modelos ENTRADA/SALIDA preservados (160/160), 8 contenedores sin nombre.
- La decisión histórica vinculante de Andrés y de la analista (Q1..Q10) y el estado de la Skill v11.2.3 (qué conservar o reemplazar).
- C-13: la asociación de modelos por grupo (B solo lo menciona como límite).
- La nota «antigua EXT-003» inexistente en el catálogo de 41.
- Impacto sobre el banco QA y sobre los paneles de v0.4.7.

### 1.3 Contradicciones entre A y B (y cómo se reconcilian)
| # | A | B | Reconciliación |
|---|---|---|---|
| 1 | Hay 7 blueprints reales | «No hay blueprints reales» | B trabajó sobre una copia sin ellos (referencia a `presentation-panels.json`, que no existe en este repositorio). Sus hipótesis se verificaron aquí: G-1, G-2, G-3, G-4, G-6 confirmadas con datos; G-5 solo por código; G-7 con un caso |
| 2 | D-03: pide discriminador | Opción (B): tercera sección ⇒ tipo | **Los datos reales refutan (B)**: 30 invocados con «Entidad» solo serían servicios aunque el nombre tenga formato de API |
| 3 | «19 de 37 reglas con hueco D/E» | «28 de 37 afectadas por D-03/05/06» | Métricas distintas: A cuenta reglas con evidencia ausente/imposible; B cuenta reglas que citan esas decisiones. Sin conflicto |
| 4 | Q8, API-003 cerrados por el texto | Residuo: cómo se certifica «API» sin tercera sección válida | Se acepta la matiz de B: cerrado para la API principal; la población invocada va a C-04 |
| 5 | D-08 (No aplica): compatible | Tensión | Se resuelve con R-08 y C-03 (cobertura) |
| 6 | SRV-004: el manifiesto lo aclara | D-21 pendiente | Resuelta por el manifiesto (R-06) |
| 7 | Directa/declarada cerrada por el texto | D-10 pide confirmar | Cerrada (R-04); la confirmación sería redundante |
| 8 | EVT-006 «C/D» | EVT-006 «directa» (texto regex) | La parte textual es directa; falta reconocer el tópico. Se mantiene «dependiente de convención» |

### 1.4 Inferencias no demostradas
- B: «afectan a 28 de las 37 reglas» (no mide evidencia); «siempre No verificable» en reglas de población invocada es correcto por código pero B lo presentó sin datos reales; la clasificación de Capa/Flujo en la sonda sintética es supuesta (lo admite).
- A: la clase A–F de cada regla es juicio; «19/37» depende de ellas; «antigua EXT-003» no existe en el catálogo de 41 (demostrado contra el CSV), pero no se sabe si alude a una versión intermedia que no vimos.
- Ambos: ninguno vio el Word/Excel de la analista; solo el ZIP.

### 1.5 Decisiones ya resueltas y realmente pendientes
Ver [`DECISIONES_DEPURADAS_2026-10-26.md`](DECISIONES_DEPURADAS_2026-10-26.md): 20 resueltas (R-01..R-20) y 13 pendientes (C-01..C-13).

---

## 2. Revisión de SRV-001 y SRV-002

- **Estado:** texto idéntico al del catálogo de 41 («Servicios principal e invocados. Puede iniciar por ms; admite -, _ o espacios. Si hay versión, V/v y tres segmentos» / «No deducir operación del nombre»), encabezado `##` en lugar de `###`, viñeta genérica «evidencia suficiente y criterio satisfecho»; la analista las declara pendientes y exige un resultado por página.
- **Conflicto con el modelo nuevo:** SRV-003 y SRV-004 dicen que el hijo principal representa el servicio principal (y SRV-003 lo excluye), así que «principal» en SRV-001/002 es ambiguo: ¿hijo principal, componente principal de E3, ambos?
- **Evidencia real:** 5 `SERVICIO` por prefijo `ms`; hijos con `ms…` (msDebitAccountPayment, user_ms) y sin él; el contenedor hijo tiene una sola sección de texto, por lo que SRV-002 (operación) no se puede evaluar sobre él.
- **Tratamiento hasta que se cierren:** conservar el texto literal, estado «ESQUELETO_PENDIENTE», resultado «No verificable — criterio normativo pendiente» (nombrando el faltante), sin ampliar la población por analogía (decisión previa vigente). Las pruebas (B/06) quedan bloqueadas por C-01.
- **Propuesta para la analista:** población = servicios invocados + componente principal de E3 (el hijo se valida por nombre en CNT-002); prefijo `ms` convencional; versión opcional; operación `camelCase` en inglés como API-002 (a definir por ella).

---

## 3. Plan de consolidación (entregable C)

### 3.1 Reglas que se pueden consolidar ahora (sin motor ni convención)
**G1 — 15 reglas:** CNT-001, CNT-002, EXT-001, EXT-002 (con la errata C-11), GW-001, API-001..004, SRV-004, CA-001, FT-001, COM-001, COM-004, MQ-001. (La población invocada de API-001..003 y EXT-002 espera C-04, sin afectar la redacción.)
**G2 — 8 reglas con una reserva menor:** CNT-003/004/005 (lista C-11 y reconocimiento C-06 para evaluar), COM-005 (C-12), MOD-001 (C-13), E1/E2/E3-001 (C-08).

### 3.2 Reglas que requieren aclaración o convención
**G3 — 12 reglas cuya redacción/certificación depende de una convención Lucidchart no aprobada:** SRV-003, COM-002, COM-003 (C-05, C-04); EVT-001..006 (C-04, C-06); EVT-007 (C-07); MQ-002 (C-06, asociación de `Federado`); MQ-003 (C-05, C-07).
**G4 — 2 bloqueadas por el criterio de la analista:** SRV-001, SRV-002 (C-01).

### 3.3 Cambios que necesita la Skill (cuando se implemente; hoy nada se toca)
1. Reconstruir desde los siete archivos de la analista sin retocarlos: catálogo CSV de 37 con hash, matriz de evidencia generada (no editada a mano) con los campos correctos (EVT-001..003), manifiesto, instrucciones y contrato a 37, carpeta raíz única, versión nueva (C-02).
2. Incorporar la prioridad de estados y los controles previos de integridad (con la tabla issue→regla, C-03).
3. Conservar de v11.2.3: HIPOTESIS/CONFIRMADO no son estados; procedencia/certeza/conflictos de PRODUCER; contención ≠ grupo; `customData` ENTRADA/SALIDA ≠ `MODELO`; Inicio certificado en E1-E3.
4. Reemplazar/retirar: «no se extiende a CNT-002»; «evaluar API-004/CA-001/FT-001 por separado»; criterio operativo de CNT-006; «UMLActiveClassBlock es solo convención»; adaptar §2 (hijo principal = servicio principal, no INVOCADO).
5. Mantener la clasificación de páginas de v11.2.2 (R-07), el protocolo de contradicción y la fórmula.
6. Nuevo conjunto de preguntas (R-10) y precedencia de conexiones (COM → una sola vez).
7. Mapeo `id_historico → id_vigente` con alias y el `riesgo_de_trazabilidad` (archivo de mapeo).

### 3.4 Cambios que necesita Evidence Studio (todos tras aprobar la decisión asociada)
| Cambio | Decisión | Naturaleza | ¿Necesario para evaluar? |
|---|---|---|---|
| EC-01 redefinir `INVOCADO` | C-05 | comportamiento de un campo publicado | Sí, para COM-002/003 y SRV-003 |
| EC-02 subtipos BPMN en todos los eventos + catálogo ampliado | C-07 | aditivo | Sí, para E1-E3, EVT-007, MQ-003 |
| EC-03 reconocimiento de figuras (evento de integración, Capa de Tópicos, concepto…) | C-04, C-06 | aditivo | Sí, para EVT-001..006 y CNT-003..005 |
| EC-04 asociaciones de Capa sin Flujo, `Federado` y hijo por grupos | C-06 | aditivo | Sí, para API-004 partner y MQ-002 |
| EC-05 dominios con nombre propio por `customData` | C-03/R-05 | comportamiento | Solo si hay casos reales (hoy 1) |
| EC-06 clasificar API/servicio/evento no principales | C-04 | según opción | Sí, para la población invocada |
| EC-07 auxiliar sin nombre | C-10 | comportamiento | No: 0 casos reales con contenido |
| EC-08 `SKILL_VERSION` | — | metadato | Trivial, cuando se implemente |
| EC-10 tabla issue→reglas y cobertura | C-03 | documental (Skill) | Sí |
Alternativa sin tocar el motor, cuando la analista la apruebe: que la Skill lea `textAreas`/`lucidchartType` literales (p. ej. «Federado», «Empresarial - Event»); es menos determinista.

### 3.5 Pruebas que debemos preparar
- Base: las 37 filas de la auditoría B (`06-pruebas-aceptacion.csv`), con expectativas derivadas solo del texto de la analista.
- Añadir casos tomados del corpus real: comandos bidireccionales (patrón 56:5), auxiliares EVC con eventos y comandos dentro, contenedor «Federado» en INTEGRACIÓN y en auxiliar, API principal con tercera sección «entidad», invocado con «Entidad» solo, evento de integración «Empresarial - Event» sin tipo, escenario NO_DETERMINADO con dos candidatos a hijo.
- Controles automáticos: 37 IDs únicos; 0 IDs retirados fuera del mapeo; hash de cada regla igual al de la analista; matriz generada igual a la comprometida; compacto invariante (4 firmas SHA-256) y HTML con hash conocido.
- Banco QA: regenerar expectativas (hoy citan IDs que cambian de significado), `FILAS_41`, lectura de IDs del CSV del ZIP, `verify-skill-zip` y `skill.lock`.

---

## 4. Riesgos (entregable D)

### 4.1 Cambio de significado de IDs históricos
Detalle por ID en el mapeo (13 de riesgo ALTO, 22 MEDIO, 9 BAJO). Los más graves: EXT-002, EVT-004..007, MQ-002, MQ-003 (el mismo ID, otra obligación); GW-001 y SRV-003 (mismo ID, semántica distinta). Consecuencia: expectativas del banco QA, informes y respuestas guardadas pueden parecer válidos y no serlo; no comparar resultados por ID entre versiones sin el mapeo.

### 4.2 Contradicciones internas del paquete de la analista
Ver C-02 y C-11 (13 puntos de B más los de A), más C-08 (E1-E3 frente a la prioridad) y la inconsistencia matriz/regla en SRV-001..003.

### 4.3 Criterios imposibles o poco fiables de verificar con el contrato y los datos actuales
| Criterio | Motivo | Evidencia |
|---|---|---|
| Subtipo Inicio/Envío/Recepción/Mensaje | El export del evento no trae subtipo | 260 eventos, `customData` en 0, claves JSON sin subtipo |
| Servicio/API invocado | `INVOCADO` incompatible con el patrón bidireccional | 0 emitidos; 56 pares bidireccionales |
| Evento de integración, Capa de Tópicos, tópicos | Sin tipo; 5 y 1 ocurrencias | corpus |
| `Federado` | Existe como texto pero sin tipo ni asociación | 8 casos |
| CNT-002 «no existe hijo / hay más de uno» | El patrón requiere un hijo ya identificado | 2 páginas NO_DETERMINADO |
| CA-001/FT-001 nombre mal escrito | Se reconoce por prefijo: un prefijo erróneo no se tipa | código (`lucidchart.js`) |
| Idioma, «específico», «genérico», infinitivo | Juicio del evaluador | variabilidad ya observada |
| «Cobertura completa» | No definida | — |
| EXT-001 nombre ausente | Un auxiliar sin nombre no se reconoce como tal | 28 `BPMNGroup` sin nombre, todos vacíos |

### 4.4 Otros riesgos
- Reabrir decisiones: B proponía como pendientes 11 asuntos que ya están resueltos (R-xx); se cierran para no gastar la atención de la analista.
- Implementar antes de C-04..C-08 produce una Skill con 19 reglas casi siempre «No verificable»; el porcentaje bajaría sin reflejar el blueprint.
- La v0.4.7 (interfaz) sigue sin aceptación visual y funcional; no mezclarla con estos cambios.

---

## 5. Recomendación para la siguiente iteración

**Iteración «Cierre normativo» (sin tocar motor ni Skill):**
1. **Andrés (hoy):** aprobar las 5 acciones de §6 de las decisiones depuradas (versionado, `AGENTS.md`, adaptación de §2, aviso de plantillas) y autorizar enviar el cuestionario.
2. **Analista (primera ronda):** responder en este orden C-01, C-07, C-04, C-05, C-06, C-08, C-13 (son las que cambian resultados); después C-10, C-03/C-09, C-12 y el lote C-11. El cuestionario ya tiene las evidencias reales prellenadas.
3. **En paralelo, sin esperar:** redactar el catálogo canónico parcial de las 15 reglas G1 (texto literal de la analista, 17 campos, aliases, ejemplos sintéticos) y preparar las pruebas de aceptación correspondientes, sin ejecutar la batería.
4. **Condición de salida:** todas las pendientes P0 y P1 cerradas o explícitamente aceptadas como «No verificable permanente».
5. **Solo entonces** proponer la implementación: Skill (paquete nuevo), Evidence Studio (cambios aditivos aprobados) y banco QA regenerado.

No se declara estable ninguna versión.
