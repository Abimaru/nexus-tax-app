# 03 — Mapa regla → evidencia → JSON (contrato `copilot-factual-v0.4.6.1`)

Entregable 4 y Fase 5. La tabla por regla (37 filas: campos, disponibilidad, brecha, estados alcanzables hoy) está en `02-matriz-reglas.csv`. Aquí van los hechos del contrato sobre los que se apoya, las rutas exactas y los casos que impiden certificar.

Método: lectura de `src/exporter.js`, `containment.js`, `roles.js`, `classifier.js`, `groups.js`, `deployment.js`, `connections.js` y `page-classifier.js`, más sondas sintéticas ejecutadas en el scratchpad (no se tocó el repositorio). **No hay blueprints reales en el repositorio**; las conclusiones sobre frecuencia e impacto son hipótesis a confirmar.

Clases de disponibilidad: EVIDENCIA_DIRECTA, EVIDENCIA_DERIVADA_VERIFICABLE, EVIDENCIA_DECLARADA_POR_ANALISTA, EVIDENCIA_AMBIGUA, EVIDENCIA_NO_DISPONIBLE.

## 1. Campos del compacto y lo que realmente certifican

Ruta base: `pages[]`.

| Ruta | Tipo / valores | Origen | Clase | Qué impide certificar |
|---|---|---|---|---|
| `page.{id,title,index}`, `counts` | cadenas / enteros | Original | DIRECTA | — |
| `pageClassification.kind` | `OPERATIONAL`, `MIXED`, `TEMPLATE_OR_LEGEND`, `BDD_OR_REQUIREMENTS`, `UNRESOLVED` | Derivado no normativo. `BDD` se decide por la palabra "BDD" en el título; `OPERATIONAL` exige un camino API/servicio→`BPMNEvent` con terminaciones verificables | DERIVADA | Una página con operación real pero sin camino verificable queda `TEMPLATE_OR_LEGEND` o `UNRESOLVED` |
| `scenario.{scenario,status}` | `E1`/`E2`/`E3`/`null`; `CONFIRMADO`/`HIPOTESIS`/`NO_DETERMINADO` | Derivado de un único camino API/servicio→`BPMNEvent` hacia un hijo | DERIVADA | Varios candidatos, orientación `AMBIGUOUS`, dominios sin resolver o principal dentro del hijo ⇒ `NO_DETERMINADO` |
| `scenario.event.{subtype,subtypeStatus}` | `START`/`END`/`SIGNAL`/`RECEIVE`/`EXCEPTION`/`null`; `CERTIFIED_BY_EXPLICIT_CUSTOM_DATA`/`NO_VERIFICABLE`/`CONFLICTING_CUSTOM_DATA` | `customData` con clave `BPMN_EVENT_TYPE`, `EVENT_TYPE` o `TIPO_EVENTO_BPMN` | DIRECTA si existe; si no, NO_DISPONIBLE | Se interpreta **solo** en el evento del escenario. No existe MESSAGE/MENSAJE ni distinción envío/recepción de señal |
| `scenario.connection.orientation.basis` | `None->Arrow`, `CircleOpen->Generalization` | Terminaciones de la línea | DERIVADA | El motor acepta ambas bases como orientación válida; la regla de la analista solo admite `None->Arrow` |
| `components[].id`, `name` | cadena | `Title`, `Text` o `FloatingTitle` (o textos unidos con `\|`) | DIRECTA | — |
| `components[].operation` | cadena / `null` | `Text1` o segunda área de texto | DIRECTA | Sin `Text1` etiquetado se toma la segunda área por posición |
| `components[].textAreas[]` | `{label,text}` literal | Original | DIRECTA | La tercera sección **no** tiene campo propio: se lee en `textAreas` (`Text2` o tercera posición) |
| `components[].lucidchartType` | clase Lucidchart | Original | DIRECTA | Identifica `BPMNGateway`, `BPMNActivity`, `BPMNEvent`, `UMLActiveClassBlock`, `BPMNGroup`, `UMLClassBlock` |
| `components[].architecturalType` | `API`, `SERVICIO`, `SERVICIO_HIJO`, `GESTOR_COLAS`, `SISTEMA_EXTERNO_AUXILIAR`, `EVENTO`, `CAPA`, `FLUJO`, `MODELO`, `null` | Ver §2 | DERIVADA / AMBIGUA | `null` es el valor mayoritario para todo lo que no sea gestor, evento BPMN, hijo, auxiliar nombrado, Capa/Flujo por prefijo o la API/servicio principal |
| `components[].role` | `PRINCIPAL`, `HIJO_PRINCIPAL`, `INVOCADO`, `null` | `PRINCIPAL` por camino inferido; `HIJO_PRINCIPAL` = `scenario.mainChildServiceId`; `INVOCADO` solo si tipo API/SERVICIO, con conexiones entrantes verificadas y **ninguna saliente** | DERIVADA | Brecha G-2 |
| `structuralParent`, `containerChainIds`, `rootContainer` | objeto / lista | `contains` del JSON original | DIRECTA (padre) / DERIVADA (cadena) | `status: CONFLICTING` (varios padres, ciclo) ⇒ no se completa |
| `architecturalDomain`, `domainRole`, `possibleDomainRoles` | `INTEGRATION`/`PRODUCER`/`EXTERNAL_SYSTEM`/`null`; `[]` si resuelto | Nombre reservado exacto, `customData` (solo `PRODUCER`) o estructura | DIRECTA (nombre) / DERIVADA (estructura) | Brecha G-7; con conflictos no es evidencia positiva |
| `connections` (componente) | lista de IDs | Líneas que tocan el componente | DIRECTA | No lleva sentido; el sentido se lee en `pages[].connections` |
| `pages[].connections[]` | `{id,endpoint1{style,connectedTo},endpoint2,textAreas,customData,status}`; `DECLARED`/`PARTIAL`/`MISSING_ENDPOINT_REFERENCE` | Original | DIRECTA | Terminaciones distintas de `None/Arrow/CircleOpen/Generalization` ⇒ orientación ambigua |
| `groups[]` | miembros directos, grupos hijos, padres, ancestros, `relatedComponentIds`, `conflicts` | Original | DIRECTA con estado | Un conflicto impide usar el grupo como evidencia |
| `deploymentAssociations[]` y `components[].deploymentAssociations` | `{flowId,layerId,associatedComponentId,status,source,superiorGroupId,modelIds,evidence}` | Contención Flujo⊃Capa⊃componente, o grupos | DERIVADA no normativa | Solo existen para **pares Flujo+Capa**. Se asocian por contención directa: `UMLClassBlock` (API, servicio o evento de integración), gestor y contenedor hijo; por grupos, solo `UMLClassBlock` y gestor. `BPMNEvent` figura únicamente como candidato relacionado |
| `containedComponentIds` | lista | `contains.shapes` de un `BPMNGroup` | DIRECTA | Solo para `BPMNGroup` |
| `customData` | arreglo literal si existe | Original | DIRECTA | `MALFORMED_CUSTOM_DATA` en `issues` |
| `inference` | `{status,evidence,contradictions}` | Camino inferido o prefijo `ms` | DERIVADA | Solo `INFERRED` sustenta rol definitivo |
| `issues[]` | `CONTAINMENT_CYCLE`, `DIRECT_PARENT_CONFLICT`, `DUPLICATE_ID`, `MISSING_ID`, `GROUP_*`, `MALFORMED_CUSTOM_DATA*`… | Diagnóstico | DIRECTA | No hay tabla issue→regla (D-22) |
| Respuestas de la analista | MCI principal, MCI hijo, exposición | Fuera del JSON | DECLARADA_POR_ANALISTA | No certifican estructura, tipo, subtipo ni asociación |

## 2. Cómo se asigna `architecturalType` (en orden de precedencia)

1. `API` o `SERVICIO` si el componente es candidato del camino hacia el evento y su estado es `INFERRED`.
2. `null` si ese estado es `AMBIGUOUS`.
3. `GESTOR_COLAS` si la clase es `UMLActiveClassBlock`.
4. `EVENTO` si la clase es `BPMNEvent` (**es el evento BPMN, no el evento de integración**).
5. `SISTEMA_EXTERNO_AUXILIAR` si la clase es `BPMNGroup` con nombre no vacío y distinto de plantilla; sin nombre ⇒ `null`.
6. `SERVICIO_HIJO` si la clase es `RectangleContainerBlock` (todo contenedor hijo, no solo el principal).
7. `SERVICIO` si el título empieza por `ms-`, `ms_`, `ms ` o `msCamelCase`.
8. `FLUJO` / `CAPA` si el nombre empieza por "Flujo Transaccional" / "Capa de Arquitectura" (insensible a tildes y mayúsculas).
9. `MODELO` si el nombre contiene "modelo" (texto libre).
10. `null`.

Sonda sintética (scratchpad, página con INTEGRACIÓN y DOMINIO PRODUCTOR):

| Componente | `architecturalType` | `role` |
|---|---|---|
| API principal con camino `None→Arrow` hacia un evento de un hijo en productor | `API` | `PRINCIPAL` |
| Segunda `UMLClassBlock` de tercera sección `partner - entidad` | `null` | `null` |
| `UMLClassBlock` "Aplicacion - Event" (evento de integración) | `null` | `null` |
| `UMLClassBlock` "Federado" | `null` | `null` |
| Servicio `ms-billing` con un solo sentido comando→servicio | `SERVICIO` | `INVOCADO` |
| El mismo servicio con **ambos** sentidos (patrón COM-003) | `SERVICIO` | **`null`** |
| `BPMNEvent` sin `customData` en el camino | `EVENTO` | `null`; escenario `E1`/`HIPOTESIS`, `subtypeStatus: NO_VERIFICABLE` |
| `BPMNGateway`, `BPMNActivity` | `null` | `null` |

Las clases de Capa y Flujo usadas en la sonda son supuestas (`UMLClassBlock`); en los diagramas reales pueden ser otras. Confirmar con exportaciones reales (D-05).

## 3. Mapa por familia (detalle por regla en `02-matriz-reglas.csv`)

| Familia | Evidencia exigida | Campos principales | Disponibilidad | Principal límite |
|---|---|---|---|---|
| CNT-001/002 | Patrón E1/E2/E3, dominios, hijo único con nombre | `scenario`, `components[].architecturalDomain/role/name` | DERIVADA | Patrón solo si `scenario.status≠NO_DETERMINADO`; dominios personalizados (G-7); "no existe/más de uno" indistinguibles |
| CNT-003/004/005, EXT-001 | Clasificación de cada componente por nivel | `structuralParent`, `containerChainIds`, `lucidchartType`, `architecturalType`, `containedComponentIds` | AMBIGUA | Concepto, pendiente, anotación, política, evento de integración y capa Federado no tienen tipo (G-3) |
| EXT-002 | Auxiliar EVC/EPC/LDC + API encapsulada + ubicación | `name`, `containedComponentIds`, `architecturalType` | DERIVADA | API encapsulada no principal sin tipo (G-1) |
| GW-001 | Texto de compuerta y etiquetas de caminos | `lucidchartType=BPMNGateway`, `pages[].connections[].textAreas` | DIRECTA | Juicio semántico de coherencia |
| API-001..003 | Primera/segunda/tercera sección + dominio | `name`, `operation`, `textAreas`, `architecturalDomain` | DERIVADA solo para la principal | G-1; formato determinista salvo inglés y "palabra significativa" |
| API-004, SRV-004 | MCI declarado + Capa/Flujo asociados | respuesta de la analista, `deploymentAssociations` | DECLARADA + DERIVADA | G-5 |
| SRV-001..003 | Texto de servicios invocados | `name`, `operation`, `textAreas` | AMBIGUA | G-1, G-2; SRV-001/002 sin criterio |
| EVT-001..003 | Texto del evento de integración | `name`, `operation`, `textAreas` | AMBIGUA | G-3 |
| EVT-004..006 | Capa de Tópicos, tópicos, p/s | `groups`, `structuralParent`, `name` | AMBIGUA / DIRECTA (nombre) | G-3; EVT-006 es regex |
| EVT-007, MQ-003 (Mensaje) | Subtipo BPMN + conexiones | `customData`, `connections` | NO_DISPONIBLE | G-4 |
| CA-001, FT-001 | Nombre de Capa/Flujo | `architecturalType`, `name` | DERIVADA | G-6 |
| E1/E2/E3-001 | Participantes, dominios, Inicio, `None→Arrow` | `scenario.*`, `components[].containerChainIds` | DERIVADA; Inicio NO_DISPONIBLE sin `customData` | G-4, D-10, D-24 |
| MOD-001 | Modelos ENTRADA/SALIDA y asociación | `customData`, `groups`, `textAreas` | DERIVADA / AMBIGUA | Reconocimiento y asociación (D-19) |
| COM-001..005 | Comando = `BPMNActivity` con conexión; bidireccional `CircleOpen→Generalization` | `lucidchartType`, `connections`, `architecturalType` | DIRECTA (gestor) / AMBIGUA (API, servicio) | G-1, G-2, D-18 |
| MQ-001..002 | Gestor `UMLActiveClassBlock`, nombre, capa de despliegue | `lucidchartType`, `deploymentAssociations` | DIRECTA / DERIVADA | G-5 |

## 4. Condiciones que impiden certificar (aplican a todas las reglas)

- Campo ausente, `null`, `possibleDomainRoles` no vacío, `status` distinto de `RESOLVED` o `conflicts` no vacío: no es evidencia positiva.
- `issues` con `CONTAINMENT_CYCLE`, `DIRECT_PARENT_CONFLICT`, `DUPLICATE_ID` o `MISSING_ID` sobre un componente o su cadena: las reglas que dependan de él son `No verificable` (00 §2 de la analista; falta la tabla issue→regla, D-22).
- `metadata.omittedPages`: páginas no evaluadas; las respuestas de la analista no se trasladan sin confirmación.
- `nonNormative: true` y `normativeEvaluation: null`: el JSON nunca trae dictamen.
