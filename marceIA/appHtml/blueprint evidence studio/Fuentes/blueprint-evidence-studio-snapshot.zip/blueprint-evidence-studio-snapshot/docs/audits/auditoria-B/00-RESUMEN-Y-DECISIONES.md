# Blueprint Evidence Studio — Auditoría de consolidación normativa (iteración 1)

Fecha: 2026-10-26. Alcance: solo auditoría. No se modificó la Skill, el motor, el contrato ni las reglas; no hay commit, push ni PR. Los archivos de esta carpeta están en el scratchpad, fuera del repositorio.

## 1. Conclusión

1. **Los tres ZIP no son tres versiones de una misma línea.** Son dos linajes con la misma etiqueta "v11.2.2":
   - **Analista (v11.2.2):** 37 reglas, redactadas por completo (criterio, evidencia mínima, cuatro estados). Es la base normativa.
   - **Técnico (v11.2.2-codex y v11.2.3):** 41 reglas con cuerpo compacto genérico ("evidencia suficiente y criterio satisfecho"). Los cuerpos de las 41 reglas son idénticos entre codex y v11.2.3 (solo cambia el encabezado). v11.2.3 añade procedimiento, no normativa.
2. **El paquete de la analista está inconsistente.** Declara 37 reglas, pero conserva referencias a 41 y no tiene versión asignada:
   - `catalogo-reglas-v11.2.csv` es el catálogo histórico de 41. El MANIFEST pide `catalogo-reglas-vigente.csv`, que no existe.
   - `INSTRUCCIONES-AGENTE-V11.md` exige "41 filas" y `CONTRATO-COMPACTO.md` dice "una página requiere 41 filas".
   - Los encabezados de las reglas dicen v11.2.1, y su propio MANIFEST lo declara "revisión en curso".
   - SRV-001 y SRV-002 siguen en esqueleto, con texto idéntico al de 41.
3. **La normativa de la analista no se puede verificar de punta a punta con el contrato actual.** Leí el motor v0.4.6.1 y lo comprobé con sondas sintéticas, que no son blueprints reales. Hay siete brechas estructurales (§3). Sin cerrarlas, casi todas las reglas de población "invocadas" y las de eventos de integración, tópicos y subtipos BPMN dan `No verificable` por construcción, no por falta de datos en el diagrama.
4. **Hay decisiones que solo la analista puede tomar.** Son 24 (§4). No resolví ninguna. D-03, D-05 y D-06 afectan a 28 de las 37 reglas.

## 2. Números

| Concepto | Valor |
|---|---|
| Reglas analista | 37 (32 modificadas, 3 nuevas, 2 sin cambios) |
| Reglas del catálogo histórico | 41 → 34 sobreviven, 7 se retiran o fusionan |
| Retiradas o absorbidas | CNT-006, EXT-002 (antigua), EVT-004 (antigua), CA-002, FT-002, MQ-002 (antigua), MQ-003+MQ-004 (fusionadas) |
| Nuevas | EXT-002 (EVC/EPC/LDC), SRV-004, COM-005 |
| IDs que cambian de significado | EXT-002, EVT-004, EVT-005, EVT-006, EVT-007, MQ-002, MQ-003 (riesgo de trazabilidad) |

## 3. Brechas estructurales con Evidence Studio (verificadas)

Cada brecha se comprobó leyendo `src/` y con una sonda sintética. Faltan blueprints reales para confirmar frecuencia e impacto.

| # | Brecha | Efecto | Decisión |
|---|---|---|---|
| G-1 | `architecturalType: API` solo se emite para la API **principal** (inferida por el camino hacia el evento). Una API invocada es `UMLClassBlock` sin tipo; un servicio solo se tipa por prefijo `ms`. | API-001..003, SRV-001..003, EXT-002, COM-002/003 y MQ-003 sobre componentes no principales: `No verificable` | D-03 |
| G-2 | `role: INVOCADO` exige conexiones entrantes **y ninguna saliente**. El patrón bidireccional de COM-002/003 (comando↔componente) siempre crea una saliente. Sonda: con un sentido, `INVOCADO`; con ambos, `null`. | "Servicio/API invocado" nunca se certifica en el patrón que la analista exige | D-04 |
| G-3 | `architecturalType: EVENTO` es la figura `BPMNEvent`. No existe tipo para "evento de integración" (`UMLClassBlock` con tercera sección `Aplicacion - Event`), ni para Capa de Tópicos, tópicos, Federado, conceptos, pendientes, anotaciones o políticas. La MATRIZ-37 apunta EVT-001..003 a `architecturalType`, que es el campo equivocado. | EVT-001..006, CNT-003/004/005, MOD-001 (eventos): `No verificable` | D-03, D-05 |
| G-4 | El catálogo de subtipos BPMN (`PROPOSED_CLOSED_CATALOG`) contiene START/INICIO, END/FIN, SIGNAL/SENAL, RECEIVE/RECEPCION y EXCEPTION. No tiene **Mensaje** ni distingue **Señal de Envío**. Además solo se interpreta en el evento del escenario, no en los demás `BPMNEvent`. | EVT-007 y MQ-003 (Mensaje): `No verificable` siempre. E1/E2/E3-001: `Cumple` solo si el diagrama trae `customData` con tipo START | D-06 |
| G-5 | `deploymentAssociations` solo publica **pares Flujo+Capa**. Una Capa sin Flujo (API `partner`), el literal `Federado` y la asociación de contenedores hijo por grupos no se publican. | API-004 (partner), MQ-002 (Federada), SRV-004 (por grupos): `Cumple` inalcanzable | D-14, EC-04 |
| G-6 | Capa y Flujo se reconocen por el **prefijo del nombre** ("Capa de Arquitectura…", "Flujo Transaccional…"). Una figura mal nombrada no se reconoce como Capa. | CA-001 y FT-001 solo pueden dar `No cumple` por el tipo, no por un nombre mal escrito (circular) | D-05 |
| G-7 | La CNT-001 de la analista admite dominios con nombre personalizado. El motor solo reconoce por nombre exacto `INTEGRACION`, `SISTEMA(S) EXTERNO(S)` y `DOMINIO PRODUCTOR`; por `customData` solo reconoce el valor `PRODUCER`. Un INTEGRACIÓN o SISTEMAS EXTERNOS con otro nombre queda `NO_DETERMINADO`. | CNT-001..005, E1/E2/E3 y todas las reglas por modalidad de dominio: `No verificable` | D-05 |

## 4. Decisiones y preguntas para la analista

Formato: decisión → alternativas → recomendación. Ninguna está resuelta; el agente no debe resolverlas por iniciativa propia.

| ID | Tema | Alternativas | Recomendación |
|---|---|---|---|
| **D-01** | Inventario base | (a) 37 de la analista como base, 41 como histórico con tabla de alias; (b) mantener 41 | (a). Asignar versión nueva solo tras cerrar D-02, y limpiar las referencias a 41 |
| **D-02** | SRV-001/SRV-002: criterio definitivo y población ("principal e invocados": ¿incluye hijo principal y el servicio principal de E3?) | Definir formato de nombre (¿prefijo `ms` obligatorio o convencional?), versión opcional/obligatoria, idioma y capitalización de la operación; delimitar población | Pedir el texto final. Hasta entonces, evaluar `No verificable` con el faltante nombrado |
| **D-03** | Cómo se certifica API vs servicio vs evento de integración en un `UMLClassBlock` no principal | (A) la analista declara el tipo por componente (la regla actual dice que una declaración no corrige el tipo arquitectónico); (B) criterio por tercera sección (`private/public/partner` ⇒ API; `entidad/utilidad/tarea` solos ⇒ servicio; `Aplicacion/Empresarial - …` ⇒ evento); (C) por prefijo/ubicación | (B), como regla normativa explícita. Con (B), una API con tercera sección malformada se tipifica como servicio y API-003 jamás da `No cumple`: la analista debe aceptar ese límite o añadir un segundo discriminador. (B) además obliga a levantar expresamente la restricción de `GUIA-TEXTAREAS.md` ("Entidad/Private… no demuestran tipo") y la decisión técnica "no interpretar texto libre como certificación" |
| **D-04** | Definición de `INVOCADO` | (a) la analista define "invocado" por relación con un comando (no por sentido único); (b) mantener y aceptar `No verificable` | (a), con cambio en el motor (EC-01) |
| **D-05** | Catálogo "figura → cómo se reconoce": Capa de Arquitectura, Flujo, Capa de Tópicos, tópico, Federado, modelo ENTRADA/SALIDA, concepto, pendiente, anotación, política | Reconocer por clase Lucidchart, por prefijo de nombre o por `customData` | Necesito JSON reales para proponer. Pedir a la analista una tabla de 10 filas |
| **D-06** | Subtipos BPMN: Inicio, Señal de Envío, Señal de Recepción, Mensaje | (a) convención `customData` explícita en los diagramas (ampliar el catálogo con MESSAGE y SIGNAL_SEND/SIGNAL_RECEIVE); (b) otro mecanismo de la herramienta de dibujo; (c) aceptar `No verificable` permanente | (a) si el estándar corporativo ya exige `customData`. Preguntar si los diagramas reales lo traen |
| **D-07** | Páginas plantilla/leyenda | La analista: `No aplica` por regla (CNT-001/002 y E1..E3). El técnico: página excluida sin filas | Conservar la clasificación técnica como paso previo y, dentro de páginas evaluables, usar el `No aplica` de la analista. Confirmar |
| **D-08** | Condición de `No aplica` | El principio técnico v11.2.2 ("la ausencia de una figura no basta") frente al texto de la analista ("la página no contiene X ni candidatos") | Son compatibles si se exige inventario con cobertura completa y sin candidatos. Confirmar y escribirlo una sola vez en el procedimiento |
| **D-09** | "Gestionado / no gestionado" (F-13) | El texto de la analista lo elimina (CNT-002 dice expresamente que no se evalúa) | Tratarlo como retirado por la analista; confirmar |
| **D-10** | Conexión de E1/E2/E3 | El texto exige API→evento con `None`/`Arrow`. ¿Debe terminar en la API y en el `BPMNEvent` mismos (sin Capa/grupo/auxiliar intermedio)? Cierra la decisión técnica pendiente "directa frente a declarada" | Tratarla como directa; confirmar |
| **D-11** | ¿Un DOMINIO PRODUCTOR inferido por estructura (`INFERRED_BY_OPERATION_STRUCTURE`) cuenta como "clasificación certificada"? | Sí con procedencia citada / solo por nombre reservado o `customData` | Riesgo de circularidad: el patrón E1 confirma un dominio que se dedujo del mismo patrón. Decidir expresamente |
| **D-12** | Criterios subjetivos ("específico", "genérico", "plantilla", "palabra significativa", "idioma inglés", "verbo en infinitivo", "coherente") | Listas cerradas aprobadas (el motor ya tiene una de plantillas); o marcar el juicio como "evaluado por el agente con justificación" | Lista cerrada de plantillas y de términos genéricos; el resto, `No verificable` si no hay certeza |
| **D-13** | Cascada EVT-004 → EVT-005/006/007 | Una Capa de Tópicos ausente da `No cumple` en EVT-004 y `No verificable` en las otras tres: un fallo cuenta cuatro veces en el denominador | Confirmar que es intencional |
| **D-14** | MQ-002: ¿se mantiene sin pregunta MCI al analista (en 41 sí existía)? ¿Cómo se asocia el literal `Federado` a un gestor? | Por contención directa, por grupo o por declaración | Definir con D-05 |
| **D-15** | EXT-001: auxiliar sin nombre y auxiliar sin contenido | Hoy "sin contenido" cae en `No verificable` y "sin nombre" no se reconoce como auxiliar | Definir qué evidencia certifica un `BPMNGroup` sin nombre como auxiliar |
| **D-16** | EXT-002: "nombre contenga EVC, EPC o LDC" | Subcadena (falsos positivos tipo "Pepco") o palabra completa. Además el criterio se autorreferencia | Palabra completa; corregir la referencia |
| **D-17** | SRV-003 acepta cualquier capitalización; API-003 exige minúsculas para los mismos valores | ¿Intencional? | Confirmar |
| **D-18** | COM: definición de "relación" que vuelve candidata a una `BPMNActivity`; "atribución inequívoca" en COM-005; solapamiento BPMNActivity comando/modelo | Relación = conexión (no grupo). En 41, un único candidato permitía atribuir | Relación = conexión directa; definir "inequívoca" |
| **D-19** | MOD-001: reconocimiento de modelo ENTRADA/SALIDA | `customData` literal (hoy) o nombre "MODELO" (hoy, texto libre) | Solo `customData` literal; el nombre no certifica |
| **D-20** | Un resultado por regla y página, o detalle por componente | Mantener un resultado agregado (pocos fallos tapan muchos cumplidos) | Mantener el agregado y exigir detalle por componente en la justificación |
| **D-21** | SRV-004 trata al hijo principal como "servicio principal"; la decisión técnica dice `SERVICIO_HIJO` ≠ `SERVICIO` | Aceptar equivalencia solo para SRV-004 | Confirmar el alcance |
| **D-22** | Controles de integridad (00 §2): ¿qué `issues` afectan a qué reglas? Además, "cobertura completa/suficiente" se usa en casi todas las reglas y no está definida en ningún archivo | Tabla `issue.code → reglas` y definición operativa de cobertura (p. ej. `issues` sin entradas que toquen los componentes implicados y `counts` coherentes con el inventario) | Redactarla en la Skill; la propone el técnico y la aprueba la analista |
| **D-23** | Reversiones respecto de decisiones previas (informativo): EVT-001 guion bajo obligatorio (antes opcional), EVT-002 camelCase (antes PascalCase), EVT-003 sin tildes (antes tolerancia); EXT-001 y CNT-005 ya no admiten evento ni gestor en un auxiliar o en SISTEMAS EXTERNOS (antes sí), con lo que un gestor externo no tiene ubicación válida | Conservar como decididas por la analista | Registrar como reversiones aprobadas; confirmar que no son erratas |
| **D-24** | Contradicción interna en E1/E2/E3-001: el procedimiento (00 §8) dice que un incumplimiento certificado prevalece, pero `No cumple` de cada regla exige también el subtipo Inicio certificado | ¿Un API fuera de INTEGRACIÓN con Inicio sin certificar es `No cumple` o `No verificable`? | `No cumple` (coherente con 00 §8 y con "la incertidumbre afecta solo a lo que depende de ella"); confirmar |

## 5. Decisiones técnicas previas (Fase 6)

Todas se conservan. Cambios o tensiones:

| Decisión previa | Estado |
|---|---|
| Cuatro estados; HIPOTESIS/CONFIRMADO no son estados | Conservada y refrendada por la analista (00 §8–9) |
| `No cumple` exige evidencia suficiente; `No verificable` = insuficiente | Conservada; la analista añade la prioridad `No cumple` > `No verificable` |
| `SERVICIO_HIJO` ≠ `SERVICIO`; `HIJO_PRINCIPAL` ≠ `INVOCADO` | Conservada. Tensión menor: SRV-004 usa "hijo principal = servicio principal" (D-21) |
| No inferir sistemas externos por descarte | Sin cambio |
| Padre, ancestros, dominio y grupo distintos; grupo ≠ contención | Sin cambio |
| Preguntar MCI y exposición; registrar como DECLARADO_POR_ANALISTA; reutilizar con confirmación | Conservada. **Cambia:** desaparece la pregunta MCI del gestor (MQ) |
| No confundir ausencia de figura con No aplica | **Tensión** con los textos de `No aplica` de la analista (D-08) |
| No inventar subtipos BPMN; texto libre no certifica | Conservada y reforzada en E1/E2/E3, EVT-007, MQ-003 |
| No ampliar poblaciones por analogía | Conservada; choca con la población indefinida de SRV (D-02) |
| Página plantilla/leyenda fuera de las filas | **Contradicción** con el `No aplica` de la analista (D-07) |
| Criterio operativo de CNT-006 | **Obsoleto**: la regla se retira |
| `UMLActiveClassBlock` ↔ `GESTOR_COLAS` como convención técnica | **Promovida a norma** por MQ-001 |

## 6. Qué no pude revisar

No estaban disponibles en el repositorio ni entre los adjuntos: `AGENTS.md`, `PROJECT_CONTEXT_2026-10-26.md`, `RULE_EVIDENCE_MATRIX_v11.2.md`, las auditorías normativas y las comparaciones anteriores. Tampoco hay blueprints reales (el repositorio solo tiene fixtures sintéticos). Por eso:

- La clasificación de ambigüedades históricas se apoya en el texto de las reglas y en las notas técnicas de v11.2.x, no en las auditorías originales.
- Las conclusiones sobre disponibilidad de evidencia vienen de leer el motor y de sondas sintéticas, no de diagramas reales. Antes de modificar el motor hay que repetirlas sobre exportaciones reales.

## 7. Siguiente paso propuesto

1. Aprobar o corregir la línea base (D-01) y responder primero D-03, D-05 y D-06, porque afectan a 28 de las 37 reglas.
2. Entregar 2–3 exportaciones reales (anonimizadas) de páginas E1, E2 y E3 para confirmar las brechas G-1..G-6.
3. Con las respuestas, redactar la Iteración 2: catálogo canónico de 37 reglas con los 17 atributos (esquema y ejemplo en `05`), sin tocar el motor.

## Archivos de esta entrega

| Archivo | Contenido |
|---|---|
| `00-RESUMEN-Y-DECISIONES.md` | Este documento |
| `01-comparacion-zips.md` | Entregables 1, 2 y 7: comparación de ZIP, tabla de cambios, redundancias |
| `02-matriz-reglas.csv` | Entregables 2, 4 y 5: una fila por regla (37) con origen, cambio, campos JSON, disponibilidad y brechas |
| `03-mapa-regla-evidencia-json.md` | Entregable 4: hechos del contrato v0.4.6.1 y mapa por familia |
| `04-ambiguedades-historicas.md` | Entregable 5: estado de cada ambigüedad de la Fase 7 |
| `05-skill-cambios-y-plan.md` | Entregables 3, 6, 8, 9 y 10: esquema de regla, arquitectura de la Skill, cambios al motor y plan |
| `06-pruebas-aceptacion.csv` | Fase 9: casos mínimos por regla |
