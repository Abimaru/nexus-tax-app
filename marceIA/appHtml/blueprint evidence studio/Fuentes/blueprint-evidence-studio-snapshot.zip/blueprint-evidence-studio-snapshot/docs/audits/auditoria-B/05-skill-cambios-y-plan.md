# 05 — Esquema de regla, arquitectura de la Skill, cambios al motor y plan

Cubre los entregables 3, 6, 8, 9 y 10. Es una propuesta para aprobar; nada de esto está aplicado.

## 1. Propuesta de normativa consolidada (entregable 3)

### 1.1 Qué se propone y qué no

Propongo **no redactar todavía** la normativa consolidada de las 37 reglas. Redactarla ahora obligaría a decidir los puntos D-02..D-24 por cuenta propia. Lo que sí propongo aprobar es:

1. La **base**: las 37 reglas de la analista, textos tal cual, sin alterar criterios.
2. El **esquema canónico** de cada regla (17 atributos, §1.2).
3. El **catálogo de decisiones pendientes** (`00`, §4), que se cierra antes de redactar.

### 1.2 Esquema canónico (Fase 3)

Una única fuente por regla, con estos campos. Los que dicen "(analista)" se copian del texto vigente; los demás se redactan solo con aprobación.

| # | Campo | Origen | Cobertura actual en el texto de la analista (37 reglas) |
|---|---|---|---|
| 1 | `id` | analista | 37/37 |
| 2 | `nombre` | analista | 37/37 |
| 3 | `objetivo` | analista ("Resumen oficial") | 37/37 |
| 4 | `poblacion` | analista ("Aplica a") | 37/37; en SRV-001/002 sin delimitar |
| 5 | `condiciones_aplicabilidad` | analista (dispersas en Criterio y No aplica) | Parcial: hay que extraerlas |
| 6 | `evidencia_minima` | analista | 37/37 |
| 7 | `criterio_cumple` | analista | 35/37 (SRV-001/002 genérico) |
| 8 | `criterio_no_cumple` | analista | 35/37 |
| 9 | `criterio_no_verificable` | analista | 35/37 |
| 10 | `criterio_no_aplica` | analista | 35/37; EVT-005/006/007 lo mezclan con `No verificable` (I-7) |
| 11 | `campos_json` | técnico, validado | `MATRIZ-37` lo da, con errores (EVT-001..003 apuntan a `architecturalType`) |
| 12 | `preguntas_analista` | analista | Solo API-004 y SRV-004 (MCI) y la exposición opcional; faltan los faltantes por regla |
| 13 | `evidencia_contradictoria` | analista | Explícita en 23/37 ("prevalece No cumple"); en las otras 14 depende de 00 §8 |
| 14 | `dependencias` | técnico, validado | Implícitas; hay que declararlas (§2 de `01`) |
| 15 | `ejemplo_positivo` | técnico, sintético, aprobado | 0/37 |
| 16 | `ejemplo_negativo` | ídem | 0/37 |
| 17 | `ejemplo_insuficiente` | ídem | 0/37 |

Adicionales de trazabilidad: `id_anterior`, `alias_historico`, `decision_origen` (D-xx o fecha de la analista), `estado_redaccion` (completa, esqueleto, pendiente).

### 1.3 Reglas de redacción

- Toda expresión de la lista de la Fase 3 ("cuando corresponda", "según el escenario", "cuando aplique", "si está bien definido", "debe estar correctamente relacionado") debe llevar su condición verificable. Auditoría del texto de la analista: "según el escenario", "cuando aplique", "bien definido" y "correctamente relacionado" **no aparecen**. "Cuando corresponda" aparece 2 veces, ambas en API-004 y SRV-004, acompañada de una condición explícita (MCI declarado), así que son aceptables. Los términos que sí requieren listas cerradas son "específico" (34 apariciones), "genérico" (37), "plantilla" (36), "funcional" (20) e "inequívoca/o" (30). Detalle en D-12.
- No se introduce ninguna condición nueva. Todo vacío se registra como decisión pendiente, con alternativas.
- Un ejemplo no es norma: se etiqueta "ilustrativo" y se deriva solo de los criterios aprobados.

### 1.4 Ejemplo del formato (ilustrativo, sin criterio nuevo): API-004

| Campo | Contenido |
|---|---|
| Población | API principal con tipo y rol certificados, declarada MCI |
| Cumple | `private` con Capa y Flujo asociados; `partner` con Capa asociada; `public` |
| No cumple | Cobertura certificada y falta Capa o Flujo según la exposición |
| No verificable | API principal no certificada; falta la declaración MCI; exposición indeterminada; Capa/Flujo candidato sin asociación demostrada |
| No aplica | API principal declarada no MCI; componente invocado; sin API principal ni candidatos |
| Preguntas | MCI de la API principal (obligatoria); exposición (opcional, solo si falta) |
| Campos | `role`, `architecturalType`, `textAreas`, `deploymentAssociations` |
| Dependencia | API-003 (exposición); CA-001 y FT-001 (nombre) |
| Vacío | `partner` y Capa sin Flujo no se publican en `deploymentAssociations` (G-5) |
| Ejemplos | Positivo: `private` MCI con Capa+Flujo asociados por contención. Negativo: `private` MCI con Capa y sin Flujo, con cobertura completa. Insuficiente: Capa a la vista pero sin asociación demostrable (solo cercanía) |

## 2. Recomendaciones de simplificación (entregable 6)

1. **Una sola fuente por regla.** Hoy el contenido vive en 7 archivos `.md`, un CSV, la matriz, el SKILL y las instrucciones. En el paquete de la analista ya divergen (37/41).
2. **Generar, no copiar.** Matriz, CSV y resumen por familia se generan desde el catálogo. Eliminar la edición manual de `MATRIZ-EVIDENCIA-37.md`.
3. **Definir una vez** (en el procedimiento): prioridad de estados, formato de resultado, "cobertura completa" (hoy indefinida, D-22), lista cerrada de "plantilla" y "genérico" (D-12), patrón bidireccional `CircleOpen→Generalization` (COM-002..005, MQ-003) y condición de Inicio (E1/E2/E3).
4. **Eliminar los `No aplica` con contenido ajeno** (EVT-005/006/007) y la autorreferencia de EXT-002.
5. **Declarar dependencias** (EVT-004 → EVT-005/006/007; COM-001 → COM-002..005; API-003 → API-004) para que el agente no recalcule el motivo en cada fila.
6. **No consolidar reglas** salvo decisión expresa. No hay duplicación demostrable (`01`, §5); la simplificación es de redacción, no de inventario.
7. **Sellar la nomenclatura de versiones**: versión normativa (analista) separada de versión de procedimiento/contrato (técnica).

## 3. Reglas candidatas a consolidación (entregable 7)

Ninguna se propone para eliminar o fusionar (no hay equivalencia normativa demostrable). Candidatas a **plantilla compartida** conservando los IDs: CNT-003/004/005; COM-002/003/004/005; E1/E2/E3-001. Detalle en `01`, §5.

## 4. Arquitectura propuesta de la Skill (entregable 8)

Principio: cada hecho normativo tiene una sola fuente; las instrucciones del agente referencian IDs y no repiten criterios.

```
validar-blueprint-integracion/
├── SKILL.md                         # entrada breve: qué leer, en qué orden
└── references/
    ├── A-catalogo/                  # A. Catálogo normativo único
    │   ├── reglas.yaml              #    37 reglas con el esquema de 17 campos (fuente canónica)
    │   └── id-historico.csv         #    41 → 37, alias, retiradas
    ├── B-procedimiento.md           # B. Cómo se evalúa: precedencia, estados, prioridad,
    │                                #    cobertura, páginas no evaluables, fórmula, integridad
    ├── C-contrato-evidencia.md      # C. Diccionario del contrato + clase de disponibilidad
    │                                #    por campo + catálogo "figura → cómo se reconoce"
    ├── D-matriz-regla-campo.csv     # D. GENERADA desde A y C (no se edita a mano)
    ├── E-preguntas-analista.md      # E. Preguntas (MCI, exposición, faltantes por regla),
    │                                #    registro DECLARADO_POR_ANALISTA y reutilización
    ├── F-ejemplos/                  # F. Ejemplos sintéticos por regla (positivo, negativo,
    │                                #    insuficiente) + batería de aceptación
    └── G-control/                   # G. Versiones, decisiones D-xx, changelog, hashes
        ├── VERSION.md
        ├── decisiones.md
        └── CHANGELOG.md
```

Controles automáticos (script en el espacio privado, no en `main`):

1. Exactamente N IDs activos, únicos, y la misma lista en A, D y los ejemplos.
2. Los cuatro estados como únicos valores; sin referencias a "41" ni a IDs retirados fuera de `id-historico.csv`.
3. Cada referencia `ID` en B, C o E existe en A.
4. Lint de frases de la Fase 3 (lista cerrada) y de términos subjetivos sin lista asociada.
5. Hash de A registrado en `VERSION.md`; D regenerada y comparada.

Restricción vigente (HANDOFF): la Skill, la normativa y las auditorías permanecen fuera de `main`. Esta arquitectura vive en el espacio privado de trabajo.

## 5. Cambios necesarios en Evidence Studio (entregable 9)

Principio: priorizar campos existentes; todo cambio de motor espera a que la analista cierre su decisión. **Ninguno se aplica en esta fase.**

| ID | Cambio | Causa | Tipo | Requiere decisión | Alternativa sin tocar el motor |
|---|---|---|---|---|---|
| EC-01 | Redefinir `role: INVOCADO` para que no exija "ninguna conexión saliente" (por ejemplo, basta con tener relación con un comando o gestor y no ser principal) | G-2 | Cambio de comportamiento de un campo publicado | D-04 | Ninguna: el patrón bidireccional impide el rol |
| EC-02 | Ampliar el catálogo de subtipos con Mensaje y con Señal de Envío/Recepción, e interpretarlo en **todos** los `BPMNEvent`; publicar `components[].bpmnEvent{subtype,subtypeStatus,evidence}` | G-4 | Campo aditivo | D-06 | Documentar el catálogo en la Skill y que el agente lea `customData` literal (menos determinista) |
| EC-03 | Publicar el reconocimiento de figuras sin sobrecargar `EVENTO`: evento de integración, Capa de Tópicos, tópico, Federado, concepto, pendiente, anotación, política, modelo. Campo aditivo (`figureKind` con `source`) o nuevos valores de `architecturalType` | G-3 | Campo aditivo | D-03, D-05 | Reglas de lectura sobre `textAreas`/`lucidchartType` en la Skill (si la analista levanta la restricción de `GUIA-TEXTAREAS.md`) |
| EC-04 | Publicar asociaciones de **Capa sin Flujo**, del literal `Federado`, y de contenedor hijo por grupos | G-5 | Aditivo | D-14 | Ninguna fiable |
| EC-05 | Aceptar `customData` de dominio para INTEGRATION y EXTERNAL_SYSTEM (hoy solo PRODUCER) | G-7 | Cambio de comportamiento | D-05, D-11 | Exigir nombres reservados exactos |
| EC-06 | Clasificar API/servicio/evento en `UMLClassBlock` no principales según la decisión D-03 | G-1 | Depende de la opción | D-03 | Pregunta por componente a la analista (no certifica tipo según la regla actual) |
| EC-07 | Reconocer `BPMNGroup` sin nombre como auxiliar sin nombre | D-15 | Cambio de comportamiento | D-15 | `lucidchartType` ya lo permite leer |
| EC-08 | Actualizar `SKILL_VERSION` (`src/version.js` dice `11.2.1`; la candidata es 11.2.3) | Desfase de metadatos | Trivial | No | — |
| EC-09 | (Interfaz) Capturar y exportar las respuestas `DECLARADO_POR_ANALISTA` (MCI, exposición, tipo declarado) fuera del JSON compacto | Preguntas por regla | Interfaz | Opcional | Capturarlas en el chat del agente |
| EC-10 | (Documental) Tabla `issue.code → reglas` y definición de cobertura | D-22 | Skill, no motor | D-22 | — |

Reglas de versionado propuestas: los cambios aditivos suben el contrato (`copilot-factual-v0.5.0`) y requieren regenerar el snapshot; los de comportamiento (EC-01, EC-05, EC-07) también, con nota de ruptura. Versión del contrato actual: `copilot-factual-v0.4.6.1` sin cambios hasta aprobación.

## 6. Pruebas de aceptación (Fase 9)

- `06-pruebas-aceptacion.csv`: una fila por regla (37) con casos mínimos derivados del texto de la analista, escenarios a cubrir y decisión que la bloquea.
- Principio de expectativas: se derivan **solo del texto normativo aprobado**, nunca de respuestas previas del agente. Cada fila de la batería final llevará: entrada sintética, estado esperado, cita del criterio que lo justifica.
- "No forzar los cuatro estados": las 37 reglas tienen, en el texto, los cuatro estados definidos. La imposibilidad es de **evidencia hoy** (columna "estados alcanzables hoy" en `02`), no normativa; esas pruebas quedan marcadas "bloqueada por D-xx" en vez de eliminar el caso.
- Cobertura transversal: población vacía; información declarada vs derivada; evidencia contradictoria (conflictos en `issues`, `possibleDomainRoles` no vacío, `status` distinto de `RESOLVED`); E1, E2 y E3; página plantilla y página mixta.
- Fixtures: solo sintéticos y anonimizados (política vigente del repositorio).

## 7. Plan de implementación y regresión (entregable 10)

| Fase | Contenido | Puerta de salida |
|---|---|---|
| 0 (esta) | Auditoría, decisiones D-01..D-24, brechas G-1..G-7 | Aprobación de la analista de la base (D-01) |
| 1 | Cerrar D-03, D-05, D-06 con 2–3 exportaciones reales anonimizadas; confirmar G-1..G-7 | Cada brecha confirmada o descartada con evidencia |
| 2 | Cerrar D-02 y las decisiones restantes. Redactar catálogo canónico (A), procedimiento (B), contrato (C) y preguntas (E); generar D. Sin tocar el motor | Revisión completa de la analista; lint verde |
| 3 | Ejemplos sintéticos (F) y batería de aceptación derivada de la norma | Una prueba por regla, con expectativa citada |
| 4 | Cambios mínimos al motor (EC-xx aprobados), versión de contrato nueva | Regresión de §7.1 en verde |
| 5 | Ejecución de la batería con el agente; análisis de discrepancias (¿norma, contrato o agente?) | Informe de discrepancias sin resolver por iniciativa del agente |
| 6 | Versión estable de la Skill; sincronizar `SKILL_VERSION` | Aceptación de la analista; nota de versión |

### 7.1 Regresión del motor y la interfaz

- `npm test` (core, contract, e2e), `npm run audit`, `npm run build`, `npm run test:e2e`.
- Snapshot del contrato compacto sobre `presentation-panels.json`: hash vigente `e9aa2326…53ac`. Cada cambio de contrato regenera y justifica el nuevo hash.
- HTML distribuido: hash vigente `205CC88E…93F5`, sin URLs remotas.
- Pruebas nuevas: una por cada brecha cerrada (por ejemplo, `INVOCADO` con ambos sentidos de COM; subtipo Mensaje; Capa sin Flujo; dominio personalizado de INTEGRACIÓN).
- Los fixtures sintéticos existentes no cubren gestores, tópicos, comandos ni compuertas; hay que ampliarlos.
- La v0.4.7 de la interfaz sigue pendiente de aceptación visual y funcional (HANDOFF); no se mezcla con estos cambios.

## 8. Qué necesito para continuar

1. Aprobación o corrección de D-01 y respuesta a D-03, D-05 y D-06.
2. Dos o tres exportaciones reales anonimizadas (E1, E2, E3), o la confirmación de que puedo generar sintéticos equivalentes.
3. El texto final de SRV-001 y SRV-002.
4. `AGENTS.md`, `PROJECT_CONTEXT_2026-10-26.md`, `RULE_EVIDENCE_MATRIX_v11.2.md` y las auditorías previas, si deben pesar en las decisiones.
