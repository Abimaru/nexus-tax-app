# MATRIZ_COBERTURA_PROPUESTA (C-03, propuesta técnica)

> Propuesta, no incorporada como norma. No resuelve C-03.

## 1. Cobertura de población por regla (las 37)

Atributo independiente de la definición normativa y de la disponibilidad de evidencia. `COMPLETA` = toda la población normativa es certificable; `PRINCIPAL` = sólo el componente principal; `SUBPOBLACION` / `PARCIAL` = una parte; `NINGUNA` = ninguna parte.

| Regla | Cobertura | Detalle | Verificabilidad hoy |
|---|---|---|---|
| CNT-001 | PARCIAL | Patrón identificable sólo con la estructura E1–E3 completa; dominios por nombre reservado o rol certificado. | VERIFICABLE_PARCIAL |
| CNT-002 | PARCIAL | Nombre y dominio del hijo único certificables; «no existe» / «existe más de uno» / «dominio distinto» no se demuestran hoy (ver INVESTIGACION_CNT002). | VERIFICABLE_PARCIAL |
| CNT-003 | PARCIAL | Componentes con clase o nombre reservado identificable; el resto queda sin tipo. | VERIFICABLE_PARCIAL |
| CNT-004 | PARCIAL | Ídem CNT-003. | VERIFICABLE_PARCIAL |
| CNT-005 | PARCIAL | Ídem CNT-003; auxiliares por BPMNGroup con nombre. | VERIFICABLE_PARCIAL |
| EXT-001 | PARCIAL | Auxiliares (BPMNGroup con nombre); su contenido sólo por clase de figura. | VERIFICABLE_PARCIAL |
| EXT-002 | PARCIAL | Nombre EVC/EPC/LDC literal; la API encapsulada no es certificable (C-04). | VERIFICABLE_PARCIAL |
| GW-001 | COMPLETA | Todas las figuras BPMNGateway. | VERIFICABLE_HOY |
| API-001 | PRINCIPAL | Sólo la API principal; las invocadas no se certifican (C-04). | VERIFICABLE_PARCIAL |
| API-002 | PRINCIPAL | Ídem API-001. | VERIFICABLE_PARCIAL |
| API-003 | PRINCIPAL | Ídem API-001. | VERIFICABLE_PARCIAL |
| API-004 | COMPLETA | La población normativa es la API principal declarada MCI; completa para ella. | VERIFICABLE_HOY |
| SRV-001 | NINGUNA | Población sin delimitar (C-01). | PENDIENTE_NORMATIVO |
| SRV-002 | NINGUNA | Población sin delimitar (C-01). | PENDIENTE_NORMATIVO |
| SRV-003 | NINGUNA | El servicio invocado no es certificable (C-05). | CON_BRECHA |
| SRV-004 | COMPLETA | La población normativa es el hijo principal de E1/E2 declarado MCI. | VERIFICABLE_HOY |
| EVT-001 | NINGUNA | El evento de integración no es certificable (C-04/C-06). | CON_BRECHA |
| EVT-002 | NINGUNA | Ídem EVT-001. | CON_BRECHA |
| EVT-003 | NINGUNA | Ídem EVT-001. | CON_BRECHA |
| EVT-004 | NINGUNA | Ídem EVT-001; la Capa de Tópicos no se reconoce (C-06). | CON_BRECHA |
| EVT-005 | NINGUNA | Ídem EVT-004. | CON_BRECHA |
| EVT-006 | NINGUNA | Ídem EVT-004. | CON_BRECHA |
| EVT-007 | NINGUNA | Ídem EVT-004; además exige subtipo de evento (C-07). | CON_BRECHA |
| CA-001 | COMPLETA | Capas reconocidas por prefijo; una candidata con otro nombre no es detectable (afecta No aplica). | VERIFICABLE_HOY |
| FT-001 | COMPLETA | Flujos reconocidos por prefijo; una candidata con otro nombre no es detectable (afecta No aplica). | VERIFICABLE_HOY |
| E1-001 | NINGUNA | El subtipo Inicio no es certificable (C-07). | CON_BRECHA |
| E2-001 | NINGUNA | Ídem E1-001. | CON_BRECHA |
| E3-001 | NINGUNA | Ídem E1-001. | CON_BRECHA |
| MOD-001 | PARCIAL | Modelos por customData ENTRADA/SALIDA; la asociación a la API principal sólo por grupo único (C-13). | VERIFICABLE_PARCIAL |
| COM-001 | SUBPOBLACION | Comandos cuya relación con un componente certificado (gestor) es comprobable; relación sin definir (C-12). | VERIFICABLE_PARCIAL |
| COM-002 | NINGUNA | La API invocada no es certificable (C-04/C-05). | CON_BRECHA |
| COM-003 | NINGUNA | El servicio invocado no es certificable (C-05). | CON_BRECHA |
| COM-004 | SUBPOBLACION | Comandos relacionados con gestores certificados. | VERIFICABLE_PARCIAL |
| COM-005 | PARCIAL | Auxiliares con una sola conexión; «atribución inequívoca» sin definir (C-12). | VERIFICABLE_PARCIAL |
| MQ-001 | COMPLETA | Todas las figuras UMLActiveClassBlock; el criterio de plantilla depende de C-09. | VERIFICABLE_PARCIAL |
| MQ-002 | SUBPOBLACION | Modalidad MCI (Capa+Flujo por contención); `Federado` depende de C-06. | VERIFICABLE_PARCIAL |
| MQ-003 | SUBPOBLACION | Sólo gestor↔gestor; los participantes invocados no son certificables (C-05). | CON_BRECHA |

Regla de coherencia: una regla `VERIFICABLE_HOY` exige cobertura `COMPLETA`; cobertura `NINGUNA` implica `CON_BRECHA` o `PENDIENTE_NORMATIVO`. Ambas se verifican en `validate-iter31.mjs` (resultado en el informe de reconciliación).

## 2. Matriz ISSUE → EVIDENCIA AFECTADA → REGLAS AFECTADAS → IMPACTO

Códigos medidos en el motor con fixtures sintéticos.

| Issue (código) | Evidencia afectada | Reglas afectadas | Impacto |
|---|---|---|---|
| `DUPLICATE_ID` | todo componente con ese ID | todas las que lo evalúen | NV en las reglas del componente; no se elige cuál es el válido |
| `MISSING_ID` | figura sin ID | las que la requieren | NV; la figura no puede referenciarse |
| `MISSING_REFERENCE` (sin `code`) | contención `contains` hacia ID inexistente | CNT-001/003/004/005, API-004, SRV-004, MQ-002 | NV de contención; ausencia no demostrable |
| `CONTAINMENT_CYCLE` | padres y ancestros | las de contención y asociación | NV |
| `DIRECT_PARENT_CONFLICT` | padre inmediato | CNT-003/004/005, EXT-001 | NV; prohíbe NC por contención |
| `MALFORMED_CUSTOM_DATA(_ENTRY)` | customData | MOD-001, E1-3, dominio por rol | NV; no certifica subtipo ni rol |
| `ROLE_UNRESOLVED_RESERVED_NAME_VARIANT` | dominio | CNT-001/003/004/005, API-001…003 | NV; no se asigna dominio por similitud |
| conflicto de grupo (`groups[].conflicts`) | asociaciones | MOD-001 | NV; ciclo, miembro inexistente o doble pertenencia |
| línea con extremo inexistente (`connections[].status`) | relaciones | COM-*, MQ-003, E1-3 | NV |
| escenario `NO_DETERMINADO` (`MULTIPLE_STRUCTURAL_CANDIDATES`, `NO_COMPLETE_STRUCTURAL_ROLE_CANDIDATE`) | patrón e hijo | CNT-001/002, E1-3 | NV; el motor no publica candidatos de hijo (EC-11, ver INVESTIGACION_CNT002) |
| páginas no seleccionadas (`metadata.omittedPages`) | inventario | cualquiera por cobertura | cobertura no demostrada: ninguna regla puede dar NC por ausencia |
| candidatos de clasificación (UMLClassBlock sin tipo) | tipo | EVT-*, COM-002/003, MQ-003, EXT-002 | NV |
| inventario completo / ausencia demostrada | ausencias | todas las NC por ausencia | requisito previo; hoy no publicado como tal (definición en EC-10; candidatos de hijo en EC-11) |

## 3. Reglas comprometidas por issue

Todo issue estructural bloquea la rama No cumple por ausencia en las reglas indicadas y fuerza No verificable. Un issue no cambia por sí mismo un resultado a No aplica.
