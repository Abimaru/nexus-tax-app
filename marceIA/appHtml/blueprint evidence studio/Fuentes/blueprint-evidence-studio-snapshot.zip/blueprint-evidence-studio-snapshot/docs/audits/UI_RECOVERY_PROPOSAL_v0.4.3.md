# Propuesta gradual de recuperación de interfaz

La v0.4.3 corrigió el motor y su contrato, pero la sustitución de la UI heredada redujo capacidades de exploración presentes en v0.3.3. No se propone recuperar su motor ni sus inferencias.

| Capacidad v0.3.3 | Estado v0.4.3 | Recuperación propuesta |
|---|---|---|
| Árbol detallado por operación | Perdida; solo tabla por página | Fase 1: árbol desde `components`, `relations` y `containerChainIds` |
| Inventario navegable | Perdida | Fase 1: tabla filtrable desde `evidence.shapes` y `classifications` |
| Conexiones legibles | Reducida a conteos | Fase 1: origen/destino, terminaciones y etiquetas desde `evidence.connections` |
| Colores y figuras SVG | Perdida | Fase 3: visor SVG sanitizado y metadatos, sin inferir por geometría |
| PDF con evidencia | Parcial; impresión de resumen | Fase 2: diseño imprimible del árbol, inventario y conexiones |
| Selección de operaciones/páginas | Reducida; todas aparecen juntas | Fase 1: selector de página que solo cambia la proyección visual |

Principio de implementación: los componentes visuales consumen exclusivamente la salida del núcleo actual. No crean clasificadores, jerarquías ni asociaciones propias. Cada fase debe tener E2E de la proyección y no modificar el JSON factual.
