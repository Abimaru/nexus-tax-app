# PLAN DE PRUEBAS — CARGA Y REFERENCIAS DE LA SKILL V12

> Candidato, no aprobado. No se ejecutó el evaluador ni la batería del banco QA. Las pruebas locales (§1–§2) se probaron sobre una **simulación** del paquete, no sobre un ZIP. Las del Copilot (§3) las ejecuta la analista.

## 1. Verificaciones locales (antes de generar el ZIP)

Prototipo: `docs/audits/prototipos_skill_v12/simulate-arch.mjs` (verificador y pruebas de mutación). Se entrega como referencia de diseño; usa rutas del entorno de trabajo y deberá portarse a `scripts/` cuando se autorice implementar.

| ID | Comprobación | Fallo si… | Prototipo |
|---|---|---|---|
| L-01 | 37 IDs únicos entre los archivos de reglas | falta, sobra o se repite un ID | ✔ |
| L-02 | 296 campos idénticos a la fuente (hash por campo, 8 por regla) | cambia un solo carácter | ✔ |
| L-03 | Ninguna regla omitida y ninguna duplicada | ver L-01 | ✔ |
| L-04 | Ningún ID retirado (`CNT-006`, `EVT-008`, `CA-002`, `FT-002`, `MQ-004`, `MQ-005`, `ACT-001`) aparece como vigente en archivos operativos | aparece en `SKILL.md`, procedimiento, contrato, guía, glosario | ✔ |
| L-05 | Referencias existentes: cada fila del índice apunta a archivo y ancla reales | archivo o regla ausente | ✔ |
| L-06 | `SKILL.md` solo cita archivos que existen en el paquete | cita un archivo inexistente | ✔ |
| L-07 | Separación normativa/procedimiento: ninguna oración de ≥ 50 caracteres de una regla se repite en archivos operativos | se copia texto de una regla | ✔ |
| L-08 | Ninguna mención de «41» en archivos operativos | hay cifras de 41 | ✔ |
| L-09 | Instrucciones contradictorias: heurística de revisión para oraciones que asignan un estado a un ID fuera de las reglas (`ID … Cumple/No cumple/No verificable/No aplica`) | aparece una fuera de las reglas (hoy: 3 en v11.2.3) | pendiente (revisión manual con la lista) |
| L-10 | Estructura del paquete: carpeta única, `SKILL.md` con frontmatter `name`/`description`, nombres ASCII sin espacios, UTF-8 sin BOM, saltos LF | cualquiera | pendiente |
| L-11 | Sin dependencias externas: ninguna URL, ruta absoluta, `../` ni mención de archivos fuera de `references/` | existe una | pendiente |
| L-12 | Índice ↔ reglas biyectivo y con el mismo orden; los conteos por familia (5,2,1,4,4,7,1,1,1,1,1,1,5,3) suman 37 | difiere | parcial |
| L-13 | Estado de la norma: SRV-001/002 aparecen como `pendiente`; ningún criterio nuevo en el índice | el índice añade un criterio | pendiente |
| L-14 | Hash por obligación del ZIP (`obligaciones.sha256.txt`) coincide con el hash de los campos | no coincide | ✔ (cálculo) |
| L-15 | Los scripts de empaquetado validan 37 IDs y hashes (y no exigen CSV ni matriz de 41) | siguen exigiendo lo antiguo | requiere implementación |

### 1.1 Resultado del prototipo

**Línea base** (simulación de las arquitecturas A, B y C): 37 IDs únicos, **296 de 296 campos idénticos**, 0 referencias rotas. El verificador detectó un defecto real heredado: `contrato-compacto.md` del repositorio todavía dice «41 filas» (L-08), que es la contradicción X3 de `AUDITORIA_ESTRUCTURA_SKILL`.

**Pruebas de mutación** (se introduce un defecto y se comprueba que el verificador lo detecta):

| Mutación | Resultado |
|---|---|
| M1 un carácter cambiado en un campo normativo | detectado (`campo CNT-001.cumple`, `CNT-002.no_verificable`) |
| M2 regla GW-001 omitida | detectado (36 IDs; ancla ausente) |
| M3 regla CA-001 duplicada | detectado (38 IDs, 37 únicos) |
| M4 `CA-002` usado como vigente en `SKILL.md` | detectado |
| M5 ancla del índice inexistente | detectado |
| M6 `SKILL.md` cita `MATRIZ-EVIDENCIA-41.md` | detectado |
| M7 criterio normativo copiado en `SKILL.md` | detectado |
| M8 «41 resultados» en el procedimiento | detectado |

8 de 8 detectadas. Límite: L-07 compara oraciones literales; no detecta paráfrasis (por eso L-09 y la revisión humana de los archivos operativos).

## 2. Pruebas de integridad de la fuente (en el repositorio)

| ID | Comprobación | Estado |
|---|---|---|
| S-01 | Cada importación de la analista registra el SHA-256 del ZIP de origen (hoy `84364b68…c2ef`) | diseño |
| S-02 | La importación rechaza cualquier diferencia entre los bloques de reglas y los campos hash ya registrados salvo que provenga de un paquete nuevo | diseño |
| S-03 | `estado-normativo.json` tiene exactamente los mismos 37 IDs que la fuente | diseño |
| S-04 | `trazabilidad/ids-41-a-37.csv`: 41 IDs históricos únicos, cada ID vigente es destino o `NUEVA` (ya verificado en la Iteración 3.1) | ✔ (datos actuales) |
| S-05 | Las fichas de prueba referencian IDs existentes | diseño |

## 3. Pruebas que debe ejecutar la analista en el Copilot corporativo

No se asume que el cargador de Skills del Copilot se comporte como el de Claude. Cada prueba se registra con: versión del paquete, fecha, resultado (OK / FALLA / PARCIAL), evidencia (captura o texto) y observaciones.
Material: el ZIP candidato (cuando exista) y una página sintética del banco (`qa/cases/p1-operational/compact.json`, sin datos corporativos).

| ID | Qué se verifica | Procedimiento | Resultado esperado | Si falla |
|---|---|---|---|---|
| T-01 | Carga del paquete | Instalar el ZIP; pedir «lista las Skills disponibles» | Aparece `validar-blueprint-integracion` con su descripción | Revisar frontmatter, nombre de carpeta, tamaño |
| T-02 | Visibilidad de `references/` | Pedir «enumera los archivos de la Skill» | Los 15 archivos | El diseño no sirve para ese cargador |
| T-03 | Lectura bajo demanda | Pedir «cita literalmente la Evidencia mínima de API-004» | Texto idéntico al del archivo (comparar hash) | El Copilot resume o inventa |
| T-04 | Archivos grandes sin truncar | Pedir las últimas 20 palabras de `reglas-01-estructura.md` y `reglas-03-eventos.md` | Coinciden con el archivo | Evaluar partir los archivos (volver a comparar B/C con este dato) |
| T-05 | Lectura de todos los archivos de reglas en una sesión | «Enumera los 37 IDs y el archivo de cada uno» | 37 IDs, ninguno inventado, archivo correcto | Revisar índice y límite de contexto |
| T-06 | ID retirado | Preguntar por `CA-002` | Indica que no es una regla vigente | Contradicción normativa |
| T-07 | Regla inexistente en el paquete | Pedir una regla «MQ-004» | No la inventa | Riesgo de alucinación |
| T-08 | Evaluación de una página sintética | Subir el compacto de `p1-operational` y pedir la evaluación | 37 filas, IDs únicos, solo cuatro estados, suma 37, justificación por fila, preguntas MCI limitadas a las autorizadas | Anotar qué falta |
| T-09 | Evaluación sin lectura completa | Repetir T-08 y registrar qué archivos abrió | Abre procedimiento, contrato, índice y los siete de reglas | Si omite alguno, reforzar el paso 1 de `SKILL.md` |
| T-10 | Varias páginas en la misma sesión | Compacto con 2 páginas (`p4-multipage`) | 37 por página evaluable; total sumando regla–página; no promedia | Revisar procedimiento §10 |
| T-11 | Presupuesto de contexto | T-08 con el mayor compacto disponible; observar si el Copilot avisa o recorta | Respuesta completa | Medir el límite real y reconsiderar C |
| T-12 | Actualización | Reemplazar un paquete antiguo (41 reglas) por el nuevo | Ya no cita las 41 reglas ni los IDs retirados | El Copilot conserva una versión anterior en caché |

Pruebas opcionales: T-13 (¿admite lectura por rango de líneas?), T-14 (¿ignora los comentarios HTML?, relevante si se usan marcas de regla), T-15 (¿admite ZIP con carpeta `references/` anidada o exige estructura plana?).

## 4. Riesgos de compatibilidad

| ID | Riesgo | Mitigación |
|---|---|---|
| R-C1 | El Copilot no abre archivos de `references/` bajo demanda | T-02/T-03; si falla, fusionar en un único archivo o en pocos (volver a evaluar B/C) |
| R-C2 | Tamaño máximo por archivo o truncamiento (el mayor es ≈ 24 KB en A, 112 KB en C) | T-04; A es la opción más tolerante |
| R-C3 | Presupuesto total de contexto: ≈ 39 600 tokens de Skill más la página | T-11; no hay reducción posible sin perder texto normativo |
| R-C4 | Caché de versiones anteriores | T-12 |
| R-C5 | El Copilot trata la `description` y el frontmatter de otra forma | T-01 |
| R-C6 | Interpretación distinta de comentarios HTML o anclas `#ID` | No usarlas en el paquete final; los encabezados `## ID — título` bastan (T-14) |
| R-C7 | Codificación o saltos de línea | L-10 |
| R-C8 | Las respuestas del Copilot no reproducen el mismo orden de lectura | T-09; la autocomprobación del paso final de `SKILL.md` |

## 5. Qué se puede y qué no se puede comprobar localmente

| Localmente (sin el Copilot) | Solo en el Copilot |
|---|---|
| Exactitud del texto normativo, unicidad de IDs, referencias, ausencia de IDs retirados, separación normativa/procedimiento, estructura del ZIP, tamaño | Si carga la Skill, si lee `references/`, límites de archivo y de contexto, caché, calidad de las respuestas, cumplimiento del formato de 37 filas |
| Heurística de contradicciones | Contradicciones que solo aparecen al razonar |

## 6. Criterios para pasar de diseño a ZIP candidato

1. L-01…L-15 en verde sobre el paquete real (no la simulación).
2. T-01…T-05 aprobadas en el Copilot.
3. Decisiones previas: C-02, C-01 (tratamiento), C-11, aprobación del catálogo (ver `PROPUESTA_SKILL_V12_OPTIMIZADA` §10).
4. Ninguna regla de la analista modificada.
