# 04 — Ambigüedades históricas (Fase 7)

Etiquetas: RESUELTA_POR_ANALISTA, RESUELTA_PREVIAMENTE, RESUELTA_POR_CONVENCIÓN_TÉCNICA, SIGUE_PENDIENTE, REQUIERE_CAMBIO_EN_EVIDENCE_STUDIO.

Criterio: marco **RESUELTA_POR_ANALISTA** solo si el texto vigente de la analista establece expresamente la condición. Cuando el texto es explícito pero la regla no se puede evaluar con el contrato actual, añado la etiqueta que corresponde, sin dar la ambigüedad por cerrada.

Limitación: las auditorías originales y `RULE_EVIDENCE_MATRIX_v11.2.md` no estaban disponibles. Las ambigüedades se reconstruyen desde el texto del catálogo histórico de 41 (p. ej. "Conservar definición vigente", "cuando corresponda"), el CHANGELOG y las notas de v11.2.x.

## 1. Lista solicitada

| Regla | Ambigüedad histórica (evidencia en el catálogo de 41) | Estado | Residual |
|---|---|---|---|
| CNT-001 | "Demás contenedores padre aplicables al escenario" sin definir | **RESUELTA_POR_ANALISTA**: dominios obligatorios por patrón (E1: INT+PROD; E2: INT; E3: PROD) | SIGUE_PENDIENTE: ¿cuenta un productor inferido por estructura? (D-11). REQUIERE_CAMBIO: dominios personalizados (G-7) |
| CNT-002 | F-13 ("no gestionado"); v11.2.3: "la interpretación de CNT-002 sigue pendiente" | **RESUELTA_POR_ANALISTA**: único hijo, nombre específico, dominio por patrón; no evalúa "gestionado" | SIGUE_PENDIENTE: confirmar retirada de F-13 (D-09). Nombre "específico" (D-12) |
| CNT-004 | "Componentes backend aplicables" | **RESUELTA_POR_ANALISTA**: listas por nivel | REQUIERE_CAMBIO: categorías sin tipo publicado (G-3) |
| CNT-006 | "Componentes evaluables" sin delimitar (v11.2.2: "sujeta a revisión normativa") | **RESUELTA_POR_ANALISTA**: regla retirada; integridad pasa a controles previos | SIGUE_PENDIENTE: tabla issue→regla (D-22) |
| MQ-001 | "Conservar definición vigente de MQ-001" (autorreferencia) | **RESUELTA_POR_ANALISTA**: `UMLActiveClassBlock` ⇒ gestor; nombre específico. La convención técnica pasa a norma | "Genérico" subjetivo (D-12) |
| MQ-002 (nueva) | Antiguas MQ-002/003/004: ubicación, modelo y detalle de despliegue | **RESUELTA_POR_ANALISTA**: MCI = Capa+Flujo; Federada = literal `Federado`; solo en nivel padre de INTEGRACIÓN | REQUIERE_CAMBIO: asociación de Federado y de Capa sin Flujo (G-5, D-14) |
| MQ-003 (nueva) | Antigua MQ-005: "Conservar patrón vigente" sin definir | **RESUELTA_POR_ANALISTA**: tres patrones con terminaciones | REQUIERE_CAMBIO: subtipo Mensaje (G-4), servicio invocado (G-1, G-2) |
| MQ-004, MQ-005 (antiguas) | Despliegue por ubicación; "no duplicar COM-004" | **RESUELTA_POR_ANALISTA** (fusionada en MQ-002; ampliada en MQ-003) | — |
| SRV-001 | Prefijo `ms` ¿requisito o convención?; versión opcional | **SIGUE_PENDIENTE** (la analista la declara pendiente) | D-02 |
| SRV-002 | Operación camelCase; ¿población incluye el hijo y el principal de E3? | **SIGUE_PENDIENTE** | D-02 |
| SRV-003 | Población "principal e invocados"; el hijo no es SERVICIO | **RESUELTA_POR_ANALISTA**: solo servicios invocados; el hijo no hace aplicable la regla | REQUIERE_CAMBIO: certificar "invocado" (G-1, G-2, D-04) |
| MOD-001 | "Modelos internos del hijo no requieren propietario"; invocados "ausencia no verificable" | **RESUELTA_POR_ANALISTA**: obligatorios solo en API principal E1/E2, principal de E3 y eventos de integración en INTEGRACIÓN | SIGUE_PENDIENTE: reconocimiento del modelo (D-19). REQUIERE_CAMBIO: eventos sin tipo (G-3) |
| API-003 | "No reclasificar automáticamente como servicio si faltan" (circularidad) | **RESUELTA_POR_ANALISTA** en formato (`tipo - modelo`, minúsculas) y en el papel de la declaración (no corrige) | SIGUE_PENDIENTE: cómo se certifica "API" sin tercera sección válida (D-03) |
| API-004 | "Private MCI: Capa y Flujo; partner MCI: Capa" sin tratar "no MCI" ni la asociación | **RESUELTA_POR_ANALISTA** (no MCI ⇒ No aplica; asociación inequívoca) | REQUIERE_CAMBIO: partner (solo Capa) y capa sin Flujo (G-5) |
| CA-001 | "Capa obligatoria y su nombre" mezclaba existencia y nombre | **RESUELTA_POR_ANALISTA**: solo nombre; existencia en API-004/SRV-004/MQ-002 | REQUIERE_CAMBIO / SIGUE_PENDIENTE: reconocimiento por prefijo (G-6, D-05) |
| FT-001 | Ídem | **RESUELTA_POR_ANALISTA** | Ídem (G-6, D-05) |
| E1-001 | "Conexión declarada al evento de Inicio cuando sea exigible"; "directa vs declarada" pendiente | **RESUELTA_POR_ANALISTA**: API→Inicio del hijo, `None`→`Arrow`, Inicio certificado | SIGUE_PENDIENTE: alcance de "directa" (D-10), prioridad `No cumple` (D-24). REQUIERE_CAMBIO: certificación de Inicio (G-4) |
| E2-001 | "Solo relación conceptual" con F-13 | **RESUELTA_POR_ANALISTA** | Ídem E1-001 |
| E3-001 | "Conexión directa al evento de Inicio cuando sea exigible" | **RESUELTA_POR_ANALISTA** | Ídem E1-001 |

## 2. Resto del catálogo

| Regla | Ambigüedad | Estado |
|---|---|---|
| CNT-003, CNT-005 | Criterios genéricos ("componentes permitidos") | RESUELTA_POR_ANALISTA (listas) + REQUIERE_CAMBIO (G-3) |
| EXT-001 | "Cuando corresponda" (cuándo puede contener evento o gestor) | RESUELTA_POR_ANALISTA (ya no admite evento ni gestor; D-23) + SIGUE_PENDIENTE (auxiliar sin nombre/vacío, D-15) |
| EXT-002 (antigua) | Atribuir la conexión al auxiliar con un único candidato | RESUELTA_POR_ANALISTA (retirada; pasa a COM-002/003/005) + SIGUE_PENDIENTE ("inequívoca", D-18) |
| EXT-002 (nueva) | — | Nueva. SIGUE_PENDIENTE: subcadena vs palabra (D-16); autorreferencia |
| GW-001 | "Caminos coherentes y reconstruibles" | RESUELTA_POR_ANALISTA (texto de compuerta ↔ etiquetas). Juicio semántico (D-12) |
| API-001, API-002 | "Estructura y versión aprobadas" sin definir | RESUELTA_POR_ANALISTA (dos modalidades). Juicio de idioma (D-12) |
| SRV-004 | — | Nueva. SIGUE_PENDIENTE: equivalencia hijo≡servicio principal (D-21) |
| EVT-001..003 | Guion bajo opcional; PascalCase; tolerancia de tilde | RESUELTA_POR_ANALISTA (reversiones, D-23) + REQUIERE_CAMBIO (G-3) |
| EVT-004 (antigua, despliegue) | Propiedad y MCI de eventos | RESUELTA_POR_ANALISTA (retirada) |
| EVT-004..007 (nuevas) | "Aplica siempre"; conexiones sin subtipo | RESUELTA_POR_ANALISTA; REQUIERE_CAMBIO (G-3, G-4); cascada (D-13) |
| COM-001 | "Relación certificada" no definida | RESUELTA_POR_ANALISTA en parte; SIGUE_PENDIENTE (D-18) |
| COM-002..004 | "Patrón vigente" (COM-004) | RESUELTA_POR_ANALISTA (patrón explícito). REQUIERE_CAMBIO (G-1, G-2) |
| COM-005 | — | Nueva. SIGUE_PENDIENTE (D-18) |
| CA-002, FT-002 | Propietario inequívoco | RESUELTA_POR_ANALISTA (retiradas; asociación en reglas del componente) |

## 3. Resumen

| Estado | Reglas con al menos una ocurrencia |
|---|---|
| RESUELTA_POR_ANALISTA (criterio normativo) | 35 de 37 (todas salvo SRV-001 y SRV-002) |
| SIGUE_PENDIENTE | SRV-001, SRV-002 (criterio); además residuales en CNT-001, CNT-002, EXT-001/002, API-003, SRV-004, MOD-001, COM-001/002/003/005, E1/E2/E3-001 |
| REQUIERE_CAMBIO_EN_EVIDENCE_STUDIO | CNT-001, CNT-003/004/005, EXT-001/002, API-001..004, SRV-003/004, EVT-001..007, CA-001, FT-001, E1/E2/E3-001, MOD-001, COM-002/003, MQ-002/003 |
| RESUELTA_POR_CONVENCIÓN_TÉCNICA | `UMLActiveClassBlock` ⇒ gestor (hoy absorbida por MQ-001); `ms` ⇒ posible servicio |
| RESUELTA_PREVIAMENTE | Cuatro estados, fórmula y preguntas MCI/exposición (idénticas en los tres paquetes) |

"Resuelta" en el criterio normativo no implica "evaluable hoy": ver `02-matriz-reglas.csv`, columna "estados alcanzables hoy".
