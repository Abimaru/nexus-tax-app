# 01 — Comparación de los tres ZIP, cambios y redundancias

Cubre los entregables 1, 2 y 7. Método: extracción íntegra, comparación por hash y diff de archivos, y lectura semántica regla por regla (los 37 textos de la analista contra el catálogo histórico de 41). La matriz por regla está en `02-matriz-reglas.csv`.

## 1. Inventario de archivos

| Archivo | Analista v11.2.2 | Codex v11.2.2 | v11.2.3 | Relación |
|---|---|---|---|---|
| `SKILL.md` | 37 reglas, sin versión | 41, "v11.2.2" | 41, "v11.2.3" | Analista distinta de las otras dos; v11.2.3 = codex + 2 frases |
| `00-procedimiento.md` | Texto v11.2.1 ampliado (§1–10) | Técnico, con clasificación de páginas | Codex + sección "Interpretación operativa (v11.2.3)" | Tres textos distintos |
| `01..07-reglas-*.md` | **37 reglas completas** (~164 KB en total) | 41 compactas genéricas | **Idénticas a codex** salvo el encabezado | Dos linajes |
| `catalogo-reglas-v11.2.csv` | 41 (histórico, desactualizado) | 41 | 41 | **Mismo hash en los tres** |
| `MANIFEST.md` | 37, "revisión en curso" | 41 | 41 | Analista distinta |
| `MATRIZ-EVIDENCIA-37.md` / `-41.md` | 37 | 41 | 41 (idéntica a codex) | |
| `CONTRATO-COMPACTO.md` | Diccionario v11.2.1 (sin `groups`, `name`, `operation`, `lucidchartType`, `containedComponentIds`, `pageClassification`, `counts`) | + campos v0.4.6.1 completos | codex + párrafo tipo/rol/PRODUCER | La matriz 37 usa campos que su propio diccionario no define |
| `GUIA-TEXTAREAS.md` | + sección "Modalidad de validación de API según ubicación" | Base | Base (idéntica a codex) | La analista amplía |
| `INSTRUCCIONES-AGENTE-V11.md` | Dice **41 filas** | 41 | 41 + 2 líneas | Desactualizada en el paquete de la analista |
| `CHANGELOG-V11.md` | Termina en v11.2.1; dice "no cambia las 41" | + v11.2.2 | + v11.2.3 | La analista no registra su cambio de 41 a 37 |

Conclusión sobre versiones: la etiqueta "v11.2.2" identifica dos artefactos distintos. Hay que fijar una nomenclatura que distinga línea normativa (analista) y línea técnica (procedimiento y contrato), por ejemplo versión normativa `N` y versión de procedimiento `P`.

## 2. Inconsistencias dentro del paquete de la analista

| # | Hallazgo | Archivo |
|---|---|---|
| I-1 | El MANIFEST exige `catalogo-reglas-vigente.csv`; el archivo incluido es `catalogo-reglas-v11.2.csv` y lista 41 reglas (incluye CNT-006, CA-002, FT-002, MQ-004…) | MANIFEST, CSV |
| I-2 | "Exactamente 41 resultados / 41 filas" | INSTRUCCIONES-AGENTE, CONTRATO-COMPACTO |
| I-3 | El propio MANIFEST pide verificar que no haya referencias a 41 reglas (punto 3 de "Verificación final"); hay 3 referencias operativas a "41" (INSTRUCCIONES ×2, CONTRATO ×1), además de menciones históricas legítimas en CHANGELOG y MANIFEST | MANIFEST, INSTRUCCIONES, CONTRATO |
| I-4 | Encabezados "v11.2.1" en 8 archivos; el MANIFEST pide asignar nueva versión | `00..07` |
| I-5 | EXT-002: el criterio dice "sus conexiones se evalúan mediante EXT-002"; es una autorreferencia al ID antiguo | `01-reglas-estructura.md` |
| I-6 | SRV-001/002 en esqueleto: encabezado `##` (no `###`), "evidencia suficiente y criterio satisfecho" | `02-reglas-api-servicios.md` |
| I-7 | En EVT-005, EVT-006 y EVT-007 la viñeta `No aplica` contiene frases que describen `No verificable` | `03-reglas-eventos.md` |
| I-8 | API-004: errata "presenta todo la capa de despliegue exigido" | `02-reglas-api-servicios.md` |
| I-9 | La cláusula "prevalece No cumple" aparece en 23 de 37 reglas. Las otras 14 dependen de la regla global (00 §8): CNT-001, CNT-003/004/005, EXT-001/002, GW-001, API-004, SRV-001/002/004, E1/E2/E3-001 | varios |
| I-10 | E1/E2/E3-001: `No cumple` exige el subtipo Inicio certificado, pero 00 §8 dice que un incumplimiento certificado prevalece (→ D-24) | `05`, `00` |
| I-11 | SRV-003 acepta cualquier capitalización de `entidad/utilidad/tarea`; API-003 la exige en minúsculas (→ D-17) | `02` |
| I-12 | CNT-003/004 no mencionan al hijo principal entre los componentes permitidos del nivel padre; solo encaja si se lo trata como "servicio" (→ D-21) | `01` |
| I-13 | EVT-001/002/003 dicen que la validación se aplica "incluso" dentro de un auxiliar, pero EXT-001 ya no admite eventos en un auxiliar. Probablemente intencional (se evalúa el nombre aunque la ubicación sea inválida); confirmar | `03`, `01` |

## 3. Clasificación de las 41 reglas históricas frente al paquete de la analista

Etiquetas pedidas: SIN CAMBIOS, MODIFICADA POR LA ANALISTA, MODIFICADA TÉCNICAMENTE, CONTRADICTORIA, DUPLICADA, POSIBLEMENTE REDUNDANTE, NUEVA, RETIRADA, PENDIENTE DE DECISIÓN.

| Etiqueta | Reglas |
|---|---|
| SIN CAMBIOS | SRV-001, SRV-002 (además PENDIENTE DE DECISIÓN: la analista las declara sin criterio final) |
| MODIFICADA POR LA ANALISTA | CNT-001..005, EXT-001, GW-001, API-001..004, SRV-003, EVT-001..003, EVT-004 (antes EVT-005), EVT-005 (antes EVT-006), EVT-006 (antes EVT-007), EVT-007 (antes EVT-008), CA-001, FT-001, E1-001, E2-001, E3-001, MOD-001, COM-001..004, MQ-001, MQ-003 (antes MQ-005) |
| NUEVA | EXT-002 (EVC/EPC/LDC), SRV-004, COM-005; MQ-002 es consolidación de las antiguas MQ-003 y MQ-004 |
| RETIRADA | CNT-006, EXT-002 (conexión mediante auxiliar), EVT-004 (despliegue), CA-002, FT-002, MQ-002 (ubicación), MQ-004 (fusionada) |
| MODIFICADA TÉCNICAMENTE (lado técnico, sin equivalente en el texto de la analista) | Ver §4 |
| CONTRADICTORIA | Entre linajes: página plantilla (D-07); `No aplica` (D-08); gestionado/no gestionado (D-09). Internas: I-10 |
| DUPLICADA / POSIBLEMENTE REDUNDANTE | Ver §5 |

Control de suma: 2 sin cambios + 32 modificadas + 3 nuevas = 37. Del histórico: 41 − 7 retiradas/fusionadas = 34 que sobreviven (2 sin cambios + 32 modificadas); 34 + 3 nuevas = 37.

### Cambios semánticos que merecen revisión explícita (en negrita, los que revierten una decisión previa)

| Regla | De 41 → 37 |
|---|---|
| CNT-001 | De "INTEGRACIÓN y demás padres" a dominios obligatorios por patrón; se admiten varios dominios y nombres personalizados |
| CNT-002 | Nuevas exigencias: único hijo, nombre específico. **Desaparece "gestionado/no gestionado" (F-13)** |
| CNT-003/004/005 | Se pasa de un criterio genérico a listas cerradas por nivel (padre/hijo). **EXT-001 y CNT-005 ya no admiten evento ni gestor en un auxiliar/SISTEMAS EXTERNOS** |
| EXT-001 | Nombre obligatorio; capa MCI/Federado solo si el auxiliar está en el nivel padre de INTEGRACIÓN |
| API-001..003 | Dos modalidades por dominio; SISTEMAS EXTERNOS con criterio reducido |
| API-004 | Se precisa; la exposición declarada por la analista no corrige API-003 |
| SRV-003 | Se restringe a servicios invocados; capitalización libre |
| **EVT-001** | **Guion bajo antes de la versión pasa de opcional a obligatorio** |
| **EVT-002** | **PascalCase → camelCase** |
| **EVT-003** | **Se retira la equivalencia de tilde** |
| EVT-004..007 | Renumeradas; EVT-007 exige BPMNEvent como Señal de Envío/Recepción y admite extremos alternativos |
| CA-001 / FT-001 | Solo nombre; la existencia pasa a API-004, SRV-004 y MQ-002 |
| E1/E2/E3-001 | Conexión `None`→`Arrow`; Inicio certificado dentro del hijo; no se habla de "gestionado" |
| MOD-001 | Añade eventos (por p/s) y el componente principal de E3; invocados e hijo sin modelos obligatorios. **Antes: ausencia de modelos en invocados = No verificable** |
| COM-001..005 | COM-005 nueva; COM-002/003 incluyen API/servicio encapsulado. **Antes un único candidato compatible permitía atribuir la conexión al auxiliar (EXT-002 antigua); ahora se exige atribución "inequívoca"** |
| MQ-001..003 | `UMLActiveClassBlock` ⇒ gestor (de convención técnica a norma). **Se elimina la pregunta MCI del gestor** |

## 4. Adiciones técnicas ausentes en el paquete de la analista

Provienen de los linajes técnicos v11.2.2 y v11.2.3. Ninguna contradice un texto de la analista salvo donde se indica.

| Adición técnica | Origen | Tratamiento propuesto |
|---|---|---|
| `pageClassification` (OPERATIONAL, MIXED, TEMPLATE_OR_LEGEND, BDD_OR_REQUIREMENTS, UNRESOLVED) | v11.2.2 | Conservar como paso previo. **Contradice** el `No aplica` por plantilla de CNT-001/002 y E1..E3 (D-07) |
| Principio "ausencia de figura ≠ No aplica" | v11.2.2 | Reconciliar con los `No aplica` explícitos de la analista (D-08) |
| Criterio operativo de CNT-006 | v11.2.2 | Obsoleto (regla retirada). Los controles de integridad pasan a 00 §2 |
| `UMLActiveClassBlock` ⇒ `GESTOR_COLAS` como convención | v11.2.2 | Absorbida por MQ-001 |
| Tipo ≠ rol; hijo principal ≠ SERVICIO/INVOCADO; no ampliar SRV | v11.2.3 §1–2 | Conservar (D-02, D-21) |
| Procedencia, certeza y conflictos al usar `domainRole: PRODUCER` | v11.2.3 §3 | Conservar; ver D-11 |
| `HIPOTESIS`/`CONFIRMADO` no son estados | v11.2.3 §4 | Ya recogido por la analista (00 §9) |
| E1/E2/E3 no `Cumple` sin Inicio certificado | v11.2.3 §5 | Ya recogido por la analista en cada regla |
| API-004, CA-001, FT-001 por separado | v11.2.3 §6 | Recogido: la analista separa por diseño |
| `No cumple` exige evidencia suficiente | v11.2.3 §7 | Recogido (00 §8) |
| Fórmula de cumplimiento | todas | Idéntica en los tres paquetes |
| Estados permitidos | todas | Los cuatro estados, idénticos; la analista añade prioridad explícita |
| Decisión pendiente "conexión directa vs declarada" | v11.2.0 | La analista la responde de hecho con `None`→`Arrow` en los extremos (D-10) |

## 5. Redundancias (Fase 4)

Regla aplicada: proponer consolidación solo con equivalencia normativa demostrable. **No se demuestra equivalencia total en ningún par.** No se propone eliminar ni renumerar ninguna regla.

| Tipo | Reglas | Análisis | Propuesta |
|---|---|---|---|
| DUPLICACIÓN REAL | — | Ninguna | — |
| SOLAPAMIENTO | CNT-003 / CNT-004 / CNT-005 | Misma estructura (listas por nivel) y evidencia común (jerarquía, clasificación); poblaciones distintas | Conservar los tres IDs; redactar una sola plantilla y tres tablas de contenido |
| SOLAPAMIENTO | COM-002 / COM-003 / COM-004 / COM-005 | Mismo patrón bidireccional `CircleOpen`→`Generalization`; cambia el participante. La precedencia (cada conexión en una sola regla) ya evita doble conteo | Conservar los cuatro IDs; definir el patrón una sola vez |
| SOLAPAMIENTO | E1-001 / E2-001 / E3-001 | Comparten la condición "Inicio certificado + `None`→`Arrow`"; poblaciones mutuamente excluyentes por patrón | Conservar; definir la condición común una sola vez |
| SOLAPAMIENTO | API-001..003 / EVT-001..003 / SRV-001..003 | Estructura análoga, poblaciones distintas | Conservar |
| SOLAPAMIENTO | EXT-001 / EXT-002 / CNT-003..005 | EXT-001 cubre contenido; EXT-002 ubicación del subconjunto EVC/EPC/LDC; CNT acota el nivel. Un auxiliar EVC con API en SISTEMAS EXTERNOS: `Cumple` en CNT-005, `No cumple` en EXT-002 | Conservar; documentar el caso como ejemplo |
| DEPENDENCIA | EVT-004 → EVT-005 → EVT-006/EVT-007 | Cascada de `No verificable` (D-13) | Conservar; declarar la dependencia en el catálogo |
| DEPENDENCIA | API-003 → API-004 (exposición) | La exposición viene de la tercera sección o de la declaración | Conservar |
| DEPENDENCIA | CA-001/FT-001 ← API-004/SRV-004/MQ-002 | La existencia se evalúa en el componente; el nombre en CA/FT | Conservar |
| DEPENDENCIA | COM-001 → COM-002..005 | COM-001 define el candidato a comando | Conservar |
| FRONTERA | COM-004 / MQ-003 | Comando↔gestor solo en COM-004; gestor↔gestor, servicio↔gestor y Mensaje↔gestor en MQ-003 | Sin redundancia; la regla ya lo establece |
| CONTRADICCIÓN | E1/E2/E3-001 internas (D-24); CNT-003/004 y el hijo principal (I-12); SRV-003 vs API-003 (D-17) | Ver §2 | Pedir decisión |
| CONTRADICCIÓN | `No aplica` de la analista vs principio técnico (D-08); plantilla/leyenda (D-07) | Entre linajes | Pedir decisión |

Reutilización de IDs con otro significado (riesgo para cualquier comparación futura): EXT-002, EVT-004, EVT-005, EVT-006, EVT-007, MQ-002, MQ-003. Recomendación: no renumerar ahora; añadir a cada regla `alias_historico` y una tabla `id_anterior → id_vigente` en el catálogo, y no volver a reutilizar IDs retirados.
