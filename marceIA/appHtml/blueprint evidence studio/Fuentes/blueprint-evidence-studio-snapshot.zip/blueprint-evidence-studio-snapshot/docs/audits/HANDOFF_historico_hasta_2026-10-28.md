# HANDOFF v0.4.6.1 (actualizado 26/10/2026)

> **Actualización 28/10/2026 (tarde):** Skill v11.4.0 integrada (paquetes v11.3.1 y v11.3.0 de la analista unificados) (paquete de la analista con correcciones; ver CHANGELOG) y preguntas MCI obligatorias aun con `HIPOTESIS`.
>
> **Actualización 28/10/2026:** Evidence Studio 0.4.9 clasifica como `MODELO` las actividades con `customData` ENTRADA/SALIDA (`MODEL_BY_CUSTOMDATA_IO`) y alinea `modelIds`; ver CHANGELOG.
>
> **Actualización 27/10/2026:** Evidence Studio 0.4.8 aplica las reglas de la analista para el tipo de componente (API invocada por marcador, servicio invocado por `ms`, evento de integración por tercera sección) hijo único por compuertas y actividades, contenedores padre (incluido el productor por estructura y E3 por descarte) y omite `DefaultSquareBlock` sin relaciones y el BPMN Event marcador de una API cierta. Contrato (`copilot-factual-v0.4.6.1`) y Skill (v11.2.4) sin cambios. Ver `CHANGELOG.md`. Git sigue pendiente.

> **Estado vigente (26/10/2026, cierre de simplificación):** Skill v11.2.4 candidata funcional, no estable: diez archivos, 37 reglas confirmadas por la analista, SHA-256 del ZIP `3c5be201…4c1d`. Motor y contrato sin cambios. HTML `dist/BlueprintEvidenceStudio.html` SHA-256 `205cc88e…93f5` (reconstruido sin diferencias desde `ui/` y `src/`). Pruebas: `npm test` 57/57; QA `selftest` sin fallos salvo la comprobación de aislamiento, que exige un registro de prueba real. Pendiente: prueba funcional con Copilot corporativo y sincronización Git (no realizada; este directorio no es un repositorio). Las menciones a v11.2.3 y 41 reglas más abajo son históricas.

Repositorio `Abimaru/blueprint-evidence-studio` ahora PRIVADO (confirmado por Andrés y verificado con `gh repo view`); `origin/main` solo tiene `README.md`. Aun así: no publicar blueprints, `Solicitud Ajustes/`, auditorías, Skill ni artefactos corporativos sin confirmar destino y alcance. Sin commit, push, merge ni PR.

- Copilot recibe inventario consolidado y solo páginas seleccionadas; diagnóstico conserva todo.
- Currency Exchange duplicado es idéntico al E2 original. Principal `tQ7mFTFbJ1SW`: API/PRINCIPAL, E2 HIPOTESIS. Gestor `4Oc~oPj98AFn` asociado solo a `4Oc~UAg.ChZ2` / `4Oc~STvzS7WZ` por contención.
- `ms-transfer-service-context` se clasifica SERVICIO por convención, pero su rol queda sin certificar por conexiones opuestas; BPMNGroup nominales son SISTEMA_EXTERNO_AUXILIAR.
- Eventos corporativos siguen NO_VERIFICABLE: no existe una clave `customData` estable demostrada. Solo el fixture sintético con declaración exacta confirma Inicio.
- Skill v11.2.3 (preparada, no estable; ver actualización 26/10) conserva 41 IDs y obligaciones, reconoce el contrato compacto, usa cuatro estados y clasifica las páginas por `pageClassification.kind` (plantillas y BDD puros no son evaluables; `UNRESOLVED` pide revisión). La conexión directa frente a declarada permanece pendiente.
- `customData` se conserva literalmente para toda figura. Un campo ausente permanece ausente; `[]` permanece vacío.
- No se infiere EXTERNAL_SYSTEM por descarte. Los roles resueltos vacían `possibleDomainRoles`.
- `window.__BES__` es un gancho no enumerable, local y de solo lectura para E2E; no hace red ni muta el modelo.
- No declarar estable ni certificado para Copilot antes de pruebas funcionales de la analista. No se hizo push.

## Candidato visual v0.4.7 — 25/10/2026

- Primera evolución visual implementada exclusivamente en `ui/`: paneles de eventos BPMN no certificados, dominios productores, contenedores hijo y modelos ENTRADA/SALIDA.
- Motor y contrato permanecen en v0.4.6.1; `src/` no cambió. La Skill v11.2.3 y las 41 obligaciones no se modificaron.
- Invariancia compacta verificada por bytes para Oski, Currency Exchange, Virtual Account Opening y Debit Card.
- Pruebas: 69/69 unitarias/regresión y 8/8 E2E; audit/build PASS.
- HTML candidato: 77.481 bytes, SHA-256 `205CC88EA198C175002E86D1A65696D3E2D7260A8E8B86BDCFDB98B68EAE93F5`, 0 URLs remotas.
- Informe: `docs/audits/DIFFERENCES_v0.4.6.1_vs_v0.4.7_CANDIDATE.md`.
- Estado: candidato, no estable. Sin commit, push, merge ni PR.

## Actualización 26/10/2026
- Evidence Studio: motor v0.4.6.1 sin cambios (`src/` idéntico al commit). El 25/10 por la tarde otro proceso dejó un **candidato visual v0.4.7** en `ui/` (cuatro paneles descriptivos: eventos BPMN con subtipo no certificado, dominios productores, contenedores hijo, modelos ENTRADA/SALIDA por `customData`): HTML 77 481 B, SHA-256 `205cc88e…93f5`; el HTML anterior era `a93f293d…a47`. Contrato `copilot-factual-v0.4.6.1` y compactos idénticos byte a byte (9 casos sintéticos regenerados). `npm test` 69/69. Pendiente de revisión visual y de la analista; no estable. Ver `docs/audits/DIFFERENCES_v0.4.6.1_vs_v0.4.7_CANDIDATE.md`.
- Skill v11.2.3 **preparada, no estable** (ZIP SHA-256 `e15c8bda…9330`). Validada en 3 casos sintéticos × 2 versiones (una ejecución cada una): sin regresión frente a v11.2.2, solo 4 reglas difieren (CNT-002/CNT-004, EVT-007) y los casos no discriminan los ajustes; costo de lista +8,2 %. Informe: `docs/audits/VALIDACION_FUNCIONAL_SKILL_V11.2.3_2026-10-26.md`.
- Corpus: el «341 BPMNEvent» de las auditorías antiguas es el corpus histórico; el subconjunto auditado hoy (7 blueprints) tiene 260 `BPMNEvent`, 0 con `customData`. No son el mismo conjunto.
- MOD-001: 160 registros ENTRADA/SALIDA preservados literalmente; `MODELO` se asigna por nombre y no los identifica; la asociación al principal por grupo no siempre es certificable (10 de 14 páginas evaluables). Pertenencia a grupo = evidencia asociativa.
- Contenedores hijo: tipo `SERVICIO_HIJO` por figura, rol `HIJO_PRINCIPAL` por escenario. 8 contenedores sin nombre (Debit Card), 6 con 21–68 figuras: advertencias de trazabilidad propuestas, no incumplimientos.
- Propuesta BPMN pendiente de aprobación: panel «Eventos BPMN con subtipo no certificado»; ninguna convención `customData` nueva; `PROPOSED_CLOSED_CATALOG` se mantiene.
- Q1–Q10: cerradas Q1 y Q10; parciales Q2, Q5, Q6, Q8; pendientes Q3, Q4, Q7, Q9 (detalle en `PROJECT_CONTEXT_2026-10-26.md`).
- La analista prepara un consolidado normativo: las 41 obligaciones permanecen intactas; comparación lista con `qa/tools/compare-normative.mjs`.
- Banco de pruebas: `--skill 11.2.2` para ejecutar versiones archivadas; se corrigió un defecto de lectura de conteos del controlador (QA).
- No ejecutar la batería de 16 casos, ni commit/push/merge/PR, hasta nueva indicación. Contexto vigente: `PROJECT_CONTEXT_2026-10-26.md`.
