# Catálogo normativo candidato — 37 reglas

Estado: **CANDIDATO, no estable**. Fecha: 26/10/2026. Iteración 2 de la consolidación. Solo documentación: no es una Skill, no modifica el motor ni el contrato, no crea versión.

**Fuente de las obligaciones:** los siete archivos normativos de la analista (`01`..`07-reglas-*.md`) del paquete `7e7b4e92-validar-blueprint-integracion-v11.2.2.zip` (SHA-256 `84364b68570a57492f5779c59a995d9ef370614941076f0f6c58c617080ef2c3`). El texto del bloque **A** de cada regla es literal; sólo se ha reformateado (separación de párrafos). El CSV histórico de 41 reglas no se usa como fuente.

**Cómo leer cada regla**

| Bloque | Qué es | Autoridad |
|---|---|---|
| **A. Texto normativo** | Obligación, población, evidencia mínima y los cuatro estados, literales | Analista (norma) |
| **B. Interpretación técnica** | Síntesis de aplicabilidad, dependencias, conflictos, preguntas | Auditoría (no es norma; no añade criterios) |
| **C. Evidencia y decisiones** | Estado de definición, estado de evidencia, brechas, decisiones abiertas | Auditoría + decisiones de Andrés |

**Vocabulario.** Estado de definición normativa: `NORMATIVAMENTE_DEFINIDA` (texto completo sin decisión abierta específica), `NORMATIVAMENTE_CONDICIONADA` (texto completo, pero una decisión abierta puede cambiar su interpretación o aplicación), `NORMATIVAMENTE_PENDIENTE` (el criterio no existe). Estado de evidencia (atributo técnico, **no** un estado normativo): `EVIDENCIA_DISPONIBLE`, `EVIDENCIA_PARCIAL`, `EVIDENCIA_AMBIGUA`, `EVIDENCIA_NO_PUBLICADA` (existe en el original pero Evidence Studio no la publica), `EVIDENCIA_NO_EXISTENTE_EN_ORIGINAL` (el export de Lucidchart no la contiene), `EVIDENCIA_DEPENDIENTE_DE_CONVENCION` (requiere una convención Lucidchart aprobada). Los estados normativos de resultado siguen siendo únicamente Cumple, No cumple, No verificable y No aplica.

**Cobertura de población** (tercer atributo, independiente de los dos anteriores y de los cuatro estados de resultado): `COMPLETA`, `PRINCIPAL` (sólo el componente principal), `SUBPOBLACION`, `PARCIAL`, `NINGUNA`. **Condiciones globales:** C-02 (paquete cerrado y versionado) y C-03 (cobertura/issue→regla) afectan a todas las reglas y no se repiten por regla.

**Verificabilidad hoy** (columna técnica): `VERIFICABLE_HOY` (Cumple y No cumple son alcanzables en casos reales con la evidencia publicada), `VERIFICABLE_PARCIAL` (sólo parte de los estados o de la población), `CON_BRECHA` (la evidencia necesaria no se publica o no existe), `PENDIENTE_NORMATIVO`.

## Principios generales de la analista (literales)

Del `00-procedimiento.md` de la analista. Son norma general; no se han añadido criterios por procedimiento.

#### 2. Controles previos de integridad

Antes de evaluar una página, comprobar que:

- los identificadores sean únicos;
- las referencias apunten a componentes existentes;
- la contención no tenga ciclos;
- el padre inmediato sea coherente con la cadena de ancestros;
- los participantes de las conexiones existan;
- los conflictos y pérdidas estén registrados en `issues`.

Las inconsistencias del JSON no son incumplimientos arquitectónicos. Las reglas afectadas se evalúan como **No verificable**.

#### 8. Estados

- **Cumple:** toda la obligación aplicable está demostrada.
- **No cumple:** existe al menos un incumplimiento certificado.
- **No verificable:** falta evidencia para confirmar cumplimiento o demostrar incumplimiento.
- **No aplica:** la regla está fuera de población o se cumple una exclusión expresa de la propia regla.

Prioridad:

1. Si existe un incumplimiento certificado: **No cumple**.
2. Si no hay incumplimiento, pero queda una condición sin resolver: **No verificable**.
3. Si todas las condiciones aplicables están demostradas: **Cumple**.
4. Si no hay población ni candidatos, o existe una exclusión expresa: **No aplica**.

Una ausencia solo produce **No cumple** cuando la cobertura demuestra que el elemento obligatorio realmente no existe. Un candidato pendiente impide declarar **No aplica** si podría pertenecer a la población.

#### 10. Métricas

`Cumple / (Cumple + No cumple + No verificable) × 100`

- Excluir No aplica del denominador.
- Si el denominador es cero, informar no calculable.
- Consolidar sumando evaluaciones regla-página aplicables.
- No promediar porcentajes de páginas.
- El total debe coincidir con los IDs activos del catálogo vigente.

## Condiciones globales abiertas

- **C-03** definición de «cobertura completa/suficiente» y tabla issue→regla (aplica a casi todas las reglas; mientras no exista, No cumple por ausencia sólo con cobertura demostrada y, si no, No verificable con causa).
- **C-09** listas cerradas para los juicios «específico», «genérico», «plantilla», idioma e infinitivo.
- **C-11** lote de erratas y precisiones editoriales (incluye la presentación de páginas plantilla, ver nota R-07 en `DECISIONES_Y_PRUEBAS_PENDIENTES.md`).
- El `SKILL.md` de la analista pide «37 resultados por página seleccionada»; la decisión previa de Andrés (R-07) excluye de la evaluación las páginas plantilla/leyenda. No es una contradicción de métrica (No aplica sale del denominador) sino de presentación; queda como confirmación no bloqueante.

## Índice

| ID | Nombre | Definición normativa | Evidencia (principal) | Verificabilidad hoy | Decisiones |
|---|---|---|---|---|---|
| CNT-001 | Contenedores padre requeridos | NORMATIVAMENTE_DEFINIDA | EVIDENCIA_PARCIAL | VERIFICABLE_PARCIAL | — |
| CNT-002 | Existencia, nombre y ubicación del contenedor hijo principal | NORMATIVAMENTE_DEFINIDA | EVIDENCIA_PARCIAL | VERIFICABLE_PARCIAL | C-09 |
| CNT-003 | Contenido permitido en INTEGRACIÓN | NORMATIVAMENTE_CONDICIONADA | EVIDENCIA_PARCIAL | VERIFICABLE_PARCIAL | C-06, C-11 |
| CNT-004 | Contenido permitido en DOMINIO PRODUCTOR | NORMATIVAMENTE_CONDICIONADA | EVIDENCIA_PARCIAL | VERIFICABLE_PARCIAL | C-06, C-11 |
| CNT-005 | Contenido permitido en SISTEMAS EXTERNOS | NORMATIVAMENTE_CONDICIONADA | EVIDENCIA_PARCIAL | VERIFICABLE_PARCIAL | C-06, C-10 |
| EXT-001 | Identificación y contenido del sistema externo auxiliar | NORMATIVAMENTE_DEFINIDA | EVIDENCIA_PARCIAL | VERIFICABLE_PARCIAL | C-10 |
| EXT-002 | Ubicación de sistemas externos auxiliares EVC, EPC o LDC | NORMATIVAMENTE_DEFINIDA | EVIDENCIA_PARCIAL | VERIFICABLE_PARCIAL | C-04, C-11 |
| GW-001 | Coherencia textual de los caminos de la compuerta | NORMATIVAMENTE_DEFINIDA | EVIDENCIA_DISPONIBLE | VERIFICABLE_HOY | C-09 |
| API-001 | Nombramiento y versión de API | NORMATIVAMENTE_DEFINIDA | EVIDENCIA_PARCIAL | VERIFICABLE_PARCIAL | C-04, C-09 |
| API-002 | Operación de API | NORMATIVAMENTE_DEFINIDA | EVIDENCIA_PARCIAL | VERIFICABLE_PARCIAL | C-04, C-09 |
| API-003 | Tipo y modelo de servicio de API | NORMATIVAMENTE_DEFINIDA | EVIDENCIA_PARCIAL | VERIFICABLE_PARCIAL | C-04, C-09, C-11 |
| API-004 | Capa de Despliegue de la API principal | NORMATIVAMENTE_DEFINIDA | EVIDENCIA_PARCIAL | VERIFICABLE_HOY | C-11 |
| SRV-001 | Nombramiento y versión opcional de servicio | NORMATIVAMENTE_PENDIENTE | EVIDENCIA_AMBIGUA | PENDIENTE_NORMATIVO | C-01 |
| SRV-002 | Operación del servicio | NORMATIVAMENTE_PENDIENTE | EVIDENCIA_AMBIGUA | PENDIENTE_NORMATIVO | C-01 |
| SRV-003 | Modelo del servicio invocado | NORMATIVAMENTE_CONDICIONADA | EVIDENCIA_NO_PUBLICADA | CON_BRECHA | C-04, C-05, C-09, C-11 |
| SRV-004 | Detalle de despliegue del servicio principal | NORMATIVAMENTE_DEFINIDA | EVIDENCIA_PARCIAL | VERIFICABLE_HOY | — |
| EVT-001 | Nombramiento y versión del evento de integración | NORMATIVAMENTE_DEFINIDA | EVIDENCIA_DEPENDIENTE_DE_CONVENCION | CON_BRECHA | C-04, C-06, C-09 |
| EVT-002 | Operación del evento de integración | NORMATIVAMENTE_DEFINIDA | EVIDENCIA_DEPENDIENTE_DE_CONVENCION | CON_BRECHA | C-04, C-06, C-09 |
| EVT-003 | Tipo y clasificación del evento de integración | NORMATIVAMENTE_DEFINIDA | EVIDENCIA_DEPENDIENTE_DE_CONVENCION | CON_BRECHA | C-04, C-06 |
| EVT-004 | Capa de Tópicos del evento de integración | NORMATIVAMENTE_DEFINIDA | EVIDENCIA_DEPENDIENTE_DE_CONVENCION | CON_BRECHA | C-06 |
| EVT-005 | Cantidad y roles de tópicos | NORMATIVAMENTE_DEFINIDA | EVIDENCIA_DEPENDIENTE_DE_CONVENCION | CON_BRECHA | C-06, C-11 |
| EVT-006 | Nombramiento de tópicos | NORMATIVAMENTE_DEFINIDA | EVIDENCIA_DEPENDIENTE_DE_CONVENCION | CON_BRECHA | C-06, C-11 |
| EVT-007 | Conexiones del evento de integración | NORMATIVAMENTE_DEFINIDA | EVIDENCIA_NO_EXISTENTE_EN_ORIGINAL | CON_BRECHA | C-06, C-07, C-11 |
| CA-001 | Nombramiento de Capa de Arquitectura | NORMATIVAMENTE_DEFINIDA | EVIDENCIA_PARCIAL | VERIFICABLE_HOY | — |
| FT-001 | Nombramiento de Flujo Transaccional | NORMATIVAMENTE_DEFINIDA | EVIDENCIA_PARCIAL | VERIFICABLE_HOY | — |
| E1-001 | Estructura integral E1 | NORMATIVAMENTE_CONDICIONADA | EVIDENCIA_NO_EXISTENTE_EN_ORIGINAL | CON_BRECHA | C-07, C-08 |
| E2-001 | Estructura integral E2 | NORMATIVAMENTE_CONDICIONADA | EVIDENCIA_NO_EXISTENTE_EN_ORIGINAL | CON_BRECHA | C-07, C-08 |
| E3-001 | Estructura integral E3 | NORMATIVAMENTE_CONDICIONADA | EVIDENCIA_NO_EXISTENTE_EN_ORIGINAL | CON_BRECHA | C-07, C-08 |
| MOD-001 | Modelos de entrada y salida | NORMATIVAMENTE_CONDICIONADA | EVIDENCIA_PARCIAL | VERIFICABLE_PARCIAL | C-13 |
| COM-001 | Nombramiento de comandos | NORMATIVAMENTE_DEFINIDA | EVIDENCIA_PARCIAL | VERIFICABLE_PARCIAL | C-09, C-12 |
| COM-002 | Conexión entre comando y API invocada | NORMATIVAMENTE_CONDICIONADA | EVIDENCIA_NO_PUBLICADA | CON_BRECHA | C-04, C-05 |
| COM-003 | Conexión entre comando y servicio invocado | NORMATIVAMENTE_CONDICIONADA | EVIDENCIA_NO_PUBLICADA | CON_BRECHA | C-04, C-05 |
| COM-004 | Conexión entre comando y gestor de colas | NORMATIVAMENTE_DEFINIDA | EVIDENCIA_DISPONIBLE | VERIFICABLE_PARCIAL | — |
| COM-005 | Conexión entre comando y sistema externo auxiliar | NORMATIVAMENTE_CONDICIONADA | EVIDENCIA_PARCIAL | VERIFICABLE_PARCIAL | C-12 |
| MQ-001 | Identificación y nombramiento del gestor de colas | NORMATIVAMENTE_DEFINIDA | EVIDENCIA_DISPONIBLE | VERIFICABLE_PARCIAL | C-09 |
| MQ-002 | Capa de Despliegue del gestor de colas | NORMATIVAMENTE_DEFINIDA | EVIDENCIA_DEPENDIENTE_DE_CONVENCION | VERIFICABLE_PARCIAL | C-06 |
| MQ-003 | Conexiones del gestor de colas | NORMATIVAMENTE_CONDICIONADA | EVIDENCIA_NO_EXISTENTE_EN_ORIGINAL | CON_BRECHA | C-04, C-05, C-07 |

---

## CNT-001 — Contenedores padre requeridos

| Campo | Valor |
|---|---|
| ID vigente | CNT-001 |
| ID histórico relacionado | CNT-001 |
| Estado de definición normativa | NORMATIVAMENTE_DEFINIDA |
| Estado de evidencia | EVIDENCIA_PARCIAL (+ EVIDENCIA_AMBIGUA) |
| Verificabilidad hoy | VERIFICABLE_PARCIAL |
| Cobertura de población | PARCIAL — Patrón identificable sólo con la estructura E1–E3 completa; dominios por nombre reservado o rol certificado. |
| Condiciones globales | C-02, C-03 |
| Procedencia | Analista · 01-reglas-estructura.md · CNT-001; decisiones aplicables: R-05, R-08, R-20; histórico: CNT-001 |

### A. Texto normativo (literal de la analista)

**Resumen oficial:** Valida la existencia de los dominios arquitectónicos obligatorios según el patrón estructural E1, E2 o E3 aplicable a la página.

**Población (Aplica a):** Páginas evaluables en las que pueda determinarse un patrón estructural E1, E2 o E3, aunque el cumplimiento integral del escenario no esté confirmado.

**Obligación (Criterio):** En E1 deben existir al menos un dominio de INTEGRACIÓN y un DOMINIO PRODUCTOR; en E2 debe existir al menos un dominio de INTEGRACIÓN; y en E3 debe existir al menos un DOMINIO PRODUCTOR. Puede existir más de un dominio del mismo tipo. Los dominios opcionales y su ausencia no afectan al cumplimiento. La regla evalúa exclusivamente la existencia y clasificación de los dominios obligatorios, independientemente de que tengan un nombre literal, derivado o personalizado; no evalúa su contenido, las relaciones de contención de sus componentes ni las demás condiciones necesarias para confirmar integralmente el escenario.

**Evidencia mínima:** Patrón estructural E1, E2 o E3 determinado e inventario completo de contenedores padre. Los dominios obligatorios deben tener una clasificación arquitectónica certificada. Los nombres personalizados son válidos siempre que exista evidencia suficiente para clasificar el dominio como INTEGRACIÓN o DOMINIO PRODUCTOR, según corresponda.

- **Cumple:** Puede determinarse el patrón estructural aplicable y existen todos los dominios arquitectónicos obligatorios para dicho patrón, con clasificación certificada.
- **No cumple:** Puede determinarse el patrón estructural aplicable, la cobertura del inventario es completa y se demuestra la ausencia de al menos uno de los dominios arquitectónicos obligatorios.
- **No verificable:** No existe evidencia suficiente para determinar el patrón estructural aplicable; el inventario de contenedores no tiene cobertura suficiente; o existe una clasificación indeterminada, ambigua o contradictoria que impide confirmar la existencia de un dominio obligatorio. La falta de certificación de otras condiciones del escenario, como el subtipo Inicio de un evento BPMN, no afecta por sí sola la evaluación de esta regla.
- **No aplica:** La página no es evaluable porque corresponde exclusivamente a una plantilla o leyenda, o no contiene una estructura susceptible de corresponder a E1, E2 o E3.

### B. Interpretación técnica (no normativa)

- **Aplicabilidad (síntesis):** Páginas evaluables con patrón E1/E2/E3 identificable (no exige escenario confirmado). No aplica: solo plantilla/leyenda o sin estructura E1-E3.
- **Dependencias:** Independiente de E1/E2/E3-001 y del subtipo Inicio. Usa la definición de cobertura (C-03).
- **Conflictos:** Ninguno entre archivos. El patrón y el dominio PRODUCER inferido salen del mismo camino (nota técnica, R-05).
- **Preguntas necesarias:** Ninguna a la analista.

### C. Evidencia y decisiones

- **Origen en Lucidchart:** Contenedores `UMLRectangleContainerBlock` con nombre (INTEGRACIÓN, DOMINIO PRODUCTOR, SISTEMAS EXTERNOS) o `customData` DOMAIN_ROLE.
- **Campo JSON existente:** `scenario`, `components[].architecturalDomain`, `domainRole`, `possibleDomainRoles`, `issues`
- **Suficiencia:** Suficiente para dominios por nombre reservado o por estructura con procedencia (Cumple). La ausencia de un dominio obligatorio no se demuestra hoy: el motor no publica el patrón cuando falta un dominio o el hijo (misma brecha que CNT-002, EC-11); queda No verificable.
- **Brecha:** G-7: dominio con nombre propio sin resolver (1 caso real); cobertura no definida (C-03).
- **Decisiones abiertas (específicas de la regla):** —

---

## CNT-002 — Existencia, nombre y ubicación del contenedor hijo principal

| Campo | Valor |
|---|---|
| ID vigente | CNT-002 |
| ID histórico relacionado | CNT-002 |
| Estado de definición normativa | NORMATIVAMENTE_DEFINIDA |
| Estado de evidencia | EVIDENCIA_PARCIAL (+ EVIDENCIA_AMBIGUA) |
| Verificabilidad hoy | VERIFICABLE_PARCIAL |
| Cobertura de población | PARCIAL — Nombre y dominio del hijo único certificables; «no existe» / «existe más de uno» / «dominio distinto» no se demuestran hoy (ver INVESTIGACION_CNT002). |
| Condiciones globales | C-02, C-03 |
| Procedencia | Analista · 01-reglas-estructura.md · CNT-002; decisiones aplicables: R-02, R-03, R-05, R-20; histórico: CNT-002 |

### A. Texto normativo (literal de la analista)

**Resumen oficial:** Valida que exista un único contenedor hijo principal, que tenga un nombre específico y que esté ubicado en el dominio arquitectónico correspondiente al patrón estructural aplicable.

**Población (Aplica a):** Páginas evaluables con una estructura susceptible de corresponder a E1, E2 o E3, aunque el cumplimiento integral del escenario no esté confirmado.

**Obligación (Criterio):** Debe existir un único contenedor hijo principal por página. El hijo debe tener un nombre visible, funcional y específico que permita identificar el servicio que representa; no se admiten nombres ausentes, vacíos, genéricos ni textos de plantilla. No se exige un formato, idioma, versión, capitalización ni estructura de palabras particular.

En E1 y E3, el hijo principal debe estar ubicado en el DOMINIO PRODUCTOR; en E2, debe estar ubicado en INTEGRACIÓN. La regla no evalúa los componentes contenidos en el hijo, su condición de gestionado o no gestionado, los eventos BPMN de su interior, sus modelos internos ni las demás condiciones necesarias para confirmar integralmente el escenario.

**Evidencia mínima:** Patrón estructural E1, E2 o E3 identificable, inventario completo de contenedores, identificación certificada de un único contenedor hijo principal, texto completo de su nombre y clasificación certificada del dominio arquitectónico en el que está ubicado. No se requiere identificar ni certificar un evento BPMN de Inicio para evaluar esta regla.

- **Cumple:** Puede determinarse el patrón estructural aplicable, existe un único contenedor certificado como hijo principal, tiene un nombre visible, funcional, específico y diferente de un texto de plantilla, y está ubicado en el dominio arquitectónico exigido por dicho patrón.
- **No cumple:** El patrón estructural aplicable y la cobertura del inventario están certificados, y se demuestra al menos una de las siguientes situaciones: no existe un contenedor hijo principal; existe más de uno; el único hijo principal está ubicado en un dominio arquitectónico diferente del exigido; o su nombre está ausente, vacío, compuesto únicamente por espacios, es genérico o corresponde a un texto de plantilla.
- **No verificable:** No existe evidencia suficiente para determinar el patrón estructural aplicable; el inventario no tiene cobertura suficiente; no puede certificarse cuál es el hijo principal; existen varios candidatos sin que pueda determinarse cuál cumple ese rol; el texto de su nombre no está disponible o está incompleto por pérdida de evidencia; no puede determinarse razonablemente si el nombre es específico o de plantilla; o la ubicación o clasificación de su dominio arquitectónico es indeterminada, ambigua o contradictoria. La falta de certificación del subtipo Inicio de un evento BPMN no afecta la evaluación de esta regla. Si existe al menos un incumplimiento certificado, prevalece **No cumple** aunque otra condición sea no verificable.
- **No aplica:** La página no es evaluable porque corresponde exclusivamente a una plantilla o leyenda, o no contiene componentes ni candidatos pendientes que puedan configurar un hijo principal de E1, E2 o E3.

### B. Interpretación técnica (no normativa)

- **Aplicabilidad (síntesis):** Páginas evaluables con estructura susceptible de E1/E2/E3. No aplica: plantilla/leyenda o sin componentes ni candidatos a hijo.
- **Dependencias:** Independiente del Inicio. Alimenta SRV-004, E1/E2/E3-001 y MOD-001 (hijo principal).
- **Conflictos:** F-13 («gestionado/no gestionado») retirado por el texto.
- **Preguntas necesarias:** Ninguna.

### C. Evidencia y decisiones

- **Origen en Lucidchart:** Contenedor `RectangleContainerBlock` (hijo) con texto de nombre.
- **Campo JSON existente:** `scenario.mainChildServiceId`, `components[role=HIJO_PRINCIPAL].name/textAreas/architecturalDomain/structuralParent/containerChainIds`
- **Suficiencia:** Nombre ausente/vacío/genérico/plantilla y dominio del hijo único: certificables con patrón E1–E3 identificado (también con escenario HIPOTESIS). «No existe hijo», «más de uno» y «dominio distinto»: el motor no publica el patrón cuando el hijo es defectuoso (brecha del extractor).
- **Brecha:** B: el motor deriva patrón e hijo principal por el mismo camino (`NO_COMPLETE_STRUCTURAL_ROLE_CANDIDATE` / `MULTIPLE_STRUCTURAL_CANDIDATES`), por lo que un hijo ausente, duplicado o en dominio distinto deja el patrón sin identificar y la regla en No verificable. D: la norma no precisa cómo se identifica el patrón cuando el hijo es defectuoso. Sin dependencia del Inicio.
- **Decisiones abiertas (específicas de la regla):** C-09

---

## CNT-003 — Contenido permitido en INTEGRACIÓN

| Campo | Valor |
|---|---|
| ID vigente | CNT-003 |
| ID histórico relacionado | CNT-003; absorbe: MQ-002 antiguo (Ubicación del gestor; retirada) |
| Estado de definición normativa | NORMATIVAMENTE_CONDICIONADA |
| Estado de evidencia | EVIDENCIA_PARCIAL (+ EVIDENCIA_NO_PUBLICADA, EVIDENCIA_DEPENDIENTE_DE_CONVENCION) |
| Verificabilidad hoy | VERIFICABLE_PARCIAL |
| Cobertura de población | PARCIAL — Componentes con clase o nombre reservado identificable; el resto queda sin tipo. |
| Condiciones globales | C-02, C-03 |
| Procedencia | Analista · 01-reglas-estructura.md · CNT-003; decisiones aplicables: R-13; histórico: CNT-003; absorbe: MQ-002 antiguo (Ubicación del gestor; retirada) |

### A. Texto normativo (literal de la analista)

**Resumen oficial:** Valida que los componentes ubicados en INTEGRACIÓN correspondan al contenido permitido para el nivel padre y, cuando exista un hijo principal dentro de este dominio, para el nivel hijo.

**Población (Aplica a):** Dominios clasificados como INTEGRACIÓN y sus componentes contenidos, exista o no un contenedor hijo principal.

**Obligación (Criterio):** En el nivel padre de INTEGRACIÓN se permiten API, eventos de integración de tipo Aplicación o Empresarial, servicios, modelos de entrada, modelos de salida, conceptos, pendientes, gestores de colas, sistemas externos auxiliares, anotaciones y capas de despliegue MCI o Federado. No se permiten compuertas, eventos BPMN operativos, políticas ni comandos. Cuando INTEGRACIÓN contenga un hijo principal, dentro de este se permiten compuertas, eventos BPMN operativos, modelos de entrada, modelos de salida, conceptos, pendientes, políticas, comandos y anotaciones; no se permiten API, eventos de integración de tipo Aplicación o Empresarial, servicios, gestores de colas, sistemas externos auxiliares ni capas de despliegue MCI o Federado. Los componentes encapsulados dentro de un sistema externo auxiliar se excluyen de esta regla y se evalúan mediante EXT-001.

**Evidencia mínima:** Identificación certificada del dominio de INTEGRACIÓN, inventario completo de sus componentes, identificación del hijo principal cuando exista, jerarquía estructural suficiente para establecer si cada componente está en el nivel padre, dentro del hijo principal o encapsulado dentro de un sistema externo auxiliar, y clasificación certificada de los componentes evaluados. Para los eventos BPMN operativos no se requiere determinar si corresponden específicamente a Inicio, Fin, Señal, Mensaje, Excepción, Mensaje de Excepción u otro subtipo cuando dicha información no esté disponible.

- **Cumple:** La clasificación de INTEGRACIÓN y la cobertura de su contenido están certificadas, y todos los componentes evaluados están permitidos en el nivel en el que se encuentran: nivel padre o nivel hijo. Los componentes encapsulados dentro de sistemas externos auxiliares no se consideran para este resultado.
- **No cumple:** La clasificación de INTEGRACIÓN y la cobertura de su contenido están certificadas, y existe al menos un componente con clasificación certificada ubicado en un nivel en el que no está permitido. El contenido interno de un sistema externo auxiliar no genera incumplimiento en esta regla.
- **No verificable:** Existe uno o más contenedores que podrían corresponder a INTEGRACIÓN, pero su clasificación es indeterminada, ambigua o contradictoria; el contenido del dominio no tiene cobertura suficiente; no puede determinarse si un componente está en el nivel padre, dentro del hijo principal o dentro de un sistema externo auxiliar; o la clasificación de algún componente es indeterminada, ambigua o contradictoria y sus posibles clasificaciones incluyen categorías permitidas y no permitidas para su ubicación. La imposibilidad de determinar el subtipo específico de un evento BPMN operativo no genera por sí sola este estado cuando puede certificarse que no corresponde a un evento de integración.
- **No aplica:** Se ha certificado que la página no contiene un dominio de INTEGRACIÓN ni contenedores pendientes de clasificación que puedan corresponder a este dominio.

### B. Interpretación técnica (no normativa)

- **Aplicabilidad (síntesis):** Dominios clasificados como INTEGRACIÓN (o contenedores que podrían serlo). No aplica: se certifica que no hay.
- **Dependencias:** EXT-001 evalúa el contenido de los auxiliares. Necesita el hijo principal (CNT-002) para el nivel hijo.
- **Conflictos:** El hijo principal no figura en la lista del nivel padre aunque la regla lo presupone (C-11).
- **Preguntas necesarias:** Ninguna.

### C. Evidencia y decisiones

- **Origen en Lucidchart:** Figuras de distintas clases dentro de `UMLRectangleContainerBlock` INTEGRACIÓN: `UMLClassBlock`, `UMLActiveClassBlock`, `BPMNGroup`, `BPMNGateway`, `BPMNActivity`, `BPMNEvent`, `BPMNTextAnnotation`, `DefaultSquareBlock`.
- **Campo JSON existente:** `components[].lucidchartType/architecturalType/structuralParent/containerChainIds/architecturalDomain/domainRole`
- **Suficiencia:** No cumple alcanzable con categorías identificables por clase; Cumple exige clasificar todo y casi siempre queda No verificable.
- **Brecha:** Sin tipo: evento de integración, concepto, pendiente, política, comando, modelo fiable (G-3).
- **Decisiones abiertas (específicas de la regla):** C-06, C-11

---

## CNT-004 — Contenido permitido en DOMINIO PRODUCTOR

| Campo | Valor |
|---|---|
| ID vigente | CNT-004 |
| ID histórico relacionado | CNT-004; absorbe: MQ-002 antiguo (Ubicación del gestor; retirada) |
| Estado de definición normativa | NORMATIVAMENTE_CONDICIONADA |
| Estado de evidencia | EVIDENCIA_PARCIAL (+ EVIDENCIA_NO_PUBLICADA, EVIDENCIA_DEPENDIENTE_DE_CONVENCION) |
| Verificabilidad hoy | VERIFICABLE_PARCIAL |
| Cobertura de población | PARCIAL — Ídem CNT-003. |
| Condiciones globales | C-02, C-03 |
| Procedencia | Analista · 01-reglas-estructura.md · CNT-004; decisiones aplicables: R-02; histórico: CNT-004; absorbe: MQ-002 antiguo (Ubicación del gestor; retirada) |

### A. Texto normativo (literal de la analista)

**Resumen oficial:** Valida que los componentes ubicados en el DOMINIO PRODUCTOR correspondan al contenido permitido para el nivel padre y, cuando exista un hijo principal dentro de este dominio, para el nivel hijo.

**Población (Aplica a):** Dominios clasificados como DOMINIO PRODUCTOR y sus componentes contenidos, exista o no un contenedor hijo principal.

**Obligación (Criterio):** En el nivel padre del DOMINIO PRODUCTOR se permiten eventos de integración de tipo Aplicación o Empresarial, servicios, modelos de entrada, modelos de salida, conceptos, pendientes, gestores de colas, anotaciones y capas de despliegue MCI o Federado. No se permiten API, sistemas externos auxiliares, compuertas, eventos BPMN operativos, políticas ni comandos. Cuando el DOMINIO PRODUCTOR contenga un hijo principal, dentro de este se permiten compuertas, eventos BPMN operativos, modelos de entrada, modelos de salida, conceptos, pendientes, políticas, comandos y anotaciones; no se permiten API, eventos de integración de tipo Aplicación o Empresarial, servicios, gestores de colas, sistemas externos auxiliares ni capas de despliegue MCI o Federado. La regla evalúa la ubicación de los componentes según el nivel en el que se encuentran, sin exigir la identificación del subtipo específico de los eventos BPMN operativos cuando la evidencia disponible no permita determinarlo.

**Evidencia mínima:** Identificación certificada del DOMINIO PRODUCTOR, inventario completo de sus componentes, identificación del hijo principal cuando exista, jerarquía estructural suficiente para establecer si cada componente está fuera o dentro del hijo y clasificación certificada de los componentes evaluados. Para los eventos BPMN operativos no se requiere determinar si corresponden específicamente a Inicio, Fin, Señal, Mensaje, Excepción, Mensaje de Excepción u otro subtipo cuando dicha información no esté disponible.

- **Cumple:** La clasificación del DOMINIO PRODUCTOR y la cobertura de su contenido están certificadas, y todos sus componentes están permitidos en el nivel en el que se encuentran: nivel padre o nivel hijo.
- **No cumple:** La clasificación del DOMINIO PRODUCTOR y la cobertura de su contenido están certificadas, y existe al menos un componente con clasificación certificada ubicado en un nivel en el que no está permitido.
- **No verificable:** Existe uno o más contenedores que podrían corresponder al DOMINIO PRODUCTOR, pero su clasificación es indeterminada, ambigua o contradictoria; el contenido del dominio no tiene cobertura suficiente; no puede determinarse si un componente está fuera o dentro del hijo principal; o la clasificación de algún componente es indeterminada, ambigua o contradictoria y sus posibles clasificaciones incluyen categorías permitidas y prohibidas para el nivel en el que se encuentra. La imposibilidad de determinar el subtipo específico de un evento BPMN operativo no genera por sí sola este estado cuando puede certificarse que no corresponde a un evento de integración.
- **No aplica:** Se ha certificado que la página no contiene un DOMINIO PRODUCTOR ni contenedores pendientes de clasificación que puedan corresponder a este dominio.

### B. Interpretación técnica (no normativa)

- **Aplicabilidad (síntesis):** Dominios clasificados como DOMINIO PRODUCTOR. No aplica: se certifica que no hay.
- **Dependencias:** Igual que CNT-003.
- **Conflictos:** Igual que CNT-003.
- **Preguntas necesarias:** Ninguna.

### C. Evidencia y decisiones

- **Origen en Lucidchart:** Ídem CNT-003 dentro del dominio productor (nombre reservado o inferido).
- **Campo JSON existente:** Ídem CNT-003
- **Suficiencia:** Ídem CNT-003.
- **Brecha:** Ídem CNT-003.
- **Decisiones abiertas (específicas de la regla):** C-06, C-11

---

## CNT-005 — Contenido permitido en SISTEMAS EXTERNOS

| Campo | Valor |
|---|---|
| ID vigente | CNT-005 |
| ID histórico relacionado | CNT-005; absorbe: MQ-002 antiguo (Ubicación del gestor; retirada) |
| Estado de definición normativa | NORMATIVAMENTE_CONDICIONADA |
| Estado de evidencia | EVIDENCIA_PARCIAL (+ EVIDENCIA_NO_PUBLICADA, EVIDENCIA_DEPENDIENTE_DE_CONVENCION) |
| Verificabilidad hoy | VERIFICABLE_PARCIAL |
| Cobertura de población | PARCIAL — Ídem CNT-003; auxiliares por BPMNGroup con nombre. |
| Condiciones globales | C-02, C-03 |
| Procedencia | Analista · 01-reglas-estructura.md · CNT-005; decisiones aplicables: R-13; histórico: CNT-005; absorbe: MQ-002 antiguo (Ubicación del gestor; retirada) |

### A. Texto normativo (literal de la analista)

**Resumen oficial:** Valida que los componentes ubicados directamente en SISTEMAS EXTERNOS correspondan al contenido permitido para este dominio.

**Población (Aplica a):** Dominios clasificados como SISTEMAS EXTERNOS y a los componentes contenidos directamente en ellos.

**Obligación (Criterio):** En SISTEMAS EXTERNOS se permiten API, servicios, modelos de entrada, modelos de salida, pendientes, conceptos, sistemas externos auxiliares y anotaciones. No se permiten eventos de integración de tipo Aplicación o Empresarial, gestores de colas, capas de despliegue MCI o Federado, compuertas, eventos BPMN operativos, políticas ni comandos. Los componentes encapsulados dentro de un sistema externo auxiliar se excluyen de esta regla y se evalúan mediante EXT-001.

**Evidencia mínima:** Identificación certificada del dominio de SISTEMAS EXTERNOS, inventario completo de sus componentes, jerarquía estructural suficiente para diferenciar los componentes ubicados directamente en el dominio de aquellos encapsulados dentro de un sistema externo auxiliar, y clasificación certificada de los componentes evaluados. Para los eventos BPMN operativos no se requiere determinar si corresponden específicamente a Inicio, Fin, Señal, Mensaje, Excepción, Mensaje de Excepción u otro subtipo cuando dicha información no esté disponible.

- **Cumple:** La clasificación del dominio de SISTEMAS EXTERNOS y la cobertura de su contenido están certificadas, y todos los componentes evaluados corresponden a categorías permitidas. Los componentes encapsulados dentro de sistemas externos auxiliares no se consideran para este resultado.
- **No cumple:** La clasificación del dominio de SISTEMAS EXTERNOS y la cobertura de su contenido están certificadas, y existe al menos un componente con clasificación certificada ubicado directamente en el dominio que corresponde a una categoría no permitida. El contenido interno de un sistema externo auxiliar no genera incumplimiento en esta regla.
- **No verificable:** Existe uno o más contenedores que podrían corresponder a SISTEMAS EXTERNOS, pero su clasificación es indeterminada, ambigua o contradictoria; el contenido del dominio no tiene cobertura suficiente; no puede determinarse si un componente está ubicado directamente en el dominio o encapsulado dentro de un sistema externo auxiliar; o la clasificación de algún componente es indeterminada, ambigua o contradictoria y sus posibles clasificaciones incluyen categorías permitidas y no permitidas. La imposibilidad de determinar el subtipo específico de un evento BPMN operativo no genera por sí sola este estado cuando puede certificarse que no corresponde a un evento de integración.
- **No aplica:** Se ha certificado que la página no contiene un dominio de SISTEMAS EXTERNOS ni contenedores pendientes de clasificación que puedan corresponder a este dominio.

### B. Interpretación técnica (no normativa)

- **Aplicabilidad (síntesis):** Dominios SISTEMAS EXTERNOS y sus componentes directos. No aplica: se certifica que no hay.
- **Dependencias:** EXT-001 para el contenido de auxiliares.
- **Conflictos:** Un gestor externo no tiene ubicación válida (reversión de la regla anterior, C-10).
- **Preguntas necesarias:** Ninguna.

### C. Evidencia y decisiones

- **Origen en Lucidchart:** Ídem CNT-003 dentro de `UMLRectangleContainerBlock` SISTEMAS EXTERNOS.
- **Campo JSON existente:** Ídem CNT-003
- **Suficiencia:** Ídem CNT-003.
- **Brecha:** Ídem CNT-003.
- **Decisiones abiertas (específicas de la regla):** C-06, C-10

---

## EXT-001 — Identificación y contenido del sistema externo auxiliar

| Campo | Valor |
|---|---|
| ID vigente | EXT-001 |
| ID histórico relacionado | EXT-001; absorbe: MQ-002 antiguo (Ubicación del gestor; retirada) |
| Estado de definición normativa | NORMATIVAMENTE_DEFINIDA |
| Estado de evidencia | EVIDENCIA_PARCIAL (+ EVIDENCIA_NO_PUBLICADA) |
| Verificabilidad hoy | VERIFICABLE_PARCIAL |
| Cobertura de población | PARCIAL — Auxiliares (BPMNGroup con nombre); su contenido sólo por clase de figura. |
| Condiciones globales | C-02, C-03 |
| Procedencia | Analista · 01-reglas-estructura.md · EXT-001; decisiones aplicables: R-13; histórico: EXT-001; absorbe: MQ-002 antiguo (Ubicación del gestor; retirada) |

### A. Texto normativo (literal de la analista)

**Resumen oficial:** Valida que cada sistema externo auxiliar tenga un nombre y encapsule únicamente componentes permitidos.

**Población (Aplica a):** Componentes certificados como sistemas externos auxiliares, independientemente del nombre visible utilizado para identificarlos.

**Obligación (Criterio):** Todo sistema externo auxiliar debe tener un nombre visible y no vacío; se admite cualquier nombre, incluido “Sistema Externo”. Puede encapsular API, servicios, pendientes, conceptos y anotaciones. También puede encapsular capas de despliegue MCI o Federado, pero únicamente cuando el auxiliar esté ubicado en el nivel padre de INTEGRACIÓN. Cualquier otro tipo de componente está prohibido. Un componente identificado únicamente como BPMNEvent no debe considerarse automáticamente permitido ni prohibido, debido a que su función específica no puede determinarse a partir de la figura. La regla evalúa el nombre y el contenido encapsulado por el auxiliar, pero no las conexiones que llegan al auxiliar o a sus componentes internos.

**Evidencia mínima:** Identificación certificada del sistema externo auxiliar, texto completo de su nombre, inventario completo de los componentes encapsulados, clasificación certificada de dichos componentes y ubicación estructural certificada del auxiliar cuando contenga una capa de despliegue MCI o Federado.

- **Cumple:** El sistema externo auxiliar tiene un nombre visible y no vacío, encapsula al menos un componente y todos los componentes encapsulados están permitidos. Si contiene una capa de despliegue MCI o Federado, está certificado que el auxiliar se encuentra en el nivel padre de INTEGRACIÓN.
- **No cumple:** La evidencia y la cobertura están certificadas, y se presenta al menos una de las siguientes situaciones: el nombre del auxiliar está ausente, vacío o compuesto únicamente por espacios; contiene un componente certificado en una categoría no permitida; o contiene una capa de despliegue MCI o Federado sin estar ubicado en el nivel padre de INTEGRACIÓN.
- **No verificable:** No puede determinarse si el auxiliar tiene un nombre debido a evidencia textual incompleta; el auxiliar no encapsula componentes o no puede certificarse si encapsula alguno; el inventario de su contenido no tiene cobertura suficiente; no puede determinarse la clasificación de uno o más componentes encapsulados y sus posibles clasificaciones incluyen categorías permitidas y prohibidas; se identifica dentro del auxiliar un componente clasificado únicamente como BPMNEvent; o no puede determinarse la ubicación del auxiliar cuando contiene una capa de despliegue MCI o Federado. Requiere revisión manual del analista.
- **No aplica:** La página no contiene componentes certificados como sistemas externos auxiliares ni candidatos pendientes de clasificación como tales.

### B. Interpretación técnica (no normativa)

- **Aplicabilidad (síntesis):** Componentes certificados como auxiliares (`BPMNGroup` con nombre). No aplica: sin auxiliares ni candidatos.
- **Dependencias:** CNT-003/004/005 (ubicación del auxiliar y de su contenido).
- **Conflictos:** Auxiliares reales con `BPMNEvent` y `BPMNActivity` dentro; la regla los prohíbe o los deja en No verificable con «revisión manual del analista» (C-10).
- **Preguntas necesarias:** Posible: qué hace el agente ante «revisión manual» (C-10).

### C. Evidencia y decisiones

- **Origen en Lucidchart:** `BPMNGroup` con nombre; contenido en `contains.shapes`.
- **Campo JSON existente:** `name`, `textAreas`, `architecturalType=SISTEMA_EXTERNO_AUXILIAR`, `containedComponentIds`, `structuralParent`, `containerChainIds`
- **Suficiencia:** Suficiente para nombre, contenido y ubicación; la clasificación del contenido es parcial.
- **Brecha:** Contenido sin tipo (G-3); auxiliar sin nombre no se reconoce (28 `BPMNGroup` sin nombre, todos vacíos).
- **Decisiones abiertas (específicas de la regla):** C-10

---

## EXT-002 — Ubicación de sistemas externos auxiliares EVC, EPC o LDC

| Campo | Valor |
|---|---|
| ID vigente | EXT-002 |
| ID histórico relacionado | — (nueva en nuestro catálogo; el manifiesto la llama «antigua EXT-003») |
| Estado de definición normativa | NORMATIVAMENTE_DEFINIDA |
| Estado de evidencia | EVIDENCIA_PARCIAL (+ EVIDENCIA_NO_PUBLICADA) |
| Verificabilidad hoy | VERIFICABLE_PARCIAL |
| Cobertura de población | PARCIAL — Nombre EVC/EPC/LDC literal; la API encapsulada no es certificable (C-04). |
| Condiciones globales | C-02, C-03 |
| Procedencia | Analista · 01-reglas-estructura.md · EXT-002; decisiones aplicables: —; histórico: — (nueva en nuestro catálogo; el manifiesto la llama «antigua EXT-003») |

### A. Texto normativo (literal de la analista)

**Resumen oficial:** Valida que un sistema externo auxiliar identificado como EVC, EPC o LDC y que encapsule una API esté ubicado en INTEGRACIÓN y no en SISTEMAS EXTERNOS.

**Población (Aplica a):** Sistemas externos auxiliares cuyo nombre contenga EVC, EPC o LDC y que encapsulen al menos un componente certificado como API.

**Obligación (Criterio):** Un sistema externo auxiliar cuyo nombre contenga EVC, EPC o LDC, sin distinguir mayúsculas y minúsculas, y que encapsule al menos una API debe estar ubicado en el nivel padre de INTEGRACIÓN. No puede estar ubicado directamente en SISTEMAS EXTERNOS ni dentro de otro sistema externo auxiliar. La regla evalúa exclusivamente la ubicación del auxiliar; el nombre y el contenido permitido dentro de este se evalúan mediante EXT-001, sus conexiones se evalúan mediante EXT-002 y el nombramiento de la API encapsulada se evalúa mediante API-001.

**Evidencia mínima:** Identificación certificada del sistema externo auxiliar, texto completo de su nombre, identificación certificada de al menos una API encapsulada y jerarquía estructural suficiente para determinar el dominio arquitectónico y el nivel en el que está ubicado el auxiliar.

- **Cumple:** El nombre del auxiliar contiene EVC, EPC o LDC, encapsula al menos una API certificada y está ubicado en el nivel padre de INTEGRACIÓN.
- **No cumple:** El nombre del auxiliar contiene EVC, EPC o LDC, encapsula al menos una API certificada y está ubicado directamente en SISTEMAS EXTERNOS, dentro de otro sistema externo auxiliar o en cualquier ubicación distinta del nivel padre de INTEGRACIÓN.
- **No verificable:** No puede determinarse el nombre completo del auxiliar; no puede establecerse si contiene EVC, EPC o LDC; no puede certificarse que el componente encapsulado sea una API; no puede certificarse que la API esté contenida por el auxiliar; o la ubicación o el dominio arquitectónico del auxiliar es indeterminado, ambiguo o contradictorio.
- **No aplica:** No existen sistemas externos auxiliares cuyo nombre contenga EVC, EPC o LDC y que encapsulen una API certificada. También aplica este estado cuando existen auxiliares con dichas expresiones, pero se certifica que no contienen API.

### B. Interpretación técnica (no normativa)

- **Aplicabilidad (síntesis):** Auxiliares cuyo nombre contenga EVC, EPC o LDC y encapsulen al menos una API certificada. No aplica: no existen, o se certifica que no contienen API.
- **Dependencias:** EXT-001 (nombre y contenido); API-001 (nombramiento de la API encapsulada).
- **Conflictos:** Autorreferencia (`sus conexiones se evalúan mediante EXT-002`); subcadena vs palabra (C-11).
- **Preguntas necesarias:** Ninguna.

### C. Evidencia y decisiones

- **Origen en Lucidchart:** `BPMNGroup` con nombre «EVC …» y una `UMLClassBlock` dentro.
- **Campo JSON existente:** `name`, `containedComponentIds`, `architecturalType`, `structuralParent`, `containerChainIds`, `architecturalDomain`
- **Suficiencia:** La ubicación y el nombre son suficientes (21 auxiliares reales: 15 bajo INTEGRACIÓN y 6 sin dominio resuelto); la API encapsulada no se certifica.
- **Brecha:** G-1: la API encapsulada es `UMLClassBlock` sin tipo.
- **Decisiones abiertas (específicas de la regla):** C-04, C-11

---

## GW-001 — Coherencia textual de los caminos de la compuerta

| Campo | Valor |
|---|---|
| ID vigente | GW-001 |
| ID histórico relacionado | GW-001 |
| Estado de definición normativa | NORMATIVAMENTE_DEFINIDA |
| Estado de evidencia | EVIDENCIA_DISPONIBLE |
| Verificabilidad hoy | VERIFICABLE_HOY |
| Cobertura de población | COMPLETA — Todas las figuras BPMNGateway. |
| Condiciones globales | C-02, C-03 |
| Procedencia | Analista · 01-reglas-estructura.md · GW-001; decisiones aplicables: —; histórico: GW-001 |

### A. Texto normativo (literal de la analista)

**Resumen oficial:** Valida la coherencia entre el texto de una compuerta BPMN y las respuestas o etiquetas de sus caminos conectados.

**Población (Aplica a):** Componentes certificados como compuertas BPMN.

**Obligación (Criterio):** Cuando una compuerta contiene una pregunta o texto de decisión, sus caminos deben incluir respuestas o etiquetas que permitan reconocer de forma coherente las alternativas resultantes. Una pregunta binaria puede utilizar respuestas como “Sí” y “No”; cuando existan más de dos alternativas, cada camino debe tener una etiqueta que permita distinguir la opción que representa. También es válido que una compuerta no tenga texto y que sus caminos no tengan respuestas o etiquetas, siempre que no exista información parcial que requiera relacionarlos. La regla no evalúa el subtipo de la compuerta ni las condiciones BPMN específicas de compuertas paralelas, exclusivas, basadas en eventos o paralelas basadas en eventos.

**Evidencia mínima:** Identificación certificada de la compuerta BPMN, texto completo de la compuerta cuando exista, inventario completo de sus caminos conectados y texto de las respuestas o etiquetas asociadas a dichos caminos. No se requiere identificar el subtipo de la compuerta.

- **Cumple:** La compuerta y sus caminos tienen cobertura suficiente, y se presenta alguna de las siguientes situaciones: la compuerta contiene una pregunta o decisión y sus caminos tienen respuestas o etiquetas coherentes que permiten distinguir las alternativas; o la compuerta no contiene texto y sus caminos tampoco contienen respuestas o etiquetas que requieran interpretación.
- **No cumple:** La evidencia textual y la cobertura de los caminos están certificadas, y las respuestas o etiquetas contradicen el texto de la compuerta, no corresponden a la pregunta planteada o no permiten distinguir los caminos cuando existen varias alternativas que requieren identificación.
- **No verificable:** No puede determinarse el texto completo de la compuerta o de sus caminos; no se tiene cobertura suficiente de las conexiones; la compuerta contiene una pregunta o decisión, pero faltan las respuestas o etiquetas necesarias para interpretar sus alternativas; los caminos contienen respuestas o etiquetas, pero falta el texto que permita establecer su significado; o la información disponible no permite concluir si el conjunto es coherente. La imposibilidad de identificar el subtipo de la compuerta no genera por sí sola este estado.
- **No aplica:** La página no contiene componentes certificados como compuertas BPMN ni candidatos pendientes de clasificación como tales.

### B. Interpretación técnica (no normativa)

- **Aplicabilidad (síntesis):** Compuertas BPMN certificadas. No aplica: sin compuertas ni candidatas.
- **Dependencias:** Ninguna.
- **Conflictos:** Ninguno.
- **Preguntas necesarias:** Ninguna.

### C. Evidencia y decisiones

- **Origen en Lucidchart:** `BPMNGateway` y etiquetas de las líneas de salida.
- **Campo JSON existente:** `lucidchartType=BPMNGateway`, `name`, `textAreas`, `pages[].connections[].textAreas`
- **Suficiencia:** Suficiente (119 compuertas, 2 con texto: el resto cumple sin texto ni etiquetas).
- **Brecha:** La coherencia es un juicio semántico (C-09).
- **Decisiones abiertas (específicas de la regla):** C-09

---

## API-001 — Nombramiento y versión de API

| Campo | Valor |
|---|---|
| ID vigente | API-001 |
| ID histórico relacionado | API-001 |
| Estado de definición normativa | NORMATIVAMENTE_DEFINIDA |
| Estado de evidencia | EVIDENCIA_PARCIAL (+ EVIDENCIA_NO_PUBLICADA) |
| Verificabilidad hoy | VERIFICABLE_PARCIAL |
| Cobertura de población | PRINCIPAL — Sólo la API principal; las invocadas no se certifican (C-04). |
| Condiciones globales | C-02, C-03 |
| Procedencia | Analista · 02-reglas-api-servicios.md · API-001; decisiones aplicables: —; histórico: API-001 |

### A. Texto normativo (literal de la analista)

**Resumen oficial:** Valida el nombre y la versión de la primera sección de una API según el dominio arquitectónico en el que se encuentre.

**Población (Aplica a):** API principales e invocadas con tipo arquitectónico certificado.

**Obligación (Criterio):** Para una API ubicada en INTEGRACIÓN, directamente o dentro de un sistema externo auxiliar, la primera sección debe seguir el formato `Nombre Producto - Nombre API vMayor.Menor.Parche`. No debe contener espacios antes de la primera letra. El producto y la API deben tener nombres reales, funcionales, específicos, no genéricos, diferentes de textos de plantilla y escritos en inglés. Cada palabra significativa debe iniciar en mayúscula; los artículos, preposiciones y conjunciones pueden permanecer en minúscula cuando la nomenclatura inglesa lo permita. Debe existir un único guion estructural entre el nombre del producto y el nombre de la API, sin evaluar la cantidad de espacios a su alrededor. La versión debe iniciar con `v` o `V` y contener exactamente tres segmentos numéricos: Mayor mayor o igual que 1, Menor mayor o igual que 0 y Parche mayor o igual que 0.

Para una API ubicada en SISTEMAS EXTERNOS, directamente o dentro de un sistema externo auxiliar, solo se exige que la primera sección contenga un nombre real, funcional, específico, no genérico y diferente de un texto de plantilla. No se evalúan el formato corporativo, el idioma, la capitalización ni la versión. La restricción de ubicación de los auxiliares identificados como EVC, EPC o LDC se evalúa mediante EXT-002.

**Evidencia mínima:** Clasificación certificada del componente como API, texto completo de la primera sección y dominio arquitectónico certificado. Para las API ubicadas en INTEGRACIÓN se requieren el nombre del producto, el nombre de la API, el separador estructural y la versión. Los espacios repetidos y situados en los extremos se normalizan, excepto los espacios anteriores a la primera letra, que constituyen incumplimiento. Los guiones propios de nombres o marcas no se consideran automáticamente separadores estructurales. El idioma no se determina únicamente por siglas, marcas, nombres propios, términos técnicos ni palabras compartidas por varios idiomas.

- **Cumple:** La clasificación y ubicación de la API están certificadas y la primera sección satisface todas las condiciones aplicables. En INTEGRACIÓN cumple el formato completo, y en SISTEMAS EXTERNOS contiene un nombre real, funcional, específico, no genérico y diferente de un texto de plantilla.
- **No cumple:** La clasificación, ubicación y primera sección están certificadas, y se incumple al menos una condición aplicable. En INTEGRACIÓN esto incluye espacios antes de la primera letra, estructura u orden incorrectos, nombre genérico o de plantilla, separador estructural inválido, capitalización incorrecta, idioma diferente del inglés o versión ausente o inválida. En SISTEMAS EXTERNOS esto incluye un nombre ausente, genérico, no funcional o correspondiente a un texto de plantilla.
- **No verificable:** No puede certificarse si el componente es una API; no puede determinarse si está ubicado en INTEGRACIÓN o SISTEMAS EXTERNOS; la primera sección está incompleta; no puede distinguirse el guion estructural de los guiones propios de los nombres; o no puede verificarse razonablemente alguna condición aplicable. Si existe al menos un incumplimiento certificado, prevalece **No cumple** aunque otra condición sea no verificable.
- **No aplica:** La página no contiene API certificadas ni componentes candidatos cuya clasificación como API esté pendiente.

### B. Interpretación técnica (no normativa)

- **Aplicabilidad (síntesis):** APIs principales e invocadas con tipo certificado; modalidad por dominio (INTEGRACIÓN: formato completo; SISTEMAS EXTERNOS: reducido). No aplica: sin API ni candidatas.
- **Dependencias:** EXT-002 (ubicación de auxiliares); API-003 → API-004.
- **Conflictos:** Ninguno.
- **Preguntas necesarias:** Ninguna.

### C. Evidencia y decisiones

- **Origen en Lucidchart:** `UMLClassBlock` de tres secciones (Title, Text1, Text2).
- **Campo JSON existente:** `architecturalType=API`, `role`, `name`, `textAreas`, `architecturalDomain`, `structuralParent`
- **Suficiencia:** Suficiente para la API principal (12 tipadas).
- **Brecha:** G-1: APIs no principales sin tipo; inglés y «palabra significativa» no deterministas.
- **Decisiones abiertas (específicas de la regla):** C-04, C-09

---

## API-002 — Operación de API

| Campo | Valor |
|---|---|
| ID vigente | API-002 |
| ID histórico relacionado | API-002 |
| Estado de definición normativa | NORMATIVAMENTE_DEFINIDA |
| Estado de evidencia | EVIDENCIA_PARCIAL (+ EVIDENCIA_NO_PUBLICADA) |
| Verificabilidad hoy | VERIFICABLE_PARCIAL |
| Cobertura de población | PRINCIPAL — Ídem API-001. |
| Condiciones globales | C-02, C-03 |
| Procedencia | Analista · 02-reglas-api-servicios.md · API-002; decisiones aplicables: —; histórico: API-002 |

### A. Texto normativo (literal de la analista)

**Resumen oficial:** Valida la operación declarada en la segunda sección de una API según el dominio arquitectónico en el que se encuentre.

**Población (Aplica a):** API principales e invocadas con tipo arquitectónico certificado.

**Obligación (Criterio):** Para una API ubicada en INTEGRACIÓN, directamente o dentro de un sistema externo auxiliar, la segunda sección debe contener únicamente el nombre de la operación expuesta por la API. La operación debe estar escrita en inglés y en formato `camelCase`: debe comenzar con una letra minúscula, contener únicamente letras y números, no incluir espacios, guiones ni guiones bajos, y utilizar una letra mayúscula inicial para cada palabra posterior a la primera cuando el nombre tenga varias palabras.

Para una API ubicada en SISTEMAS EXTERNOS, directamente o dentro de un sistema externo auxiliar, no se exige el idioma inglés ni el formato `camelCase`; la segunda sección debe contener una operación funcional, específica, no genérica y diferente de un texto de plantilla. La presencia de EVC, EPC o LDC en el nombre del auxiliar no modifica la modalidad de nombramiento de la operación; la restricción de ubicación del auxiliar se evalúa mediante EXT-002.

**Evidencia mínima:** Clasificación certificada del componente como API, dominio arquitectónico certificado y texto completo de la segunda sección. Para las API ubicadas en INTEGRACIÓN, el texto debe permitir comprobar que existe una única operación, que está escrita en inglés y que cumple el formato `camelCase`. Para las API ubicadas en SISTEMAS EXTERNOS, el texto debe permitir comprobar que la operación es funcional, específica, no genérica y diferente de un texto de plantilla. La operación no debe deducirse a partir del nombre de la API ni de otra sección.

- **Cumple:** La clasificación y ubicación de la API están certificadas y la segunda sección satisface todas las condiciones aplicables. En INTEGRACIÓN contiene únicamente una operación en inglés y en formato `camelCase`. En SISTEMAS EXTERNOS contiene una operación funcional, específica, no genérica y diferente de un texto de plantilla.
- **No cumple:** La clasificación, ubicación y segunda sección están certificadas y se incumple al menos una condición aplicable. En INTEGRACIÓN esto incluye una operación ausente, genérica, de plantilla, escrita en un idioma diferente del inglés, fuera del formato `camelCase`, acompañada de texto adicional o con más de una operación. En SISTEMAS EXTERNOS esto incluye una operación ausente, genérica, no funcional o correspondiente a un texto de plantilla.
- **No verificable:** No puede certificarse si el componente es una API; no puede determinarse si está ubicado en INTEGRACIÓN o SISTEMAS EXTERNOS; la segunda sección está ausente o incompleta por falta de evidencia; no puede verificarse razonablemente el idioma cuando se exige la validación rigurosa; o cualquier ambigüedad impide determinar si el texto corresponde exactamente a una operación válida. Si existe al menos un incumplimiento certificado, prevalece **No cumple** aunque otra condición sea no verificable.
- **No aplica:** La página no contiene API certificadas ni componentes candidatos cuya clasificación como API esté pendiente.

### B. Interpretación técnica (no normativa)

- **Aplicabilidad (síntesis):** Igual que API-001.
- **Dependencias:** Igual que API-001.
- **Conflictos:** Ninguno.
- **Preguntas necesarias:** Ninguna.

### C. Evidencia y decisiones

- **Origen en Lucidchart:** Segunda sección (`Text1`) de la `UMLClassBlock`.
- **Campo JSON existente:** `operation`, `textAreas`, `architecturalType`, `architecturalDomain`
- **Suficiencia:** Igual que API-001.
- **Brecha:** Igual que API-001.
- **Decisiones abiertas (específicas de la regla):** C-04, C-09

---

## API-003 — Tipo y modelo de servicio de API

| Campo | Valor |
|---|---|
| ID vigente | API-003 |
| ID histórico relacionado | API-003 |
| Estado de definición normativa | NORMATIVAMENTE_DEFINIDA |
| Estado de evidencia | EVIDENCIA_PARCIAL (+ EVIDENCIA_NO_PUBLICADA) |
| Verificabilidad hoy | VERIFICABLE_PARCIAL |
| Cobertura de población | PRINCIPAL — Ídem API-001. |
| Condiciones globales | C-02, C-03 |
| Procedencia | Analista · 02-reglas-api-servicios.md · API-003; decisiones aplicables: R-14; histórico: API-003 |

### A. Texto normativo (literal de la analista)

**Resumen oficial:** Valida el tipo de API y el modelo de servicio declarados en la tercera sección, según el dominio arquitectónico en el que se encuentre la API.

**Población (Aplica a):** API principales e invocadas con tipo arquitectónico certificado.

**Obligación (Criterio):** Para una API ubicada en INTEGRACIÓN, directamente o dentro de un sistema externo auxiliar, la tercera sección debe seguir la estructura `tipo - modelo de servicio`. El valor anterior al guion debe ser exactamente `private`, `public` o `partner`, y el valor posterior debe ser exactamente `entidad`, `utilidad` o `tarea`. Ambos valores deben estar completamente en minúsculas y separados por un único guion estructural. No se admiten abreviaturas, traducciones, mayúsculas ni valores diferentes.

Para una API ubicada en SISTEMAS EXTERNOS, directamente o dentro de un sistema externo auxiliar, no se exige la estructura corporativa, los tipos ni los modelos del catálogo. La tercera sección debe contener información funcional, específica, no genérica y diferente de un texto de plantilla. La presencia de EVC, EPC o LDC en el nombre del auxiliar no modifica esta modalidad; la restricción de ubicación del auxiliar se evalúa mediante EXT-002.

**Evidencia mínima:** Clasificación certificada del componente como API, dominio arquitectónico certificado y texto completo de la tercera sección. Antes de evaluar, se eliminan los espacios iniciales y finales y se normalizan los espacios repetidos como un solo espacio. No se evalúa la cantidad de espacios antes o después del guion. Para las API ubicadas en INTEGRACIÓN debe ser posible identificar inequívocamente el tipo, el guion estructural y el modelo de servicio. Una exposición declarada por el analista puede utilizarse en API-004, pero no sustituye el tipo que debe estar escrito en la tercera sección para API-003.

- **Cumple:** La clasificación y ubicación de la API están certificadas y la tercera sección satisface todas las condiciones aplicables. En INTEGRACIÓN presenta exactamente un tipo permitido y un modelo de servicio permitido, en minúsculas y separados por un único guion estructural. En SISTEMAS EXTERNOS contiene información funcional, específica, no genérica y diferente de un texto de plantilla.
- **No cumple:** La clasificación, ubicación y tercera sección están certificadas y se incumple al menos una condición aplicable. En INTEGRACIÓN esto incluye la ausencia del tipo, del modelo de servicio o del guion estructural; un valor fuera de los catálogos permitidos; el uso de mayúsculas, abreviaturas o traducciones; un orden incorrecto; o más de un guion estructural. La declaración posterior del tipo por parte del analista no corrige este incumplimiento. En SISTEMAS EXTERNOS esto incluye una sección ausente, genérica, no funcional o correspondiente a un texto de plantilla.
- **No verificable:** No puede certificarse si el componente es una API; no puede determinarse si está ubicado en INTEGRACIÓN o en SISTEMAS EXTERNOS; el texto de la tercera sección no está disponible o está incompleto por falta de evidencia; no puede distinguirse inequívocamente el guion estructural de un guion perteneciente a un valor; o cualquier ambigüedad impide evaluar una condición aplicable. Si la sección está disponible y se certifica que falta el tipo, el modelo o el guion, corresponde **No cumple**, no **No verificable**. Si existe al menos un incumplimiento certificado, prevalece **No cumple** aunque otra condición sea no verificable.
- **No aplica:** La página no contiene API certificadas ni componentes candidatos cuya clasificación como API esté pendiente.

### B. Interpretación técnica (no normativa)

- **Aplicabilidad (síntesis):** Igual que API-001.
- **Dependencias:** Alimenta API-004 (la exposición puede venir de la tercera sección).
- **Conflictos:** SRV-003 acepta cualquier capitalización; API-003 exige minúsculas (C-11).
- **Preguntas necesarias:** Ninguna (la exposición declarada no corrige esta regla).

### C. Evidencia y decisiones

- **Origen en Lucidchart:** Tercera sección (`Text2`).
- **Campo JSON existente:** `textAreas` (Text2), `architecturalType`, `architecturalDomain`
- **Suficiencia:** Suficiente para la API principal: «private - entidad» (4), «entidad» (5), «tarea» (1), plantilla (2).
- **Brecha:** G-1 para no principales.
- **Decisiones abiertas (específicas de la regla):** C-04, C-09, C-11

---

## API-004 — Capa de Despliegue de la API principal

| Campo | Valor |
|---|---|
| ID vigente | API-004 |
| ID histórico relacionado | API-004; absorbe: CA-002 antiguo (Asociación de Capa; retirada); FT-002 antiguo (Asociación de Flujo; retirada) |
| Estado de definición normativa | NORMATIVAMENTE_DEFINIDA |
| Estado de evidencia | EVIDENCIA_PARCIAL (+ EVIDENCIA_NO_PUBLICADA) |
| Verificabilidad hoy | VERIFICABLE_HOY |
| Cobertura de población | COMPLETA — La población normativa es la API principal declarada MCI; completa para ella. |
| Condiciones globales | C-02, C-03 |
| Procedencia | Analista · 02-reglas-api-servicios.md · API-004; decisiones aplicables: R-10, R-14, R-15; histórico: API-004; absorbe: CA-002 antiguo (Asociación de Capa; retirada); FT-002 antiguo (Asociación de Flujo; retirada) |

### A. Texto normativo (literal de la analista)

**Resumen oficial:** Valida que la API principal declarada como MCI tenga la capa de despliegue requerido según su tipo de exposición.

**Población (Aplica a):** API principal con tipo arquitectónico y rol certificados, declarada como MCI.

**Obligación (Criterio):** Cuando la API principal está declarada como MCI, la capa de despliegue exigido depende de su tipo de exposición: una API `private` debe tener asociadas una Capa de Arquitectura y un Flujo Transaccional; una API `partner` debe tener asociada una Capa de Arquitectura y no requiere Flujo Transaccional; una API `public` no requiere Capa de Arquitectura ni Flujo Transaccional. Las asociaciones requeridas deben pertenecer inequívocamente a la API principal y no pueden establecerse únicamente por cercanía, alineación, superposición o ubicación dentro del mismo contenedor.

Cuando la API principal está declarada como no MCI, no se exige Capa de Arquitectura, Flujo Transaccional ni la declaración `Federado`. Las API invocadas se excluyen de esta regla, independientemente de su condición MCI o de los elementos de despliegue que presenten.

**Evidencia mínima:** Identificación certificada de la API principal, tipo de exposición obtenido de la tercera sección o declarado por la analista, condición MCI o no MCI declarada por la analista y asociaciones estructurales suficientes para determinar si la Capa de Arquitectura y el Flujo Transaccional requeridos pertenecen a la API principal. La declaración de la analista determina la exposición o condición MCI cuando corresponda, pero no sustituye la evidencia de asociación de la Capa o del Flujo.

- **Cumple:** La API principal está declarada como MCI, su tipo de exposición está determinado y presenta todo la capa de despliegue exigido: Capa de Arquitectura y Flujo Transaccional para `private`, o Capa de Arquitectura para `partner`. Una API `public` cumple sin necesidad de Capa ni Flujo.
- **No cumple:** La API principal está declarada como MCI, su tipo de exposición y las asociaciones de despliegue están suficientemente certificadas, y falta al menos uno de los elementos obligatorios según su exposición: Capa o Flujo para `private`, o Capa para `partner`.
- **No verificable:** No puede certificarse cuál es la API principal; falta la declaración de su condición MCI cuando esta cambia la aplicabilidad; no puede determinarse su tipo de exposición mediante la tercera sección ni mediante una declaración de la analista; o existe una Capa o un Flujo candidato, pero no puede certificarse que esté asociado a la API principal. La presencia visual, cercanía o pertenencia al mismo contenedor no constituye evidencia suficiente de asociación.
- **No aplica:** La API principal está declarada como no MCI; el componente corresponde a una API invocada; o la página no contiene una API principal ni candidatos pendientes de identificación para ese rol.

### B. Interpretación técnica (no normativa)

- **Aplicabilidad (síntesis):** Solo la API principal certificada y declarada MCI por la analista. No aplica: no MCI; invocada; sin API principal ni candidatos.
- **Dependencias:** API-003 (exposición); CA-001/FT-001 (nombre de las figuras asociadas).
- **Conflictos:** Errata «presenta todo la capa» (C-11).
- **Preguntas necesarias:** MCI de la API principal (obligatoria); exposición (opcional, solo si falta y hace falta).

### C. Evidencia y decisiones

- **Origen en Lucidchart:** Capa y Flujo como `UMLRectangleContainerBlock` con prefijo; la API principal contenida o agrupada con ellos.
- **Campo JSON existente:** `role=PRINCIPAL`, `textAreas`, `deploymentAssociations`, registro `DECLARADO_POR_ANALISTA` de la Skill (no es un campo del JSON)
- **Suficiencia:** Suficiente para `private` (par Flujo+Capa por contención o grupo); no hay API `partner` en el corpus.
- **Brecha:** G-5: «Capa sin Flujo» (partner) no se publica.
- **Decisiones abiertas (específicas de la regla):** C-11

---

## SRV-001 — Nombramiento y versión opcional de servicio

| Campo | Valor |
|---|---|
| ID vigente | SRV-001 |
| ID histórico relacionado | SRV-001 |
| Estado de definición normativa | NORMATIVAMENTE_PENDIENTE |
| Estado de evidencia | EVIDENCIA_AMBIGUA |
| Verificabilidad hoy | PENDIENTE_NORMATIVO |
| Cobertura de población | NINGUNA — Población sin delimitar (C-01). |
| Condiciones globales | C-02, C-03 |
| Procedencia | Analista · 02-reglas-api-servicios.md · SRV-001; decisiones aplicables: —; histórico: SRV-001 |

### A. Texto normativo (literal de la analista)

**Resumen oficial:** Valida el nombre específico y la versión opcional del servicio.

**Población (Aplica a):** Servicios principal e invocados

**Obligación (Criterio):** Puede iniciar por ms; admite -, _ o espacios. Si hay versión, V/v y tres segmentos.

**Evidencia mínima:** Primera sección completa.

- **Cumple:** evidencia suficiente y criterio satisfecho.
- **No cumple:** Nombre genérico o versión presente con formato inválido.
- **No verificable:** Clasificación o texto no certificados.
- **No aplica:** Fuera de la población evaluable.

### B. Interpretación técnica (no normativa)

- **Aplicabilidad (síntesis):** Sin delimitar (texto heredado: «Servicios principal e invocados»).
- **Dependencias:** Pendiente de C-01.
- **Conflictos:** Texto de la versión anterior; población ambigua frente a SRV-003/SRV-004; encabezado y cuerpo genéricos.
- **Preguntas necesarias:** Criterio y población (C-01).

### C. Evidencia y decisiones

- **Origen en Lucidchart:** `UMLClassBlock` con prefijo `ms` (5 en el corpus); contenedor hijo con una sola sección.
- **Campo JSON existente:** `name`, `textAreas`, `architecturalType=SERVICIO`
- **Suficiencia:** No evaluable normativamente hasta cerrar C-01.
- **Brecha:** Criterio y población sin definir.
- **Decisiones abiertas (específicas de la regla):** C-01

---

## SRV-002 — Operación del servicio

| Campo | Valor |
|---|---|
| ID vigente | SRV-002 |
| ID histórico relacionado | SRV-002 |
| Estado de definición normativa | NORMATIVAMENTE_PENDIENTE |
| Estado de evidencia | EVIDENCIA_AMBIGUA |
| Verificabilidad hoy | PENDIENTE_NORMATIVO |
| Cobertura de población | NINGUNA — Población sin delimitar (C-01). |
| Condiciones globales | C-02, C-03 |
| Procedencia | Analista · 02-reglas-api-servicios.md · SRV-002; decisiones aplicables: —; histórico: SRV-002 |

### A. Texto normativo (literal de la analista)

**Resumen oficial:** Valida operación obligatoria, específica y en camelCase.

**Población (Aplica a):** Servicios principal e invocados

**Obligación (Criterio):** No deducir operación del nombre.

**Evidencia mínima:** Segunda sección completa.

- **Cumple:** evidencia suficiente y criterio satisfecho.
- **No cumple:** Operación ausente, genérica o fuera de camelCase.
- **No verificable:** Sección incompleta o servicio no certificado.
- **No aplica:** Fuera de la población evaluable.

### B. Interpretación técnica (no normativa)

- **Aplicabilidad (síntesis):** Sin delimitar.
- **Dependencias:** Pendiente de C-01.
- **Conflictos:** Igual que SRV-001; el contenedor hijo no tiene segunda sección.
- **Preguntas necesarias:** C-01.

### C. Evidencia y decisiones

- **Origen en Lucidchart:** Segunda sección de la `UMLClassBlock` de servicio.
- **Campo JSON existente:** `operation`, `textAreas`
- **Suficiencia:** No evaluable normativamente hasta cerrar C-01.
- **Brecha:** Criterio y población sin definir.
- **Decisiones abiertas (específicas de la regla):** C-01

---

## SRV-003 — Modelo del servicio invocado

| Campo | Valor |
|---|---|
| ID vigente | SRV-003 |
| ID histórico relacionado | SRV-003 |
| Estado de definición normativa | NORMATIVAMENTE_CONDICIONADA |
| Estado de evidencia | EVIDENCIA_NO_PUBLICADA (+ EVIDENCIA_DEPENDIENTE_DE_CONVENCION) |
| Verificabilidad hoy | CON_BRECHA |
| Cobertura de población | NINGUNA — El servicio invocado no es certificable (C-05). |
| Condiciones globales | C-02, C-03 |
| Procedencia | Analista · 02-reglas-api-servicios.md · SRV-003; decisiones aplicables: R-06; histórico: SRV-003 |

### A. Texto normativo (literal de la analista)

**Resumen oficial:** Valida que la tercera sección de un servicio invocado declare un modelo de servicio permitido.

**Población (Aplica a):** Componentes certificados como servicios invocados.

**Obligación (Criterio):** La tercera sección debe declarar obligatoriamente uno de los siguientes modelos de servicio: `entidad`, `utilidad` o `tarea`. Se aceptan diferencias de mayúsculas y minúsculas, pero no se admiten traducciones, abreviaturas, valores distintos de los permitidos ni textos de plantilla.

Esta regla se aplica únicamente a servicios invocados. El contenedor hijo principal representa el servicio principal del escenario y no se evalúa mediante esta regla. La clasificación del componente como servicio invocado debe estar certificada; las palabras `entidad`, `utilidad` o `tarea` no demuestran por sí solas que el componente sea un servicio.

**Evidencia mínima:** Clasificación certificada del componente como servicio invocado y texto completo de su tercera sección. Antes de evaluar, se eliminan los espacios iniciales y finales. La evidencia debe permitir determinar que la sección declara un único modelo de servicio perteneciente al catálogo permitido.

- **Cumple:** Todos los servicios invocados evaluables declaran en su tercera sección exactamente uno de los modelos permitidos: `entidad`, `utilidad` o `tarea`, sin importar el uso de mayúsculas o minúsculas.
- **No cumple:** El componente está certificado como servicio invocado y la tercera sección está disponible y completa, pero el modelo está ausente, corresponde a un texto de plantilla, contiene un valor diferente de `entidad`, `utilidad` o `tarea`, utiliza una traducción o abreviatura, declara más de un modelo o contiene texto adicional que impide reconocer un único valor permitido.
- **No verificable:** No puede determinarse si el componente es una API o un servicio invocado; no puede certificarse su rol como invocado; la tercera sección no está disponible o está incompleta por pérdida de evidencia; o existe una ambigüedad que impide determinar el modelo declarado. Las palabras `entidad`, `utilidad` o `tarea`, sin evidencia arquitectónica adicional, no permiten clasificar el componente como servicio. Si existe al menos un incumplimiento certificado, prevalece **No cumple** aunque otro servicio sea no verificable.
- **No aplica:** La página no contiene servicios invocados certificados ni componentes candidatos cuya clasificación como servicio invocado esté pendiente. El contenedor hijo principal no hace aplicable esta regla.

### B. Interpretación técnica (no normativa)

- **Aplicabilidad (síntesis):** Servicios invocados certificados. No aplica: sin invocados ni candidatos; el hijo principal no la hace aplicable.
- **Dependencias:** Definición de «invocado» (C-05); COM-003.
- **Conflictos:** Capitalización libre frente a API-003 (C-11).
- **Preguntas necesarias:** Ninguna.

### C. Evidencia y decisiones

- **Origen en Lucidchart:** `UMLClassBlock` de servicio no principal (tercera sección «Entidad/Utilidad/Tarea»).
- **Campo JSON existente:** `textAreas` (Text2), `architecturalType=SERVICIO`, `role=INVOCADO`
- **Suficiencia:** Insuficiente: `INVOCADO` no se emite en el patrón bidireccional (0 en el corpus; 56 pares bidireccionales).
- **Brecha:** G-2.
- **Decisiones abiertas (específicas de la regla):** C-04, C-05, C-09, C-11

---

## SRV-004 — Detalle de despliegue del servicio principal

| Campo | Valor |
|---|---|
| ID vigente | SRV-004 |
| ID histórico relacionado | — (nueva); absorbe: CA-002 antiguo (Asociación de Capa; retirada); FT-002 antiguo (Asociación de Flujo; retirada) |
| Estado de definición normativa | NORMATIVAMENTE_DEFINIDA |
| Estado de evidencia | EVIDENCIA_PARCIAL (+ EVIDENCIA_NO_PUBLICADA) |
| Verificabilidad hoy | VERIFICABLE_HOY |
| Cobertura de población | COMPLETA — La población normativa es el hijo principal de E1/E2 declarado MCI. |
| Condiciones globales | C-02, C-03 |
| Procedencia | Analista · 02-reglas-api-servicios.md · SRV-004; decisiones aplicables: R-06, R-10, R-15; histórico: — (nueva); absorbe: CA-002 antiguo (Asociación de Capa; retirada); FT-002 antiguo (Asociación de Flujo; retirada) |

### A. Texto normativo (literal de la analista)

**Resumen oficial:** Valida que el servicio principal representado por el contenedor hijo tenga asociados una Capa de Arquitectura y un Flujo Transaccional cuando corresponda a los escenarios E1 o E2 y esté declarado como MCI.

**Población (Aplica a):** Contenedor hijo principal de los escenarios E1 y E2, entendido como representación del servicio principal del escenario.

**Obligación (Criterio):** En los escenarios E1 y E2, cuando el contenedor hijo principal esté declarado como MCI, debe tener asociados una Capa de Arquitectura y un Flujo Transaccional. Ambas figuras deben pertenecer inequívocamente al hijo principal; la asociación no puede establecerse únicamente por cercanía, alineación, superposición o ubicación dentro del mismo contenedor.

Cuando el hijo principal esté declarado como no MCI, no se exigen Capa de Arquitectura, Flujo Transaccional ni la declaración `Federado`. En el escenario E3 no se evalúa la capa de despliegue del hijo principal mediante esta regla. Para esta evaluación, el hijo principal representa el servicio principal del escenario y no se requiere que el JSON lo clasifique adicionalmente como servicio principal. El nombramiento de las figuras existentes se evalúa mediante CA-001 y FT-001.

**Evidencia mínima:** Patrón estructural E1 o E2 determinado, identificación certificada de un único contenedor hijo principal, condición MCI o no MCI declarada por la analista y evidencia estructural suficiente para demostrar la asociación del hijo con una Capa de Arquitectura y un Flujo Transaccional. La declaración MCI determina la aplicabilidad de la obligación, pero no demuestra por sí misma la existencia ni la asociación de las figuras de despliegue.

- **Cumple:** El patrón estructural aplicable es E1 o E2, el hijo principal está declarado como MCI y tiene asociados inequívocamente una Capa de Arquitectura y un Flujo Transaccional.
- **No cumple:** El patrón estructural aplicable es E1 o E2, el hijo principal está declarado como MCI, la cobertura de las figuras de despliegue y sus asociaciones está certificada, y falta la Capa de Arquitectura, el Flujo Transaccional o ambos.
- **No verificable:** No puede determinarse el patrón estructural E1 o E2; no puede identificarse inequívocamente un único contenedor hijo principal; falta la declaración de su condición MCI; la cobertura de las figuras de despliegue es insuficiente; o existen una Capa de Arquitectura o un Flujo Transaccional candidatos, pero no puede demostrarse que pertenezcan al hijo principal. La cercanía, alineación, superposición o ubicación dentro del mismo contenedor no constituyen evidencia suficiente de asociación.
- **No aplica:** El hijo principal de E1 o E2 está declarado como no MCI; el patrón estructural aplicable es E3; o la página no contiene un hijo principal ni candidatos pendientes de identificación para ese rol.

### B. Interpretación técnica (no normativa)

- **Aplicabilidad (síntesis):** Hijo principal de E1/E2 declarado MCI. No aplica: no MCI; E3; sin hijo ni candidatos.
- **Dependencias:** CNT-002 (hijo); patrón de API-004; CA-001/FT-001.
- **Conflictos:** Ninguno (el manifiesto aclara hijo = servicio principal).
- **Preguntas necesarias:** MCI del hijo principal (solo E1/E2).

### C. Evidencia y decisiones

- **Origen en Lucidchart:** Contenedor hijo dentro de Flujo/Capa, o agrupado con ellos.
- **Campo JSON existente:** `scenario`, `role=HIJO_PRINCIPAL`, `deploymentAssociations`, registro `DECLARADO_POR_ANALISTA` de la Skill (no es un campo del JSON)
- **Suficiencia:** Suficiente por contención directa.
- **Brecha:** G-5: la asociación por grupos no cubre contenedores hijo.
- **Decisiones abiertas (específicas de la regla):** —

---

## EVT-001 — Nombramiento y versión del evento de integración

| Campo | Valor |
|---|---|
| ID vigente | EVT-001 |
| ID histórico relacionado | EVT-001 |
| Estado de definición normativa | NORMATIVAMENTE_DEFINIDA |
| Estado de evidencia | EVIDENCIA_DEPENDIENTE_DE_CONVENCION (+ EVIDENCIA_NO_PUBLICADA) |
| Verificabilidad hoy | CON_BRECHA |
| Cobertura de población | NINGUNA — El evento de integración no es certificable (C-04/C-06). |
| Condiciones globales | C-02, C-03 |
| Procedencia | Analista · 03-reglas-eventos.md · EVT-001; decisiones aplicables: R-13; histórico: EVT-001 |

### A. Texto normativo (literal de la analista)

**Resumen oficial:** Valida el nombre y la versión declarados en la primera sección de un evento de integración.

**Población (Aplica a):** Componentes certificados como eventos de integración de tipo Aplicación o Empresarial.

**Obligación (Criterio):** La primera sección debe seguir el formato `Nombre Producto - Nombre Capacidad_vMayor.Menor.Parche`. El nombre del producto y el nombre de la capacidad deben ser reales, funcionales, específicos, no genéricos, diferentes de textos de plantilla y estar escritos en inglés. Cada palabra significativa debe comenzar con letra mayúscula; los artículos, preposiciones y conjunciones pueden permanecer en minúscula cuando la nomenclatura inglesa lo permita.

Debe existir un único guion con función estructural entre el nombre del producto y el nombre de la capacidad. Los guiones que formen parte legítima de nombres propios, marcas o términos compuestos no se consideran automáticamente separadores estructurales. La versión debe estar precedida por un guion bajo, comenzar con `v` o `V` y contener exactamente tres segmentos numéricos: Mayor mayor o igual que 1, Menor mayor o igual que 0 y Parche mayor o igual que 0.

En la primera sección se permiten letras de la `a` a la `z`, en mayúsculas o minúsculas, números del `0` al `9`, espacios entre palabras, punto, guion bajo y guion. No se admiten otros caracteres especiales. La validación completa se aplica a todo evento de integración certificado, incluso cuando esté encapsulado dentro de un sistema externo auxiliar. La ubicación permitida del evento se evalúa en las reglas de contenedores y sistemas externos auxiliares, y no modifica la evaluación de su nomenclatura.

**Evidencia mínima:** Clasificación certificada del componente como evento de integración de tipo Aplicación o Empresarial y texto completo de la primera sección. La evidencia debe permitir identificar inequívocamente el nombre del producto, el guion estructural, el nombre de la capacidad, el guion bajo y la versión. Antes de evaluar, se eliminan los espacios iniciales y finales y se normalizan los espacios repetidos como un solo espacio. No se evalúa la cantidad de espacios alrededor del guion estructural. El idioma no se determina únicamente por siglas, marcas, nombres propios, términos técnicos ni palabras compartidas por varios idiomas.

- **Cumple:** El componente está certificado como evento de integración y la primera sección cumple todas las condiciones de estructura, especificidad, idioma, capitalización, caracteres permitidos y versión.
- **No cumple:** La clasificación del evento y el texto completo están certificados, y se incumple al menos una condición aplicable. Esto incluye un nombre ausente, genérico, no funcional o de plantilla; producto o capacidad ausentes o en orden incorrecto; idioma diferente del inglés; capitalización incorrecta; ausencia o invalidez del guion estructural; ausencia del guion bajo anterior a la versión; versión ausente o inválida; o presencia de caracteres no permitidos.
- **No verificable:** No puede certificarse que el componente sea un evento de integración de tipo Aplicación o Empresarial; la primera sección no está disponible o está incompleta por pérdida de evidencia; no puede distinguirse el guion estructural de los guiones propios de nombres o marcas; no puede verificarse razonablemente el idioma; o cualquier ambigüedad impide evaluar alguna condición aplicable. Si existe al menos un incumplimiento certificado, prevalece **No cumple** aunque otra condición sea no verificable.
- **No aplica:** La página no contiene eventos de integración certificados ni componentes candidatos cuya clasificación como evento de integración esté pendiente.

### B. Interpretación técnica (no normativa)

- **Aplicabilidad (síntesis):** Eventos de integración certificados (Aplicación o Empresarial). No aplica: sin eventos ni candidatos.
- **Dependencias:** Reconocimiento del evento de integración (C-04/C-06).
- **Conflictos:** La matriz de la analista apunta a `architecturalType`, que es `BPMNEvent`.
- **Preguntas necesarias:** Ninguna.

### C. Evidencia y decisiones

- **Origen en Lucidchart:** `UMLClassBlock` de tres secciones con tercera sección «Empresarial - Event/Query» (5 en el corpus).
- **Campo JSON existente:** `name`, `textAreas`, `lucidchartType=UMLClassBlock`
- **Suficiencia:** El texto está publicado; el reconocimiento del evento no.
- **Brecha:** G-3.
- **Decisiones abiertas (específicas de la regla):** C-04, C-06, C-09

---

## EVT-002 — Operación del evento de integración

| Campo | Valor |
|---|---|
| ID vigente | EVT-002 |
| ID histórico relacionado | EVT-002 |
| Estado de definición normativa | NORMATIVAMENTE_DEFINIDA |
| Estado de evidencia | EVIDENCIA_DEPENDIENTE_DE_CONVENCION (+ EVIDENCIA_NO_PUBLICADA) |
| Verificabilidad hoy | CON_BRECHA |
| Cobertura de población | NINGUNA — Ídem EVT-001. |
| Condiciones globales | C-02, C-03 |
| Procedencia | Analista · 03-reglas-eventos.md · EVT-002; decisiones aplicables: R-13; histórico: EVT-002 |

### A. Texto normativo (literal de la analista)

**Resumen oficial:** Valida la operación declarada en la segunda sección de un evento de integración.

**Población (Aplica a):** Componentes certificados como eventos de integración de tipo Aplicación o Empresarial.

**Obligación (Criterio):** La segunda sección debe contener únicamente el nombre de la operación del evento de integración. La operación debe estar escrita en inglés y en formato `camelCase`: debe comenzar con una letra minúscula, contener únicamente letras y números, no incluir espacios, guiones ni guiones bajos, y utilizar una letra mayúscula inicial para cada palabra posterior a la primera cuando el nombre tenga varias palabras. La operación debe ser funcional, específica, no genérica y diferente de un texto de plantilla.

La validación completa se aplica a todo evento de integración certificado, incluso cuando esté encapsulado dentro de un sistema externo auxiliar o esté ubicado directamente en SISTEMAS EXTERNOS. La ubicación permitida del evento se evalúa mediante las reglas de contenedores y sistemas externos auxiliares, y no modifica la evaluación de su operación.

**Evidencia mínima:** Clasificación certificada del componente como evento de integración de tipo Aplicación o Empresarial y texto completo de la segunda sección. El texto debe permitir comprobar que contiene únicamente una operación, que está escrita en inglés y que cumple el formato `camelCase`. La operación no debe deducirse a partir del nombre del evento, de su clasificación ni de otra sección.

- **Cumple:** El componente está certificado como evento de integración y la segunda sección contiene únicamente una operación funcional, específica, no genérica, diferente de un texto de plantilla, escrita en inglés y en formato `camelCase`.
- **No cumple:** La clasificación del evento y el texto completo de la segunda sección están certificados, y la operación está ausente, es genérica, no es funcional, corresponde a un texto de plantilla, está escrita en un idioma diferente del inglés, no cumple el formato `camelCase`, contiene caracteres no permitidos, incluye texto adicional o contiene más de una operación.
- **No verificable:** No puede certificarse que el componente sea un evento de integración de tipo Aplicación o Empresarial; la segunda sección no está disponible o está incompleta por pérdida de evidencia; no puede verificarse razonablemente el idioma; o existe una ambigüedad que impide determinar si el texto corresponde exactamente a una operación válida. Si existe al menos un incumplimiento certificado, prevalece **No cumple** aunque otra condición sea no verificable.
- **No aplica:** La página no contiene eventos de integración certificados ni componentes candidatos cuya clasificación como evento de integración esté pendiente.

### B. Interpretación técnica (no normativa)

- **Aplicabilidad (síntesis):** Igual que EVT-001.
- **Dependencias:** Igual.
- **Conflictos:** PascalCase → camelCase (reversión explícita).
- **Preguntas necesarias:** Ninguna.

### C. Evidencia y decisiones

- **Origen en Lucidchart:** Segunda sección (`Text1`).
- **Campo JSON existente:** `operation`, `textAreas`
- **Suficiencia:** Igual que EVT-001.
- **Brecha:** G-3.
- **Decisiones abiertas (específicas de la regla):** C-04, C-06, C-09

---

## EVT-003 — Tipo y clasificación del evento de integración

| Campo | Valor |
|---|---|
| ID vigente | EVT-003 |
| ID histórico relacionado | EVT-003 |
| Estado de definición normativa | NORMATIVAMENTE_DEFINIDA |
| Estado de evidencia | EVIDENCIA_DEPENDIENTE_DE_CONVENCION (+ EVIDENCIA_NO_PUBLICADA) |
| Verificabilidad hoy | CON_BRECHA |
| Cobertura de población | NINGUNA — Ídem EVT-001. |
| Condiciones globales | C-02, C-03 |
| Procedencia | Analista · 03-reglas-eventos.md · EVT-003; decisiones aplicables: R-13; histórico: EVT-003 |

### A. Texto normativo (literal de la analista)

**Resumen oficial:** Valida el tipo y la clasificación declarados en la tercera sección de un evento de integración.

**Población (Aplica a):** Componentes certificados como eventos de integración.

**Obligación (Criterio):** La tercera sección debe seguir la estructura `Tipo - Clasificacion`. El valor anterior al guion estructural debe ser exactamente `Aplicacion` o `Empresarial`, y el valor posterior debe ser exactamente `Query`, `Command` o `Event`. Ambos valores deben respetar la capitalización indicada: letra inicial en mayúscula y letras restantes en minúscula. Debe existir un único guion con función estructural entre el tipo y la clasificación. No se admiten traducciones, abreviaturas, tildes, diferencias de mayúsculas o minúsculas ni valores distintos de los catálogos permitidos.

La validación completa se aplica a todo evento de integración certificado, independientemente de que esté ubicado directamente en un dominio o encapsulado dentro de un sistema externo auxiliar. La ubicación permitida del evento se evalúa mediante las reglas de contenedores y sistemas externos auxiliares, y no modifica la evaluación de su tipo y clasificación.

**Evidencia mínima:** Clasificación certificada del componente como evento de integración y texto completo de la tercera sección. Antes de evaluar, se eliminan los espacios iniciales y finales y se normalizan los espacios consecutivos como un solo espacio. Se permite cualquier cantidad de espacios alrededor del guion estructural. La evidencia debe permitir identificar inequívocamente el tipo, el guion estructural y la clasificación.

- **Cumple:** El componente está certificado como evento de integración y la tercera sección contiene exactamente un tipo y una clasificación permitidos, en el orden y con la capitalización exigidos, separados por un único guion estructural.
- **No cumple:** La clasificación del componente y el texto completo de la tercera sección están certificados, y se presenta al menos una de las siguientes situaciones: falta el tipo, la clasificación o el guion estructural; el orden es incorrecto; existe más de un guion estructural; alguno de los valores está fuera del catálogo permitido; se utiliza una traducción, abreviatura o tilde; o no se respeta la capitalización exigida.
- **No verificable:** No puede certificarse que el componente sea un evento de integración; la tercera sección no está disponible o está incompleta por pérdida de evidencia; no puede distinguirse inequívocamente el guion estructural de un guion perteneciente a otro texto; o existe una ambigüedad que impide evaluar alguna condición aplicable. Si la sección está disponible y se certifica que falta el tipo, la clasificación o el guion estructural, corresponde **No cumple**, no **No verificable**. Si existe al menos un incumplimiento certificado, prevalece **No cumple** aunque otra condición sea no verificable.
- **No aplica:** La página no contiene eventos de integración certificados ni componentes candidatos cuya clasificación como evento de integración esté pendiente.

### B. Interpretación técnica (no normativa)

- **Aplicabilidad (síntesis):** Igual que EVT-001.
- **Dependencias:** Igual.
- **Conflictos:** Se retira la tolerancia de tilde (reversión explícita).
- **Preguntas necesarias:** Ninguna.

### C. Evidencia y decisiones

- **Origen en Lucidchart:** Tercera sección (`Text2`).
- **Campo JSON existente:** `textAreas` (Text2), `customData`
- **Suficiencia:** Igual que EVT-001.
- **Brecha:** G-3.
- **Decisiones abiertas (específicas de la regla):** C-04, C-06

---

## EVT-004 — Capa de Tópicos del evento de integración

| Campo | Valor |
|---|---|
| ID vigente | EVT-004 |
| ID histórico relacionado | EVT-005 (ID reutilizado: la EVT-004 anterior era despliegue) |
| Estado de definición normativa | NORMATIVAMENTE_DEFINIDA |
| Estado de evidencia | EVIDENCIA_DEPENDIENTE_DE_CONVENCION (+ EVIDENCIA_NO_PUBLICADA) |
| Verificabilidad hoy | CON_BRECHA |
| Cobertura de población | NINGUNA — Ídem EVT-001; la Capa de Tópicos no se reconoce (C-06). |
| Condiciones globales | C-02, C-03 |
| Procedencia | Analista · 03-reglas-eventos.md · EVT-004; decisiones aplicables: R-09; histórico: EVT-005 (ID reutilizado: la EVT-004 anterior era despliegue) |

### A. Texto normativo (literal de la analista)

**Resumen oficial:** Valida que cada evento de integración tenga asociada una única Capa de Tópicos.

**Población (Aplica a):** Componentes certificados como eventos de integración.

**Obligación (Criterio):** Todo evento de integración debe tener asociada exactamente una Capa de Tópicos. El nombre de la Capa de Tópicos no afecta al cumplimiento de esta regla. Tampoco se evalúan aquí la cantidad, los roles, el nombramiento ni las conexiones de los tópicos contenidos.

**Evidencia mínima:** Identificación certificada del evento de integración, inventario completo de las Capas de Tópicos y evidencia estructural suficiente para determinar cuántas están asociadas al evento. La asociación no debe inferirse únicamente por cercanía, alineación, superposición o pertenencia al mismo contenedor.

- **Cumple:** Cada evento de integración certificado tiene asociada inequívocamente una única Capa de Tópicos.
- **No cumple:** La cobertura de las Capas de Tópicos y sus asociaciones está certificada, y al menos un evento de integración no tiene ninguna Capa de Tópicos asociada o tiene más de una.
- **No verificable:** No puede certificarse que el componente sea un evento de integración; el inventario o las asociaciones no tienen cobertura suficiente; existen una o más Capas de Tópicos candidatas, pero no puede demostrarse su asociación con el evento; o la asociación es ambigua, parcial o contradictoria. Si se demuestra la ausencia o multiplicidad de Capas de Tópicos para un evento, prevalece **No cumple**.
- **No aplica:** La página no contiene eventos de integración certificados ni componentes candidatos cuya clasificación como evento de integración esté pendiente.

### B. Interpretación técnica (no normativa)

- **Aplicabilidad (síntesis):** Eventos de integración certificados. No aplica: sin eventos ni candidatos.
- **Dependencias:** EVT-001..003 (población). Alimenta EVT-005/006/007 (cascada).
- **Conflictos:** Ninguno.
- **Preguntas necesarias:** Ninguna.

### C. Evidencia y decisiones

- **Origen en Lucidchart:** Contenedor asociado al evento (Capa de Tópicos): 1 ocurrencia en todo el corpus.
- **Campo JSON existente:** `structuralParent`, `containerChainIds`, `groups`
- **Suficiencia:** Insuficiente: no existe tipo ni criterio de reconocimiento.
- **Brecha:** G-3.
- **Decisiones abiertas (específicas de la regla):** C-06

---

## EVT-005 — Cantidad y roles de tópicos

| Campo | Valor |
|---|---|
| ID vigente | EVT-005 |
| ID histórico relacionado | EVT-006 |
| Estado de definición normativa | NORMATIVAMENTE_DEFINIDA |
| Estado de evidencia | EVIDENCIA_DEPENDIENTE_DE_CONVENCION (+ EVIDENCIA_NO_PUBLICADA) |
| Verificabilidad hoy | CON_BRECHA |
| Cobertura de población | NINGUNA — Ídem EVT-004. |
| Condiciones globales | C-02, C-03 |
| Procedencia | Analista · 03-reglas-eventos.md · EVT-005; decisiones aplicables: R-09; histórico: EVT-006 |

### A. Texto normativo (literal de la analista)

**Resumen oficial:** Valida la cantidad y los roles de los tópicos contenidos en la Capa de Tópicos de un evento de integración, según su clasificación.

**Población (Aplica a):** Eventos de integración con clasificación certificada como `Query`, `Command` o `Event` y con una única Capa de Tópicos asociada.

**Obligación (Criterio):** Los tópicos se identifican por su rol como publicación (`p`) o suscripción (`s`). Un evento clasificado como `Query` debe tener exactamente dos tópicos: uno de publicación y uno de suscripción. Un evento clasificado como `Command` debe tener exactamente uno de estos patrones: un tópico de publicación; un tópico de suscripción; o un tópico de publicación y uno de suscripción. Un evento clasificado como `Event` debe tener exactamente un tópico, que puede ser de publicación o de suscripción. La Capa de Tópicos no puede estar vacía. Esta regla evalúa únicamente la cantidad y los roles; el formato completo del nombre de cada tópico se evalúa mediante EVT-006.

**Evidencia mínima:** Clasificación certificada del evento como `Query`, `Command` o `Event`; asociación certificada con una única Capa de Tópicos; inventario completo de los tópicos contenidos en esa capa; y evidencia suficiente para determinar el rol de cada tópico como publicación (`p`) o suscripción (`s`).

- **Cumple:** La Capa de Tópicos contiene la cantidad y combinación exactas exigidas por la clasificación del evento: un tópico `p` y uno `s` para `Query`; un tópico `p`, un tópico `s`, o uno de cada rol para `Command`; o exactamente un tópico `p` o `s` para `Event`.
- **No cumple:** La clasificación, la asociación con la Capa de Tópicos y la cobertura de sus tópicos están certificadas, y la capa está vacía, falta un rol obligatorio, existe una combinación no permitida, la cantidad no corresponde a la clasificación del evento o hay tópicos adicionales a los admitidos.
- **No verificable:** No puede certificarse la clasificación del evento; no puede demostrarse la asociación con la Capa de Tópicos; el inventario de tópicos no tiene cobertura suficiente; no puede determinarse el rol de al menos un tópico; o el evento tiene más de una Capa de Tópicos y no existe una única capa sobre la cual evaluar la cantidad y los roles. Si se demuestra que la única capa está vacía o existe otro incumplimiento certificado, prevalece **No cumple**.
- **No aplica:** La página no contiene eventos de integración certificados ni candidatos pendientes de clasificación. Si existe un evento de integración, pero no tiene una Capa de Tópicos asociada, la ausencia se evalúa en EVT-004 y EVT-005 queda **No verificable**.

### B. Interpretación técnica (no normativa)

- **Aplicabilidad (síntesis):** Eventos con clasificación certificada y única Capa de Tópicos asociada.
- **Dependencias:** EVT-004.
- **Conflictos:** Viñeta «No aplica» con contenido de «No verificable» (C-11).
- **Preguntas necesarias:** Ninguna.

### C. Evidencia y decisiones

- **Origen en Lucidchart:** Tópicos con prefijo `p.`/`s.` dentro de la capa.
- **Campo JSON existente:** `groups`, `structuralParent`, `textAreas`, `customData`
- **Suficiencia:** Insuficiente (depende de EVT-004).
- **Brecha:** G-3.
- **Decisiones abiertas (específicas de la regla):** C-06, C-11

---

## EVT-006 — Nombramiento de tópicos

| Campo | Valor |
|---|---|
| ID vigente | EVT-006 |
| ID histórico relacionado | EVT-007 |
| Estado de definición normativa | NORMATIVAMENTE_DEFINIDA |
| Estado de evidencia | EVIDENCIA_DEPENDIENTE_DE_CONVENCION (+ EVIDENCIA_NO_PUBLICADA) |
| Verificabilidad hoy | CON_BRECHA |
| Cobertura de población | NINGUNA — Ídem EVT-004. |
| Condiciones globales | C-02, C-03 |
| Procedencia | Analista · 03-reglas-eventos.md · EVT-006; decisiones aplicables: R-09; histórico: EVT-007 |

### A. Texto normativo (literal de la analista)

**Resumen oficial:** Valida que el nombre de cada tópico asociado a un evento de integración cumpla uno de los patrones permitidos.

**Población (Aplica a):** Tópicos contenidos en la Capa de Tópicos asociada a un evento de integración.

**Obligación (Criterio):** El nombre de cada tópico debe cumplir exactamente uno de los siguientes patrones: `p.producto.capacidad.vX`, `s.producto.capacidad.vX`, `p.producto.capacidad.codigoAplicacion.vX` o `s.producto.capacidad.codigoAplicacion.vX`. El primer segmento debe ser `p` para publicación o `s` para suscripción. Los segmentos `producto` y `capacidad` son obligatorios, mientras que `codigoAplicacion` es opcional y, cuando exista, debe ubicarse después de `capacidad`. El último segmento debe seguir el formato `vX`, donde `v` es minúscula y `X` es un número entero mayor o igual que 1, sin ceros iniciales.

El nombre completo debe estar escrito en minúsculas. Los segmentos `producto`, `capacidad` y `codigoAplicacion` solo pueden contener letras de la `a` a la `z` y números del `0` al `9`; no pueden contener espacios, guiones, guiones bajos ni otros caracteres especiales. Los segmentos deben estar separados exclusivamente mediante puntos y no pueden estar vacíos.

**Evidencia mínima:** Asociación certificada del tópico con la Capa de Tópicos del evento y texto completo de su nombre. La evidencia debe permitir identificar inequívocamente el rol `p` o `s`, los segmentos obligatorios `producto` y `capacidad`, el segmento opcional `codigoAplicacion` cuando exista y la versión final `vX`.

- **Cumple:** Todos los tópicos evaluados cumplen exactamente uno de los cuatro patrones permitidos, están escritos completamente en minúsculas, contienen los segmentos obligatorios en el orden establecido, utilizan únicamente letras y números dentro de cada segmento y terminan con una versión `vX` cuyo número es mayor o igual que 1 y no contiene ceros iniciales.
- **No cumple:** El inventario y los nombres completos de los tópicos están certificados, y al menos un tópico presenta una de las siguientes situaciones: no cumple ninguno de los patrones permitidos; utiliza un prefijo diferente de `p` o `s`; omite `producto`, `capacidad` o la versión; ubica `codigoAplicacion` en una posición incorrecta; contiene segmentos adicionales o vacíos; utiliza mayúsculas, espacios, guiones, guiones bajos u otros caracteres especiales; no separa los segmentos mediante puntos; utiliza una `V` mayúscula; o declara una versión igual a cero, no numérica o con ceros iniciales.
- **No verificable:** No puede demostrarse la asociación del tópico con la Capa de Tópicos del evento; el nombre del tópico no está disponible o está incompleto por pérdida de evidencia; el inventario de tópicos no tiene cobertura suficiente; o existe una ambigüedad que impide separar o interpretar sus segmentos. Si existe al menos un incumplimiento certificado, prevalece **No cumple** aunque otro tópico sea no verificable.
- **No aplica:** No existen tópicos asociados a eventos de integración ni candidatos pendientes de identificación. Si existe un evento de integración, pero falta su Capa de Tópicos o no puede determinarse su contenido, la regla queda **No verificable**, no **No aplica**.

### B. Interpretación técnica (no normativa)

- **Aplicabilidad (síntesis):** Tópicos contenidos en la Capa de Tópicos de un evento.
- **Dependencias:** EVT-004.
- **Conflictos:** Igual que EVT-005.
- **Preguntas necesarias:** Ninguna.

### C. Evidencia y decisiones

- **Origen en Lucidchart:** Texto del tópico (regex determinista).
- **Campo JSON existente:** `name`, `textAreas`, `groups`
- **Suficiencia:** El nombre es literal; falta reconocer el tópico y su capa.
- **Brecha:** G-3.
- **Decisiones abiertas (específicas de la regla):** C-06, C-11

---

## EVT-007 — Conexiones del evento de integración

| Campo | Valor |
|---|---|
| ID vigente | EVT-007 |
| ID histórico relacionado | EVT-008 |
| Estado de definición normativa | NORMATIVAMENTE_DEFINIDA |
| Estado de evidencia | EVIDENCIA_NO_EXISTENTE_EN_ORIGINAL (+ EVIDENCIA_DEPENDIENTE_DE_CONVENCION) |
| Verificabilidad hoy | CON_BRECHA |
| Cobertura de población | NINGUNA — Ídem EVT-004; además exige subtipo de evento (C-07). |
| Condiciones globales | C-02, C-03 |
| Procedencia | Analista · 03-reglas-eventos.md · EVT-007; decisiones aplicables: R-09; histórico: EVT-008 |

### A. Texto normativo (literal de la analista)

**Resumen oficial:** Valida la existencia, el sentido, las terminaciones y el tipo de `BPMNEvent` de las conexiones asociadas a los tópicos de un evento de integración.

**Población (Aplica a):** Eventos de integración con clasificación certificada y tópicos identificados con rol de publicación (`p`) o suscripción (`s`).

**Obligación (Criterio):** Cada tópico debe tener una conexión acorde con su rol. Un tópico de publicación (`p`) exige una conexión desde un `BPMNEvent` de tipo Señal de Envío hacia el evento de integración, con `CircleOpen` en el origen y `Generalization` en el destino. Un tópico de suscripción (`s`) exige una conexión desde el evento de integración hacia un `BPMNEvent` de tipo Señal de Recepción, con `Generalization` en el origen y `CircleOpen` en el destino.

Para un evento `Query` deben existir las conexiones correspondientes a los tópicos `p` y `s`. Para un evento `Command` se exigen ambas conexiones cuando tenga tópicos `p` y `s`, o únicamente la conexión correspondiente cuando tenga solo `p` o solo `s`. Para un evento `Event` se exige la conexión correspondiente al único tópico `p` o `s`.

La conexión puede terminar directamente en el evento de integración, en su Capa de Tópicos o en una Capa de Despliegue inequívocamente asociada al evento. Cuando se utilice una capa como extremo, debe demostrarse que pertenece al evento de integración.

**Evidencia mínima:** Clasificación certificada del evento de integración; inventario completo de sus tópicos y roles `p` o `s`; identificación certificada del `BPMNEvent` como Señal de Envío o Señal de Recepción, según corresponda; y conexiones completas con participantes, sentido y terminaciones. Cuando una conexión termine en la Capa de Tópicos o en una Capa de Despliegue, debe estar certificada su asociación con el evento.

- **Cumple:** Para cada tópico existe la conexión exigida por su rol. Los tópicos `p` están relacionados con un `BPMNEvent` de tipo Señal de Envío mediante una conexión dirigida hacia el evento, con `CircleOpen` en el origen y `Generalization` en el destino. Los tópicos `s` están relacionados con un `BPMNEvent` de tipo Señal de Recepción mediante una conexión dirigida desde el evento, con `Generalization` en el origen y `CircleOpen` en el destino. Los extremos alternativos utilizados pertenecen inequívocamente al evento.
- **No cumple:** La clasificación, los roles, el tipo de `BPMNEvent` y la cobertura de las conexiones están certificados, y falta una conexión obligatoria, el sentido no corresponde al rol del tópico, el tipo de `BPMNEvent` es incompatible con dicho rol, las terminaciones son incorrectas o la conexión termina en un componente certificado que no representa ni pertenece al evento de integración.
- **No verificable:** No puede certificarse el tipo del `BPMNEvent` como Señal de Envío o Señal de Recepción; no puede determinarse el rol de un tópico; la clasificación del evento es indeterminada; la dirección, las terminaciones o los participantes de una conexión son ambiguos o contradictorios; la cobertura no permite demostrar su existencia o ausencia; o no puede demostrarse que la capa utilizada como extremo pertenece al evento. La identificación genérica de una figura como `BPMNEvent` no es suficiente para declarar cumplimiento. Si existe al menos un incumplimiento certificado, prevalece **No cumple** aunque otra conexión sea no verificable.
- **No aplica:** La página no contiene eventos de integración certificados ni componentes candidatos cuya clasificación como evento de integración esté pendiente. Si existe un evento, pero faltan la Capa de Tópicos, los tópicos, sus roles o el subtipo de los `BPMNEvent`, la regla queda **No verificable**, no **No aplica**.

### B. Interpretación técnica (no normativa)

- **Aplicabilidad (síntesis):** Eventos con clasificación certificada y tópicos p/s. Si falta capa, tópicos, roles o subtipo, queda No verificable.
- **Dependencias:** EVT-004..006; convención de subtipos (C-07).
- **Conflictos:** Igual que EVT-005 (viñeta No aplica).
- **Preguntas necesarias:** Ninguna.

### C. Evidencia y decisiones

- **Origen en Lucidchart:** `BPMNEvent` de tipo Señal de Envío/Recepción y líneas con `CircleOpen`/`Generalization`.
- **Campo JSON existente:** `customData`, `connections`, `groups`, `deploymentAssociations`
- **Suficiencia:** Los estilos de extremo existen; el subtipo no existe en el JSON original.
- **Brecha:** G-4 (260 eventos, 0 con `customData`).
- **Decisiones abiertas (específicas de la regla):** C-06, C-07, C-11

---

## CA-001 — Nombramiento de Capa de Arquitectura

| Campo | Valor |
|---|---|
| ID vigente | CA-001 |
| ID histórico relacionado | CA-001 (la existencia pasa a otras reglas; CA-002 retirada) |
| Estado de definición normativa | NORMATIVAMENTE_DEFINIDA |
| Estado de evidencia | EVIDENCIA_PARCIAL |
| Verificabilidad hoy | VERIFICABLE_HOY |
| Cobertura de población | COMPLETA — Capas reconocidas por prefijo; una candidata con otro nombre no es detectable (afecta No aplica). |
| Condiciones globales | C-02, C-03 |
| Procedencia | Analista · 04-reglas-despliegue.md · CA-001; decisiones aplicables: R-15; histórico: CA-001 (la existencia pasa a otras reglas; CA-002 retirada) |

### A. Texto normativo (literal de la analista)

**Resumen oficial:** Valida el nombre de las figuras certificadas como Capa de Arquitectura.

**Población (Aplica a):** Figuras certificadas como Capas de Arquitectura, independientemente del componente al que estén asociadas.

**Obligación (Criterio):** El nombre debe seguir exactamente la estructura `Capa de Arquitectura - tipo`. El valor anterior al guion estructural debe ser `Capa de Arquitectura` y el valor posterior debe ser exactamente `composicion`, `experiencia` o `sistema`. Los tipos deben escribirse completamente en minúsculas y sin tildes. Debe existir un único guion con función estructural entre el nombre de la figura y el tipo. No se admiten abreviaturas, traducciones, variaciones de mayúsculas o minúsculas, tildes, valores diferentes de los permitidos ni texto adicional.

Antes de evaluar, se eliminan los espacios iniciales y finales y se normalizan los espacios consecutivos como un solo espacio. No se evalúa la cantidad de espacios alrededor del guion estructural. La existencia obligatoria de una Capa de Arquitectura se evalúa en la regla específica del componente que la requiere; esta regla evalúa únicamente el nombre de las capas existentes.

**Evidencia mínima:** Identificación certificada de la figura como Capa de Arquitectura y texto completo de su nombre. La evidencia debe permitir distinguir inequívocamente la expresión `Capa de Arquitectura`, el guion estructural y el tipo. No es necesario conocer el componente propietario para evaluar el nombramiento.

- **Cumple:** Todas las Capas de Arquitectura existentes y evaluables siguen exactamente la estructura `Capa de Arquitectura - tipo` y utilizan uno de los tipos permitidos: `composicion`, `experiencia` o `sistema`.
- **No cumple:** La figura y su texto completo están certificados, y al menos una Capa de Arquitectura incumple alguna condición aplicable: falta la expresión `Capa de Arquitectura`, el tipo o el guion estructural; el orden es incorrecto; existe más de un guion estructural; el tipo está fuera del catálogo permitido; se utilizan tildes, abreviaturas, traducciones, mayúsculas no permitidas o texto adicional.
- **No verificable:** No puede certificarse que la figura sea una Capa de Arquitectura; su nombre no está disponible o está incompleto por pérdida de evidencia; no puede distinguirse inequívocamente el guion estructural de un guion perteneciente al texto; o alguna ambigüedad impide evaluar el nombre. La falta de identificación del componente propietario no impide evaluar esta regla. Si existe al menos un incumplimiento certificado, prevalece **No cumple** aunque otra Capa sea no verificable.
- **No aplica:** La página no contiene figuras certificadas como Capas de Arquitectura ni figuras candidatas pendientes de clasificación como tales.

### B. Interpretación técnica (no normativa)

- **Aplicabilidad (síntesis):** Figuras certificadas como Capa de Arquitectura. No aplica: sin figuras ni candidatas.
- **Dependencias:** La existencia se evalúa en API-004/SRV-004/MQ-002.
- **Conflictos:** Ninguno.
- **Preguntas necesarias:** Ninguna.

### C. Evidencia y decisiones

- **Origen en Lucidchart:** `UMLRectangleContainerBlock` con texto «Capa de Arquitectura - tipo».
- **Campo JSON existente:** `architecturalType=CAPA`, `name`, `textAreas`
- **Suficiencia:** Suficiente para nombres con prefijo correcto (37 figuras).
- **Brecha:** G-6: un prefijo mal escrito no se tipa y queda como candidata (No verificable).
- **Decisiones abiertas (específicas de la regla):** —

---

## FT-001 — Nombramiento de Flujo Transaccional

| Campo | Valor |
|---|---|
| ID vigente | FT-001 |
| ID histórico relacionado | FT-001 (FT-002 retirada) |
| Estado de definición normativa | NORMATIVAMENTE_DEFINIDA |
| Estado de evidencia | EVIDENCIA_PARCIAL |
| Verificabilidad hoy | VERIFICABLE_HOY |
| Cobertura de población | COMPLETA — Flujos reconocidos por prefijo; una candidata con otro nombre no es detectable (afecta No aplica). |
| Condiciones globales | C-02, C-03 |
| Procedencia | Analista · 04-reglas-despliegue.md · FT-001; decisiones aplicables: R-15; histórico: FT-001 (FT-002 retirada) |

### A. Texto normativo (literal de la analista)

**Resumen oficial:** Valida el nombre de las figuras certificadas como Flujo Transaccional.

**Población (Aplica a):** Figuras certificadas como Flujos Transaccionales, independientemente del componente al que estén asociadas.

**Obligación (Criterio):** El nombre debe seguir exactamente la estructura `Flujo Transaccional - tipo`. El valor anterior al guion estructural debe ser exactamente `Flujo Transaccional` y el valor posterior debe ser exactamente `monetario`, `no-monetario`, `operativo` o `transversal`. Los tipos deben escribirse completamente en minúsculas. Debe existir un único guion con función estructural entre el nombre de la figura y el tipo. El guion de `no-monetario` forma parte del valor permitido y no se considera un separador estructural adicional. No se admiten abreviaturas, traducciones, variaciones de mayúsculas o minúsculas, valores diferentes de los permitidos ni texto adicional.

Antes de evaluar, se eliminan los espacios iniciales y finales y se normalizan los espacios consecutivos como un solo espacio. No se evalúa la cantidad de espacios alrededor del guion estructural. La existencia obligatoria de un Flujo Transaccional se evalúa en la regla específica del componente que lo requiere; esta regla evalúa únicamente el nombre de los flujos existentes.

**Evidencia mínima:** Identificación certificada de la figura como Flujo Transaccional y texto completo de su nombre. La evidencia debe permitir distinguir inequívocamente la expresión `Flujo Transaccional`, el guion estructural y el tipo. No es necesario conocer el componente propietario para evaluar el nombramiento.

- **Cumple:** Todos los Flujos Transaccionales existentes y evaluables siguen exactamente la estructura `Flujo Transaccional - tipo` y utilizan uno de los tipos permitidos: `monetario`, `no-monetario`, `operativo` o `transversal`.
- **No cumple:** La figura y su texto completo están certificados, y al menos un Flujo Transaccional incumple alguna condición aplicable: falta la expresión `Flujo Transaccional`, el tipo o el guion estructural; el orden es incorrecto; existe más de un guion estructural, sin contar el guion propio de `no-monetario`; el tipo está fuera del catálogo permitido; se utilizan abreviaturas, traducciones, mayúsculas no permitidas o texto adicional.
- **No verificable:** No puede certificarse que la figura sea un Flujo Transaccional; su nombre no está disponible o está incompleto por pérdida de evidencia; no puede distinguirse inequívocamente el guion estructural de un guion perteneciente al texto; o alguna ambigüedad impide evaluar el nombre. La falta de identificación del componente propietario no impide evaluar esta regla. Si existe al menos un incumplimiento certificado, prevalece **No cumple** aunque otro Flujo sea no verificable.
- **No aplica:** La página no contiene figuras certificadas como Flujos Transaccionales ni figuras candidatas pendientes de clasificación como tales.

### B. Interpretación técnica (no normativa)

- **Aplicabilidad (síntesis):** Figuras certificadas como Flujo Transaccional.
- **Dependencias:** Igual que CA-001.
- **Conflictos:** Ninguno.
- **Preguntas necesarias:** Ninguna.

### C. Evidencia y decisiones

- **Origen en Lucidchart:** `UMLRectangleContainerBlock` con texto «Flujo Transaccional - tipo».
- **Campo JSON existente:** `architecturalType=FLUJO`, `name`, `textAreas`
- **Suficiencia:** Igual que CA-001 (37 figuras).
- **Brecha:** G-6.
- **Decisiones abiertas (específicas de la regla):** —

---

## E1-001 — Estructura integral E1

| Campo | Valor |
|---|---|
| ID vigente | E1-001 |
| ID histórico relacionado | E1-001 |
| Estado de definición normativa | NORMATIVAMENTE_CONDICIONADA |
| Estado de evidencia | EVIDENCIA_NO_EXISTENTE_EN_ORIGINAL (+ EVIDENCIA_PARCIAL) |
| Verificabilidad hoy | CON_BRECHA |
| Cobertura de población | NINGUNA — El subtipo Inicio no es certificable (C-07). |
| Condiciones globales | C-02, C-03 |
| Procedencia | Analista · 05-reglas-escenarios.md · E1-001; decisiones aplicables: R-03, R-04, R-05; histórico: E1-001 |

### A. Texto normativo (literal de la analista)

**Resumen oficial:** Valida que el escenario E1 esté conformado por una API principal ubicada en INTEGRACIÓN, un hijo principal ubicado en el DOMINIO PRODUCTOR y una conexión desde la API hacia el evento BPMN de Inicio del hijo.

**Población (Aplica a):** Páginas evaluables con patrón estructural candidato a E1: API principal que consume el servicio representado por el hijo principal ubicado en el DOMINIO PRODUCTOR.

**Obligación (Criterio):** El escenario E1 debe tener una API principal ubicada en INTEGRACIÓN y un único hijo principal ubicado en el DOMINIO PRODUCTOR. La API principal debe estar conectada con un evento BPMN de tipo Inicio perteneciente al hijo principal. La conexión debe dirigirse desde la API hacia el evento de Inicio, con terminación `None` en el extremo de la API y `Arrow` en el extremo del evento.

La identificación genérica de una figura como `BPMNEvent` no permite confirmar que corresponda a un evento de Inicio. Mientras el subtipo Inicio no pueda certificarse, esta regla debe evaluarse como **No verificable**, aunque la ubicación de la API principal y del hijo principal estén correctamente demostradas. Esta incertidumbre no afecta por sí sola los resultados independientes de CNT-001, CNT-002, CNT-003 o CNT-004.

**Evidencia mínima:** Identificación certificada de la API principal, identificación certificada de un único hijo principal, dominio arquitectónico efectivo de ambos componentes, identificación certificada de un evento BPMN de tipo Inicio perteneciente al hijo y conexión completa entre la API y dicho evento, con participantes, sentido y terminaciones verificables. No se debe inferir el subtipo Inicio únicamente por la figura genérica, el texto visible, la posición o la ubicación dentro del hijo.

- **Cumple:** La API principal está ubicada en INTEGRACIÓN; existe un único hijo principal ubicado en el DOMINIO PRODUCTOR; se certifica dentro del hijo un evento BPMN de tipo Inicio; y existe una conexión desde la API hacia dicho evento, con terminación `None` en el extremo de la API y `Arrow` en el extremo del evento.
- **No cumple:** La identidad de los participantes, sus dominios, el subtipo Inicio del evento y la cobertura de la conexión están certificados, y se demuestra al menos una de las siguientes situaciones: la API principal no está ubicada en INTEGRACIÓN; el hijo principal no está ubicado en el DOMINIO PRODUCTOR; la API no está conectada con el evento de Inicio del hijo; la conexión tiene el sentido contrario; o sus terminaciones no corresponden a `None` en la API y `Arrow` en el evento.
- **No verificable:** No puede identificarse inequívocamente la API principal o el hijo principal; no puede certificarse el dominio arquitectónico efectivo de alguno de ellos; el evento está identificado únicamente como `BPMNEvent` y no puede certificarse como evento de Inicio; no puede demostrarse que el evento pertenezca al hijo principal; o la existencia, el sentido, las terminaciones o los participantes de la conexión son insuficientes, ambiguos o contradictorios. Si el único dato pendiente es el subtipo Inicio del `BPMNEvent`, la regla permanece **No verificable**, aunque las demás condiciones estén demostradas.
- **No aplica:** Se certifica que el patrón estructural de la página corresponde a E2 o E3 y no existen candidatos pendientes que puedan configurar un escenario E1. Las páginas exclusivamente de plantilla o leyenda también quedan fuera de la población.

### B. Interpretación técnica (no normativa)

- **Aplicabilidad (síntesis):** Páginas evaluables con patrón candidato a E1. No aplica: patrón E2/E3 certificado sin candidatos E1; plantilla/leyenda.
- **Dependencias:** Independiente de CNT-001..004. Subtipo Inicio (C-07).
- **Conflictos:** La viñeta No cumple exige Inicio certificado; el procedimiento dice que un incumplimiento certificado prevalece (C-08).
- **Preguntas necesarias:** Ninguna.

### C. Evidencia y decisiones

- **Origen en Lucidchart:** API (`UMLClassBlock`), `RectangleContainerBlock` (hijo), `BPMNEvent` dentro del hijo y una línea `None→Arrow`.
- **Campo JSON existente:** `scenario` (subcampos), `scenario.event.subtype/subtypeStatus`, `components[].containerChainIds`, `connections`
- **Suficiencia:** Estructura y conexión suficientes (12 de 12 `None->Arrow`); Inicio no certificable (0 `customData`).
- **Brecha:** G-4.
- **Decisiones abiertas (específicas de la regla):** C-07, C-08

---

## E2-001 — Estructura integral E2

| Campo | Valor |
|---|---|
| ID vigente | E2-001 |
| ID histórico relacionado | E2-001 |
| Estado de definición normativa | NORMATIVAMENTE_CONDICIONADA |
| Estado de evidencia | EVIDENCIA_NO_EXISTENTE_EN_ORIGINAL (+ EVIDENCIA_PARCIAL) |
| Verificabilidad hoy | CON_BRECHA |
| Cobertura de población | NINGUNA — Ídem E1-001. |
| Condiciones globales | C-02, C-03 |
| Procedencia | Analista · 05-reglas-escenarios.md · E2-001; decisiones aplicables: R-03, R-04; histórico: E2-001 |

### A. Texto normativo (literal de la analista)

**Resumen oficial:** Valida que el escenario E2 esté conformado por una API principal y un hijo principal ubicados en INTEGRACIÓN, con una conexión desde la API hacia el evento BPMN de Inicio del hijo.

**Población (Aplica a):** Páginas evaluables con patrón estructural candidato a E2: API principal que consume el servicio representado por el hijo principal ubicado en INTEGRACIÓN.

**Obligación (Criterio):** El escenario E2 debe tener una API principal y un hijo principal ubicados en INTEGRACIÓN. La API y el hijo deben ser componentes estructuralmente separados. La API principal debe estar conectada con un evento BPMN de tipo Inicio perteneciente al hijo principal. La conexión debe dirigirse desde la API hacia el evento de Inicio, con terminación `None` en el extremo de la API y `Arrow` en el extremo del evento.

La validación del subtipo Inicio se realiza exclusivamente en esta regla para el escenario E2. La identificación genérica de una figura como `BPMNEvent` no permite confirmar esta condición. Mientras el subtipo Inicio no pueda certificarse, la regla queda **No verificable**, sin afectar por sí sola las reglas independientes de dominios, contenedores o contenido.

**Evidencia mínima:** Identificación certificada de la API principal y del hijo principal, dominio arquitectónico efectivo de ambos componentes, evidencia estructural de que son componentes separados, identificación certificada de un evento BPMN de tipo Inicio perteneciente al hijo y conexión completa entre la API y dicho evento, con participantes, sentido y terminaciones verificables. No se debe inferir el subtipo Inicio únicamente por la figura genérica, el texto visible, la posición o la ubicación dentro del hijo.

- **Cumple:** La API principal y el hijo principal están ubicados en INTEGRACIÓN y son componentes estructuralmente separados; se certifica dentro del hijo un evento BPMN de tipo Inicio; y existe una conexión desde la API hacia dicho evento, con terminación `None` en el extremo de la API y `Arrow` en el extremo del evento.
- **No cumple:** La identidad de los participantes, sus dominios, su separación estructural, el subtipo Inicio y la cobertura de la conexión están certificados, y se demuestra al menos una de las siguientes situaciones: la API principal o el hijo principal no están ubicados en INTEGRACIÓN; la API está contenida dentro del hijo; la API no está conectada con el evento de Inicio del hijo; la conexión tiene el sentido contrario; o sus terminaciones no corresponden a `None` en la API y `Arrow` en el evento.
- **No verificable:** No puede identificarse inequívocamente la API principal o el hijo principal; no puede certificarse el dominio arquitectónico efectivo de alguno de ellos; no puede demostrarse que sean componentes estructuralmente separados; el evento está identificado únicamente como `BPMNEvent` y no puede certificarse como evento de Inicio; no puede demostrarse que el evento pertenezca al hijo principal; o la existencia, el sentido, las terminaciones o los participantes de la conexión son insuficientes, ambiguos o contradictorios. Si el único dato pendiente es el subtipo Inicio del `BPMNEvent`, la regla permanece **No verificable**, aunque las demás condiciones estén demostradas.
- **No aplica:** Se certifica que el patrón estructural de la página corresponde a E1 o E3 y no existen candidatos pendientes que puedan configurar un escenario E2. Las páginas exclusivamente de plantilla o leyenda también quedan fuera de la población.

### B. Interpretación técnica (no normativa)

- **Aplicabilidad (síntesis):** Páginas con patrón candidato a E2. No aplica: E1/E3 certificado sin candidatos E2; plantilla/leyenda.
- **Dependencias:** Igual que E1-001.
- **Conflictos:** Igual (C-08).
- **Preguntas necesarias:** Ninguna.

### C. Evidencia y decisiones

- **Origen en Lucidchart:** Igual que E1-001 con la API y el hijo en INTEGRACIÓN.
- **Campo JSON existente:** Igual que E1-001
- **Suficiencia:** Igual.
- **Brecha:** G-4.
- **Decisiones abiertas (específicas de la regla):** C-07, C-08

---

## E3-001 — Estructura integral E3

| Campo | Valor |
|---|---|
| ID vigente | E3-001 |
| ID histórico relacionado | E3-001 |
| Estado de definición normativa | NORMATIVAMENTE_CONDICIONADA |
| Estado de evidencia | EVIDENCIA_NO_EXISTENTE_EN_ORIGINAL (+ EVIDENCIA_PARCIAL) |
| Verificabilidad hoy | CON_BRECHA |
| Cobertura de población | NINGUNA — Ídem E1-001. |
| Condiciones globales | C-02, C-03 |
| Procedencia | Analista · 05-reglas-escenarios.md · E3-001; decisiones aplicables: R-03, R-04, R-05; histórico: E3-001 |

### A. Texto normativo (literal de la analista)

**Resumen oficial:** Valida que el escenario E3 esté conformado por un componente principal y un hijo principal ubicados en el DOMINIO PRODUCTOR, con una conexión desde el componente principal hacia el evento BPMN de Inicio del hijo.

**Población (Aplica a):** Páginas evaluables con patrón estructural candidato a E3: componente principal que consume el servicio representado por el hijo principal, ambos ubicados en el DOMINIO PRODUCTOR.

**Obligación (Criterio):** El escenario E3 debe tener un componente principal y un hijo principal ubicados en el mismo DOMINIO PRODUCTOR y estructuralmente separados. El componente principal debe estar conectado con un evento BPMN de tipo Inicio perteneciente al hijo principal. La conexión debe dirigirse desde el componente principal hacia el evento de Inicio, con terminación `None` en el extremo del componente principal y `Arrow` en el extremo del evento.

La validación del subtipo Inicio se realiza exclusivamente en esta regla para el escenario E3. La identificación genérica de una figura como `BPMNEvent` no permite confirmar esta condición. Mientras el subtipo Inicio no pueda certificarse, la regla queda **No verificable**, sin afectar por sí sola las reglas independientes de dominios, contenedores o contenido.

**Evidencia mínima:** Identificación certificada del componente principal y del hijo principal, dominio arquitectónico efectivo de ambos componentes, evidencia estructural de que están ubicados en el mismo DOMINIO PRODUCTOR y son componentes separados, identificación certificada de un evento BPMN de tipo Inicio perteneciente al hijo y conexión completa entre el componente principal y dicho evento, con participantes, sentido y terminaciones verificables. No se debe inferir el subtipo Inicio únicamente por la figura genérica, el texto visible, la posición o la ubicación dentro del hijo.

- **Cumple:** El componente principal y el hijo principal están ubicados en el mismo DOMINIO PRODUCTOR y son componentes estructuralmente separados; se certifica dentro del hijo un evento BPMN de tipo Inicio; y existe una conexión desde el componente principal hacia dicho evento, con terminación `None` en el extremo del componente principal y `Arrow` en el extremo del evento.
- **No cumple:** La identidad de los participantes, sus dominios, su separación estructural, el subtipo Inicio y la cobertura de la conexión están certificados, y se demuestra al menos una de las siguientes situaciones: el componente principal o el hijo principal no están ubicados en el DOMINIO PRODUCTOR; pertenecen a dominios productores diferentes; el componente principal está contenido dentro del hijo; no existe conexión con el evento de Inicio del hijo; la conexión tiene el sentido contrario; o sus terminaciones no corresponden a `None` en el componente principal y `Arrow` en el evento.
- **No verificable:** No puede identificarse inequívocamente el componente principal o el hijo principal; no puede certificarse el dominio arquitectónico efectivo de alguno de ellos; no puede demostrarse que estén ubicados en el mismo DOMINIO PRODUCTOR y sean componentes separados; el evento está identificado únicamente como `BPMNEvent` y no puede certificarse como evento de Inicio; no puede demostrarse que el evento pertenezca al hijo principal; o la existencia, el sentido, las terminaciones o los participantes de la conexión son insuficientes, ambiguos o contradictorios. Si el único dato pendiente es el subtipo Inicio del `BPMNEvent`, la regla permanece **No verificable**, aunque las demás condiciones estén demostradas.
- **No aplica:** Se certifica que el patrón estructural de la página corresponde a E1 o E2 y no existen candidatos pendientes que puedan configurar un escenario E3. Las páginas exclusivamente de plantilla o leyenda también quedan fuera de la población.

### B. Interpretación técnica (no normativa)

- **Aplicabilidad (síntesis):** Páginas con patrón candidato a E3. No aplica: E1/E2 certificado sin candidatos E3; plantilla/leyenda.
- **Dependencias:** Igual que E1-001; «mismo DOMINIO PRODUCTOR» exige el mismo dominio efectivo.
- **Conflictos:** Igual (C-08).
- **Preguntas necesarias:** Ninguna.

### C. Evidencia y decisiones

- **Origen en Lucidchart:** Igual con el componente principal y el hijo en el mismo dominio productor.
- **Campo JSON existente:** Igual que E1-001
- **Suficiencia:** Igual; no hay E3 en las 12 páginas con escenario (solo fixture sintético).
- **Brecha:** G-4.
- **Decisiones abiertas (específicas de la regla):** C-07, C-08

---

## MOD-001 — Modelos de entrada y salida

| Campo | Valor |
|---|---|
| ID vigente | MOD-001 |
| ID histórico relacionado | MOD-001 |
| Estado de definición normativa | NORMATIVAMENTE_CONDICIONADA |
| Estado de evidencia | EVIDENCIA_PARCIAL (+ EVIDENCIA_AMBIGUA, EVIDENCIA_NO_PUBLICADA) |
| Verificabilidad hoy | VERIFICABLE_PARCIAL |
| Cobertura de población | PARCIAL — Modelos por customData ENTRADA/SALIDA; la asociación a la API principal sólo por grupo único (C-13). |
| Condiciones globales | C-02, C-03 |
| Procedencia | Analista · 06-reglas-modelos-comandos.md · MOD-001; decisiones aplicables: R-11; histórico: MOD-001 |

### A. Texto normativo (literal de la analista)

**Resumen oficial:** Valida la existencia y asociación de los modelos de entrada y salida obligatorios para la API principal, el servicio principal modelado en E3 y los eventos de integración ubicados en INTEGRACIÓN.

**Población (Aplica a):** API principal de los escenarios E1 y E2, componente principal del escenario E3 y eventos de integración ubicados en INTEGRACIÓN.

**Obligación (Criterio):** La API principal de los escenarios E1 y E2 debe tener asociados un modelo de entrada y un modelo de salida. El componente principal del escenario E3 debe tener asociados un modelo de entrada y un modelo de salida.

Para los eventos de integración ubicados en INTEGRACIÓN, los modelos obligatorios dependen de los roles de sus tópicos: cuando el evento tenga tópicos de publicación (`p`) y suscripción (`s`), debe tener asociados un modelo de entrada y un modelo de salida; cuando tenga únicamente un tópico de publicación (`p`), debe tener asociado un modelo de entrada; y cuando tenga únicamente un tópico de suscripción (`s`), debe tener asociado un modelo de salida.

El contenedor hijo principal no tiene modelos obligatorios en esta regla. La presencia o ausencia de modelos dentro del hijo no afecta al cumplimiento de MOD-001 y su ubicación se evalúa mediante las reglas CNT. Las API y los servicios invocados tampoco tienen modelos obligatorios en esta regla.

Los modelos exigidos deben estar asociados inequívocamente al componente evaluado. La asociación no puede establecerse únicamente por cercanía, alineación, superposición o pertenencia al mismo contenedor.

**Evidencia mínima:** Identificación certificada del patrón estructural y del componente principal aplicable; clasificación certificada de los modelos como entrada o salida; y evidencia estructural suficiente para demostrar su asociación con la API principal o el componente principal de E3. Para los eventos de integración se requiere además su ubicación certificada en INTEGRACIÓN, la asociación con su Capa de Tópicos y la identificación de los roles `p` y `s`. La evidencia debe permitir demostrar tanto la presencia como la ausencia de los modelos obligatorios.

- **Cumple:** Todos los componentes sujetos a esta regla presentan los modelos obligatorios y sus asociaciones están certificadas: entrada y salida para la API principal de E1/E2; entrada y salida para el componente principal de E3; entrada y salida para eventos con tópicos `p` y `s`; entrada para eventos con un único tópico `p`; y salida para eventos con un único tópico `s`.
- **No cumple:** La población, la cobertura de los modelos y sus asociaciones están certificadas, y falta al menos un modelo obligatorio para alguno de los componentes evaluados. También corresponde este estado cuando existe un modelo requerido, pero está certificadamente asociado a un componente diferente.
- **No verificable:** No puede identificarse inequívocamente el componente principal aplicable; no puede determinarse el patrón estructural; no puede clasificarse un modelo como entrada o salida; existen modelos candidatos, pero no puede demostrarse que estén asociados al componente evaluado; la cobertura no permite demostrar la presencia o ausencia de un modelo obligatorio; o, para un evento, no puede certificarse su ubicación en INTEGRACIÓN o el rol de sus tópicos. Si existe al menos un incumplimiento certificado, prevalece **No cumple** aunque otra obligación sea no verificable.
- **No aplica:** La página no contiene una API principal de E1/E2, un componente principal de E3 ni eventos de integración ubicados en INTEGRACIÓN, y tampoco existen candidatos pendientes que puedan pertenecer a esta población. El hijo principal y los componentes invocados no hacen aplicable la regla por sí solos.

### B. Interpretación técnica (no normativa)

- **Aplicabilidad (síntesis):** API principal de E1/E2, componente principal de E3 y eventos de integración en INTEGRACIÓN. El hijo y los invocados no la hacen aplicable.
- **Dependencias:** EVT-004/005 para eventos; CNT-002.
- **Conflictos:** La norma no dice si un grupo compartido es asociación inequívoca (C-13).
- **Preguntas necesarias:** Ninguna.

### C. Evidencia y decisiones

- **Origen en Lucidchart:** Figuras `BPMNActivity` con `customData` ENTRADA/SALIDA; grupos.
- **Campo JSON existente:** `customData`, `textAreas`, `groups`, `scenario`, `role`, `structuralParent`
- **Suficiencia:** `customData` literal suficiente y preservado (160/160); asociación al principal en 10 de 14 páginas por grupo único.
- **Brecha:** Asociación por grupo (C-13); eventos de integración sin tipo (G-3). `MODELO` por nombre no identifica modelos.
- **Decisiones abiertas (específicas de la regla):** C-13

---

## COM-001 — Nombramiento de comandos

| Campo | Valor |
|---|---|
| ID vigente | COM-001 |
| ID histórico relacionado | COM-001 |
| Estado de definición normativa | NORMATIVAMENTE_DEFINIDA |
| Estado de evidencia | EVIDENCIA_PARCIAL (+ EVIDENCIA_AMBIGUA) |
| Verificabilidad hoy | VERIFICABLE_PARCIAL |
| Cobertura de población | SUBPOBLACION — Comandos cuya relación con un componente certificado (gestor) es comprobable; relación sin definir (C-12). |
| Condiciones globales | C-02, C-03 |
| Procedencia | Analista · 06-reglas-modelos-comandos.md · COM-001; decisiones aplicables: —; histórico: COM-001 |

### A. Texto normativo (literal de la analista)

**Resumen oficial:** Valida el nombre de las actividades BPMN identificadas como comandos por su relación con una API, un servicio, un gestor de colas o un sistema externo auxiliar.

**Población (Aplica a):** Figuras `BPMNActivity` que tengan una relación identificable con una API, un servicio, un gestor de colas o un sistema externo auxiliar.

**Obligación (Criterio):** El nombre del comando debe estar escrito en español y comenzar con un verbo en infinitivo seguido de un complemento que identifique de manera clara, específica y coherente el objeto o propósito de la acción. El complemento es obligatorio; no se admiten nombres formados únicamente por un verbo, expresiones genéricas ni textos de plantilla. No se evalúa si la primera letra está escrita en mayúscula o minúscula.

Una `BPMNActivity` se considera candidata a comando únicamente cuando exista evidencia de una relación con una API, un servicio, un gestor de colas o un sistema externo auxiliar. No debe clasificarse como comando solo por su figura, texto, ubicación, cercanía o significado aparente. La misma actividad se evalúa una sola vez mediante esta regla, aunque esté relacionada con varios componentes. La validez de sus conexiones se evalúa mediante COM-002, COM-003, COM-004 o COM-005.

**Evidencia mínima:** Identificación certificada de la figura como `BPMNActivity`, texto completo de su nombre y evidencia suficiente de una relación con una API, un servicio, un gestor de colas o un sistema externo auxiliar. La relación debe permitir identificar la actividad como candidata a comando, aunque la corrección de la bidireccionalidad, el sentido o las terminaciones se evalúe en la regla de conexión correspondiente.

- **Cumple:** La actividad está identificada como candidata a comando y su nombre está escrito en español, comienza con un verbo en infinitivo y contiene un complemento claro, específico y coherente con la acción representada.
- **No cumple:** La actividad está identificada como candidata a comando y su nombre está ausente, corresponde a un texto de plantilla, es genérico, no comienza con un verbo en infinitivo, contiene únicamente el verbo sin complemento o presenta un complemento que no permite identificar de manera coherente la acción ejecutada. El uso de mayúscula o minúscula en la primera letra no afecta al resultado.
- **No verificable:** No puede certificarse que la figura sea una `BPMNActivity`; no puede identificarse una relación suficiente con una API, un servicio, un gestor de colas o un sistema externo auxiliar; el texto no está disponible o está incompleto por pérdida de evidencia; no puede determinarse razonablemente si la primera palabra corresponde a un verbo en infinitivo en español; o la información disponible no permite establecer la coherencia entre el verbo y su complemento. Si existe un incumplimiento certificado, prevalece **No cumple** aunque otra actividad sea no verificable.
- **No aplica:** La página no contiene actividades relacionadas con API, servicios, gestores de colas o sistemas externos auxiliares, ni relaciones pendientes que puedan identificar una `BPMNActivity` como candidata a comando.

### B. Interpretación técnica (no normativa)

- **Aplicabilidad (síntesis):** `BPMNActivity` con relación identificable con API, servicio, gestor o auxiliar. No aplica: sin tales actividades ni relaciones pendientes.
- **Dependencias:** Define la población de COM-002..005.
- **Conflictos:** «Relación identificable» sin definir (C-12).
- **Preguntas necesarias:** Ninguna.

### C. Evidencia y decisiones

- **Origen en Lucidchart:** `BPMNActivity` con líneas hacia la API, el servicio, el gestor o el auxiliar.
- **Campo JSON existente:** `lucidchartType=BPMNActivity`, `name`, `textAreas`, `connections`
- **Suficiencia:** Suficiente cuando la contraparte es gestor o auxiliar; con API/servicio no certificados la relación queda como candidata.
- **Brecha:** Infinitivo y español son juicios (C-09).
- **Decisiones abiertas (específicas de la regla):** C-09, C-12

---

## COM-002 — Conexión entre comando y API invocada

| Campo | Valor |
|---|---|
| ID vigente | COM-002 |
| ID histórico relacionado | COM-002; absorbe: EXT-002 antiguo (Conexión mediante auxiliar externo; retirada) |
| Estado de definición normativa | NORMATIVAMENTE_CONDICIONADA |
| Estado de evidencia | EVIDENCIA_NO_PUBLICADA (+ EVIDENCIA_DEPENDIENTE_DE_CONVENCION) |
| Verificabilidad hoy | CON_BRECHA |
| Cobertura de población | NINGUNA — La API invocada no es certificable (C-04/C-05). |
| Condiciones globales | C-02, C-03 |
| Procedencia | Analista · 06-reglas-modelos-comandos.md · COM-002; decisiones aplicables: —; histórico: COM-002; absorbe: EXT-002 antiguo (Conexión mediante auxiliar externo; retirada) |

### A. Texto normativo (literal de la analista)

**Resumen oficial:** Valida la conexión bidireccional entre un comando y una API invocada, independientemente de que la API esté o no encapsulada dentro de un sistema externo auxiliar.

**Población (Aplica a):** Relaciones identificables entre figuras `BPMNActivity` candidatas a comando y componentes certificados como API invocadas.

**Obligación (Criterio):** Todo comando relacionado con una API invocada debe tener dos conexiones entre los mismos participantes: una dirigida desde el comando hacia la API y otra dirigida desde la API hacia el comando. En cada conexión, el participante que actúa como origen debe utilizar `CircleOpen` y el participante que actúa como destino debe utilizar `Generalization`.

La regla se aplica tanto a las API ubicadas directamente en un dominio como a las API encapsuladas dentro de un sistema externo auxiliar, siempre que el extremo conectado sea la API o una figura que la represente inequívocamente. Si la conexión termina únicamente en el sistema externo auxiliar y no puede atribuirse directamente a una API encapsulada, la relación se evalúa mediante COM-005.

El nombramiento del comando se evalúa mediante COM-001 y no afecta al resultado de esta regla.

**Evidencia mínima:** Identificación certificada de la `BPMNActivity` candidata a comando y de la API invocada, junto con las conexiones completas entre ambos participantes. La evidencia debe permitir comprobar el origen, el destino y las terminaciones de cada conexión. Si la API está encapsulada dentro de un sistema externo auxiliar, debe estar certificada su pertenencia a dicho auxiliar.

- **Cumple:** Existen las dos conexiones requeridas entre el comando y la API invocada: una desde el comando hacia la API y otra desde la API hacia el comando. En ambas conexiones, el origen utiliza `CircleOpen` y el destino utiliza `Generalization`, sin conexiones duplicadas para la misma pareja y el mismo sentido.
- **No cumple:** Los participantes y la cobertura de las conexiones están certificados, y falta uno de los dos sentidos; una conexión está orientada incorrectamente; el origen no utiliza `CircleOpen`; el destino no utiliza `Generalization`; existen conexiones duplicadas para la misma pareja y el mismo sentido; o la conexión termina en un componente certificado que no corresponde ni representa a la API invocada.
- **No verificable:** No puede certificarse la actividad candidata a comando o la API invocada; no puede demostrarse que ambos sentidos correspondan a la misma pareja de participantes; la dirección o las terminaciones son indeterminadas, ambiguas o contradictorias; no puede determinarse si el extremo conectado corresponde a la API o únicamente al sistema externo auxiliar; o la cobertura no permite confirmar la presencia o ausencia de alguna conexión. Si existe un incumplimiento certificado, prevalece **No cumple** aunque otra conexión sea no verificable.
- **No aplica:** La página no contiene API invocadas relacionadas con actividades candidatas a comando ni conexiones pendientes que puedan configurar esta relación.

### B. Interpretación técnica (no normativa)

- **Aplicabilidad (síntesis):** Relaciones entre comandos y APIs invocadas certificadas. Si la línea termina solo en el auxiliar, COM-005.
- **Dependencias:** COM-001; definición de «invocado» (C-05).
- **Conflictos:** «Invocada» no es certificable con el patrón exigido.
- **Preguntas necesarias:** Ninguna.

### C. Evidencia y decisiones

- **Origen en Lucidchart:** Dos líneas `CircleOpen→Generalization` entre `BPMNActivity` y `UMLClassBlock`.
- **Campo JSON existente:** `connections` (`endpoint1.style`, `endpoint2.style`, `endpoint1.connectedTo`, `endpoint2.connectedTo`), `architecturalType`, `role`, `containedComponentIds`
- **Suficiencia:** Estilos suficientes; API invocada no certificable.
- **Brecha:** G-1, G-2 (56 pares bidireccionales; 0 `role=INVOCADO` emitidos; el valor existe en el código pero exige entrada y ninguna salida).
- **Decisiones abiertas (específicas de la regla):** C-04, C-05

---

## COM-003 — Conexión entre comando y servicio invocado

| Campo | Valor |
|---|---|
| ID vigente | COM-003 |
| ID histórico relacionado | COM-003; absorbe: EXT-002 antiguo (Conexión mediante auxiliar externo; retirada) |
| Estado de definición normativa | NORMATIVAMENTE_CONDICIONADA |
| Estado de evidencia | EVIDENCIA_NO_PUBLICADA (+ EVIDENCIA_DEPENDIENTE_DE_CONVENCION) |
| Verificabilidad hoy | CON_BRECHA |
| Cobertura de población | NINGUNA — El servicio invocado no es certificable (C-05). |
| Condiciones globales | C-02, C-03 |
| Procedencia | Analista · 06-reglas-modelos-comandos.md · COM-003; decisiones aplicables: —; histórico: COM-003; absorbe: EXT-002 antiguo (Conexión mediante auxiliar externo; retirada) |

### A. Texto normativo (literal de la analista)

**Resumen oficial:** Valida la conexión bidireccional entre un comando y un servicio invocado, independientemente de que el servicio esté o no encapsulado dentro de un sistema externo auxiliar.

**Población (Aplica a):** Relaciones identificables entre figuras `BPMNActivity` candidatas a comando y componentes certificados como servicios invocados.

**Obligación (Criterio):** Todo comando relacionado con un servicio invocado debe tener dos conexiones entre los mismos participantes: una dirigida desde el comando hacia el servicio y otra dirigida desde el servicio hacia el comando. En cada conexión, el participante que actúa como origen debe utilizar `CircleOpen` y el participante que actúa como destino debe utilizar `Generalization`.

La regla se aplica tanto a los servicios ubicados directamente en un dominio como a los servicios encapsulados dentro de un sistema externo auxiliar, siempre que el extremo conectado sea el servicio o una figura que lo represente inequívocamente. Si la conexión termina únicamente en el sistema externo auxiliar y no puede atribuirse directamente a un servicio encapsulado, la relación se evalúa mediante COM-005.

El nombramiento del comando se evalúa mediante COM-001 y no afecta al resultado de esta regla.

**Evidencia mínima:** Identificación certificada de la `BPMNActivity` candidata a comando y del servicio invocado, junto con las conexiones completas entre ambos participantes. La evidencia debe permitir comprobar el origen, el destino y las terminaciones de cada conexión. Si el servicio está encapsulado dentro de un sistema externo auxiliar, debe estar certificada su pertenencia a dicho auxiliar.

- **Cumple:** Existen las dos conexiones requeridas entre el comando y el servicio invocado: una desde el comando hacia el servicio y otra desde el servicio hacia el comando. En ambas conexiones, el origen utiliza `CircleOpen` y el destino utiliza `Generalization`, sin conexiones duplicadas para la misma pareja y el mismo sentido.
- **No cumple:** Los participantes y la cobertura de las conexiones están certificados, y falta uno de los dos sentidos; una conexión está orientada incorrectamente; el origen no utiliza `CircleOpen`; el destino no utiliza `Generalization`; existen conexiones duplicadas para la misma pareja y el mismo sentido; o la conexión termina en un componente certificado que no corresponde ni representa al servicio invocado.
- **No verificable:** No puede certificarse la actividad candidata a comando o el servicio invocado; no puede demostrarse que ambos sentidos correspondan a la misma pareja de participantes; la dirección o las terminaciones son indeterminadas, ambiguas o contradictorias; no puede determinarse si el extremo conectado corresponde al servicio o únicamente al sistema externo auxiliar; o la cobertura no permite confirmar la presencia o ausencia de alguna conexión. Si existe un incumplimiento certificado, prevalece **No cumple** aunque otra conexión sea no verificable.
- **No aplica:** La página no contiene servicios invocados relacionados con actividades candidatas a comando ni conexiones pendientes que puedan configurar esta relación.

### B. Interpretación técnica (no normativa)

- **Aplicabilidad (síntesis):** Igual con servicios invocados.
- **Dependencias:** Igual.
- **Conflictos:** Igual.
- **Preguntas necesarias:** Ninguna.

### C. Evidencia y decisiones

- **Origen en Lucidchart:** Igual con servicio (`ms…`).
- **Campo JSON existente:** Igual
- **Suficiencia:** Igual.
- **Brecha:** G-1, G-2.
- **Decisiones abiertas (específicas de la regla):** C-04, C-05

---

## COM-004 — Conexión entre comando y gestor de colas

| Campo | Valor |
|---|---|
| ID vigente | COM-004 |
| ID histórico relacionado | COM-004; absorbe: EXT-002 antiguo (Conexión mediante auxiliar externo; retirada) |
| Estado de definición normativa | NORMATIVAMENTE_DEFINIDA |
| Estado de evidencia | EVIDENCIA_DISPONIBLE |
| Verificabilidad hoy | VERIFICABLE_PARCIAL |
| Cobertura de población | SUBPOBLACION — Comandos relacionados con gestores certificados. |
| Condiciones globales | C-02, C-03 |
| Procedencia | Analista · 06-reglas-modelos-comandos.md · COM-004; decisiones aplicables: —; histórico: COM-004; absorbe: EXT-002 antiguo (Conexión mediante auxiliar externo; retirada) |

### A. Texto normativo (literal de la analista)

**Resumen oficial:** Valida la conexión bidireccional entre un comando y un gestor de colas.

**Población (Aplica a):** Relaciones identificables entre figuras `BPMNActivity` candidatas a comando y componentes certificados como gestores de colas.

**Obligación (Criterio):** Todo comando relacionado con un gestor de colas debe tener dos conexiones entre los mismos participantes: una dirigida desde el comando hacia el gestor y otra dirigida desde el gestor hacia el comando. En cada conexión, el participante que actúa como origen debe utilizar `CircleOpen` y el participante que actúa como destino debe utilizar `Generalization`.

Esta relación se evalúa exclusivamente mediante COM-004 y no debe evaluarse nuevamente en las reglas MQ. El nombramiento del comando se evalúa mediante COM-001 y no afecta al resultado de esta regla.

**Evidencia mínima:** Identificación certificada de la `BPMNActivity` candidata a comando y del gestor de colas, junto con las conexiones completas entre ambos participantes. La evidencia debe permitir comprobar el origen, el destino y las terminaciones de cada conexión.

- **Cumple:** Existen las dos conexiones requeridas entre el comando y el gestor de colas: una desde el comando hacia el gestor y otra desde el gestor hacia el comando. En ambas conexiones, el origen utiliza `CircleOpen` y el destino utiliza `Generalization`, sin conexiones duplicadas para la misma pareja y el mismo sentido.
- **No cumple:** Los participantes y la cobertura de las conexiones están certificados, y falta uno de los dos sentidos; una conexión está orientada incorrectamente; el origen no utiliza `CircleOpen`; el destino no utiliza `Generalization`; existen conexiones duplicadas para la misma pareja y el mismo sentido; o la conexión termina en un componente certificado que no corresponde al gestor de colas.
- **No verificable:** No puede certificarse la actividad candidata a comando o el gestor de colas; no puede demostrarse que ambos sentidos correspondan a la misma pareja de participantes; la dirección o las terminaciones son indeterminadas, ambiguas o contradictorias; o la cobertura no permite confirmar la presencia o ausencia de alguna conexión. Si existe un incumplimiento certificado, prevalece **No cumple** aunque otra conexión sea no verificable.
- **No aplica:** La página no contiene gestores de colas relacionados con actividades candidatas a comando ni conexiones pendientes que puedan configurar esta relación.

### B. Interpretación técnica (no normativa)

- **Aplicabilidad (síntesis):** Relaciones entre comandos y gestores certificados.
- **Dependencias:** COM-001; frontera con MQ-003.
- **Conflictos:** Ninguno.
- **Preguntas necesarias:** Ninguna.

### C. Evidencia y decisiones

- **Origen en Lucidchart:** `UMLActiveClassBlock` y líneas con `CircleOpen`/`Generalization`.
- **Campo JSON existente:** `connections` (`endpoint1.style`, `endpoint2.style`, `endpoint1.connectedTo`, `endpoint2.connectedTo`), `lucidchartType`, `architecturalType`
- **Suficiencia:** Suficiente (4 gestores en el corpus).
- **Brecha:** Ninguna relevante.
- **Decisiones abiertas (específicas de la regla):** —

---

## COM-005 — Conexión entre comando y sistema externo auxiliar

| Campo | Valor |
|---|---|
| ID vigente | COM-005 |
| ID histórico relacionado | — (nueva; en 41 un único candidato permitía atribuir la conexión al auxiliar); absorbe: EXT-002 antiguo (Conexión mediante auxiliar externo; retirada) |
| Estado de definición normativa | NORMATIVAMENTE_CONDICIONADA |
| Estado de evidencia | EVIDENCIA_PARCIAL (+ EVIDENCIA_AMBIGUA) |
| Verificabilidad hoy | VERIFICABLE_PARCIAL |
| Cobertura de población | PARCIAL — Auxiliares con una sola conexión; «atribución inequívoca» sin definir (C-12). |
| Condiciones globales | C-02, C-03 |
| Procedencia | Analista · 06-reglas-modelos-comandos.md · COM-005; decisiones aplicables: —; histórico: — (nueva; en 41 un único candidato permitía atribuir la conexión al auxiliar); absorbe: EXT-002 antiguo (Conexión mediante auxiliar externo; retirada) |

### A. Texto normativo (literal de la analista)

**Resumen oficial:** Valida la conexión bidireccional entre un comando y un sistema externo auxiliar cuando la relación no puede atribuirse directamente a un componente encapsulado.

**Población (Aplica a):** Relaciones identificables entre figuras `BPMNActivity` candidatas a comando y sistemas externos auxiliares que actúan como extremo gráfico de la conexión.

**Obligación (Criterio):** Cuando un comando se conecte directamente con un sistema externo auxiliar y la conexión no pueda atribuirse inequívocamente a una API o servicio encapsulado, deben existir dos conexiones entre los mismos participantes: una dirigida desde el comando hacia el auxiliar y otra dirigida desde el auxiliar hacia el comando. En cada conexión, el participante que actúa como origen debe utilizar `CircleOpen` y el participante que actúa como destino debe utilizar `Generalization`.

Si el extremo conectado es una API certificada contenida en el auxiliar, la relación se evalúa mediante COM-002. Si el extremo conectado es un servicio certificado contenido en el auxiliar, la relación se evalúa mediante COM-003. Una misma conexión no debe evaluarse en más de una regla COM.

**Evidencia mínima:** Identificación certificada de la `BPMNActivity` candidata a comando y del sistema externo auxiliar, junto con las conexiones completas entre ambos participantes. La evidencia debe permitir comprobar que el extremo gráfico es el auxiliar, que la relación no puede atribuirse inequívocamente a una API o servicio encapsulado y que los sentidos y terminaciones son verificables.

- **Cumple:** Existen las dos conexiones requeridas entre el comando y el sistema externo auxiliar: una desde el comando hacia el auxiliar y otra desde el auxiliar hacia el comando. En ambas conexiones, el origen utiliza `CircleOpen` y el destino utiliza `Generalization`, sin conexiones duplicadas para la misma pareja y el mismo sentido.
- **No cumple:** Los participantes y la cobertura de las conexiones están certificados, y falta uno de los dos sentidos; una conexión está orientada incorrectamente; el origen no utiliza `CircleOpen`; el destino no utiliza `Generalization`; existen conexiones duplicadas para la misma pareja y el mismo sentido; o la conexión termina en un componente certificado que no corresponde al auxiliar.
- **No verificable:** No puede certificarse la actividad candidata a comando o el sistema externo auxiliar; no puede determinarse si la conexión termina en el auxiliar o en un componente encapsulado; existen varios componentes internos y no puede atribuirse la conexión a uno de ellos; la dirección o las terminaciones son indeterminadas, ambiguas o contradictorias; o la cobertura no permite confirmar la presencia o ausencia de alguna conexión. Si existe un incumplimiento certificado, prevalece **No cumple** aunque otra conexión sea no verificable.
- **No aplica:** La página no contiene sistemas externos auxiliares relacionados directamente con actividades candidatas a comando ni conexiones pendientes que puedan configurar esta relación.

### B. Interpretación técnica (no normativa)

- **Aplicabilidad (síntesis):** Comando conectado directamente a un auxiliar sin atribución inequívoca a una API/servicio encapsulado.
- **Dependencias:** COM-001; COM-002/003 (si la línea termina en el componente interno).
- **Conflictos:** «Atribución inequívoca» sin definir; en la versión anterior un único candidato permitía atribuir (C-12).
- **Preguntas necesarias:** Ninguna.

### C. Evidencia y decisiones

- **Origen en Lucidchart:** `BPMNGroup` con nombre y líneas desde `BPMNActivity`.
- **Campo JSON existente:** `connections`, `architecturalType`, `containedComponentIds`
- **Suficiencia:** Suficiente para el extremo gráfico; la atribución es ambigua.
- **Brecha:** Definición de «inequívoca».
- **Decisiones abiertas (específicas de la regla):** C-12

---

## MQ-001 — Identificación y nombramiento del gestor de colas

| Campo | Valor |
|---|---|
| ID vigente | MQ-001 |
| ID histórico relacionado | MQ-001 |
| Estado de definición normativa | NORMATIVAMENTE_DEFINIDA |
| Estado de evidencia | EVIDENCIA_DISPONIBLE |
| Verificabilidad hoy | VERIFICABLE_PARCIAL |
| Cobertura de población | COMPLETA — Todas las figuras UMLActiveClassBlock; el criterio de plantilla depende de C-09. |
| Condiciones globales | C-02, C-03 |
| Procedencia | Analista · 07-reglas-gestores-colas.md · MQ-001; decisiones aplicables: R-17; histórico: MQ-001 |

### A. Texto normativo (literal de la analista)

**Resumen oficial:** Valida que toda figura identificada como gestor de colas tenga un nombre específico y diferente de un texto genérico o de plantilla.

**Población (Aplica a):** Figuras cuyo tipo Lucidchart esté certificado como `UMLActiveClassBlock`.

**Obligación (Criterio):** Toda figura `UMLActiveClassBlock` se considera un gestor de colas y debe tener un nombre visible, funcional y específico que permita identificarlo. No se admiten nombres ausentes, vacíos, genéricos ni textos de plantilla. No se exige un formato particular, idioma, versión, prefijo, capitalización ni estructura de palabras.

La regla evalúa exclusivamente la identificación y el nombramiento del gestor de colas. Su ubicación se evalúa mediante las reglas de contenido CNT; su Capa de Despliegue se evalúa mediante MQ-002; y las conexiones en las que participe se evalúan mediante las reglas COM o MQ que correspondan.

**Evidencia mínima:** Tipo Lucidchart certificado como `UMLActiveClassBlock` y texto completo del nombre visible de la figura. La clasificación como gestor de colas se determina mediante el tipo de figura y no debe inferirse únicamente por el texto, la ubicación, las conexiones o la cercanía con otros componentes.

- **Cumple:** Todas las figuras certificadas como `UMLActiveClassBlock` tienen un nombre visible, funcional, específico y diferente de un texto genérico o de plantilla.
- **No cumple:** La figura está certificada como `UMLActiveClassBlock` y su nombre está ausente, vacío, compuesto únicamente por espacios, es genérico o corresponde a un texto de plantilla.
- **No verificable:** No puede certificarse que la figura sea de tipo `UMLActiveClassBlock`; el texto del nombre no está disponible o está incompleto por pérdida de evidencia; o la información disponible no permite determinar razonablemente si el nombre es específico o corresponde a un texto genérico o de plantilla. Si existe al menos un incumplimiento certificado, prevalece **No cumple** aunque otro gestor sea no verificable.
- **No aplica:** La página no contiene figuras certificadas como `UMLActiveClassBlock` ni figuras candidatas pendientes de clasificación como tales.

### B. Interpretación técnica (no normativa)

- **Aplicabilidad (síntesis):** Figuras `UMLActiveClassBlock`. No aplica: sin figuras ni candidatas.
- **Dependencias:** Ubicación: CNT/EXT; despliegue: MQ-002; conexiones: COM/MQ.
- **Conflictos:** Promueve a norma la convención técnica anterior.
- **Preguntas necesarias:** Ninguna.

### C. Evidencia y decisiones

- **Origen en Lucidchart:** `UMLActiveClassBlock` con nombre visible.
- **Campo JSON existente:** `lucidchartType`, `architecturalType=GESTOR_COLAS`, `name`, `textAreas`
- **Suficiencia:** Suficiente (4 en el corpus).
- **Brecha:** «Genérico/plantilla» subjetivo (C-09).
- **Decisiones abiertas (específicas de la regla):** C-09

---

## MQ-002 — Capa de Despliegue del gestor de colas

| Campo | Valor |
|---|---|
| ID vigente | MQ-002 |
| ID histórico relacionado | MQ-003 + MQ-004 (fusión; el ID MQ-002 anterior era ubicación); absorbe: CA-002 antiguo (Asociación de Capa; retirada); FT-002 antiguo (Asociación de Flujo; retirada); MQ-003 antiguo (Modelo de despliegue del gestor; fusionada + renumerada); MQ-004 antiguo (Detalle de despliegue del gestor; fusionada) |
| Estado de definición normativa | NORMATIVAMENTE_DEFINIDA |
| Estado de evidencia | EVIDENCIA_DEPENDIENTE_DE_CONVENCION (+ EVIDENCIA_NO_PUBLICADA) |
| Verificabilidad hoy | VERIFICABLE_PARCIAL |
| Cobertura de población | SUBPOBLACION — Modalidad MCI (Capa+Flujo por contención); `Federado` depende de C-06. |
| Condiciones globales | C-02, C-03 |
| Procedencia | Analista · 07-reglas-gestores-colas.md · MQ-002; decisiones aplicables: R-10, R-15; histórico: MQ-003 + MQ-004 (fusión; el ID MQ-002 anterior era ubicación); absorbe: CA-002 antiguo (Asociación de Capa; retirada); FT-002 antiguo (Asociación de Flujo; retirada); MQ-003 antiguo (Modelo de despliegue del gestor; fusionada + renumerada); MQ-004 antiguo (Detalle de despliegue del gestor; fusionada) |

### A. Texto normativo (literal de la analista)

**Resumen oficial:** Valida que todo gestor de colas ubicado en INTEGRACIÓN tenga asociada una Capa de Despliegue MCI o Federada.

**Población (Aplica a):** Gestores de colas ubicados en el nivel padre de INTEGRACIÓN.

**Obligación (Criterio):** Todo gestor de colas ubicado en INTEGRACIÓN debe tener asociada una Capa de Despliegue, que puede corresponder a una de las siguientes modalidades:

- **MCI:** debe estar representada por una Capa de Arquitectura y un Flujo Transaccional asociados inequívocamente al gestor.
- **Federada:** debe estar representada mediante el valor exacto `Federado`; en esta modalidad no se exigen Capa de Arquitectura ni Flujo Transaccional.

La modalidad debe poder determinarse inequívocamente y sus elementos deben pertenecer al gestor de colas evaluado. La asociación no puede establecerse únicamente por cercanía, alineación, superposición o ubicación dentro del mismo contenedor.

Cuando el gestor esté ubicado fuera de INTEGRACIÓN, esta regla no exige ni evalúa una Capa de Despliegue. La ubicación permitida del gestor se evalúa mediante las reglas CNT y EXT. El nombramiento de la Capa de Arquitectura y del Flujo Transaccional existentes se evalúa mediante CA-001 y FT-001.

**Evidencia mínima:** Identificación certificada del gestor mediante el tipo `UMLActiveClassBlock`, ubicación certificada en el nivel padre de INTEGRACIÓN y evidencia completa de la modalidad de Capa de Despliegue. Para MCI se requieren una Capa de Arquitectura y un Flujo Transaccional inequívocamente asociados al gestor. Para Federada se requiere el valor literal `Federado` inequívocamente asociado al gestor.

- **Cumple:** El gestor está ubicado en el nivel padre de INTEGRACIÓN y tiene asociada una Capa de Despliegue válida: una Capa de Arquitectura y un Flujo Transaccional para la modalidad MCI, o el valor exacto `Federado` para la modalidad Federada.
- **No cumple:** La ubicación del gestor, la modalidad de despliegue y la cobertura de sus elementos están certificadas, y se presenta al menos una de las siguientes situaciones: el gestor ubicado en INTEGRACIÓN no tiene Capa de Despliegue; la modalidad MCI carece de Capa de Arquitectura, Flujo Transaccional o ambos; la modalidad Federada no contiene el valor exacto `Federado`; o los elementos están certificadamente asociados a un componente diferente.
- **No verificable:** No puede certificarse la ubicación del gestor; no puede determinarse si la Capa de Despliegue es MCI o Federada; existen una Capa de Arquitectura, un Flujo Transaccional o un valor `Federado` candidatos, pero no puede demostrarse que pertenezcan al gestor; o la cobertura no permite confirmar la presencia o ausencia de los elementos obligatorios. La cercanía, alineación, superposición o pertenencia al mismo contenedor no constituyen evidencia suficiente de asociación. Si existe un incumplimiento certificado, prevalece **No cumple** aunque otra condición sea no verificable.
- **No aplica:** El gestor está certificadamente ubicado fuera de INTEGRACIÓN, o la página no contiene gestores de colas ni candidatos pendientes de clasificación como tales.

### B. Interpretación técnica (no normativa)

- **Aplicabilidad (síntesis):** Gestores en el nivel padre de INTEGRACIÓN. No aplica: gestor certificado fuera de INTEGRACIÓN, o sin gestores ni candidatos.
- **Dependencias:** CNT-003 (ubicación); CA-001/FT-001 (nombres).
- **Conflictos:** Ninguno (se elimina la pregunta MCI del gestor).
- **Preguntas necesarias:** Ninguna.

### C. Evidencia y decisiones

- **Origen en Lucidchart:** Gestor + par Capa/Flujo, o contenedor `UMLRectangleContainerBlock`/`MinimalTextBlock` con el texto «Federado» (8 casos).
- **Campo JSON existente:** `structuralParent`, `containerChainIds`, `architecturalDomain`, `textAreas`, `deploymentAssociations`
- **Suficiencia:** MCI por contención: suficiente; `Federado`: el literal existe pero su asociación no se publica.
- **Brecha:** G-5 (cómo se asocia `Federado` a un gestor no está definido).
- **Decisiones abiertas (específicas de la regla):** C-06

---

## MQ-003 — Conexiones del gestor de colas

| Campo | Valor |
|---|---|
| ID vigente | MQ-003 |
| ID histórico relacionado | MQ-005 (ampliada; el ID MQ-003 anterior era modelo de despliegue); absorbe: EXT-002 antiguo (Conexión mediante auxiliar externo; retirada) |
| Estado de definición normativa | NORMATIVAMENTE_CONDICIONADA |
| Estado de evidencia | EVIDENCIA_NO_EXISTENTE_EN_ORIGINAL (+ EVIDENCIA_NO_PUBLICADA) |
| Verificabilidad hoy | CON_BRECHA |
| Cobertura de población | SUBPOBLACION — Sólo gestor↔gestor; los participantes invocados no son certificables (C-05). |
| Condiciones globales | C-02, C-03 |
| Procedencia | Analista · 07-reglas-gestores-colas.md · MQ-003; decisiones aplicables: —; histórico: MQ-005 (ampliada; el ID MQ-003 anterior era modelo de despliegue); absorbe: EXT-002 antiguo (Conexión mediante auxiliar externo; retirada) |

### A. Texto normativo (literal de la analista)

**Resumen oficial:** Valida las conexiones del gestor de colas con otros gestores, servicios invocados y eventos BPMN de tipo Mensaje.

**Población (Aplica a):** Gestores de colas relacionados con otros gestores de colas, servicios invocados o eventos BPMN candidatos a tipo Mensaje.

**Obligación (Criterio):** Las conexiones admitidas para un gestor de colas dependen del tipo de participante relacionado:

- Entre dos gestores de colas, la relación debe ser bidireccional. Debe existir una conexión desde el primer gestor hacia el segundo y otra en sentido contrario. En cada conexión, el origen debe utilizar `CircleOpen` y el destino `Generalization`.
- Entre un servicio invocado y un gestor de colas, se admite una relación unidireccional desde el servicio hacia el gestor o una relación bidireccional entre ambos. La conexión desde el servicio hacia el gestor debe utilizar `CircleOpen` en el servicio y `Generalization` en el gestor. Cuando exista la conexión de retorno, debe utilizar `CircleOpen` en el gestor y `Generalization` en el servicio.
- Entre un evento BPMN de tipo Mensaje y un gestor de colas, la relación debe ser unidireccional desde el evento hacia el gestor, con `CircleOpen` en el evento y `Generalization` en el gestor.

La relación con un servicio invocado se evalúa mediante esta regla tanto si el servicio está ubicado directamente en un dominio como si está encapsulado dentro de un sistema externo auxiliar. Las conexiones entre un comando y un gestor de colas se excluyen de esta regla y se evalúan exclusivamente mediante COM-004.

**Evidencia mínima:** Identificación certificada del gestor de colas y del participante relacionado, junto con las conexiones completas, sus sentidos y terminaciones. Para relaciones con servicios debe estar certificada la clasificación del componente como servicio invocado. Si el servicio está encapsulado dentro de un sistema externo auxiliar, debe demostrarse su pertenencia al auxiliar. Para relaciones con eventos BPMN debe certificarse el subtipo Mensaje; la clasificación genérica como `BPMNEvent` no es suficiente.

- **Cumple:** Todas las conexiones evaluadas corresponden a uno de los patrones admitidos: relación bidireccional entre gestores; relación unidireccional desde el servicio hacia el gestor o bidireccional entre ambos; o relación unidireccional desde un evento BPMN de tipo Mensaje hacia el gestor. Cada conexión utiliza `CircleOpen` en el origen y `Generalization` en el destino.
- **No cumple:** Los participantes, sus tipos y la cobertura de las conexiones están certificados, y se presenta al menos una de las siguientes situaciones: falta alguno de los sentidos obligatorios entre dos gestores; una conexión tiene un sentido no permitido; una terminación es incorrecta; existe una conexión de retorno desde el gestor hacia un evento BPMN de tipo Mensaje; la relación servicio-gestor solo existe desde el gestor hacia el servicio; existen conexiones duplicadas para la misma pareja y el mismo sentido; o la conexión termina en un participante certificado que no corresponde al patrón evaluado.
- **No verificable:** No puede certificarse alguno de los participantes; un evento está identificado únicamente como `BPMNEvent` y no puede certificarse como evento de tipo Mensaje; no puede determinarse si el servicio está contenido en un sistema externo auxiliar; la dirección o las terminaciones son indeterminadas, ambiguas o contradictorias; o la cobertura no permite confirmar la presencia o ausencia de las conexiones obligatorias. Si existe un incumplimiento certificado, prevalece **No cumple** aunque otra relación sea no verificable.
- **No aplica:** La página no contiene gestores de colas relacionados con otros gestores, servicios invocados o eventos BPMN candidatos a tipo Mensaje, ni conexiones pendientes que puedan configurar alguna de estas relaciones.

### B. Interpretación técnica (no normativa)

- **Aplicabilidad (síntesis):** Gestores relacionados con otros gestores, servicios invocados o eventos candidatos a Mensaje.
- **Dependencias:** COM-004 (comando↔gestor, no se duplica); definición de «invocado» (C-05).
- **Conflictos:** Ninguno.
- **Preguntas necesarias:** Ninguna.

### C. Evidencia y decisiones

- **Origen en Lucidchart:** Líneas `CircleOpen→Generalization` entre gestores; `BPMNEvent` Mensaje (sin subtipo en el JSON).
- **Campo JSON existente:** `connections`, `lucidchartType`, `customData`, `structuralParent`
- **Suficiencia:** Gestor↔gestor suficiente; Mensaje y servicio invocado no certificables.
- **Brecha:** G-4, G-1, G-2.
- **Decisiones abiertas (específicas de la regla):** C-04, C-05, C-07

---

## Anexo: trazabilidad histórica 41 → 37

Fuente: `MAPEO_IDS_41_A_37_2026-10-26.csv`. Cada ID del catálogo histórico aparece una vez. «Reutilizado» = el mismo ID designa ahora otra obligación.

| ID histórico | Título histórico | Destino vigente | Relación | Riesgo |
|---|---|---|---|---|
| CNT-001 | Contenedores padre requeridos | CNT-001 | MODIFICADA | MEDIO |
| CNT-002 | Estructura del contenedor hijo | CNT-002 | MODIFICADA | MEDIO |
| CNT-003 | Contenido permitido en INTEGRACIÓN | CNT-003 | MODIFICADA | MEDIO |
| CNT-004 | Contenido permitido en dominio productor | CNT-004 | MODIFICADA | MEDIO |
| CNT-005 | Contenido permitido en SISTEMAS EXTERNOS | CNT-005 | MODIFICADA | MEDIO |
| CNT-006 | Exclusividad de padre directo | (retirada) | RETIRADA | BAJO |
| EXT-001 | Sistema externo auxiliar válido | EXT-001 | MODIFICADA | MEDIO |
| EXT-002 | Conexión mediante auxiliar externo | (retirada) → conexiones en COM-002..005 y MQ-003 | RETIRADA | ALTO |
| GW-001 | Caminos alternos del gateway | GW-001 | MODIFICADA | ALTO |
| API-001 | Nombramiento y versión de API | API-001 | MODIFICADA | MEDIO |
| API-002 | Operación de API | API-002 | MODIFICADA | MEDIO |
| API-003 | Tipo y modelo de servicio de API | API-003 | MODIFICADA | MEDIO |
| API-004 | Detalle de despliegue de API | API-004 | MODIFICADA | MEDIO |
| SRV-001 | Nombramiento y versión opcional de servicio | SRV-001 | SIN CAMBIO TEXTUAL (pendiente) | MEDIO |
| SRV-002 | Operación del servicio | SRV-002 | SIN CAMBIO TEXTUAL (pendiente) | MEDIO |
| SRV-003 | Modelo de servicio | SRV-003 | MODIFICADA | ALTO |
| EVT-001 | Nombramiento y versión del evento | EVT-001 | MODIFICADA | MEDIO |
| EVT-002 | Operación del evento | EVT-002 | MODIFICADA | MEDIO |
| EVT-003 | Tipo y clasificación del evento | EVT-003 | MODIFICADA | MEDIO |
| EVT-004 | Detalle de despliegue del evento | (retirada) | RETIRADA | ALTO |
| EVT-005 | Contenedor de tópicos | EVT-004 | RENUMERADA + MODIFICADA | ALTO |
| EVT-006 | Cantidad y roles de tópicos | EVT-005 | RENUMERADA + MODIFICADA | ALTO |
| EVT-007 | Nombramiento de tópicos | EVT-006 | RENUMERADA + MODIFICADA | ALTO |
| EVT-008 | Conexiones del evento | EVT-007 | RENUMERADA + MODIFICADA | ALTO |
| CA-001 | Existencia y nombramiento de Capa | CA-001 | MODIFICADA | MEDIO |
| CA-002 | Asociación de Capa | (retirada) → API-004, SRV-004, MQ-002 | RETIRADA | BAJO |
| FT-001 | Existencia y nombramiento de Flujo | FT-001 | MODIFICADA | MEDIO |
| FT-002 | Asociación de Flujo | (retirada) → API-004, SRV-004, MQ-002 | RETIRADA | BAJO |
| E1-001 | Estructura integral E1 | E1-001 | MODIFICADA | MEDIO |
| E2-001 | Estructura integral E2 | E2-001 | MODIFICADA | MEDIO |
| E3-001 | Estructura integral E3 | E3-001 | MODIFICADA | MEDIO |
| MOD-001 | Modelos de entrada y salida | MOD-001 | MODIFICADA | MEDIO |
| COM-001 | Nombramiento de comandos | COM-001 | MODIFICADA (refinamiento) | BAJO |
| COM-002 | Conexión comando con API invocada | COM-002 | MODIFICADA (refinamiento) | BAJO |
| COM-003 | Conexión comando con servicio invocado | COM-003 | MODIFICADA (refinamiento) | BAJO |
| COM-004 | Conexión comando con gestor de colas | COM-004 | MODIFICADA (refinamiento) | BAJO |
| MQ-001 | Identificación y nombramiento del gestor | MQ-001 | MODIFICADA | MEDIO |
| MQ-002 | Ubicación del gestor | (retirada) → CNT-003/004/005, EXT-001 | RETIRADA | ALTO |
| MQ-003 | Modelo de despliegue del gestor | MQ-002 (fusión con MQ-004) | FUSIONADA + RENUMERADA | ALTO |
| MQ-004 | Detalle de despliegue del gestor | MQ-002 (fusión con MQ-003) | FUSIONADA | ALTO |
| MQ-005 | Conexión gestor con servicio invocado | MQ-003 | RENUMERADA + AMPLIADA | ALTO |

Reglas nuevas sin antecedente: EXT-002, SRV-004, COM-005.
