# Regresión v0.4.4

## Resultados por caso

- Currency Exchange E2: `tQ7mFTFbJ1SW` → `gT7m.rKo0qu-` → `iQ7mp2EXtgT-` → `TJ7m.cKnR-~v`; origen/destino INTEGRACIÓN, BDD presente, `mainApi`, `INFERRED`, evento Inicio no certificado.
- Oski: `mainApi`/E1 como `CANDIDATE`; RECAUDOS conserva rol productor no verificado.
- Debit Card: componentes con tercera sección Query/Event reconocidos y excluidos como principales.
- E3 sintético: dominio con `DOMAIN_ROLE=PRODUCER`, servicio y evento dentro del hijo producen `mainService` `INFERRED`, no escenario certificado.
- Contraejemplos: conexión invertida no genera rol; orientación no resoluble genera `AMBIGUOUS`; varios candidatos se conservan.

| Blueprint | Operaciones con candidaturas | Resultado contextual |
|---|---|---|
| Collections / Oski | msDebitAccountPayment | mainApi E1 `CANDIDATE` |
| Virtual Account | initiateVirtualAccount, initiateVirtualAccountAlias | mainApi E1 `CANDIDATE` |
| Debit Card | cuatro operaciones | E1 `CANDIDATE` o E2 `INFERRED`; Query/Event excluidos |
| Currency Exchange E2 | executeTransactionCurrencyExchange | mainApi E2 `INFERRED` |
| Ejemplo_BP | API-ServicioIntegracion, API-Backend | mainApi E2/E1 según dominio declarado |
| Mortgage | initiateMortgageLoanDisbursement | mainApi E2 `INFERRED` |
| QR Payments | tres operaciones | mainApi E1 `CANDIDATE` |
| E3 sintético | runMainService | mainService E3 `INFERRED` |

Las páginas de leyenda/NOTACIÓN y páginas auxiliares vacías no generan candidaturas.

## Ejecución

- Unitarias/integridad: 21 PASS.
- E2E del HTML: 3 PASS.
- Líneas, etiquetas, conteos 99/20, 170/78 y 126/30 contrastados contra JSON originales.
- Build autocontenido sin red: PASS.
- Skill: sin cambios normativos; 41 IDs preservados.

## Incertidumbres

- El rol productor requiere declaración; nombres personalizados no bastan.
- El subtipo Inicio no se certifica con la clase BPMNEvent.
- BDD se asocia por operación textual; coincidencias ausentes permanecen sin evidencia BDD.
- F-13 y directa/declarada siguen pendientes de aprobación.
