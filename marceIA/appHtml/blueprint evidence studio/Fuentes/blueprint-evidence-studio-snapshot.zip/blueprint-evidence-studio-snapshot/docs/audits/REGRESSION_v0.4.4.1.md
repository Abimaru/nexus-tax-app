# Regresión v0.4.4.1

## Matriz estructural

| Escenario | Evidencia | Resultado |
|---|---|---|
| E1 Oski | `wniB5n~8CzU8` → `wniB.7Dl~hrs` → `wniBqOut_oya` → `20QoxCoCdtvE`; INTEGRACIÓN → RECAUDOS/PRODUCER | STRUCTURALLY_CONFIRMED, mainApi |
| E2 Currency Exchange | `tQ7mFTFbJ1SW` → `gT7m.rKo0qu-` → `iQ7mp2EXtgT-` → `TJ7m.cKnR-~v`; INTEGRACIÓN → INTEGRACIÓN | STRUCTURALLY_CONFIRMED, mainApi |
| E3 sintético | `service` → `service-to-event` → `event` → `child`; CUSTOM PRODUCER DOMAIN en origen/destino | STRUCTURALLY_CONFIRMED, mainService |

Oski conserva página `msDebitAccountPayment`, componente `CollectionBillPayment - payBill 1.0.0`, operación `debitAccountPayment` y servicio hijo `msDebitAccountPayment` sin igualarlos.

## Negativas

- Múltiples principales: `AMBIGUOUS`.
- Conexión invertida: no genera rol.
- Orientación desconocida: `AMBIGUOUS`.
- Sin evento o raíz: `UNRESOLVED`.
- Sin hijo: `STRUCTURALLY_SUPPORTED`.
- Query/Event y NOTACIÓN: excluidos.
- BDD alterado: resultado idéntico.
- `ms-`, `ms_`, `ms ` y `msCamel`: señal; `mservice`/`mspayment`: no señal.

## Ejecución

- Unitarias/integridad: 26 PASS.
- E2E HTML: 3 PASS.
- Conteos y conexiones originales: PASS.
- HTML autocontenido sin red: PASS.
- Skill: 41 IDs, sin cambios normativos.
