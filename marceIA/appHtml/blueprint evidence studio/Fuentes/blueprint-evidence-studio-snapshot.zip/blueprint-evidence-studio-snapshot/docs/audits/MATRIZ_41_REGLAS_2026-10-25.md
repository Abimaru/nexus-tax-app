# Matriz independiente de las 41 reglas — 25/10/2026

Fuente: `catalogo-reglas-v11.2.csv` y `MATRIZ-EVIDENCIA-41.md` de la Skill v11.2.2 (contrato `copilot-factual-v0.4.6.1`), contrastadas con el motor vigente. Las columnas «criterio» reproducen el catálogo; las columnas de ambigüedad y acción son juicio de esta auditoría y **no modifican ninguna obligación**. La conducta del agente no se toma como interpretación normativa.

Clases de ambigüedad: A evidencia insuficiente de Evidence Studio · B contrato JSON incompleto/contradictorio · C instrucción operativa de la Skill insuficiente · D ambigüedad normativa · E mala interpretación del agente · F resultado correcto que requiere mejor justificación.
Grupos de acción: 1 ajuste autorizado sin cambio normativo · 2 ajuste operativo de la Skill · 3 decisión normativa pendiente (solo con aprobación expresa).

## CNT-001 — Contenedores padre requeridos

- **Obligación vigente:** Deben identificarse INTEGRACIÓN y los demás contenedores padre aplicables al escenario, sin confundir auxiliares o leyendas.
- **Población evaluable:** Blueprint completo
- **Condición de aplicabilidad / No aplica:** Fuera de la población evaluable.
- **Evidencia requerida:** Jerarquía estructural y nombres certificados.
- **Campo del JSON compacto:** `components, architecturalDomain`
- **Evidencia declarativa requerida:** Ninguna (la respuesta humana no certifica estructura)
- **Cumple:** Evidencia positiva y completa de que se satisface: Deben identificarse INTEGRACIÓN y los demás contenedores padre aplicables al escenario, sin confundir auxiliares o leyendas.
- **No cumple:** Falta un contenedor obligatorio con cobertura completa.
- **No verificable:** La jerarquía o el nombre del contenedor no están certificados.
- **No aplica:** Fuera de la población evaluable.
- **Dependencia del escenario:** Sí: los padres aplicables dependen del escenario
- **Dependencia de evidencia visual:** No (nombres de contenedor son texto exportado)
- **Ambigüedad detectada:** «Demás contenedores padre aplicables» no está enumerado; «cobertura completa» sin definir (C15-Q2). Clase D.
- **Acción recomendada:** Pedir a la analista la lista cerrada de padres por escenario y la definición de cobertura completa. Grupo 3.
- **Estado de aprobación:** VIGENTE (texto aprobado); interpretación PENDIENTE

## CNT-002 — Estructura del contenedor hijo

- **Obligación vigente:** Evaluar el dominio arquitectónico efectivo del hijo: E1/E3 no gestionado dentro del DOMINIO PRODUCTOR y E2 gestionado dentro de INTEGRACIÓN; capas intermedias no invalidan el escenario.
- **Población evaluable:** Contenedor hijo principal
- **Condición de aplicabilidad / No aplica:** Fuera de la población evaluable.
- **Evidencia requerida:** Padre directo, cadena de ancestros, dominio arquitectónico efectivo y escenario certificados.
- **Campo del JSON compacto:** `scenario, architecturalDomain, domainRole`
- **Evidencia declarativa requerida:** Ninguna (la respuesta humana no certifica estructura)
- **Cumple:** Evidencia positiva y completa de que se satisface: Evaluar el dominio arquitectónico efectivo del hijo: E1/E3 no gestionado dentro del DOMINIO PRODUCTOR y E2 gestionado dentro de INTEGRACIÓN; capas intermedias no invalidan el escenario.
- **No cumple:** La estructura contradice el escenario certificado.
- **No verificable:** El padre directo o el escenario no pueden certificarse.
- **No aplica:** Fuera de la población evaluable.
- **Dependencia del escenario:** Sí: E1/E3 vs E2. Escenario real siempre HIPOTESIS (0/341 BPMNEvent con customData)
- **Dependencia de evidencia visual:** No
- **Ambigüedad detectada:** (1) «Escenario certificado» admite dos lecturas defendibles: escenario identificado estructuralmente (incluye HIPOTESIS) o CONFIRMADO; la evidencia mínima no menciona Inicio. (2) PRODUCER estructural (Recaudos, CORE GLOBAL ACCOUNT) es decisión previa confirmada; el catálogo usa «DOMINIO PRODUCTOR» como dominio efectivo y no exige nombre literal: sin acción. Clase D.
- **Acción recomendada:** Solo la lectura (1) queda como decisión normativa pendiente (Q2). Texto sin cambios.
- **Estado de aprobación:** VIGENTE (texto aprobado) (F-13); lectura de «escenario certificado» PENDIENTE

## CNT-003 — Contenido permitido en INTEGRACIÓN

- **Obligación vigente:** La API principal de E1/E2 y componentes de integración aplicables deben estar en INTEGRACIÓN; no trasladar contenido por proximidad.
- **Población evaluable:** INTEGRACIÓN
- **Condición de aplicabilidad / No aplica:** Fuera de la población evaluable.
- **Evidencia requerida:** Contención directa certificada.
- **Campo del JSON compacto:** `structuralParent, containerChainIds, domainRole`
- **Evidencia declarativa requerida:** Ninguna (la respuesta humana no certifica estructura)
- **Cumple:** Evidencia positiva y completa de que se satisface: La API principal de E1/E2 y componentes de integración aplicables deben estar en INTEGRACIÓN; no trasladar contenido por proximidad.
- **No cumple:** Existe un componente prohibido o un componente obligatorio está fuera.
- **No verificable:** La contención es parcial o contradictoria.
- **No aplica:** Fuera de la población evaluable.
- **Dependencia del escenario:** Sí (API principal E1/E2 en INTEGRACIÓN)
- **Dependencia de evidencia visual:** No
- **Ambigüedad detectada:** «Componentes de integración aplicables» y «componente prohibido» sin lista cerrada. Clase D.
- **Acción recomendada:** Definir lista permitida/prohibida de INTEGRACIÓN. Grupo 3.
- **Estado de aprobación:** VIGENTE (texto aprobado); interpretación PENDIENTE

## CNT-004 — Contenido permitido en dominio productor

- **Obligación vigente:** El dominio productor contiene el hijo de E1/E3, el servicio principal de E3 y componentes backend aplicables.
- **Población evaluable:** Dominio productor
- **Condición de aplicabilidad / No aplica:** Fuera de la población evaluable.
- **Evidencia requerida:** Contención directa certificada.
- **Campo del JSON compacto:** `structuralParent, containerChainIds, domainRole`
- **Evidencia declarativa requerida:** Ninguna (la respuesta humana no certifica estructura)
- **Cumple:** Evidencia positiva y completa de que se satisface: El dominio productor contiene el hijo de E1/E3, el servicio principal de E3 y componentes backend aplicables.
- **No cumple:** Existe ubicación incompatible con el escenario o tipo.
- **No verificable:** Dominio o contención no certificados.
- **No aplica:** Fuera de la población evaluable.
- **Dependencia del escenario:** Sí
- **Dependencia de evidencia visual:** No
- **Ambigüedad detectada:** «Componentes backend aplicables» abierto; mismo problema del productor inferido que CNT-002. Clase D.
- **Acción recomendada:** Igual que CNT-003 para el dominio productor. Grupo 3.
- **Estado de aprobación:** VIGENTE (texto aprobado); interpretación PENDIENTE

## CNT-005 — Contenido permitido en SISTEMAS EXTERNOS

- **Obligación vigente:** Solo componentes externos y auxiliares válidos deben aparecer en este contenedor.
- **Población evaluable:** SISTEMAS EXTERNOS
- **Condición de aplicabilidad / No aplica:** Fuera de la población evaluable.
- **Evidencia requerida:** Jerarquía y clasificación del componente.
- **Campo del JSON compacto:** `structuralParent, containerChainIds, domainRole`
- **Evidencia declarativa requerida:** Ninguna (la respuesta humana no certifica estructura)
- **Cumple:** Evidencia positiva y completa de que se satisface: Solo componentes externos y auxiliares válidos deben aparecer en este contenedor.
- **No cumple:** Componente propio ubicado como externo o contenido no permitido.
- **No verificable:** No se certifica externalidad o contención.
- **No aplica:** Fuera de la población evaluable.
- **Dependencia del escenario:** No
- **Dependencia de evidencia visual:** No
- **Ambigüedad detectada:** «Externo válido» no definido. No aplica solo si no existe el contenedor SISTEMAS EXTERNOS. Clase D.
- **Acción recomendada:** Mantener; documentar cuándo un componente es «propio» vs «externo».
- **Estado de aprobación:** VIGENTE (texto aprobado)

## CNT-006 — Exclusividad de padre directo

- **Obligación vigente:** No asumir propiedad por cercanía, alineación, ancestro o padre compartido.
- **Población evaluable:** Componentes evaluables
- **Condición de aplicabilidad / No aplica:** Fuera de la población evaluable.
- **Evidencia requerida:** structuralParent y relaciones de contención coherentes.
- **Campo del JSON compacto:** `structuralParent.status, issues`
- **Evidencia declarativa requerida:** Ninguna (la respuesta humana no certifica estructura)
- **Cumple:** Evidencia positiva y completa de que se satisface: No asumir propiedad por cercanía, alineación, ancestro o padre compartido.
- **No cumple:** Dos padres directos incompatibles con cobertura completa.
- **No verificable:** Padres múltiples, parciales o contradictorios.
- **No aplica:** Fuera de la población evaluable.
- **Dependencia del escenario:** No
- **Dependencia de evidencia visual:** No
- **Ambigüedad detectada:** Población «componentes evaluables» no precisa (¿incluye raíz?). C15-Q3. Clase D.
- **Acción recomendada:** Decisión del analista (opción A + advertencia C recomendada).
- **Estado de aprobación:** VIGENTE (texto aprobado); PENDIENTE C15-Q3

## EXT-001 — Sistema externo auxiliar válido

- **Obligación vigente:** Puede contener API, servicio, evento o gestor externo cuando corresponda.
- **Población evaluable:** Sistema externo auxiliar
- **Condición de aplicabilidad / No aplica:** Fuera de la población evaluable.
- **Evidencia requerida:** Padre directo y componentes contenidos.
- **Campo del JSON compacto:** `architecturalType, containedComponentIds`
- **Evidencia declarativa requerida:** Ninguna (la respuesta humana no certifica estructura)
- **Cumple:** Evidencia positiva y completa de que se satisface: Puede contener API, servicio, evento o gestor externo cuando corresponda.
- **No cumple:** Auxiliar en ubicación no permitida o contenido incompatible.
- **No verificable:** Ubicación o clasificación no certificada.
- **No aplica:** Fuera de la población evaluable.
- **Dependencia del escenario:** No
- **Dependencia de evidencia visual:** Parcial: el auxiliar es un BPMNGroup con nombre real; sin nombre es agrupación
- **Ambigüedad detectada:** Condicionada a la presencia de la figura: No aplica vs No verificable (C15-Q1). Clase D.
- **Acción recomendada:** Decisión C15-Q1.
- **Estado de aprobación:** VIGENTE (texto aprobado); PENDIENTE C15-Q1

## EXT-002 — Conexión mediante auxiliar externo

- **Obligación vigente:** Con un único candidato compatible puede atribuirse la conexión; con varios, la asociación específica queda no verificable.
- **Población evaluable:** Conexiones a auxiliares
- **Condición de aplicabilidad / No aplica:** Fuera de la población evaluable.
- **Evidencia requerida:** Extremos, auxiliar y candidatos contenidos.
- **Campo del JSON compacto:** `connections`
- **Evidencia declarativa requerida:** Ninguna (la respuesta humana no certifica estructura)
- **Cumple:** Evidencia positiva y completa de que se satisface: Con un único candidato compatible puede atribuirse la conexión; con varios, la asociación específica queda no verificable.
- **No cumple:** No cumple solo si la comunicación está certificadamente ausente o es incompatible, nunca por terminar en el auxiliar.
- **No verificable:** Varios candidatos compatibles o asociación no demostrada.
- **No aplica:** Fuera de la población evaluable.
- **Dependencia del escenario:** No
- **Dependencia de evidencia visual:** Parcial
- **Ambigüedad detectada:** Con varios candidatos compatibles queda No verificable; sin auxiliar, C15-Q1. Clase D.
- **Acción recomendada:** Decisión C15-Q1.
- **Estado de aprobación:** VIGENTE (texto aprobado); PENDIENTE C15-Q1

## GW-001 — Caminos alternos del gateway

- **Obligación vigente:** No basta identificar la figura; los caminos deben ser coherentes y reconstruibles.
- **Población evaluable:** Gateways BPMN
- **Condición de aplicabilidad / No aplica:** Fuera de la población evaluable.
- **Evidencia requerida:** Gateway y conexiones de entrada/salida.
- **Campo del JSON compacto:** `lucidchartType, connections`
- **Evidencia declarativa requerida:** Ninguna (la respuesta humana no certifica estructura)
- **Cumple:** Evidencia positiva y completa de que se satisface: No basta identificar la figura; los caminos deben ser coherentes y reconstruibles.
- **No cumple:** Caminos incompletos o incoherentes con cobertura completa.
- **No verificable:** No se certifican extremos, direcciones o cobertura.
- **No aplica:** Fuera de la población evaluable.
- **Dependencia del escenario:** No
- **Dependencia de evidencia visual:** Sí: los caminos alternos requieren texto de condición de las salidas
- **Ambigüedad detectada:** «Caminos coherentes y reconstruibles» sin criterio numérico; sin gateway, C15-Q1. Clases C/D.
- **Acción recomendada:** Decisión C15-Q1; precisar qué es coherente en el Procedimiento.
- **Estado de aprobación:** VIGENTE (texto aprobado); PENDIENTE C15-Q1

## API-001 — Nombramiento y versión de API

- **Obligación vigente:** Nombre específico, no genérico, con la estructura y versión aprobadas.
- **Población evaluable:** API principal e invocadas
- **Condición de aplicabilidad / No aplica:** Fuera de la población evaluable.
- **Evidencia requerida:** Secciones textuales completas.
- **Campo del JSON compacto:** `name, textAreas`
- **Evidencia declarativa requerida:** Ninguna (la respuesta humana no certifica estructura)
- **Cumple:** Evidencia positiva y completa de que se satisface: Nombre específico, no genérico, con la estructura y versión aprobadas.
- **No cumple:** Nombre o versión fuera del patrón.
- **No verificable:** Texto parcial o clasificación API no certificada.
- **No aplica:** Fuera de la población evaluable.
- **Dependencia del escenario:** No
- **Dependencia de evidencia visual:** No
- **Ambigüedad detectada:** «Genérico» y «versión aprobada» se evalúan por texto; la población «invocadas» es inalcanzable en el corpus real (INVOCADO no se emite). Clase A/D.
- **Acción recomendada:** Mantener; documentar que INVOCADO no se emite.
- **Estado de aprobación:** VIGENTE (texto aprobado)

## API-002 — Operación de API

- **Obligación vigente:** La operación no puede ser vacía, genérica ni de plantilla.
- **Población evaluable:** API principal e invocadas
- **Condición de aplicabilidad / No aplica:** Fuera de la población evaluable.
- **Evidencia requerida:** Segunda sección u operación certificada.
- **Campo del JSON compacto:** `operation, textAreas`
- **Evidencia declarativa requerida:** Ninguna (la respuesta humana no certifica estructura)
- **Cumple:** Evidencia positiva y completa de que se satisface: La operación no puede ser vacía, genérica ni de plantilla.
- **No cumple:** Operación ausente o genérica con exportación completa.
- **No verificable:** Sección incompleta o asociación no certificada.
- **No aplica:** Fuera de la población evaluable.
- **Dependencia del escenario:** No
- **Dependencia de evidencia visual:** No
- **Ambigüedad detectada:** Misma población que API-001.
- **Acción recomendada:** Mantener.
- **Estado de aprobación:** VIGENTE (texto aprobado)

## API-003 — Tipo y modelo de servicio de API

- **Obligación vigente:** Tipo private/public/partner y modelo deben estar declarados; no reclasificar automáticamente como servicio si faltan.
- **Población evaluable:** API principal e invocadas
- **Condición de aplicabilidad / No aplica:** Fuera de la población evaluable.
- **Evidencia requerida:** Tercera sección y señales estructurales.
- **Campo del JSON compacto:** `textAreas, architecturalType`
- **Evidencia declarativa requerida:** Exposición si falta (DECLARADO_POR_ANALISTA)
- **Cumple:** Evidencia positiva y completa de que se satisface: Tipo private/public/partner y modelo deben estar declarados; no reclasificar automáticamente como servicio si faltan.
- **No cumple:** API certificada con tipo/modelo ausente o inválido.
- **No verificable:** Clasificación API/servicio o tipo no certificado.
- **No aplica:** Fuera de la población evaluable.
- **Dependencia del escenario:** No
- **Dependencia de evidencia visual:** No
- **Ambigüedad detectada:** Tercera sección sin tipo/modelo: el piloto dio No cumple en 4/4 páginas (O4) mientras la Skill pregunta la exposición si falta. Dos caminos (preguntar vs No cumple). Clases C/F.
- **Acción recomendada:** Aclarar en el Procedimiento si tras la respuesta DECLARADO_POR_ANALISTA de exposición la regla pasa de No cumple a Cumple. Grupo 2/3.
- **Estado de aprobación:** VIGENTE (texto aprobado); interpretación PENDIENTE

## API-004 — Detalle de despliegue de API

- **Obligación vigente:** Private MCI: Capa y Flujo; partner MCI: Capa; public: no aplican.
- **Población evaluable:** API principal
- **Condición de aplicabilidad / No aplica:** Fuera de la población evaluable.
- **Evidencia requerida:** Tipo, MCI y asociaciones de Capa/Flujo.
- **Campo del JSON compacto:** `deploymentAssociations`
- **Evidencia declarativa requerida:** MCI principal (DECLARADO_POR_ANALISTA)
- **Cumple:** Evidencia positiva y completa de que se satisface: Private MCI: Capa y Flujo; partner MCI: Capa; public: no aplican.
- **No cumple:** Falta detalle obligatorio o existe detalle no permitido.
- **No verificable:** Tipo, MCI o asociación no certificados.
- **No aplica:** Fuera de la población evaluable.
- **Dependencia del escenario:** Parcial (API principal)
- **Dependencia de evidencia visual:** No
- **Ambigüedad detectada:** Depende del MCI principal (declarado) y de la exposición; duplicado funcional con CA-001/FT-001 (O3). Clase C.
- **Acción recomendada:** Definir qué regla porta el hallazgo de Capa/Flujo ausente (una sola). Grupo 3.
- **Estado de aprobación:** VIGENTE (texto aprobado); interpretación PENDIENTE

## SRV-001 — Nombramiento y versión opcional de servicio

- **Obligación vigente:** Puede iniciar por ms; admite -, _ o espacios. Si hay versión, V/v y tres segmentos.
- **Población evaluable:** Servicios principal e invocados
- **Condición de aplicabilidad / No aplica:** Fuera de la población evaluable.
- **Evidencia requerida:** Primera sección completa.
- **Campo del JSON compacto:** `name, textAreas`
- **Evidencia declarativa requerida:** Ninguna (la respuesta humana no certifica estructura)
- **Cumple:** Evidencia positiva y completa de que se satisface: Puede iniciar por ms; admite -, _ o espacios. Si hay versión, V/v y tres segmentos.
- **No cumple:** Nombre genérico o versión presente con formato inválido.
- **No verificable:** Clasificación o texto no certificados.
- **No aplica:** Fuera de la población evaluable.
- **Dependencia del escenario:** No
- **Dependencia de evidencia visual:** No
- **Ambigüedad detectada:** ¿El SERVICIO_HIJO entra en «servicios principal e invocados»? (O6). Prefijo ms opcional. Clase C/D.
- **Acción recomendada:** Pregunta a la analista: población SRV (hijo principal sí/no).
- **Estado de aprobación:** VIGENTE (texto aprobado); PENDIENTE población

## SRV-002 — Operación del servicio

- **Obligación vigente:** No deducir operación del nombre.
- **Población evaluable:** Servicios principal e invocados
- **Condición de aplicabilidad / No aplica:** Fuera de la población evaluable.
- **Evidencia requerida:** Segunda sección completa.
- **Campo del JSON compacto:** `operation, textAreas`
- **Evidencia declarativa requerida:** Ninguna (la respuesta humana no certifica estructura)
- **Cumple:** Evidencia positiva y completa de que se satisface: No deducir operación del nombre.
- **No cumple:** Operación ausente, genérica o fuera de camelCase.
- **No verificable:** Sección incompleta o servicio no certificado.
- **No aplica:** Fuera de la población evaluable.
- **Dependencia del escenario:** No
- **Dependencia de evidencia visual:** No
- **Ambigüedad detectada:** Misma población.
- **Acción recomendada:** Ídem SRV-001.
- **Estado de aprobación:** VIGENTE (texto aprobado); PENDIENTE población

## SRV-003 — Modelo de servicio

- **Obligación vigente:** Valores permitidos: entidad, utilidad o tarea; el servicio no tiene tipo API.
- **Población evaluable:** Servicios principal e invocados
- **Condición de aplicabilidad / No aplica:** Fuera de la población evaluable.
- **Evidencia requerida:** Tercera sección completa.
- **Campo del JSON compacto:** `textAreas, architecturalType`
- **Evidencia declarativa requerida:** Ninguna (la respuesta humana no certifica estructura)
- **Cumple:** Evidencia positiva y completa de que se satisface: Valores permitidos: entidad, utilidad o tarea; el servicio no tiene tipo API.
- **No cumple:** Modelo ausente o fuera del catálogo.
- **No verificable:** Clasificación API/servicio no certificada.
- **No aplica:** Fuera de la población evaluable.
- **Dependencia del escenario:** No
- **Dependencia de evidencia visual:** No
- **Ambigüedad detectada:** Misma población; «el servicio no tiene tipo API».
- **Acción recomendada:** Ídem SRV-001.
- **Estado de aprobación:** VIGENTE (texto aprobado); PENDIENTE población

## EVT-001 — Nombramiento y versión del evento

- **Obligación vigente:** Guion entre producto/capacidad, versión obligatoria, V/v equivalentes y guion bajo opcional.
- **Población evaluable:** Eventos de integración
- **Condición de aplicabilidad / No aplica:** Fuera de la población evaluable.
- **Evidencia requerida:** Primera sección.
- **Campo del JSON compacto:** `name, textAreas`
- **Evidencia declarativa requerida:** Ninguna (la respuesta humana no certifica estructura)
- **Cumple:** Evidencia positiva y completa de que se satisface: Guion entre producto/capacidad, versión obligatoria, V/v equivalentes y guion bajo opcional.
- **No cumple:** Texto completo fuera del patrón.
- **No verificable:** Evento o texto no certificados.
- **No aplica:** Fuera de la población evaluable.
- **Dependencia del escenario:** No
- **Dependencia de evidencia visual:** No
- **Ambigüedad detectada:** Población «eventos de integración» vs BPMNEvent: la Skill debe distinguir figura de evento de integración de BPMNEvent. Clase C.
- **Acción recomendada:** Mantener; confirmar definición de población.
- **Estado de aprobación:** VIGENTE (texto aprobado)

## EVT-002 — Operación del evento

- **Obligación vigente:** No deducir de la sección de nombre.
- **Población evaluable:** Eventos de integración
- **Condición de aplicabilidad / No aplica:** Fuera de la población evaluable.
- **Evidencia requerida:** Segunda sección.
- **Campo del JSON compacto:** `operation, textAreas`
- **Evidencia declarativa requerida:** Ninguna (la respuesta humana no certifica estructura)
- **Cumple:** Evidencia positiva y completa de que se satisface: No deducir de la sección de nombre.
- **No cumple:** Operación ausente, genérica o fuera de PascalCase.
- **No verificable:** Sección incompleta.
- **No aplica:** Fuera de la población evaluable.
- **Dependencia del escenario:** No
- **Dependencia de evidencia visual:** No
- **Ambigüedad detectada:** Ídem.
- **Acción recomendada:** Mantener.
- **Estado de aprobación:** VIGENTE (texto aprobado)

## EVT-003 — Tipo y clasificación del evento

- **Obligación vigente:** Aceptar equivalencia de tilde en Aplicacion.
- **Población evaluable:** Eventos de integración
- **Condición de aplicabilidad / No aplica:** Fuera de la población evaluable.
- **Evidencia requerida:** Tercera sección.
- **Campo del JSON compacto:** `textAreas, customData`
- **Evidencia declarativa requerida:** Ninguna (la respuesta humana no certifica estructura)
- **Cumple:** Evidencia positiva y completa de que se satisface: Aceptar equivalencia de tilde en Aplicacion.
- **No cumple:** Valor ausente o fuera del catálogo.
- **No verificable:** Clasificación no certificada.
- **No aplica:** Fuera de la población evaluable.
- **Dependencia del escenario:** No
- **Dependencia de evidencia visual:** No
- **Ambigüedad detectada:** Equivalencia de tilde ya definida. El subtipo del BPMNEvent (Inicio) es otra cosa (customData).
- **Acción recomendada:** Mantener.
- **Estado de aprobación:** VIGENTE (texto aprobado)

## EVT-004 — Detalle de despliegue del evento

- **Obligación vigente:** Propio MCI requiere Capa y Flujo; no MCI no debe tenerlos; externo no aplica.
- **Población evaluable:** Eventos propios
- **Condición de aplicabilidad / No aplica:** Fuera de la población evaluable.
- **Evidencia requerida:** Propiedad, MCI y asociaciones.
- **Campo del JSON compacto:** `deploymentAssociations`
- **Evidencia declarativa requerida:** MCI del componente aplicable (DECLARADO_POR_ANALISTA)
- **Cumple:** Evidencia positiva y completa de que se satisface: Propio MCI requiere Capa y Flujo; no MCI no debe tenerlos; externo no aplica.
- **No cumple:** Falta detalle obligatorio o hay detalle no permitido.
- **No verificable:** Propiedad, MCI o asociación no certificados.
- **No aplica:** Fuera de la población evaluable.
- **Dependencia del escenario:** No
- **Dependencia de evidencia visual:** No
- **Ambigüedad detectada:** Propiedad MCI del evento depende de respuesta de la analista; «externo no aplica». Clase C.
- **Acción recomendada:** Mantener.
- **Estado de aprobación:** VIGENTE (texto aprobado)

## EVT-005 — Contenedor de tópicos

- **Obligación vigente:** Aplica siempre a eventos certificados.
- **Población evaluable:** Eventos de integración
- **Condición de aplicabilidad / No aplica:** Fuera de la población evaluable.
- **Evidencia requerida:** Contención/asociación estructural.
- **Campo del JSON compacto:** `structuralParent, containerChainIds`
- **Evidencia declarativa requerida:** Ninguna (la respuesta humana no certifica estructura)
- **Cumple:** Evidencia positiva y completa de que se satisface: Aplica siempre a eventos certificados.
- **No cumple:** Ausente con cobertura completa.
- **No verificable:** Candidato sin asociación demostrada.
- **No aplica:** Fuera de la población evaluable.
- **Dependencia del escenario:** No
- **Dependencia de evidencia visual:** No
- **Ambigüedad detectada:** «Aplica siempre» a eventos certificados; asociación solo por contención/asociación estructural. Clase D.
- **Acción recomendada:** Mantener.
- **Estado de aprobación:** VIGENTE (texto aprobado)

## EVT-006 — Cantidad y roles de tópicos

- **Obligación vigente:** Query p+s; Command p+s, solo p o solo s; Event exactamente p o s.
- **Población evaluable:** Eventos de integración
- **Condición de aplicabilidad / No aplica:** Fuera de la población evaluable.
- **Evidencia requerida:** Clasificación y tópicos asociados.
- **Campo del JSON compacto:** `textAreas`
- **Evidencia declarativa requerida:** Ninguna (la respuesta humana no certifica estructura)
- **Cumple:** Evidencia positiva y completa de que se satisface: Query p+s; Command p+s, solo p o solo s; Event exactamente p o s.
- **No cumple:** Cantidad o combinación inválida.
- **No verificable:** Clasificación o asociación no certificadas.
- **No aplica:** Fuera de la población evaluable.
- **Dependencia del escenario:** No
- **Dependencia de evidencia visual:** No
- **Ambigüedad detectada:** Depende de EVT-003.
- **Acción recomendada:** Mantener.
- **Estado de aprobación:** VIGENTE (texto aprobado)

## EVT-007 — Nombramiento de tópicos

- **Obligación vigente:** Debe incluir producto y capacidad; código de aplicación opcional; X entero > 0.
- **Población evaluable:** Tópicos asociados
- **Condición de aplicabilidad / No aplica:** Fuera de la población evaluable.
- **Evidencia requerida:** Texto completo del tópico.
- **Campo del JSON compacto:** `textAreas`
- **Evidencia declarativa requerida:** Ninguna (la respuesta humana no certifica estructura)
- **Cumple:** Evidencia positiva y completa de que se satisface: Debe incluir producto y capacidad; código de aplicación opcional; X entero > 0.
- **No cumple:** Tópico fuera del patrón.
- **No verificable:** Texto o asociación incompletos.
- **No aplica:** Fuera de la población evaluable.
- **Dependencia del escenario:** No
- **Dependencia de evidencia visual:** No
- **Ambigüedad detectada:** C15-Q1 la menciona por extensión (sin tópicos).
- **Acción recomendada:** Mantener.
- **Estado de aprobación:** VIGENTE (texto aprobado)

## EVT-008 — Conexiones del evento

- **Obligación vigente:** Query y Command p+s bidireccionales; p: BPMNEvent->evento; s: evento->BPMNEvent. CircleOpen origen y Generalization destino.
- **Población evaluable:** Eventos de integración
- **Condición de aplicabilidad / No aplica:** Fuera de la población evaluable.
- **Evidencia requerida:** Clasificación, tópicos y extremos.
- **Campo del JSON compacto:** `connections`
- **Evidencia declarativa requerida:** Ninguna (la respuesta humana no certifica estructura)
- **Cumple:** Evidencia positiva y completa de que se satisface: Query y Command p+s bidireccionales; p: BPMNEvent->evento; s: evento->BPMNEvent. CircleOpen origen y Generalization destino.
- **No cumple:** Falta dirección obligatoria o extremos incorrectos.
- **No verificable:** Dirección, clasificación, tópicos o cobertura no certificados.
- **No aplica:** Fuera de la población evaluable.
- **Dependencia del escenario:** No
- **Dependencia de evidencia visual:** No
- **Ambigüedad detectada:** Direcciones y estilos de extremo literales (CircleOpen/Generalization).
- **Acción recomendada:** Mantener.
- **Estado de aprobación:** VIGENTE (texto aprobado)

## CA-001 — Existencia y nombramiento de Capa

- **Obligación vigente:** Patrón Capa de Arquitectura - tipo; tipos composicion, experiencia, sistema, minúsculos y sin tilde.
- **Población evaluable:** Componentes con Capa aplicable
- **Condición de aplicabilidad / No aplica:** Fuera de la población evaluable.
- **Evidencia requerida:** Figura y texto completos.
- **Campo del JSON compacto:** `architecturalType, name`
- **Evidencia declarativa requerida:** Ninguna (la respuesta humana no certifica estructura)
- **Cumple:** Evidencia positiva y completa de que se satisface: Patrón Capa de Arquitectura - tipo; tipos composicion, experiencia, sistema, minúsculos y sin tilde.
- **No cumple:** Ausente cuando es obligatoria o nombre inválido.
- **No verificable:** Aplicabilidad o cobertura no certificadas.
- **No aplica:** Fuera de la población evaluable.
- **Dependencia del escenario:** No
- **Dependencia de evidencia visual:** No
- **Ambigüedad detectada:** «Componentes con Capa aplicable»: cuándo es obligatoria depende de API-004/EVT-004/MQ-004. En el piloto duplicó API-004 (O3). Clase C/D.
- **Acción recomendada:** Ídem API-004. Grupo 3.
- **Estado de aprobación:** VIGENTE (texto aprobado); interpretación PENDIENTE

## CA-002 — Asociación de Capa

- **Obligación vigente:** No preguntar ni inferir por proximidad.
- **Población evaluable:** Capas existentes
- **Condición de aplicabilidad / No aplica:** No existe figura de Capa.
- **Evidencia requerida:** Asociación estructural exclusiva.
- **Campo del JSON compacto:** `deploymentAssociations`
- **Evidencia declarativa requerida:** Ninguna (la respuesta humana no certifica estructura)
- **Cumple:** Evidencia positiva y completa de que se satisface: No preguntar ni inferir por proximidad.
- **No cumple:** Propietario incorrecto certificado.
- **No verificable:** Asociación no demostrada o varios candidatos.
- **No aplica:** No existe figura de Capa.
- **Dependencia del escenario:** No
- **Dependencia de evidencia visual:** No
- **Ambigüedad detectada:** Asociación solo por contención explícita o grupo superior común inequívoco; No aplica si no hay figura Capa.
- **Acción recomendada:** Mantener.
- **Estado de aprobación:** VIGENTE (texto aprobado)

## FT-001 — Existencia y nombramiento de Flujo

- **Obligación vigente:** Patrón Flujo Transaccional - tipo; monetario, no-monetario, operativo, transversal.
- **Población evaluable:** Componentes con Flujo aplicable
- **Condición de aplicabilidad / No aplica:** Fuera de la población evaluable.
- **Evidencia requerida:** Figura y texto completos.
- **Campo del JSON compacto:** `architecturalType, name`
- **Evidencia declarativa requerida:** Ninguna (la respuesta humana no certifica estructura)
- **Cumple:** Evidencia positiva y completa de que se satisface: Patrón Flujo Transaccional - tipo; monetario, no-monetario, operativo, transversal.
- **No cumple:** Ausente cuando es obligatorio o nombre inválido.
- **No verificable:** Aplicabilidad o cobertura no certificadas.
- **No aplica:** Fuera de la población evaluable.
- **Dependencia del escenario:** No
- **Dependencia de evidencia visual:** No
- **Ambigüedad detectada:** Ídem CA-001.
- **Acción recomendada:** Ídem API-004. Grupo 3.
- **Estado de aprobación:** VIGENTE (texto aprobado); interpretación PENDIENTE

## FT-002 — Asociación de Flujo

- **Obligación vigente:** No preguntar ni inferir por proximidad.
- **Población evaluable:** Flujos existentes
- **Condición de aplicabilidad / No aplica:** No existe figura de Flujo.
- **Evidencia requerida:** Asociación estructural exclusiva.
- **Campo del JSON compacto:** `deploymentAssociations`
- **Evidencia declarativa requerida:** Ninguna (la respuesta humana no certifica estructura)
- **Cumple:** Evidencia positiva y completa de que se satisface: No preguntar ni inferir por proximidad.
- **No cumple:** Propietario incorrecto certificado.
- **No verificable:** Asociación no demostrada o varios candidatos.
- **No aplica:** No existe figura de Flujo.
- **Dependencia del escenario:** No
- **Dependencia de evidencia visual:** No
- **Ambigüedad detectada:** Ídem CA-002.
- **Acción recomendada:** Mantener.
- **Estado de aprobación:** VIGENTE (texto aprobado)

## E1-001 — Estructura integral E1

- **Obligación vigente:** API principal en INTEGRACIÓN; hijo no gestionado con dominio efectivo DOMINIO PRODUCTOR; conexión declarada al evento de Inicio cuando sea exigible.
- **Población evaluable:** Escenario E1
- **Condición de aplicabilidad / No aplica:** Escenario certificado E2 o E3.
- **Evidencia requerida:** API, hijo, padre directo, cadena de ancestros, dominio efectivo, semántica de Inicio y extremos.
- **Campo del JSON compacto:** `scenario, dominios, conexión`
- **Evidencia declarativa requerida:** MCI principal e hijo (DECLARADO_POR_ANALISTA)
- **Cumple:** Evidencia positiva y completa de que se satisface: API principal en INTEGRACIÓN; hijo no gestionado con dominio efectivo DOMINIO PRODUCTOR; conexión declarada al evento de Inicio cuando sea exigible.
- **No cumple:** La estructura certificada contradice E1.
- **No verificable:** Algún participante, relación o cobertura no certificado.
- **No aplica:** Escenario certificado E2 o E3.
- **Dependencia del escenario:** Sí (E1)
- **Dependencia de evidencia visual:** No
- **Ambigüedad detectada:** Escenario HIPOTESIS ⇒ No verificable. Criterio dice «conexión declarada» para E1/E2 y «directa» para E3: la decisión directa vs declarada está pendiente. Clases B/D.
- **Acción recomendada:** Decisión analista: directa vs declarada; alcance de la hipótesis. Grupo 3.
- **Estado de aprobación:** VIGENTE (texto aprobado) (F-13); PENDIENTE directa/declarada

## E2-001 — Estructura integral E2

- **Obligación vigente:** API principal e hijo separados y gestionados bajo INTEGRACIÓN; conexión declarada al evento de Inicio cuando sea exigible.
- **Población evaluable:** Escenario E2
- **Condición de aplicabilidad / No aplica:** Escenario certificado E1 o E3.
- **Evidencia requerida:** API, hijo, padre directo, cadena de ancestros, dominio raíz, semántica de Inicio y extremos.
- **Campo del JSON compacto:** `scenario, dominios, conexión`
- **Evidencia declarativa requerida:** MCI principal e hijo (DECLARADO_POR_ANALISTA)
- **Cumple:** Evidencia positiva y completa de que se satisface: API principal e hijo separados y gestionados bajo INTEGRACIÓN; conexión declarada al evento de Inicio cuando sea exigible.
- **No cumple:** La estructura certificada contradice E2.
- **No verificable:** Algún participante, relación o cobertura no certificado.
- **No aplica:** Escenario certificado E1 o E3.
- **Dependencia del escenario:** Sí (E2)
- **Dependencia de evidencia visual:** No
- **Ambigüedad detectada:** Ídem E1-001.
- **Acción recomendada:** Ídem.
- **Estado de aprobación:** VIGENTE (texto aprobado); PENDIENTE directa/declarada

## E3-001 — Estructura integral E3

- **Obligación vigente:** Servicio principal fuera del hijo; ambos con el mismo dominio efectivo DOMINIO PRODUCTOR; conexión directa al evento de Inicio cuando sea exigible.
- **Población evaluable:** Escenario E3
- **Condición de aplicabilidad / No aplica:** Escenario certificado E1 o E2.
- **Evidencia requerida:** Servicio, hijo, padre directo, cadena de ancestros, dominio efectivo, semántica de Inicio y extremos.
- **Campo del JSON compacto:** `scenario, dominios, conexión`
- **Evidencia declarativa requerida:** MCI principal e hijo (DECLARADO_POR_ANALISTA)
- **Cumple:** Evidencia positiva y completa de que se satisface: Servicio principal fuera del hijo; ambos con el mismo dominio efectivo DOMINIO PRODUCTOR; conexión directa al evento de Inicio cuando sea exigible.
- **No cumple:** La estructura certificada contradice E3.
- **No verificable:** Algún participante, relación o cobertura no certificado.
- **No aplica:** Escenario certificado E1 o E2.
- **Dependencia del escenario:** Sí (E3)
- **Dependencia de evidencia visual:** No
- **Ambigüedad detectada:** Ídem E1-001; el criterio usa «directa».
- **Acción recomendada:** Ídem. Armonizar redacción con E1/E2 tras la decisión.
- **Estado de aprobación:** VIGENTE (texto aprobado) (F-13); PENDIENTE directa/declarada

## MOD-001 — Modelos de entrada y salida

- **Obligación vigente:** Principal API/servicio: entrada+salida obligatorias. Invocados: ausencia no verificable. Eventos según Query/Command/Event y p/s. Modelos internos del hijo no requieren propietario individual.
- **Población evaluable:** API/servicio principal, invocados y eventos
- **Condición de aplicabilidad / No aplica:** Fuera de la población evaluable.
- **Evidencia requerida:** Asociaciones explícitas, clasificación y tópicos.
- **Campo del JSON compacto:** `customData, textAreas, groups`
- **Evidencia declarativa requerida:** Ninguna (la respuesta humana no certifica estructura)
- **Cumple:** Evidencia positiva y completa de que se satisface: Principal API/servicio: entrada+salida obligatorias. Invocados: ausencia no verificable. Eventos según Query/Command/Event y p/s. Modelos internos del hijo no requieren propietario individual.
- **No cumple:** Falta modelo obligatorio con componente, asociación y cobertura certificados.
- **No verificable:** Asociación/evidencia insuficiente; invocados sin modelos verificables.
- **No aplica:** Fuera de la población evaluable.
- **Dependencia del escenario:** Parcial (Query/Command/Event, p/s)
- **Dependencia de evidencia visual:** Sí: ENTRADA/SALIDA se reconocen por grupos/customData/texto
- **Ambigüedad detectada:** Principal exige entrada+salida: sin modelos, No cumple en 4/4 páginas del piloto (O7). La asociación se hace sin inferir propietarios. Clase B/F.
- **Acción recomendada:** Verificar que el JSON compacto exporta los modelos (customData, grupos) y que Evidence Studio los asocia; decidir si «sin modelos exportados» es No cumple o No verificable. Grupo 1/3.
- **Estado de aprobación:** VIGENTE (texto aprobado); interpretación PENDIENTE

## COM-001 — Nombramiento de comandos

- **Obligación vigente:** Una actividad conectada con API, servicio o gestor se evalúa una vez; no inferir por clase o semántica.
- **Población evaluable:** BPMNActivity con relación certificada
- **Condición de aplicabilidad / No aplica:** No hay comandos certificados ni candidatos.
- **Evidencia requerida:** Relación certificada y texto de actividad.
- **Campo del JSON compacto:** `textAreas, connections`
- **Evidencia declarativa requerida:** Ninguna (la respuesta humana no certifica estructura)
- **Cumple:** Evidencia positiva y completa de que se satisface: Una actividad conectada con API, servicio o gestor se evalúa una vez; no inferir por clase o semántica.
- **No cumple:** Nombre fuera del patrón.
- **No verificable:** Candidato sin relación certificada.
- **No aplica:** No hay comandos certificados ni candidatos.
- **Dependencia del escenario:** No
- **Dependencia de evidencia visual:** No
- **Ambigüedad detectada:** Se evalúa una vez por actividad con relación certificada; sin comandos, No aplica. Clase D menor.
- **Acción recomendada:** Mantener.
- **Estado de aprobación:** VIGENTE (texto aprobado)

## COM-002 — Conexión comando con API invocada

- **Obligación vigente:** Comando->API y API->comando, CircleOpen origen y Generalization destino.
- **Población evaluable:** Comandos y APIs invocadas
- **Condición de aplicabilidad / No aplica:** No hay APIs invocadas relacionadas con comandos.
- **Evidencia requerida:** Dos conexiones y clasificaciones.
- **Campo del JSON compacto:** `connections, architecturalType`
- **Evidencia declarativa requerida:** Ninguna (la respuesta humana no certifica estructura)
- **Cumple:** Evidencia positiva y completa de que se satisface: Comando->API y API->comando, CircleOpen origen y Generalization destino.
- **No cumple:** Falta una dirección o extremos incorrectos con cobertura completa.
- **No verificable:** Participantes, dirección o cobertura no certificados.
- **No aplica:** No hay APIs invocadas relacionadas con comandos.
- **Dependencia del escenario:** No
- **Dependencia de evidencia visual:** No
- **Ambigüedad detectada:** APIs invocadas inalcanzables ⇒ habitualmente No aplica. Clase A.
- **Acción recomendada:** Mantener.
- **Estado de aprobación:** VIGENTE (texto aprobado)

## COM-003 — Conexión comando con servicio invocado

- **Obligación vigente:** Comando->servicio y servicio->comando, CircleOpen origen y Generalization destino.
- **Población evaluable:** Comandos y servicios invocados
- **Condición de aplicabilidad / No aplica:** No hay servicios invocados relacionados con comandos.
- **Evidencia requerida:** Dos conexiones y clasificaciones.
- **Campo del JSON compacto:** `connections, architecturalType`
- **Evidencia declarativa requerida:** Ninguna (la respuesta humana no certifica estructura)
- **Cumple:** Evidencia positiva y completa de que se satisface: Comando->servicio y servicio->comando, CircleOpen origen y Generalization destino.
- **No cumple:** Falta una dirección o extremos incorrectos con cobertura completa.
- **No verificable:** Participantes, dirección o cobertura no certificados.
- **No aplica:** No hay servicios invocados relacionados con comandos.
- **Dependencia del escenario:** No
- **Dependencia de evidencia visual:** No
- **Ambigüedad detectada:** Ídem COM-002 para servicios invocados.
- **Acción recomendada:** Mantener.
- **Estado de aprobación:** VIGENTE (texto aprobado)

## COM-004 — Conexión comando con gestor de colas

- **Obligación vigente:** Patrón vigente de comando con gestor, evaluado exclusivamente en COM.
- **Población evaluable:** Comandos y gestores
- **Condición de aplicabilidad / No aplica:** No hay gestores relacionados con comandos.
- **Evidencia requerida:** Conexiones, extremos y participantes certificados.
- **Campo del JSON compacto:** `connections, architecturalType`
- **Evidencia declarativa requerida:** Ninguna (la respuesta humana no certifica estructura)
- **Cumple:** Evidencia positiva y completa de que se satisface: Patrón vigente de comando con gestor, evaluado exclusivamente en COM.
- **No cumple:** Patrón incumplido con cobertura completa.
- **No verificable:** Participantes, dirección, extremos o cobertura no certificados.
- **No aplica:** No hay gestores relacionados con comandos.
- **Dependencia del escenario:** No
- **Dependencia de evidencia visual:** No
- **Ambigüedad detectada:** Evaluada solo en COM; sin gestor, No aplica.
- **Acción recomendada:** Mantener.
- **Estado de aprobación:** VIGENTE (texto aprobado)

## MQ-001 — Identificación y nombramiento del gestor

- **Obligación vigente:** Conservar definición vigente de MQ-001; clasificación y nombre específicos.
- **Población evaluable:** Gestores de colas
- **Condición de aplicabilidad / No aplica:** Fuera de la población evaluable.
- **Evidencia requerida:** Tipo, rol, estructura y nombre.
- **Campo del JSON compacto:** `architecturalType, name`
- **Evidencia declarativa requerida:** Ninguna (la respuesta humana no certifica estructura)
- **Cumple:** Evidencia positiva y completa de que se satisface: Conservar definición vigente de MQ-001; clasificación y nombre específicos.
- **No cumple:** Gestor certificado con nombre inválido.
- **No verificable:** Clasificación como gestor no certificada.
- **No aplica:** Fuera de la población evaluable.
- **Dependencia del escenario:** No
- **Dependencia de evidencia visual:** No
- **Ambigüedad detectada:** Sin figura de gestor: No aplica (piloto, 4/4) vs No verificable (expectativa). La ausencia de la figura no equivale a la ausencia de la obligación (criterio aprobado). C15-Q1. Clase D.
- **Acción recomendada:** Decisión C15-Q1 (¿gestor opcional?).
- **Estado de aprobación:** VIGENTE (texto aprobado); PENDIENTE C15-Q1

## MQ-002 — Ubicación del gestor

- **Obligación vigente:** Gestor externo permitido en auxiliar de SISTEMAS EXTERNOS.
- **Población evaluable:** Gestores de colas
- **Condición de aplicabilidad / No aplica:** Fuera de la población evaluable.
- **Evidencia requerida:** Padre directo y externalidad.
- **Campo del JSON compacto:** `structuralParent, domainRole`
- **Evidencia declarativa requerida:** Ninguna (la respuesta humana no certifica estructura)
- **Cumple:** Evidencia positiva y completa de que se satisface: Gestor externo permitido en auxiliar de SISTEMAS EXTERNOS.
- **No cumple:** Ubicación fuera de las permitidas.
- **No verificable:** Ubicación o externalidad no certificadas.
- **No aplica:** Fuera de la población evaluable.
- **Dependencia del escenario:** No
- **Dependencia de evidencia visual:** No
- **Ambigüedad detectada:** Ídem MQ-001.
- **Acción recomendada:** Decisión C15-Q1.
- **Estado de aprobación:** VIGENTE (texto aprobado); PENDIENTE C15-Q1

## MQ-003 — Modelo de despliegue del gestor

- **Obligación vigente:** En INTEGRACIÓN: MCI. Fuera: debe declarar Federado.
- **Población evaluable:** Gestores de colas
- **Condición de aplicabilidad / No aplica:** Fuera de la población evaluable.
- **Evidencia requerida:** Ubicación y etiqueta/modelo.
- **Campo del JSON compacto:** `domainRole, textAreas`
- **Evidencia declarativa requerida:** MCI del gestor si falta (DECLARADO_POR_ANALISTA)
- **Cumple:** Evidencia positiva y completa de que se satisface: En INTEGRACIÓN: MCI. Fuera: debe declarar Federado.
- **No cumple:** Modelo incompatible con ubicación.
- **No verificable:** Ubicación o modelo no certificados.
- **No aplica:** Fuera de la población evaluable.
- **Dependencia del escenario:** No
- **Dependencia de evidencia visual:** No
- **Ambigüedad detectada:** Ídem MQ-001; pregunta MCI del gestor si falta.
- **Acción recomendada:** Decisión C15-Q1.
- **Estado de aprobación:** VIGENTE (texto aprobado); PENDIENTE C15-Q1

## MQ-004 — Detalle de despliegue del gestor

- **Obligación vigente:** En INTEGRACIÓN: Capa y Flujo obligatorios. Fuera: no debe tener Capa ni Flujo.
- **Población evaluable:** Gestores de colas
- **Condición de aplicabilidad / No aplica:** Fuera de la población evaluable.
- **Evidencia requerida:** Ubicación y asociaciones de Capa/Flujo.
- **Campo del JSON compacto:** `deploymentAssociations`
- **Evidencia declarativa requerida:** Ninguna (la respuesta humana no certifica estructura)
- **Cumple:** Evidencia positiva y completa de que se satisface: En INTEGRACIÓN: Capa y Flujo obligatorios. Fuera: no debe tener Capa ni Flujo.
- **No cumple:** Falta detalle obligatorio o existe detalle no permitido.
- **No verificable:** Asociación o cobertura no certificadas.
- **No aplica:** Fuera de la población evaluable.
- **Dependencia del escenario:** No
- **Dependencia de evidencia visual:** No
- **Ambigüedad detectada:** Ídem MQ-001.
- **Acción recomendada:** Decisión C15-Q1.
- **Estado de aprobación:** VIGENTE (texto aprobado); PENDIENTE C15-Q1

## MQ-005 — Conexión gestor con servicio invocado

- **Obligación vigente:** Conservar patrón vigente; no trasladar a COM y no duplicar COM-004.
- **Población evaluable:** Gestores y servicios invocados
- **Condición de aplicabilidad / No aplica:** No hay servicios invocados relacionados con gestores.
- **Evidencia requerida:** Conexiones, extremos y participantes.
- **Campo del JSON compacto:** `connections`
- **Evidencia declarativa requerida:** Ninguna (la respuesta humana no certifica estructura)
- **Cumple:** Evidencia positiva y completa de que se satisface: Conservar patrón vigente; no trasladar a COM y no duplicar COM-004.
- **No cumple:** Patrón incumplido con cobertura completa.
- **No verificable:** Participantes, dirección, extremos o cobertura no certificados.
- **No aplica:** No hay servicios invocados relacionados con gestores.
- **Dependencia del escenario:** No
- **Dependencia de evidencia visual:** No
- **Ambigüedad detectada:** Su texto declara No aplica si no hay servicios invocados relacionados con gestores: criterio TECHNICAL.
- **Acción recomendada:** Mantener.
- **Estado de aprobación:** VIGENTE (texto aprobado)
