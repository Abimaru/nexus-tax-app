# Anexo propuesto para la Skill — candidaturas de rol

Estado: propuesta no incorporada a la Skill oficial.

`architecturalRoleCandidates[]` puede orientar la búsqueda de API/servicio principal, pero es evidencia derivada no normativa. El agente debe volver a comprobar conexión, orientación, cadena, dominio, hijo, clasificación funcional y BDD. `INFERRED` no equivale a escenario certificado ni a Cumple. `CANDIDATE`, `AMBIGUOUS` y `UNRESOLVED` requieren conservar incertidumbre. Nunca usar la hipótesis de escenario para justificar circularmente el rol que permitió formularla.
