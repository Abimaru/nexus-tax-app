// Simulates three candidate package layouts (NOT a Skill, NOT a ZIP) to measure size and test the verification design.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
const S = 'C:/Users/ABIMARU/AppData/Local/Temp/claude/C--Users-ABIMARU-Desktop-Desarrollo-blueprint-evidence-studio/d58e4513-4869-481b-9616-ebce70ebdfe5/scratchpad/';
const OUT = S + 'sim/';
const REPO = 'C:/Users/ABIMARU/Desktop/Desarrollo/blueprint-evidence-studio/';
const rules = JSON.parse(fs.readFileSync(S + 'catalogo-analista-derivado.json', 'utf8'));
const { CAN } = await import('./canon-fix.mjs');
const FIELDS = [['resumen', 'Resumen oficial'], ['aplica_a', 'Población (Aplica a)'], ['criterio', 'Obligación (Criterio)'], ['evidencia', 'Evidencia mínima'], ['cumple', 'Cumple'], ['no_cumple', 'No cumple'], ['no_verificable', 'No verificable'], ['no_aplica', 'No aplica']];
const un = s => String(s ?? '').replace(/ ¶ /g, '\n\n').trim();
const sha = s => crypto.createHash('sha256').update(s).digest('hex');
const tok = n => Math.round(n / 3.6);
// canonical block: one per rule, delimiters <!--RULE id-->; this is the ONLY place the normative text lives
const block = r => `<!--RULE ${r.id}-->\n## ${r.id} — ${r.titulo}\n\n` + FIELDS.map(([k, l]) => `**${l}:** ${un(r[k])}`).join('\n\n') + `\n<!--/RULE ${r.id}-->\n`;
const canonical = rules.map(block);
const canonicalHash = Object.fromEntries(rules.map(r => [r.id, Object.fromEntries(FIELDS.map(([k]) => [k, sha(un(r[k]))]))]));
const groups = {
  A: Object.entries(rules.reduce((a, r) => ((a[r.fuente.replace(/^\d\d-reglas-/, '').replace('.md', '')] ??= []).push(r), a), {})).map(([n, rs], i) => [`reglas-${String(i + 1).padStart(2, '0')}-${n}.md`, rs]),
  B: [['reglas-1-estructura-y-contenido.md', f => /^(CNT|EXT|GW)/.test(f)], ['reglas-2-apis-servicios-modelos.md', f => /^(API|SRV|MOD)/.test(f)], ['reglas-3-eventos-y-escenarios.md', f => /^(EVT|E[123])/.test(f)], ['reglas-4-conexiones-y-despliegue.md', f => /^(CA|FT|COM|MQ)/.test(f)]].map(([n, p]) => [n, rules.filter(r => p(r.id))]),
  C: [['catalogo-normativo.md', rules]]
};
const header = (title, rs) => `# ${title}\n\nTexto normativo literal. IDs: ${rs.map(r => r.id).join(', ')}.\n\n`;
const R = n => fs.readFileSync(n, 'utf8').replace(/^\uFEFF/, '');
const analyst = S + 'analyst-zip/validar-blueprint-integracion-v11.2.2/validar-blueprint-integracion/references/';
const common = {
  'procedimiento.md': R(analyst + '00-procedimiento.md'),
  'contrato-compacto.md': R(REPO + 'skills/validar-blueprint-integracion/references/CONTRATO-COMPACTO.md'),
  'glosario-normativo.md': (() => { const m = R(analyst + 'MANIFEST.md'); const a = m.indexOf('### Lenguaje normativo vigente'), b = m.indexOf('### Controles obligatorios del catálogo'); return '# Glosario y respuestas humanas autorizadas (literal del MANIFEST de la analista)\n\n' + m.slice(a, b).trim() + '\n'; })(),
  'guia-textareas.md': R(REPO + 'skills/validar-blueprint-integracion/references/GUIA-TEXTAREAS.md')
};
const skillMd = R(S + 'skill-v12-draft.md');
const index = (layout) => {
  const fileOf = id => layout.find(([, rs]) => (Array.isArray(rs) ? rs : []).some(r => r.id === id))[0];
  return '# Índice de reglas (generado)\n\n| ID | Título | Archivo | Campos del contrato | Pregunta a la analista |\n|---|---|---|---|---|\n' + rules.map(r => `| ${r.id} | ${r.titulo} | references/${fileOf(r.id)}#${r.id} | ${CAN[r.id].campo.replace(/\|/g, '/').slice(0, 140)} | ${/^(API-004)$/.test(r.id) ? 'MCI API principal; exposición si falta' : r.id === 'SRV-004' ? 'MCI hijo principal (E1/E2)' : '—'} |`).join('\n') + '\n';
};
const result = {};
for (const [arch, layoutRaw] of Object.entries(groups)) {
  const layout = layoutRaw.map(([n, rs]) => [n, rs]);
  const dir = OUT + arch + '/'; fs.rmSync(dir, { recursive: true, force: true }); fs.mkdirSync(dir + 'references', { recursive: true });
  const files = { 'SKILL.md': skillMd };
  for (const [n, rs] of layout) files['references/' + n] = header(n.replace('.md', ''), rs) + rs.map(block).join('\n');
  for (const [n, t] of Object.entries(common)) files['references/' + n] = t;
  files['references/indice-reglas.md'] = index(layout);
  files['references/obligaciones.sha256.txt'] = rules.map(r => sha(FIELDS.map(([k]) => un(r[k])).join(String.fromCharCode(10))) + '  ' + r.id).join(String.fromCharCode(10)) + String.fromCharCode(10);
  for (const [n, t] of Object.entries(files)) fs.writeFileSync(dir + n, t);
  const sizes = Object.fromEntries(Object.entries(files).map(([n, t]) => [n, Buffer.byteLength(t)]));
  const total = Object.values(sizes).reduce((a, b) => a + b, 0);
  const ruleFiles = Object.entries(sizes).filter(([n]) => /references\/(reglas-|catalogo-normativo)/.test(n));
  const ruleBytes = ruleFiles.reduce((a, [, b]) => a + b, 0);
  const mustRead = ['SKILL.md', 'references/procedimiento.md', 'references/contrato-compacto.md', 'references/guia-textareas.md', 'references/glosario-normativo.md', 'references/indice-reglas.md'].map(n => sizes[n]).reduce((a, b) => a + b, 0) + ruleBytes;
  const maxFile = Math.max(...ruleFiles.map(([, b]) => b));
  const avgLookup = ruleFiles.reduce((a, [, b], _, arr) => a + b, 0) / ruleFiles.length;
  // weighted by rules per file for a random-rule lookup
  const weighted = layout.reduce((a, [n, rs]) => a + rs.length * sizes['references/' + n], 0) / rules.length;
  result[arch] = { files: Object.keys(files).length, totalBytes: total, totalTokens: tok(total), skillMdBytes: sizes['SKILL.md'], ruleFiles: ruleFiles.length, ruleBytes, largestRuleFileBytes: maxFile, largestRuleFileTokens: tok(maxFile), fullPageReadBytes: mustRead, fullPageReadTokens: tok(mustRead), fileReadsPerPage: 5 + ruleFiles.length, lookupWeightedBytes: Math.round(weighted), lookupWeightedTokens: tok(weighted), sizes };
}
// ---------------- verifier (design test) on each simulated package
const verify = (arch) => {
  const dir = OUT + arch + '/', problems = [];
  const all = {}; (function w(d) { for (const e of fs.readdirSync(d, { withFileTypes: true })) e.isDirectory() ? w(d + e.name + '/') : (all[(d + e.name).replace(dir, '')] = fs.readFileSync(d + e.name, 'utf8')); })(dir);
  const ruleText = Object.entries(all).filter(([n]) => /references\/(reglas-|catalogo-normativo)/.test(n)).map(([, t]) => t).join('\n');
  const ids = [...ruleText.matchAll(/<!--RULE ([A-Z0-9]+-\d{3})-->/g)].map(m => m[1]);
  if (ids.length !== 37 || new Set(ids).size !== 37) problems.push('IDs: ' + ids.length + ' únicos ' + new Set(ids).size);
  let fieldsOk = 0;
  for (const id of new Set(ids)) { const blk = ruleText.split(`<!--RULE ${id}-->`)[1].split(`<!--/RULE ${id}-->`)[0]; for (const [k, l] of FIELDS) { const m = blk.match(new RegExp(`\\*\\*${l.replace(/[()]/g, '\\$&')}:\\*\\* ([\\s\\S]*?)(?=\\n\\n\\*\\*|$)`)); if (m && sha(m[1].trim()) === canonicalHash[id][k]) fieldsOk++; else problems.push(`campo ${id}.${k}`); } }
  const retired = ['CNT-006', 'EVT-008', 'CA-002', 'FT-002', 'MQ-004', 'MQ-005', 'ACT-001'];
  const operative = Object.entries(all).filter(([n]) => !/references\/(reglas-|catalogo-normativo)|sha256/.test(n));
  for (const [n, t] of operative) for (const rid of retired) if (new RegExp(`\\b${rid}\\b`).test(t)) problems.push(`ID retirado en ${n}: ${rid}`);
  // references: every references/<file>#ID in index + every file name quoted in SKILL.md exists
  for (const m of all['references/indice-reglas.md'].matchAll(/references\/([\w.-]+)#([A-Z0-9]+-\d{3})/g)) { if (!all['references/' + m[1]]) problems.push('archivo inexistente ' + m[1]); else if (!all['references/' + m[1]].includes(`<!--RULE ${m[2]}-->`)) problems.push(`ancla ausente ${m[2]} en ${m[1]}`); }
  for (const m of all['SKILL.md'].matchAll(/references\/([\w.-]+\.(?:md|json))/g)) if (!all['references/' + m[1]]) problems.push('SKILL.md cita archivo inexistente ' + m[1]);
  // separation: SKILL.md must not contain rule sentences (>=50-char sentences shared with rules)
  const norm = s => s.toLowerCase().replace(/[^a-záéíóúñ0-9 ]/g, ' ').replace(/\s+/g, ' ').trim();
  const rs = new Set(ruleText.split(/\n|(?<=[.;:])\s+/).map(norm).filter(x => x.length >= 50));
  for (const t of operative.map(([n, t]) => [n, t])) for (const p of t[1].split(/\n|(?<=[.;:])\s+/).map(norm).filter(x => x.length >= 50)) if (rs.has(p)) problems.push(`texto de regla duplicado en ${t[0]}: ${p.slice(0, 60)}`);
  // 37 mentions only where expected
  for (const [n, t] of operative) if (/\b41\b/.test(t)) problems.push(`mención de 41 en ${n}`);
  return { ids: ids.length, uniqueIds: new Set(ids).size, fieldsIdentical: fieldsOk, problems };
};
for (const a of Object.keys(result)) result[a].verify = verify(a);
fs.writeFileSync(S + 'sim-results.json', JSON.stringify(result, null, 1));
for (const [a, r] of Object.entries(result)) console.log(a, JSON.stringify({ ...r, sizes: undefined, verify: r.verify }, null, 0));

// ---------------- MUTATION TESTS: each defect must be detected by the verifier
const mut = [];
const cp = (from, to) => { fs.rmSync(OUT + to, { recursive: true, force: true }); fs.cpSync(OUT + from, OUT + to, { recursive: true }); };
const edit = (dirName, file, fn) => { const p = OUT + dirName + '/' + file; fs.writeFileSync(p, fn(fs.readFileSync(p, 'utf8'))); };
const RULES = 'references/catalogo-normativo.md';
const cases = [
  ['M1 un carácter cambiado en un campo normativo', d => edit(d, RULES, t => t.replace('prevalece **No cumple**', 'prevalece **No  cumple**').replace('Cumple:** ', 'Cumple:** x'))],
  ['M2 regla omitida (GW-001)', d => edit(d, RULES, t => t.replace(/<!--RULE GW-001-->[\s\S]*?<!--\/RULE GW-001-->\n/, ''))],
  ['M3 regla duplicada (CA-001)', d => edit(d, RULES, t => t + t.match(/<!--RULE CA-001-->[\s\S]*?<!--\/RULE CA-001-->\n/)[0])],
  ['M4 ID retirado usado en SKILL.md', d => edit(d, 'SKILL.md', t => t + '\nEvaluar también CA-002.\n')],
  ['M5 ancla del índice inexistente', d => edit(d, 'references/indice-reglas.md', t => t.replace('#COM-001', '#COM-099'))],
  ['M6 archivo citado por SKILL.md inexistente', d => edit(d, 'SKILL.md', t => t + '\nVer references/MATRIZ-EVIDENCIA-41.md\n')],
  ['M7 criterio normativo copiado en SKILL.md', d => edit(d, 'SKILL.md', t => t + '\nSi existe al menos un incumplimiento certificado, prevalece No cumple aunque otra condición sea no verificable.\n')],
  ['M8 mención de 41 reglas en el procedimiento', d => edit(d, 'references/procedimiento.md', t => t + '\nEntregar 41 resultados.\n')]
];
for (const [name, fn] of cases) { cp('C', 'M'); fn('M'); const v = verify('M'); mut.push({ name, detected: v.problems.some(p => !/mención de 41 en references\/contrato-compacto/.test(p)), problems: v.problems.filter(p => !/contrato-compacto/.test(p)).slice(0, 2) }); }
fs.writeFileSync(S + 'sim-mutations.json', JSON.stringify(mut, null, 1));
for (const m of mut) console.log((m.detected ? 'DETECTADO ' : 'NO DETECTADO ') + m.name + '  ' + JSON.stringify(m.problems).slice(0, 140));
