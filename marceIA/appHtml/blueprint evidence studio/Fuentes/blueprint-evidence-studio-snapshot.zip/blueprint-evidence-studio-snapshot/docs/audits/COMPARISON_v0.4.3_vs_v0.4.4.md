# Comparación v0.4.3 / v0.4.4

v0.4.3 estabilizó el motor único y mantuvo prudente el tipo técnico, pero no producía roles principales contextuales. v0.4.4 añade una proyección derivada sin cambiar la evidencia cruda ni certificar escenarios.

| Área | v0.4.3 | v0.4.4 |
|---|---|---|
| Tipo UML | Conservador | Sin cambio |
| Tercera sección | Una clasificación funcional | Exposición, modelo y evento separados; admite combinaciones |
| Ruta principal | UML↔BPMN en ambos sentidos posibles | Respeta terminaciones y excluye eventos de integración |
| Rol principal | No disponible | Candidaturas no normativas con estado |
| BDD | Conservada en páginas | Evidencia explícita asociada por operación |
| Despliegue | Pareja y candidatos | Contenidos separados de Flujo/Capa y relación explícita |
| E2E | Espera por resultado existente | Espera por generación nueva; conteos y líneas contra originales |

No cambian conexiones, jerarquía, multipágina, ausencia de red, Skill ni los 41 IDs.
