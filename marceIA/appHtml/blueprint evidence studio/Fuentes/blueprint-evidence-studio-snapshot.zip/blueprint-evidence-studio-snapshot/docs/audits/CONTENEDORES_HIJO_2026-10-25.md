# Auditoría de contenedores hijo (`RectangleContainerBlock`) — solo lectura

Reproducible con `node qa/tools/audit-child-containers.mjs --out <archivo>`. Total de contenedores: 25; en páginas OPERATIONAL/MIXED: 20. Ninguna clasificación se modifica.

## Resumen por condición

```json
{
  "sinNombre": {
    "operativas": 8,
    "plantillas": 0
  },
  "sinPadre": {
    "operativas": 6,
    "plantillas": 0
  },
  "anidado": {
    "operativas": 2,
    "plantillas": 0
  },
  "sinRolPrincipal": {
    "operativas": 8,
    "plantillas": 5
  },
  "escenarioNoDeterminado": {
    "operativas": 6,
    "plantillas": 5
  }
}
```

## Contenedores operativos con alguna condición a señalar

| Blueprint · página | ID | Tipo | Rol | Texto | Padre | Contiene | Sin nombre | Sin padre | Anidado | Escenario |
|---|---|---|---|---|---|---|---|---|---|---|
| Debit Card · asociatePreIssuedCardMediadoConsulta | Mm89cWGdOYLg | SERVICIO_HIJO | null | _vacío_ | — (—) | 2 | sí | sí | no | E2 |
| Debit Card · createCustomizedCardConsulta | AAztRTdbhApb | SERVICIO_HIJO | null | _vacío_ | — (—) | 21 | sí | sí | no | NO_DETERMINADO |
| Debit Card · createCustomizedCardConsulta | iy.SVb3uZRsH | SERVICIO_HIJO | null | _vacío_ | — (—) | 68 | sí | sí | no | NO_DETERMINADO |
| Debit Card · createCustomizedCardConsulta | AAztE7-ReJ9u | SERVICIO_HIJO | null | _vacío_ | iy.SVb3uZRsH (CHILD_CONTAINER) | 64 | sí | no | sí | NO_DETERMINADO |
| Debit Card · createVirtualCard | BbYhTgCQpwds | SERVICIO_HIJO | null | _vacío_ | — (—) | 21 | sí | sí | no | NO_DETERMINADO |
| Debit Card · createVirtualCard | BbYhFkV9zgrq | SERVICIO_HIJO | null | _vacío_ | — (—) | 66 | sí | sí | no | NO_DETERMINADO |
| Debit Card · createVirtualCard | BbYhfjREOgCH | SERVICIO_HIJO | null | _vacío_ | BbYhFkV9zgrq (CHILD_CONTAINER) | 62 | sí | no | sí | NO_DETERMINADO |
| Debit Card · createVirtualCardConsulta | X389OYd9uWQh | SERVICIO_HIJO | null | _vacío_ | — (—) | 2 | sí | sí | no | E2 |
