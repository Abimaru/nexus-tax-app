# COMPARACIÓN DE ARQUITECTURAS DE LA SKILL V12

> Candidato, no aprobado. Las tres arquitecturas se **simularon en el área de trabajo** (no son una Skill ni un ZIP) con un prototipo reproducible: `docs/audits/prototipos_skill_v12/simulate-arch.mjs`. Todas parten de la misma fuente: los 37 bloques de reglas del paquete de la analista, 8 campos cada uno (100 642 caracteres normativos).
> Tokens = bytes ÷ 3,6 (estimación; sirve para comparar, no como cifra absoluta).

## 1. Las tres alternativas

| | A. Siete archivos por familia | B. Cuatro archivos agrupados | C. Catálogo único |
|---|---|---|---|
| Archivos de reglas | `reglas-01-estructura` (CNT, EXT, GW) · `-02-api-servicios` · `-03-eventos` · `-04-despliegue` · `-05-escenarios` · `-06-modelos-comandos` · `-07-gestores-colas` (los mismos 7 de la analista) | 1 Estructura y contenido (CNT, EXT, GW) · 2 APIs, servicios y modelos (API, SRV, MOD) · 3 Eventos y escenarios (EVT, E1–E3) · 4 Conexiones y despliegue (CA, FT, COM, MQ) | `catalogo-normativo.md` (37 reglas) |
| Resto del paquete (igual en las tres) | `SKILL.md` breve, `procedimiento`, `contrato-compacto`, `guia-textareas`, `glosario-normativo`, `indice-reglas` (generado), `obligaciones.sha256` | ídem | ídem |

## 2. Medidas (prototipo)

| Medida | A | B | C |
|---|---:|---:|---:|
| Archivos en el paquete | 14 | 11 | 8 |
| Tamaño total (bytes) | 139 508 | 139 725 | 139 047 |
| Tokens estimados del paquete | 38 752 | 38 813 | 38 624 |
| Tamaño de `SKILL.md` | 2 291 | 2 291 | 2 291 |
| Texto normativo duplicado entre archivos | 0 | 0 | 0 |
| Lecturas de archivo tras `SKILL.md` para evaluar una página | 12 | 9 | 6 |
| Tamaño del archivo de reglas más grande | 23 718 B (6 588 tok) | 33 158 B (9 211 tok) | 112 594 B (31 276 tok) |
| Coste medio de consultar **una** regla leyendo su archivo | 18 982 B (5 273 tok) | 28 533 B (7 926 tok) | 112 594 B (31 276 tok) |
| Referencias entre reglas que cruzan archivos (de 31) | 13 | 10 | 0 |
| Anclas del índice a verificar | 37 | 37 | 37 |
| Lectura completa para evaluar una página (SKILL + procedimiento + contrato + guía + glosario + índice + reglas) | 136 779 B (37 994 tok) | 136 996 B (38 054 tok) | 136 318 B (37 866 tok) |

Referencia: el paquete actual de la analista pesa 164 197 B (≈ 45 000 tok); el ZIP v11.2.3, 71 822 B (≈ 19 700 tok).

## 3. Lectura de los datos

1. **Menos archivos no es menos tokens.** La diferencia entre A y C es de 461 bytes (0,3 %). Para evaluar una página hay que leer todas las reglas en cualquier caso; reunirlas o separarlas solo cambia el número de lecturas (12, 9 o 6) y el tamaño del archivo que se puede perder o truncar.
2. **El ahorro real viene de otro lado:** pasar de 164 KB a ≈ 139 KB (−15 %) se logra eliminando lo redundante o generable (CSV de 41 reglas, `INSTRUCCIONES`, `MATRIZ` parafraseada, inventario del `MANIFEST`, historia) y reduciendo `SKILL.md` de 5,9 a 2,3 KB, no tocando la arquitectura de reglas.
3. **El coste de consulta sí cambia mucho:** consultar una regla cuesta 5,3 k tokens en A, 7,9 k en B y 31,3 k en C, salvo que el Copilot permita leer por rango de líneas, algo que no está comprobado (ver `PLAN_PRUEBAS_CARGA_REFERENCIAS`).
4. **Mantenimiento:** A coincide uno a uno con los archivos de la analista; un cambio en una familia toca un solo archivo y se revisa por diferencia. B obliga a regrupar los bloques con un paso de generación; C concentra todos los cambios en un archivo de 112 KB.
5. **Integridad:** en las tres, la verificación por hash de campos (296) y por ancla (37) da el mismo resultado; la diferencia es que A exige comprobar 13 referencias entre archivos y C ninguna. Con 31 referencias totales (17 reglas) el riesgo de A es bajo, y la mayor parte son hacia el archivo de estructura.

## 4. Puntuación cualitativa (1 = peor, 3 = mejor)

| Criterio (orden de prioridad del encargo) | A | B | C | Comentario |
|---|:-:|:-:|:-:|---|
| 1. Exactitud normativa | 3 | 2 | 2 | A puede conservar los bloques de la analista sin regrupar; B y C reorganizan |
| 2. Recuperación correcta de referencias | 3 | 2 | 1 | C depende de que se lea un archivo de 112 KB completo y sin truncar |
| 3. Ausencia de contradicciones | 2 | 2 | 3 | C elimina referencias entre archivos; A y B las mantienen verificables |
| 4. Trazabilidad de evidencia | 3 | 2 | 2 | Un archivo por familia corresponde a la numeración histórica |
| 5. Mantenimiento sencillo | 3 | 2 | 1 | Cambios localizados; el diff es legible |
| 6. Uso eficiente del contexto | 3 | 2 | 1 | Misma lectura total; menor coste por consulta y por relectura |
| Compatibilidad con el empaquetado actual | 3 | 2 | 2 | A mantiene la estructura `references/0N-…` que ya usan los scripts |
| **Total** | **20** | **14** | **12** | |

## 5. Variante A con bloques literales

Los siete archivos de la analista pueden usarse tal cual (110 194 B) o regenerarse desde la fuente con encabezados nuevos (112 930 B en el prototipo, que añade marcas de regla y la lista de IDs). Se recomienda **no copiar los archivos enteros** (traen el título «v11.2.1» y `##`/`###` inconsistentes) sino **reproducir cada bloque de regla byte a byte** y regenerar solo el encabezado del archivo. La prueba de integridad es entonces por **campo** (296 hashes), no por archivo.

## 6. Recomendación

**Arquitectura A: siete archivos por familia, bloques de regla literales, con un índice generado.**

Motivos con evidencia: coste de consulta 6 veces menor que C (5,3 k frente a 31,3 k tokens); coincidencia uno a uno con la fuente de la analista; solo 13 de 31 referencias entre reglas cruzan archivos; el paquete total es igual de grande en las tres (±0,3 %), de modo que no hay beneficio de tokens en agrupar.

Por qué no B: reduce 3 lecturas (12 → 9), pero aumenta un 40 % el archivo mayor, exige un paso de regrupación y rompe la correspondencia con la fuente. Por qué no C: sin ahorro de tokens, 31 k tokens por consulta y el riesgo de truncamiento de un archivo de 112 KB.

Condición: si la prueba de carga en el Copilot (`PLAN_PRUEBAS_CARGA_REFERENCIAS`, T-04 y T-05) mostrara que el Copilot **no** lee archivos de `references/` bajo demanda, la elección pasaría a depender de cuántos archivos puede cargar de una vez, y habría que volver a evaluar B o C con ese dato.
