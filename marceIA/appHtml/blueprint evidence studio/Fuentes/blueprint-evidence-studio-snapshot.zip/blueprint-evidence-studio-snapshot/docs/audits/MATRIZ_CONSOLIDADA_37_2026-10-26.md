# Matriz consolidada de 37 reglas — 26/10/2026

Catálogo base: el derivado literalmente de los siete archivos normativos de la analista (`ANALISTA_CATALOGO_DERIVADO_37_2026-10-26.csv`), **no** el CSV de 41 reglas. Todas las columnas en el CSV; aquí el resumen. «Evidencia disponible» se mide sobre los 7 blueprints reales (14 páginas operativas); la existencia de un campo no se toma como prueba de que contenga evidencia suficiente.

**Grupos:** G1 consolidar ahora · G2 consolidar con una reserva menor · G3 la evaluación (y la definición de «certificado») depende de una convención Lucidchart no aprobada · G4 bloqueada.

| ID vigente | ID histórico | Estado de definición | Grupo | Decisiones | Brecha técnica principal |
|---|---|---|---|---|---|
| CNT-001 | CNT-001 | COMPLETA | G1 | C-03 | G-7 (1 caso real, no INTEGRACIÓN); circularidad PRODUCER/patrón (cerrada por decisión de Andrés, con procedencia). |
| CNT-002 | CNT-002 | COMPLETA | G1 | C-03, C-09 | «No existe hijo» y «existe más de uno» no se distinguen (escenario NO_DETERMINADO, 2 páginas Debit); «específico/genérico» es juicio (C-09). |
| CNT-003 | CNT-003 | COMPLETA_CON_REDACCION_A_CONFIRMAR | G2 | C-06, C-11 | Sin tipo: evento de integración, concepto, pendiente, política, anotación (BPMNTextAnnotation 7 existe como clase), comando, modelo fiable (G-3). |
| CNT-004 | CNT-004 | COMPLETA_CON_REDACCION_A_CONFIRMAR | G2 | C-06, C-11 | Igual que CNT-003. |
| CNT-005 | CNT-005 | COMPLETA_CON_REDACCION_A_CONFIRMAR | G2 | C-06, C-10 | Igual que CNT-003. Consecuencia: un gestor externo no tiene ubicación válida. |
| EXT-001 | EXT-001 | COMPLETA | G1 | C-10 | Auxiliares reales con BPMNEvent y BPMNActivity dentro (VAO, Debit): la regla los prohíbe/deja NV. Auxiliar sin nombre con contenido: 0 casos reales. |
| EXT-002 | — (nueva en nuestro catálogo; el manifiesto la llama «antigu | COMPLETA_CON_ERRATAS | G1 | C-04, C-11 | La API encapsulada es UMLClassBlock sin tipo (G-1): el contenido no se certifica como API. |
| GW-001 | GW-001 | COMPLETA | G1 | C-09 | Coherencia es juicio semántico (C-09). |
| API-001 | API-001 | COMPLETA | G1 | C-04, C-09 | G-1: APIs invocadas sin tipo; inglés/«palabra significativa» no deterministas. |
| API-002 | API-002 | COMPLETA | G1 | C-04, C-09 | Igual que API-001. |
| API-003 | API-003 | COMPLETA | G1 | C-04 | G-1 para APIs no principales. Resuelve la tensión histórica: sección sin modelo = No cumple; la exposición declarada no corrige. |
| API-004 | API-004 | COMPLETA_CON_ERRATAS | G1 | C-11 | G-5: Capa sin Flujo (partner) y `Federado` no se publican. No hay API partner en el corpus (4 private, 5 sin tipo, 1 tarea). |
| SRV-001 | SRV-001 | ESQUELETO_PENDIENTE | G4 | C-01 | Criterio y población sin definir. |
| SRV-002 | SRV-002 | ESQUELETO_PENDIENTE | G4 | C-01 | Criterio y población sin definir. |
| SRV-003 | SRV-003 | COMPLETA | G3 | C-05, C-04 | G-2: rol INVOCADO 0 en el corpus; los comandos usan el patrón bidireccional (56 pares frente a 5 de un sentido). |
| SRV-004 | — (nueva) | COMPLETA | G1 | — | G-5: asociación por grupos no cubre contenedores hijo. |
| EVT-001 | EVT-001 | COMPLETA | G3 | C-04, C-06, C-09 | G-3: sin tipo para evento de integración; MATRIZ-37 apunta a `architecturalType`, que es EVENTO=BPMNEvent (campo equivocado). |
| EVT-002 | EVT-002 | COMPLETA | G3 | C-04, C-06 | Igual que EVT-001. |
| EVT-003 | EVT-003 | COMPLETA | G3 | C-04, C-06 | Igual que EVT-001. |
| EVT-004 | EVT-005 (ID reutilizado: la EVT-004 anterior era despliegue) | COMPLETA | G3 | C-06 | G-3: sin tipo para Capa de Tópicos. |
| EVT-005 | EVT-006 | COMPLETA_CON_ERRATAS | G3 | C-06, C-11 | Depende de EVT-004; viñeta «No aplica» con contenido de «No verificable». |
| EVT-006 | EVT-007 | COMPLETA_CON_ERRATAS | G3 | C-06, C-11 | Falta reconocer el tópico y su capa (G-3). |
| EVT-007 | EVT-008 | COMPLETA_CON_ERRATAS | G3 | C-07, C-06, C-11 | G-4: Señal de Envío/Recepción no certificable; el catálogo propuesto no distingue envío. |
| CA-001 | CA-001 (la existencia pasa a otras reglas; CA-002 retirada) | COMPLETA | G1 | — | G-6: un prefijo mal escrito no se tipa (queda NV, no No cumple). |
| FT-001 | FT-001 (FT-002 retirada) | COMPLETA | G1 | — | G-6. |
| E1-001 | E1-001 | COMPLETA_CON_CONFLICTO_INTERNO | G2 | C-07, C-08 | G-4; el No cumple de la regla exige Inicio certificado pero el procedimiento dice que el incumplimiento certificado prevalece. |
| E2-001 | E2-001 | COMPLETA_CON_CONFLICTO_INTERNO | G2 | C-07, C-08 | Igual. |
| E3-001 | E3-001 | COMPLETA_CON_CONFLICTO_INTERNO | G2 | C-07, C-08 | Igual. |
| MOD-001 | MOD-001 | COMPLETA | G2 | C-13 | Asociación por grupo vs «mismo contenedor»; eventos de integración sin tipo (G-3). |
| COM-001 | COM-001 | COMPLETA | G1 | C-12, C-09 | «Relación identificable» sin definir; infinitivo/español es juicio. |
| COM-002 | COM-002 | COMPLETA | G3 | C-05, C-04, C-12 | G-1, G-2: API invocada no certificable. |
| COM-003 | COM-003 | COMPLETA | G3 | C-05, C-04, C-12 | Igual; SERVICIO solo por prefijo `ms`. |
| COM-004 | COM-004 | COMPLETA | G1 | C-12 | Ninguna relevante. |
| COM-005 | — (nueva; en 41 un único candidato permitía atribuir la cone | COMPLETA | G2 | C-12 | «Atribución inequívoca» sin definir. |
| MQ-001 | MQ-001 | COMPLETA | G1 | C-09 | «Genérico/plantilla» subjetivo (C-09). Convención técnica promovida a norma. |
| MQ-002 | MQ-003 + MQ-004 (fusión; el ID MQ-002 anterior era ubicación | COMPLETA | G3 | C-06 | G-5: `Federado` no se publica como asociación; cómo se asocia al gestor no está definido. |
| MQ-003 | MQ-005 (ampliada; el ID MQ-003 anterior era modelo de despli | COMPLETA | G3 | C-05, C-07 | G-4 (Mensaje), G-1/G-2. |

- **G1 (15):** CNT-001, CNT-002, EXT-001, EXT-002, GW-001, API-001, API-002, API-003, API-004, SRV-004, CA-001, FT-001, COM-001, COM-004, MQ-001
- **G2 (8):** CNT-003, CNT-004, CNT-005, E1-001, E2-001, E3-001, MOD-001, COM-005
- **G3 (12):** SRV-003, EVT-001, EVT-002, EVT-003, EVT-004, EVT-005, EVT-006, EVT-007, COM-002, COM-003, MQ-002, MQ-003
- **G4 (2):** SRV-001, SRV-002
