# Propuesta: panel «Eventos BPMN con subtipo no certificado»

Fecha: 25/10/2026 · Estado: **propuesta, sin implementar** · Alcance: Evidence Studio (interfaz y exportación) · No modifica la Skill, las 41 obligaciones ni el catálogo de subtipos.

## 1. Situación verificada
- En los 7 blueprints auditados hoy hay **260** figuras `BPMNEvent` y **0** traen `customData` (verificado con `analyzeBlueprint`; las auditorías anteriores citaban 341 sobre un conjunto de archivos más amplio, cifra que hoy no se reconcilió).
- Las 12 páginas con escenario identificado quedan en `scenario.status = HIPOTESIS` con `scenario.event.subtypeStatus = NO_VERIFICABLE`.
- `CONFIRMADO` exige una declaración inequívoca en `customData` con una de las claves `BPMN_EVENT_TYPE`, `EVENT_TYPE` o `TIPO_EVENTO_BPMN` y un valor del catálogo cerrado propuesto (`START`/`INICIO`, `END`/`FIN`, `SIGNAL`/`SENAL`, `RECEIVE`/`RECEPCION`, `EXCEPTION`/`EXCEPCION`). El catálogo es `PROPOSED_CLOSED_CATALOG`: **una propuesta técnica, no un estándar corporativo demostrado**.
- Consecuencia práctica: E1-001, E2-001 y E3-001 no pueden declararse Cumple (Skill v11.2.3, §5) y CNT-002 depende de su lectura pendiente.

## 2. Restricciones de la propuesta
1. No se implementa ninguna convención `customData` nueva sin evidencia corporativa.
2. `PROPOSED_CLOSED_CATALOG` se mantiene tal cual; nombres, texto libre y forma de la figura no certifican el subtipo.
3. Una respuesta de la analista no certifica BPMN (`DECLARADO_POR_ANALISTA` no sirve para esto).
4. Nada de esto cambia cómo se calcula `scenario.status` ni el contrato `copilot-factual-v0.4.6.1`.

## 3. Mejora propuesta (solo presentación, derivable de datos existentes)
### 3.1 Panel «Eventos BPMN con subtipo no certificado» (nombre revisado el 26/10/2026)
El panel no presupone que ningún evento sea de Inicio: lista eventos cuyo subtipo no está certificado, sin importar cuál sea. Por cada página seleccionada, mostrar los `BPMNEvent` que participan en el escenario (`scenario.event.id`) y los que reciben conexiones orientadas desde el componente principal. Columnas:

| Columna | Origen (ya existe) |
|---|---|
| Página y ID del evento | `page`, `scenario.event.id` |
| Estado del subtipo | `scenario.event.subtypeStatus`: `CERTIFIED_BY_EXPLICIT_CUSTOM_DATA`, `NO_VERIFICABLE`, `CONFLICTING_CUSTOM_DATA` |
| Motivo | `scenario.event.conflicts` (`UNRECOGNIZED_OR_MALFORMED_BPMN_EVENT_TYPE_DECLARATION`, `UNRECOGNIZED_BPMN_EVENT_TYPE_VALUE`, `INCOMPATIBLE_BPMN_EVENT_TYPE_DECLARATIONS`) o «sin declaración» |
| Declaración encontrada | `customData` literal del evento, sin interpretarlo |
| Efecto | texto fijo: «Mientras el subtipo no esté certificado, el escenario permanece HIPOTESIS y las reglas que requieren un subtipo certificado no pueden darse por Cumple» |

### 3.2 Contador y advertencia
Un resumen por página («1 de 1 evento BPMN con subtipo no certificado») y una advertencia no bloqueante antes de exportar. La exportación no cambia.

### 3.3 Lo que el panel no hace
No sugiere un valor, no completa `customData`, no llama «de Inicio» a ningún evento antes de certificarlo (ni por ser el primero, estar a la izquierda, tener cierto nombre, texto o forma, ni por descarte). Un texto libre como «Inicio…» dentro de la figura se muestra como texto literal, nunca como subtipo.

## 4. Siguientes pasos que requieren evidencia o aprobación
| Paso | Requiere |
|---|---|
| Confirmar con la analista cómo se declara hoy el subtipo Inicio en Lucidchart (si es que se declara) | Evidencia corporativa |
| Decidir si el catálogo propuesto pasa a ser convención corporativa | Aprobación normativa |
| Si se aprueba, documentar la convención en la plantilla de Lucidchart | Aprobación + versión nueva |

## 5. Pruebas y riesgos de la implementación futura
- Pruebas: página sin eventos; evento con declaración válida; con valor no reconocido; con dos declaraciones incompatibles; `customData` ausente frente a `[]`; páginas no evaluables.
- Riesgo bajo: es presentación sobre campos existentes. Riesgo principal: que el panel se lea como validación normativa; el texto debe decir que describe evidencia, no cumplimiento.
- Versión estimada: 0.4.7 (cambio de interfaz), previa autorización expresa.
