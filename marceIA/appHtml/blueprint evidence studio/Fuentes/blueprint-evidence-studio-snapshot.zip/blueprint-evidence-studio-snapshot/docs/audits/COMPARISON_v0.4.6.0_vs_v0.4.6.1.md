# Comparación v0.4.6.0 → v0.4.6.1

| Área | v0.4.6.0 | v0.4.6.1 |
|---|---|---|
| `customData` compacto | Solo BPMNEvent | Toda figura que declare la propiedad, literal |
| Dominios | Posibilidades junto a rol; externo por descarte | Posibilidades vacías al resolver; sin externo por descarte |
| Tipos/roles | Podía emitir SERVICE, principal ambiguo e INVOCADO débil | SERVICIO normalizado; ambigüedad sin rol/tipo; INVOCADO orientado |
| BPMN | START podía prevalecer sobre declaración dudosa | Toda declaración reconocida dudosa impide CONFIRMADO |
| Grupos | Conflictos no siempre llegaban a asociación | Ciclo, ausencia, membresía y fuentes incompatibles se propagan |
| UI | Admitía cero páginas; selección por título | Bloqueo explícito y preselección por clasificación real |
| Skill | Contrato antiguo y cinco estados | Contrato v0.4.6.1, cuatro estados, diccionario y matriz de 41 IDs |

El diagnóstico sigue siendo compatible y completo. Cambia la versión contractual; no cambian IDs ni obligaciones normativas. La asociación verificada de Currency y la de `nombreOperacion1` permanecen.
