# Anexo propuesto para Skill v11.1 — dominio y escenario estructural

Estado: propuesta; no incorporada a la Skill oficial.

La Skill puede consumir `rootContainers[].role`, `roleSource`, `architecturalRoleCandidates[]` y `structuralScenario` como evidencia derivada. `STRUCTURALLY_CONFIRMED` significa que el patrón estructural E1/E2/E3 está identificado, no que las reglas cumplen. El subtipo Inicio, MCI, capas, flujo y demás obligaciones se evalúan aparte. La fuente `CORPORATE_PARENT_DOMAIN_CONVENTION` debe citarse como inferencia. BDD y nombre de página no justifican el escenario. `normativeEvaluation:null` impide tratar el resultado como dictamen.

No se modifican IDs, F-13 ni la decisión directa/declarada.
