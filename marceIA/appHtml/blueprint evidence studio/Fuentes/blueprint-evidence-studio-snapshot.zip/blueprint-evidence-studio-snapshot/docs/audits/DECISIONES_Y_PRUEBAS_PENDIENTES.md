# Decisiones y pruebas pendientes — norma de 37 reglas

26/10/2026 · Iteración 2 · Documento de trabajo candidato. Reutiliza `DECISIONES_DEPURADAS_2026-10-26.md` y `CONSOLIDACION_NORMATIVA_BASE_Y_PLAN_2026-10-26.md` como referencias históricas; aquí sólo se consolida el estado vigente y se añade el diseño de pruebas. Catálogo: [`CATALOGO_NORMATIVO_37_CANDIDATO.md`](CATALOGO_NORMATIVO_37_CANDIDATO.md). Contrato: [`CONTRATO_EVIDENCIA_OBJETIVO.md`](CONTRATO_EVIDENCIA_OBJETIVO.md). Matriz: [`MATRIZ_NORMA_EVIDENCIA_37.csv`](MATRIZ_NORMA_EVIDENCIA_37.csv).

## 1. Decisiones congeladas (R-01 a R-20) frente a la norma más reciente

Se comprobó cada decisión contra el texto vigente de la analista. **Ninguna es contradicha de forma demostrada.** Dos requieren una acción documental de Andrés (R-03 y R-10 sobre `AGENTS.md`) y una (R-07) un matiz de presentación explicado en la sección 2.

| # | Decisión congelada | Contraste con el texto vigente de la analista | Estado |
|---|---|---|---|
| R-01 | Base = 37 reglas derivadas de los siete archivos | Instrucción de Andrés del 26/10; el CSV del paquete (41) no se usa | Vigente |
| R-02 | CNT-002/CNT-004 no dependen del escenario ni del Inicio | CNT-002: «No se requiere identificar ni certificar un evento BPMN de Inicio»; CNT-004 no lo menciona | Vigente |
| R-03 | F-13 («gestionado/no gestionado») retirado | CNT-002: «no evalúa… su condición de gestionado o no gestionado» | Vigente; Andrés actualiza `AGENTS.md` |
| R-04 | Conexión E1/E2/E3 = línea API→evento `None→Arrow` | Misma redacción en E1-001, E2-001 y E3-001 | Vigente |
| R-05 | Productor estructural cuenta como DOMINIO PRODUCTOR | CNT-001: nombres personalizados válidos «siempre que exista evidencia suficiente» | Vigente |
| R-06 | Hijo principal = servicio principal del escenario | MANIFEST, SRV-003 (lo excluye) y SRV-004 | Vigente; Andrés aprueba adaptar §2 de la Skill |
| R-07 | Plantillas/leyenda/BDD no se evalúan | Ver sección 2 | Vigente; matiz de presentación |
| R-08 | «No aplica» sólo por el criterio de cada regla | Cada regla declara su cláusula «No aplica» | Vigente |
| R-09 | Cascada EVT-004 → EVT-005/006/007 | Viñetas «No aplica» de EVT-005/006/007 | Vigente (con erratas de redacción, C-11) |
| R-10 | Preguntas: MCI API principal, MCI hijo (E1/E2), exposición opcional; sin MCI del gestor | MANIFEST «Respuestas humanas autorizadas»; SKILL | Vigente; Andrés actualiza `AGENTS.md` |
| R-11 | `customData` ENTRADA/SALIDA reconoce los modelos; el nombre no | `GUIA-TEXTAREAS`: evidencia literal, no se transforma en `MODELO` | Vigente |
| R-12 | Un resultado por regla y página | SKILL: «un resultado por cada una de las 37 reglas» | Vigente |
| R-13 | Reversiones explícitas (EVT-001..003, EXT-001, CNT-005) | Textos de esas reglas | Vigente |
| R-14 | API-003: sin modelo = No cumple; la declaración no corrige | API-003 y `GUIA-TEXTAREAS` | Vigente |
| R-15 | API-004, CA-001 y FT-001 separadas | CA-001/FT-001: «evalúa únicamente el nombre» | Vigente |
| R-16 | CNT-006 eliminado; integridad como control previo | MANIFEST y procedimiento §2 | Vigente |
| R-17 | UMLActiveClassBlock = gestor; sin figura, No aplica | MQ-001 y cláusulas «No aplica» | Vigente |
| R-18 | Cuatro estados, fórmula y prioridad de incumplimiento demostrado | Procedimiento §8 y §10 | Vigente |
| R-19 | Reutilizar respuestas entre páginas sólo con confirmación explícita | SKILL y procedimiento §5 | Vigente |
| R-20 | CNT-001/002 con patrón estructural aunque el escenario siga en HIPOTESIS | CNT-001/002: «aunque el cumplimiento integral… no esté confirmado» | Vigente |

## 2. R-07: declarar «No aplica» frente a obligar a evaluar páginas plantilla

**Hechos.** (a) Decisión de Andrés (v11.2.2): `TEMPLATE_OR_LEGEND` y `BDD_OR_REQUIREMENTS` no se evalúan; se informa ID, título, tipo y motivo, sin filas ni porcentaje. (b) Texto de la analista: CNT-001 y CNT-002 declaran **No aplica** cuando «la página no es evaluable porque corresponde exclusivamente a una plantilla o leyenda»; E1/E2/E3-001 dicen que esas páginas «quedan fuera de la población»; el procedimiento §7 empieza por «Confirmar que la página… no es exclusivamente plantilla o leyenda»; el `SKILL.md` pide «Evaluar exactamente las 37 reglas activas por cada página seleccionada».

**Distinción.**

| | Qué dice | Qué implica |
|---|---|---|
| Declaración de No aplica | Las cláusulas de CNT-001/002 y E1-E3 describen el resultado de la regla cuando la página no es evaluable o su población está vacía | Es una **regla de resultado**, no una obligación de evaluar la plantilla; el propio texto la llama «no evaluable» y «fuera de la población» |
| Obligación de evaluar | «37 resultados por página seleccionada» (`SKILL.md`) | Sólo se activaría si una plantilla se selecciona **y** se ignora el paso §7 del procedimiento |

**Conclusión.** No se demuestra contradicción de obligación: el procedimiento de la analista excluye las plantillas antes de evaluar, y sus cláusulas «No aplica» cubren el caso residual. En la métrica ambas lecturas coinciden (No aplica sale del denominador; una página sin reglas aplicables es «no calculable» y no entra en el total). La diferencia es de **presentación** (37 filas «No aplica» frente a un aviso con ID, título, tipo y motivo). R-07 se mantiene; la confirmación de presentación se agrega como punto 9 del lote C-11, sin ampliar el cuestionario.

## 3. Decisiones abiertas C-01 a C-13: estado tras esta iteración

Se revisó si alguna podía resolverse con texto normativo, decisiones aprobadas, código o corpus. **Ninguna se cierra por inferencia técnica.** Lo que cambió es la evidencia disponible para decidir. Las fichas completas (norma, texto, alternativas, consecuencia) siguen en `DECISIONES_DEPURADAS_2026-10-26.md`.

| ID | Tema | ¿Resoluble sin la analista? | Qué se verificó | Propuesta técnica (no aprobada) | Aprueba | Reglas |
|---|---|---|---|---|---|---|
| C-01 | SRV-001/002: criterio y población | No (texto heredado, sin criterio) | Texto idéntico al histórico; 5 `SERVICIO` por prefijo; hijo sin sección de operación | Población = invocados + principal de E3; formato paralelo a API-001/002 | Analista | SRV-001, SRV-002 |
| C-02 | Paquete cerrado y versionado | Sólo en parte (versionado es de Andrés) | CSV de 41; instrucciones/contrato a 41; encabezados v11.2.1; colisión de etiqueta «v11.2.2» | Paquete v12.0.0-rc.1 con N y P separadas | Analista + Andrés | Todas |
| C-03 | Cobertura completa, tabla issue→regla, No aplica unificado | No | La norma usa «cobertura» sin definirla; `issues`, `counts`, `omittedPages` existen | Definición general + tabla | Analista + Andrés | Casi todas |
| C-04 | Certificar API/servicio/evento en figuras no principales | No | 62 `UMLClassBlock` sin tipo; 30 con «Entidad» solo (refuta «tercera sección ⇒ tipo») | Pedir discriminador; mientras tanto No verificable | Analista | API-001, API-002, API-003, EXT-002, SRV-003, COM-002, COM-003, EVT-001, EVT-002, EVT-003, MQ-003 |
| C-05 | Definición de «invocado» y rol `INVOCADO` | No (definición normativa) | Código: exige entrada y ninguna salida; corpus: 0 emitidos, 56 pares bidireccionales | Invocado = no principal ni hijo, relacionado con un comando | Analista + Andrés | SRV-003, COM-002, COM-003, MQ-003 |
| C-06 | Reconocimiento de figuras (tópicos, evento de integración, `Federado`…) | No | Tabla prellenada con ocurrencias reales (`Federado` 8, evento de integración 5, Capa de Tópicos 1) | La analista confirma/completa la tabla | Analista | EVT-001, EVT-002, EVT-003, EVT-004, EVT-005, EVT-006, EVT-007, MQ-002, CNT-003, CNT-004, CNT-005 |
| C-07 | Convención de subtipos BPMN | No | 260 eventos, 0 `customData`; el export no trae subtipo; el catálogo propuesto no cubre Envío ni Mensaje | `customData` explícito si el estándar lo exige; si no, No verificable permanente | Analista + Andrés | E1-001, E2-001, E3-001, EVT-007, MQ-003 |
| C-08 | E1-E3: violación certificada con Inicio sin certificar | No (conflicto interno del texto) | El principio de prioridad (§8) y la viñeta No cumple se contradicen | No cumple si la violación estructural está certificada | Analista | E1-001, E2-001, E3-001 |
| C-09 | Criterios subjetivos | No | Variabilidad observada en CNT-002/CNT-004 (validación v11.2.3) | Listas cerradas de plantilla/genérico; resto, juicio justificado | Analista + Andrés | CNT-002, GW-001, API-001, API-002, API-003, SRV-003, EVT-001, EVT-002, COM-001, MQ-001 |
| C-10 | EXT-001/CNT-005 frente a diagramas reales | No | 34 auxiliares: 21 con `BPMNEvent`, 11 con `BPMNActivity`, 4 vacíos; gestor externo sin ubicación | Confirmar con casos reales | Analista | EXT-001, CNT-005 |
| C-11 | Erratas y confirmaciones editoriales (9 puntos) | Parcialmente (las erratas son evidentes pero no se corrigen sin aprobación) | Autorreferencia EXT-002; «todo la capa» API-004; viñetas No aplica de EVT-005/6/7; hijo en CNT-003/004; capitalización SRV-003; «antigua EXT-003»; presentación de plantillas (punto 9) | Lote de correcciones propuestas | Analista | EXT-002, API-003, API-004, EVT-005, EVT-006, EVT-007, CNT-003, CNT-004, SRV-003 |
| C-12 | COM: «relación» y «atribución inequívoca» | No | 61 pares comando↔componente por conexión; la versión anterior atribuía con un único candidato | Relación = conexión directa; inequívoca = un único componente compatible | Analista | COM-001, COM-005 |
| C-13 | MOD-001: ¿grupo compartido = asociación inequívoca? | No | 160 modelos preservados; 20 en grupo único con el principal, 59 en grupos sin él, 43 sin grupo | Basta si el grupo contiene un único propietario posible | Analista | MOD-001 |

## 4. Cuestionario depurado para la analista (11 puntos, sin ampliar)

1. **C-01** SRV-001/002: población, prefijo `ms`, versión y operación.
2. **C-07** ¿Cómo se declara el subtipo (Inicio, Señal de Envío/Recepción, Mensaje) en Lucidchart?
3. **C-04** ¿Cómo distinguimos API, servicio y evento de integración en las figuras no principales? (con la tabla de las 62).
4. **C-05** ¿Qué es un servicio/API «invocado»?
5. **C-06** Confirmar/completar la tabla de reconocimiento (concepto, pendiente, política, Capa de Tópicos, asociación de «Federado»).
6. **C-08** Violación estructural certificada con Inicio sin certificar: ¿No cumple o No verificable?
7. **C-13** ¿Un grupo con el principal basta para asociar modelos?
8. **C-10** Auxiliares con comandos/eventos dentro; «revisión manual»; ubicación del gestor externo.
9. **C-03/C-09** Definición de cobertura completa y listas cerradas de plantilla/genérico.
10. **C-12** Definición de relación y atribución inequívoca.
11. **C-11** Lote de erratas y confirmaciones (incluida la presentación de páginas plantilla).

## 5. Pendientes de Andrés

1. **C-02**: nomenclatura de versiones y nombre del paquete.
2. `AGENTS.md` (no se modifica en esta iteración): retirar F-13, pasar a 37 reglas, preguntas MCI (hijo sólo en E1/E2), `UMLActiveClassBlock` como norma.
3. Aprobar adaptar §2 de la Skill (R-06) y retirar «no se extiende a CNT-002» y «evaluar API-004/CA-001/FT-001 por separado».
4. Avisar a la analista del tratamiento de plantillas (R-07).
5. Cuando se implemente: `SKILL_VERSION` en `src/version.js` (`11.2.1`).

## 6. Pruebas históricas: separadas por versión, no reutilizables por ID

| Conjunto | Versión de la Skill | Catálogo | Estado frente a las 37 reglas |
|---|---|---|---|
| `c14`, `c15` (Fases 1 a 1.6) | v11.2.1–v11.2.2 | 41 reglas | Histórico. Sus expectativas sobre MQ-001..004, CA-002, FT-002, COM-001..004, EXT-001/002, GW-001 citan IDs que cambian de significado o se retiran |
| `p1`..`p4` (piloto Fase 2) | v11.2.2 | 41 reglas | Histórico; igual |
| `v123-a/b/c` y `v1122cmp-*` (validación v11.2.3) | v11.2.3 y v11.2.2 | 41 reglas | Histórico; sus compactos sintéticos pueden reutilizarse como **entradas**, no sus expectativas |
| `selftest` del controlador (123 pruebas) | — | Lógica del controlador | Reutilizable; las partes que exigen «41 filas» deben parametrizarse |
| `test/skill.test.js` (hash de cuerpos de 41 reglas) | v11.2.x | 41 reglas | No aplica a las 37; se sustituye por pruebas de hash del catálogo nuevo |

**IDs con riesgo de falsa coincidencia:** EXT-002, EVT-004..007, MQ-002, MQ-003 (mismo ID, otra obligación) y, por cambio de semántica, GW-001, SRV-003, CA-001, FT-001, API-004. Cualquier expectativa histórica de esos IDs debe tratarse como de otra regla (ver `MAPEO_IDS_41_A_37_2026-10-26.csv`).

## 7. Pruebas de aceptación candidatas (4 por regla × 37 = 148)

Las expectativas se derivan **sólo del texto normativo**. Esta tabla es la reconciliación de las 148 combinaciones regla–estado; las fichas (entrada sintética, evidencia, justificación, campos, dependencias e invalidantes) están en `PRUEBAS_EJECUTABLES_CANDIDATAS.md`. Una prueba con precondiciones reproducidas **no** es una evaluación normativa aprobada: el resultado esperado sigue siendo una expectativa candidata hasta que lo apruebe la analista y lo compruebe la Skill.

| Categoría | Pruebas |
|---|---|
| EJECUTABLE_DEFINITIVA | 72 |
| BLOQUEADA_POR_CONTRATO | 4 |
| EJECUTABLE_CON_RESERVA | 25 |
| BLOQUEADA_POR_DECISION_NORMATIVA | 21 |
| BLOQUEADA_POR_CONVENCION | 26 |
| **Total** | **148** |

| Prueba | Regla | Estado esperado (candidato) | Categoría | Motivo / reserva |
|---|---|---|---|---|
| PA-CNT-001-C | CNT-001 | Cumple | EJECUTABLE_DEFINITIVA | — |
| PA-CNT-001-NC | CNT-001 | No cumple | BLOQUEADA_POR_CONTRATO | el contrato actual no publica la cobertura o la ausencia demostrada (C-03) |
| PA-CNT-001-NV | CNT-001 | No verificable | EJECUTABLE_DEFINITIVA | — |
| PA-CNT-001-NA | CNT-001 | No aplica | BLOQUEADA_POR_CONTRATO | el contrato actual no publica la cobertura o la ausencia demostrada (C-03) |
| PA-CNT-002-C | CNT-002 | Cumple | EJECUTABLE_DEFINITIVA | — |
| PA-CNT-002-NC | CNT-002 | No cumple | EJECUTABLE_CON_RESERVA | reproducible; el resultado depende de C-09 (lista de plantillas) |
| PA-CNT-002-NV | CNT-002 | No verificable | EJECUTABLE_DEFINITIVA | — |
| PA-CNT-002-NA | CNT-002 | No aplica | BLOQUEADA_POR_DECISION_NORMATIVA | depende de C-09 |
| PA-CNT-003-C | CNT-003 | Cumple | EJECUTABLE_CON_RESERVA | reproducible; el resultado depende de C-06, C-11 |
| PA-CNT-003-NC | CNT-003 | No cumple | EJECUTABLE_DEFINITIVA | — |
| PA-CNT-003-NV | CNT-003 | No verificable | EJECUTABLE_DEFINITIVA | — |
| PA-CNT-003-NA | CNT-003 | No aplica | EJECUTABLE_DEFINITIVA | — |
| PA-CNT-004-C | CNT-004 | Cumple | BLOQUEADA_POR_DECISION_NORMATIVA | depende de C-11 |
| PA-CNT-004-NC | CNT-004 | No cumple | EJECUTABLE_DEFINITIVA | — |
| PA-CNT-004-NV | CNT-004 | No verificable | EJECUTABLE_DEFINITIVA | — |
| PA-CNT-004-NA | CNT-004 | No aplica | EJECUTABLE_DEFINITIVA | — |
| PA-CNT-005-C | CNT-005 | Cumple | EJECUTABLE_CON_RESERVA | reproducible; el resultado depende de C-06 |
| PA-CNT-005-NC | CNT-005 | No cumple | EJECUTABLE_CON_RESERVA | reproducible; el resultado depende de C-10 (consecuencia para gestores externos) |
| PA-CNT-005-NV | CNT-005 | No verificable | BLOQUEADA_POR_DECISION_NORMATIVA | depende de C-10 |
| PA-CNT-005-NA | CNT-005 | No aplica | EJECUTABLE_DEFINITIVA | — |
| PA-EXT-001-C | EXT-001 | Cumple | EJECUTABLE_DEFINITIVA | — |
| PA-EXT-001-NC | EXT-001 | No cumple | EJECUTABLE_CON_RESERVA | reproducible; el resultado depende de C-10 |
| PA-EXT-001-NV | EXT-001 | No verificable | EJECUTABLE_DEFINITIVA | — |
| PA-EXT-001-NA | EXT-001 | No aplica | EJECUTABLE_DEFINITIVA | — |
| PA-EXT-002-C | EXT-002 | Cumple | BLOQUEADA_POR_DECISION_NORMATIVA | depende de C-11 |
| PA-EXT-002-NC | EXT-002 | No cumple | BLOQUEADA_POR_DECISION_NORMATIVA | depende de C-11 |
| PA-EXT-002-NV | EXT-002 | No verificable | EJECUTABLE_CON_RESERVA | reproducible; el resultado depende de C-04 |
| PA-EXT-002-NA | EXT-002 | No aplica | EJECUTABLE_DEFINITIVA | — |
| PA-GW-001-C | GW-001 | Cumple | EJECUTABLE_DEFINITIVA | — |
| PA-GW-001-NC | GW-001 | No cumple | EJECUTABLE_DEFINITIVA | — |
| PA-GW-001-NV | GW-001 | No verificable | EJECUTABLE_DEFINITIVA | — |
| PA-GW-001-NA | GW-001 | No aplica | EJECUTABLE_DEFINITIVA | — |
| PA-API-001-C | API-001 | Cumple | EJECUTABLE_DEFINITIVA | — |
| PA-API-001-NC | API-001 | No cumple | EJECUTABLE_DEFINITIVA | — |
| PA-API-001-NV | API-001 | No verificable | EJECUTABLE_DEFINITIVA | — |
| PA-API-001-NA | API-001 | No aplica | BLOQUEADA_POR_DECISION_NORMATIVA | depende de C-09 |
| PA-API-002-C | API-002 | Cumple | EJECUTABLE_DEFINITIVA | — |
| PA-API-002-NC | API-002 | No cumple | EJECUTABLE_DEFINITIVA | — |
| PA-API-002-NV | API-002 | No verificable | EJECUTABLE_DEFINITIVA | — |
| PA-API-002-NA | API-002 | No aplica | BLOQUEADA_POR_DECISION_NORMATIVA | depende de C-09 |
| PA-API-003-C | API-003 | Cumple | EJECUTABLE_DEFINITIVA | — |
| PA-API-003-NC | API-003 | No cumple | EJECUTABLE_DEFINITIVA | — |
| PA-API-003-NV | API-003 | No verificable | EJECUTABLE_DEFINITIVA | — |
| PA-API-003-NA | API-003 | No aplica | BLOQUEADA_POR_DECISION_NORMATIVA | depende de C-09, C-11 |
| PA-API-004-C | API-004 | Cumple | EJECUTABLE_DEFINITIVA | — |
| PA-API-004-NC | API-004 | No cumple | EJECUTABLE_DEFINITIVA | — |
| PA-API-004-NV | API-004 | No verificable | EJECUTABLE_DEFINITIVA | — |
| PA-API-004-NA | API-004 | No aplica | EJECUTABLE_DEFINITIVA | — |
| PA-SRV-001-C | SRV-001 | Cumple | BLOQUEADA_POR_DECISION_NORMATIVA | C-01: regla en esqueleto; no se fija ninguna expectativa |
| PA-SRV-001-NC | SRV-001 | No cumple | BLOQUEADA_POR_DECISION_NORMATIVA | C-01: regla en esqueleto; no se fija ninguna expectativa |
| PA-SRV-001-NV | SRV-001 | No verificable | BLOQUEADA_POR_DECISION_NORMATIVA | C-01: regla en esqueleto; no se fija ninguna expectativa |
| PA-SRV-001-NA | SRV-001 | No aplica | BLOQUEADA_POR_DECISION_NORMATIVA | C-01: regla en esqueleto; no se fija ninguna expectativa |
| PA-SRV-002-C | SRV-002 | Cumple | BLOQUEADA_POR_DECISION_NORMATIVA | C-01: regla en esqueleto; no se fija ninguna expectativa |
| PA-SRV-002-NC | SRV-002 | No cumple | BLOQUEADA_POR_DECISION_NORMATIVA | C-01: regla en esqueleto; no se fija ninguna expectativa |
| PA-SRV-002-NV | SRV-002 | No verificable | BLOQUEADA_POR_DECISION_NORMATIVA | C-01: regla en esqueleto; no se fija ninguna expectativa |
| PA-SRV-002-NA | SRV-002 | No aplica | BLOQUEADA_POR_DECISION_NORMATIVA | C-01: regla en esqueleto; no se fija ninguna expectativa |
| PA-SRV-003-C | SRV-003 | Cumple | BLOQUEADA_POR_CONVENCION | la evidencia requerida no se publica o no existe en el original (C-04, C-05, C-09, C-11) |
| PA-SRV-003-NC | SRV-003 | No cumple | BLOQUEADA_POR_CONVENCION | la evidencia requerida no se publica o no existe en el original (C-04, C-05, C-09, C-11) |
| PA-SRV-003-NV | SRV-003 | No verificable | EJECUTABLE_CON_RESERVA | reproducible; el resultado depende de C-05 |
| PA-SRV-003-NA | SRV-003 | No aplica | EJECUTABLE_DEFINITIVA | — |
| PA-SRV-004-C | SRV-004 | Cumple | EJECUTABLE_DEFINITIVA | — |
| PA-SRV-004-NC | SRV-004 | No cumple | EJECUTABLE_DEFINITIVA | — |
| PA-SRV-004-NV | SRV-004 | No verificable | EJECUTABLE_DEFINITIVA | — |
| PA-SRV-004-NA | SRV-004 | No aplica | EJECUTABLE_DEFINITIVA | — |
| PA-EVT-001-C | EVT-001 | Cumple | BLOQUEADA_POR_CONVENCION | la evidencia requerida no se publica o no existe en el original (C-04, C-06, C-09) |
| PA-EVT-001-NC | EVT-001 | No cumple | BLOQUEADA_POR_CONVENCION | la evidencia requerida no se publica o no existe en el original (C-04, C-06, C-09) |
| PA-EVT-001-NV | EVT-001 | No verificable | EJECUTABLE_CON_RESERVA | reproducible; el resultado depende de C-04, C-06 |
| PA-EVT-001-NA | EVT-001 | No aplica | EJECUTABLE_DEFINITIVA | — |
| PA-EVT-002-C | EVT-002 | Cumple | BLOQUEADA_POR_CONVENCION | la evidencia requerida no se publica o no existe en el original (C-04, C-06, C-09) |
| PA-EVT-002-NC | EVT-002 | No cumple | BLOQUEADA_POR_CONVENCION | la evidencia requerida no se publica o no existe en el original (C-04, C-06, C-09) |
| PA-EVT-002-NV | EVT-002 | No verificable | EJECUTABLE_CON_RESERVA | reproducible; el resultado depende de C-04, C-06 |
| PA-EVT-002-NA | EVT-002 | No aplica | EJECUTABLE_DEFINITIVA | — |
| PA-EVT-003-C | EVT-003 | Cumple | BLOQUEADA_POR_CONVENCION | la evidencia requerida no se publica o no existe en el original (C-04, C-06) |
| PA-EVT-003-NC | EVT-003 | No cumple | BLOQUEADA_POR_CONVENCION | la evidencia requerida no se publica o no existe en el original (C-04, C-06) |
| PA-EVT-003-NV | EVT-003 | No verificable | EJECUTABLE_CON_RESERVA | reproducible; el resultado depende de C-04, C-06 |
| PA-EVT-003-NA | EVT-003 | No aplica | EJECUTABLE_DEFINITIVA | — |
| PA-EVT-004-C | EVT-004 | Cumple | BLOQUEADA_POR_CONVENCION | la evidencia requerida no se publica o no existe en el original (C-06) |
| PA-EVT-004-NC | EVT-004 | No cumple | BLOQUEADA_POR_CONVENCION | la evidencia requerida no se publica o no existe en el original (C-06) |
| PA-EVT-004-NV | EVT-004 | No verificable | EJECUTABLE_CON_RESERVA | reproducible; el resultado depende de C-04, C-06 |
| PA-EVT-004-NA | EVT-004 | No aplica | EJECUTABLE_DEFINITIVA | — |
| PA-EVT-005-C | EVT-005 | Cumple | BLOQUEADA_POR_CONVENCION | la evidencia requerida no se publica o no existe en el original (C-06, C-11) |
| PA-EVT-005-NC | EVT-005 | No cumple | BLOQUEADA_POR_CONVENCION | la evidencia requerida no se publica o no existe en el original (C-06, C-11) |
| PA-EVT-005-NV | EVT-005 | No verificable | EJECUTABLE_CON_RESERVA | reproducible; el resultado depende de C-04, C-06 |
| PA-EVT-005-NA | EVT-005 | No aplica | EJECUTABLE_DEFINITIVA | — |
| PA-EVT-006-C | EVT-006 | Cumple | BLOQUEADA_POR_CONVENCION | la evidencia requerida no se publica o no existe en el original (C-06, C-11) |
| PA-EVT-006-NC | EVT-006 | No cumple | BLOQUEADA_POR_CONVENCION | la evidencia requerida no se publica o no existe en el original (C-06, C-11) |
| PA-EVT-006-NV | EVT-006 | No verificable | EJECUTABLE_CON_RESERVA | reproducible; el resultado depende de C-04, C-06 |
| PA-EVT-006-NA | EVT-006 | No aplica | EJECUTABLE_DEFINITIVA | — |
| PA-EVT-007-C | EVT-007 | Cumple | BLOQUEADA_POR_CONVENCION | la evidencia requerida no se publica o no existe en el original (C-06, C-07, C-11) |
| PA-EVT-007-NC | EVT-007 | No cumple | BLOQUEADA_POR_CONVENCION | la evidencia requerida no se publica o no existe en el original (C-06, C-07, C-11) |
| PA-EVT-007-NV | EVT-007 | No verificable | EJECUTABLE_CON_RESERVA | reproducible; el resultado depende de C-04, C-06 |
| PA-EVT-007-NA | EVT-007 | No aplica | EJECUTABLE_DEFINITIVA | — |
| PA-CA-001-C | CA-001 | Cumple | EJECUTABLE_DEFINITIVA | — |
| PA-CA-001-NC | CA-001 | No cumple | EJECUTABLE_DEFINITIVA | — |
| PA-CA-001-NV | CA-001 | No verificable | BLOQUEADA_POR_CONTRATO | el contrato actual no publica la cobertura o la ausencia demostrada (C-03) |
| PA-CA-001-NA | CA-001 | No aplica | EJECUTABLE_CON_RESERVA | C-03: una Capa candidata con otro nombre no es detectable, por lo que la ausencia de Capas no se demuestra |
| PA-FT-001-C | FT-001 | Cumple | EJECUTABLE_DEFINITIVA | — |
| PA-FT-001-NC | FT-001 | No cumple | EJECUTABLE_DEFINITIVA | — |
| PA-FT-001-NV | FT-001 | No verificable | BLOQUEADA_POR_CONTRATO | el contrato actual no publica la cobertura o la ausencia demostrada (C-03) |
| PA-FT-001-NA | FT-001 | No aplica | EJECUTABLE_CON_RESERVA | C-03: un Flujo candidato con otro nombre no es detectable, por lo que la ausencia de Flujos no se demuestra |
| PA-E1-001-C | E1-001 | Cumple | BLOQUEADA_POR_CONVENCION | la evidencia requerida no se publica o no existe en el original (C-07, C-08) |
| PA-E1-001-NC | E1-001 | No cumple | BLOQUEADA_POR_CONVENCION | la evidencia requerida no se publica o no existe en el original (C-07, C-08) |
| PA-E1-001-NV | E1-001 | No verificable | EJECUTABLE_DEFINITIVA | — |
| PA-E1-001-NA | E1-001 | No aplica | EJECUTABLE_DEFINITIVA | — |
| PA-E2-001-C | E2-001 | Cumple | BLOQUEADA_POR_CONVENCION | la evidencia requerida no se publica o no existe en el original (C-07, C-08) |
| PA-E2-001-NC | E2-001 | No cumple | BLOQUEADA_POR_CONVENCION | la evidencia requerida no se publica o no existe en el original (C-07, C-08) |
| PA-E2-001-NV | E2-001 | No verificable | EJECUTABLE_DEFINITIVA | — |
| PA-E2-001-NA | E2-001 | No aplica | EJECUTABLE_DEFINITIVA | — |
| PA-E3-001-C | E3-001 | Cumple | BLOQUEADA_POR_CONVENCION | la evidencia requerida no se publica o no existe en el original (C-07, C-08) |
| PA-E3-001-NC | E3-001 | No cumple | BLOQUEADA_POR_CONVENCION | la evidencia requerida no se publica o no existe en el original (C-07, C-08) |
| PA-E3-001-NV | E3-001 | No verificable | EJECUTABLE_DEFINITIVA | — |
| PA-E3-001-NA | E3-001 | No aplica | EJECUTABLE_DEFINITIVA | — |
| PA-MOD-001-C | MOD-001 | Cumple | BLOQUEADA_POR_DECISION_NORMATIVA | depende de C-13 |
| PA-MOD-001-NC | MOD-001 | No cumple | EJECUTABLE_DEFINITIVA | — |
| PA-MOD-001-NV | MOD-001 | No verificable | EJECUTABLE_DEFINITIVA | — |
| PA-MOD-001-NA | MOD-001 | No aplica | BLOQUEADA_POR_DECISION_NORMATIVA | depende de C-13 |
| PA-COM-001-C | COM-001 | Cumple | EJECUTABLE_CON_RESERVA | reproducible; el resultado depende de C-12, C-09 |
| PA-COM-001-NC | COM-001 | No cumple | EJECUTABLE_CON_RESERVA | reproducible; el resultado depende de C-09, C-12 |
| PA-COM-001-NV | COM-001 | No verificable | EJECUTABLE_CON_RESERVA | reproducible; el resultado depende de C-04, C-12 |
| PA-COM-001-NA | COM-001 | No aplica | EJECUTABLE_DEFINITIVA | — |
| PA-COM-002-C | COM-002 | Cumple | BLOQUEADA_POR_CONVENCION | la evidencia requerida no se publica o no existe en el original (C-04, C-05) |
| PA-COM-002-NC | COM-002 | No cumple | BLOQUEADA_POR_CONVENCION | la evidencia requerida no se publica o no existe en el original (C-04, C-05) |
| PA-COM-002-NV | COM-002 | No verificable | EJECUTABLE_CON_RESERVA | reproducible; el resultado depende de C-04, C-05 |
| PA-COM-002-NA | COM-002 | No aplica | EJECUTABLE_DEFINITIVA | — |
| PA-COM-003-C | COM-003 | Cumple | BLOQUEADA_POR_CONVENCION | la evidencia requerida no se publica o no existe en el original (C-04, C-05) |
| PA-COM-003-NC | COM-003 | No cumple | BLOQUEADA_POR_CONVENCION | la evidencia requerida no se publica o no existe en el original (C-04, C-05) |
| PA-COM-003-NV | COM-003 | No verificable | EJECUTABLE_CON_RESERVA | reproducible; el resultado depende de C-05 |
| PA-COM-003-NA | COM-003 | No aplica | EJECUTABLE_DEFINITIVA | — |
| PA-COM-004-C | COM-004 | Cumple | EJECUTABLE_DEFINITIVA | — |
| PA-COM-004-NC | COM-004 | No cumple | EJECUTABLE_DEFINITIVA | — |
| PA-COM-004-NV | COM-004 | No verificable | EJECUTABLE_DEFINITIVA | — |
| PA-COM-004-NA | COM-004 | No aplica | EJECUTABLE_DEFINITIVA | — |
| PA-COM-005-C | COM-005 | Cumple | BLOQUEADA_POR_DECISION_NORMATIVA | depende de C-12 |
| PA-COM-005-NC | COM-005 | No cumple | BLOQUEADA_POR_DECISION_NORMATIVA | depende de C-12 |
| PA-COM-005-NV | COM-005 | No verificable | EJECUTABLE_CON_RESERVA | reproducible; el resultado depende de C-12 |
| PA-COM-005-NA | COM-005 | No aplica | EJECUTABLE_DEFINITIVA | — |
| PA-MQ-001-C | MQ-001 | Cumple | EJECUTABLE_DEFINITIVA | — |
| PA-MQ-001-NC | MQ-001 | No cumple | EJECUTABLE_CON_RESERVA | reproducible; el resultado depende de C-09 (lista de plantillas) |
| PA-MQ-001-NV | MQ-001 | No verificable | BLOQUEADA_POR_DECISION_NORMATIVA | depende de C-09 |
| PA-MQ-001-NA | MQ-001 | No aplica | EJECUTABLE_DEFINITIVA | — |
| PA-MQ-002-C | MQ-002 | Cumple | EJECUTABLE_DEFINITIVA | — |
| PA-MQ-002-NC | MQ-002 | No cumple | EJECUTABLE_DEFINITIVA | — |
| PA-MQ-002-NV | MQ-002 | No verificable | EJECUTABLE_CON_RESERVA | reproducible; el resultado depende de C-06 |
| PA-MQ-002-NA | MQ-002 | No aplica | EJECUTABLE_DEFINITIVA | — |
| PA-MQ-003-C | MQ-003 | Cumple | EJECUTABLE_DEFINITIVA | — |
| PA-MQ-003-NC | MQ-003 | No cumple | EJECUTABLE_DEFINITIVA | — |
| PA-MQ-003-NV | MQ-003 | No verificable | EJECUTABLE_CON_RESERVA | reproducible; el resultado depende de C-05, C-04 |
| PA-MQ-003-NA | MQ-003 | No aplica | EJECUTABLE_DEFINITIVA | — |

## 8. Cifras de la propuesta

| Indicador | Valor |
|---|---|
| Normativamente definidas | 23 |
| Normativamente condicionadas | 12 |
| Normativamente pendientes | 2 (SRV-001, SRV-002) |
| Técnicamente verificables hoy (Cumple y No cumple alcanzables con casos reales) | 5 |
| Verificables parcialmente | 16 |
| Con brecha de evidencia que exige convención o cambio de motor | 14 |
| Pendientes de norma | 2 |
