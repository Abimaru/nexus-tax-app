# Auditoría independiente — Blueprint Evidence Studio v0.4.6.0 y Skill v11.2.0

Rama auditada: `feature/evidence-studio-v0.4.6.0-private` (HEAD `35825fa`). Rama pública revisada: `public/evidence-studio-v0.4.6.0` (`f264098`).
Alcance: solo lectura. No se modificó código, Skill, catálogo, fixtures ni pruebas. No hubo commits, push ni publicación. Único archivo persistente creado: este informe.

> Esta calificación no certifica la versión como estable ni sustituye las pruebas de aceptación de la analista.

---

## A. Veredicto

**NO APTO tal como se entregó para iniciar las pruebas de aceptación con la analista y Copilot.**
Pasaría a **APTO CON RESERVAS** al cerrar H-01 y H-02, que son correcciones acotadas y no tocan la lógica estructural.

Lo que sí quedó demostrado:

- Los hallazgos bloqueantes de la v0.4.5.0 (A-1, A-2, A-3) están corregidos, y M-1, M-2, M-5, M-6 y M-8 también.
- Los siete escenarios obligatorios dan el resultado esperado.
- Las asociaciones Flujo/Capa de Currency Exchange y nombreOperacion1 coinciden con la reconstrucción independiente desde el JSON original.
- Los 41 IDs se conservan y solo cambian CNT-002, E1-001 y E3-001, que son los textos autorizados por F-13.
- No hay dictamen normativo falso: `normativeEvaluation` es siempre `null` y ningún `HIPOTESIS` se presenta como cumplimiento.

Lo que impide el visto bueno:

- **H-01 (P1):** el JSON compacto descarta el `customData` de las figuras que no son `BPMNEvent`. En el corpus real eso elimina la marca `ENTRADA`/`SALIDA` de 202 modelos (13 en la página de Oski), y la regla MOD-001 no puede evaluarse con el JSON compacto.
- **H-02 (P1):** la Skill del ZIP no describe el contrato compacto y todavía ordena consultar estructuras que ese JSON no contiene (`rootContainers`, `deploymentPairs`, `architecturalRoleCandidates`) y una convención que el motor ya no emite (`CORPORATE_PARENT_DOMAIN_CONVENTION`).

---

## B. Resultados ejecutados

Las 6 filas de "oráculo propio" de la UI no cuentan como fallos del producto. Una era una expectativa mal escrita por mí (Limpiar deja encabezados estáticos) y cinco comparaban IDs que ya coinciden entre los dos archivos originales. Tras corregir mi oráculo, 96 de 96 comprobaciones de UI pasan.

| # | Prueba | Estado | Evidencia / motivo |
|---|---|---|---|
| 1 | Git limpio, rama y commits | PASS | HEAD `35825fa`; árbol limpio al inicio y al final; `f264098` presente en la rama pública |
| 2 | Hash HTML y ZIP | PASS | HTML `88B92F52…085E`, ZIP `A2819601…6BF5`: coinciden con lo informado |
| 3 | `npm test` | PASS | 46/46 |
| 4 | `npm run audit` | PASS | `issues:0` en las páginas auditadas |
| 5 | `npm run build` | PASS | Reconstrucción byte a byte idéntica (mismo SHA-256); autocontenido |
| 6 | `npm run test:e2e` (Edge) | PASS | 4/4 |
| 7 | `skill:zip:validate` | PASS | 15 entradas portables |
| 8 | ZIP leído en bruto (directorio central) | PASS | 15 entradas, 0 con `\`, 2 de directorio, extracción literal crea `validar-blueprint-integracion/`. Cierra A-3 |
| 9 | ZIP == `skills/` | PASS | `diff -rq` sin diferencias |
| 10 | CSV | PASS | 41 filas × 10 columnas, 41 IDs únicos, 41 encabezados en los `.md`, sin IDs huérfanos |
| 11 | HTML sin red | PASS | 0 URLs remotas, 0 `fetch`/XHR/WebSocket/`src=`/`href=`; 0 peticiones no locales; 0 errores de consola |
| 12 | Un solo motor | PASS | `ui/app.js` solo importa `../src/index.js`; el HTML contiene una única copia de `interpretBpmnEventSubtype` |
| 13 | Rama pública sanitizada | PASS con residuos | Sin `Blueprints_ejemplos`, `skills`, auditorías, SVG, docx/xlsx ni ZIP. `fcc67ac` no es ancestro. Ver H-14 |
| 14 | Pruebas públicas (`public.test.js` + e2e) | PASS | 7/7 y 1/1, sobre un `git archive` en carpeta temporal |
| 15 | UI real, 10 casos de selección (descarga real) | PASS | 96 comprobaciones propias; páginas, omitidas, conteos, IDs, conexiones y `textAreas` contra el JSON original |
| 16 | Siete escenarios obligatorios | PASS | Sección D.4 |
| 17 | 37 páginas reales | PASS | 0 escenarios sobre BDD o plantilla (10 BDD, 10 plantillas, 17 mixtas) |
| 18 | Invariantes sobre 2 596 componentes (corpus real + fixtures) | PASS | `PRINCIPAL`/`HIJO_PRINCIPAL` coherentes con `scenario`; `deploymentAssociations` coincide en ambos sentidos |
| 19 | Textos y conexiones literales | PASS | 0 diferencias de `textAreas` o `endpoint` contra el original |
| 20 | Batería BPMN (31 casos) | **FAIL parcial** | H-05 |
| 21 | Batería de grupos (21 casos) | PASS con observaciones | H-08 |
| 22 | Batería `ms` (22 nombres) y texto funcional (10) | PASS con observación | H-06 |
| 23 | `BPMNGroup` (11) y dominios productores (9) | PASS | H-03 como residuo |
| 24 | Regresiones A-1…M-8 | Sección E | |
| 25 | Contrato compacto contra las 41 reglas | **FAIL** | H-01 |
| 26 | Texto de la Skill vs contrato | **FAIL** | H-02, H-07 |
| 27 | Prueba funcional del agente (Fase 8) | **NO EJECUTADO** | No hay un agente Copilot con la Skill instalada en este entorno. Una lectura documental no equivale a la prueba. Queda pendiente |

Total: unas 270 comprobaciones propias, además de las 58 de las suites existentes (46 + 4 + 7 + 1).
Cambios temporales: `npm run build` reescribió `dist/` con bytes idénticos y no dejó cambios en Git. Todo lo demás (scripts, descargas, `git archive` público con un enlace a `node_modules`) está en el directorio temporal de la sesión, fuera del repositorio.

---

## C. Hallazgos

### P1

#### H-01 — El JSON compacto pierde el `customData` de figuras distintas de `BPMNEvent`
- **Ubicación:** `src/exporter.js`, línea de `compactPage`: `customData:shape.class==='BPMNEvent'?…:undefined`.
- **Datos:** `Blueprints_ejemplos/Collections_Bill_Payments/…Pay_Bill U (1).json`, página `msDebitAccountPayment`.
- **Reproducción:**
  1. Analizar y exportar con `copilotExport`.
  2. Filtrar las `BPMNActivity` del original con `customData` `ENTRADA` o `SALIDA`.
  3. Buscarlas en `components[]`.
- **Esperado:** el marcador de entrada o salida llega al agente. MOD-001 exige modelo de entrada y salida para el principal.
- **Real:**
  - Las 13 actividades aparecen con `architecturalType:null`, sin `customData` y sin la palabra "modelo" en su texto (0 de 13), así que el compacto no permite distinguirlas.
  - En todo el corpus hay 202 actividades con esa marca, 6 `UMLClassBlock` y 2 contenedores con `customData`, y ninguno se conserva.
  - El diagnóstico sí los conserva.
- **Impacto:** MOD-001 y parte de COM/EVT quedan como No verificable por una pérdida del extractor, no por falta de evidencia. Contradice el criterio de no perder lo que el extractor conoce.
- **Corrección sugerida:**
  - Exportar `customData` de cualquier figura que lo tenga. Sin cambios en la lógica de clasificación.
  - Añadir una prueba que compare, para cada figura del original con `customData`, su presencia en el compacto.
  - Decisión funcional pendiente: si `ENTRADA`/`SALIDA` debe además producir `architecturalType:"MODELO"`.

#### H-02 — La Skill no describe el contrato compacto y cita estructuras inexistentes en él
- **Ubicación:** `skills/…/references/00-procedimiento.md` (líneas 7 y 34), `INSTRUCCIONES-AGENTE-V11.md` (línea 13), `SKILL.md`.
- **Reproducción:** `grep -rnE "components\[\]|deploymentAssociations|architecturalType|HIJO_PRINCIPAL|INVOCADO|PRINCIPAL|possibleDomainRoles" skills/` no devuelve nada.
- **Esperado:** el ZIP indica qué campos usar para cada familia de reglas. `RULE_EVIDENCE_MATRIX_v11.2.md` y `COPILOT_JSON_CONTRACT.md` existen, pero solo en el repositorio, no dentro del ZIP.
- **Real:**
  - La precedencia de evidencia ordena usar `rootContainers`, `groupStructure`, `deploymentPairs`, `architecturalRoleCandidates` y `structuralScenario`. El compacto contiene `components`, `groups`, `deploymentAssociations` y `scenario`.
  - El procedimiento y las instrucciones del agente siguen citando `CORPORATE_PARENT_DOMAIN_CONVENTION`. El motor ahora usa `STRUCTURAL_CHILD_EVENT_MAIN_PATH`, y `SKILL.md` ya no habla de esa convención.
- **Impacto:** el agente puede buscar campos que no existen, o rechazar un `domainRole:"PRODUCER"` válido porque no coincide con la convención que le indicaron. Eso dificulta reproducir los resultados entre analistas.
- **Corrección sugerida:** incluir en `references/` un diccionario breve del compacto (tipos, roles, procedencia, `null` frente a ausente) y la matriz regla→campo. Sustituir las referencias por los nombres reales, o decir explícitamente que son del diagnóstico. Eliminar la convención antigua.

### P2

#### H-03 — `domainRole` resuelto y `possibleDomainRoles` no vacío en el mismo componente
- **Ubicación:** `src/containment.js` (calcula `possibleDomainRoles` antes de la resolución), `src/roles.js` (`resolveDomainRolesFromStructure` cambia `domainRole` después).
- **Reproducción:** analizar cualquier página E1 (Oski, Virtual Account Opening) y filtrar los componentes con ambos campos.
- **Real:** 441 de 2 585 componentes reales muestran, por ejemplo, `domainRole:"PRODUCER"` con `possibleDomainRoles:["PRODUCER","EXTERNAL_SYSTEM"]`. Los contenedores restantes reciben `EXTERNAL_SYSTEM` por descarte (`SCENARIO_REMAINDER_AFTER_UNIQUE_PRODUCER`) y arrastran la misma contradicción.
- **Impacto:** viola el criterio "sin clasificaciones contradictorias entre campos".
- **Corrección sugerida:** vaciar `possibleDomainRoles` cuando `domainRole` queda resuelto. Prueba: ningún componente tiene ambos campos a la vez. Mantener la procedencia (`roleSource`) del rol inferido por descarte.

#### H-04 — Valor de `architecturalType` fuera del contrato (`SERVICE`)
- **Ubicación:** `src/exporter.js`, `architecturalType()`: usa `role.inferredArchitecturalType.toUpperCase()`.
- **Reproducción:** `fixtures/synthetic/e3-role-candidate.json`, componente `service`.
- **Real:** `SERVICE` para el servicio principal de E3, `SERVICIO` para los servicios `ms`. En el corpus hay 2 y 6 respectivamente. El contrato solo admite `SERVICIO`.
- **Impacto:** un agente que filtre por `SERVICIO` pasa por alto el servicio principal de un E3.
- **Corrección sugerida:** normalizar a `SERVICIO` (y `API`) en un único punto. Prueba: el conjunto de valores del campo coincide con el listado del contrato.

#### H-05 — `CONFIRMADO` con declaraciones adicionales desconocidas, vacías, negativas o con estructura inesperada
- **Ubicación:** `src/roles.js`, `interpretBpmnEventSubtype`.
- **Reproducción:** E3 sintético, `customData` del evento:

| customData | Resultado | Esperado |
|---|---|---|
| `EVENT_TYPE=START` + `BPMN_EVENT_TYPE=RESTART` | CONFIRMADO | no confirmar |
| `EVENT_TYPE=START` + `BPMN_EVENT_TYPE=""` | CONFIRMADO | no confirmar |
| `EVENT_TYPE=START` + `TIPO_EVENTO_BPMN="No es inicio"` | CONFIRMADO | no confirmar |
| `EVENT_TYPE=["START"]` | CONFIRMADO (el arreglo se convierte en texto) | rechazar |

- **Real:** la declaración reconocida prevalece y las no reconocidas se ignoran. La declaración START/END incompatible sí se detecta (`CONFLICTING_CUSTOM_DATA`).
- **Impacto:** el criterio es que una declaración inequívoca certifique el subtipo. Aquí hay una declaración dudosa junto a otra y aun así se confirma. No es un dictamen normativo, pero sí un `CONFIRMADO` sobreestimado.
- **Corrección sugerida:** si existe cualquier clave admitida con valor no reconocido, vacío o no textual, devolver `NO_VERIFICABLE` o conflicto. Pruebas: los casos de la tabla.
- **Casos que sí pasan** (31 evaluados): claves parciales (`restart_policy`, `X_EVENT_TYPE`, `EVENT_TYPE_EXTRA`), frases negativas, `Start-up failed`, `RESTART`, texto START sin `customData`, `customData` vacío o ausente, START en otro evento, START en el servicio o el hijo, conexión invertida, sin conexión, `None–None`, valor objeto, número o `null`. Todos terminan en `HIPOTESIS` o `NO_DETERMINADO` sin confirmar.
- **Nota:** `"START "` con espacio final y claves en minúsculas se aceptan (normalización deliberada). Es aceptable, pero debe quedar documentado.

#### H-06 — Clasificación afirmada con candidato ambiguo e `INVOCADO` por prefijo más cualquier conexión
- **Ubicación:** `src/exporter.js`, `architecturalType()` y la expresión de `role`.
- **Reproducción 1:** API principal con título `ms-main-api`, conectada `None→Arrow` al evento del hijo.
  - Real: `scenario.status=NO_DETERMINADO` y `inference.status=AMBIGUOUS`, pero el componente figura como `API` / `PRINCIPAL`.
  - Esperado: sin tipo ni rol principal mientras exista la contradicción `SERVICE_NAMING_SIGNAL_CONFLICTS_WITH_MAIN_API_TOPOLOGY`.
- **Reproducción 2:** `ms-transfer-service-context` (Currency).
  - Real: `SERVICIO` / `INVOCADO`. Sus dos líneas son `CircleOpen→Generalization` en sentidos opuestos entre el mismo par, y `INVOCADO` se asigna con solo tener alguna conexión, sin comprobar el sentido.
  - Esperado: `INVOCADO` solo con una conexión orientada hacia el componente.
- **Impacto:** el agente puede tratar como firme un rol que el propio motor marca como ambiguo.
- **Corrección sugerida:** `role` y `architecturalType` principal solo cuando `status` del candidato sea `INFERRED`. `INVOCADO` solo con orientación verificada de destino. Pruebas: las dos reproducciones anteriores.

#### H-07 — Instrucciones de la Skill desactualizadas o contradictorias
Confirmados los cuatro puntos que se sospechaban:

1. `SKILL.md` usa cinco estados y `00-procedimiento.md` enumera cuatro, sin Parcialmente cumple. **Real.**
2. `INSTRUCCIONES-AGENTE-V11.md` conserva el encabezado v11.1.1. **Real.**
3. Ese documento no enumera Parcialmente cumple en los conteos obligatorios (entrega 3), aunque la fórmula lo incluye. **Real.**
4. Las referencias a `rootContainers`, `deploymentPairs` y `architecturalRoleCandidates` son diagnósticas y válidas en el diagnóstico. Dejan de serlo como instrucción sobre el compacto. Se tratan en H-02.

Además:
- Los cinco archivos de reglas 02, 03, 04, 06 y 07 conservan el encabezado "v11.1" (inofensivo).
- `CHANGELOG-V11.md` mezcla bloques históricos sin separar y menciona `STRUCTURALLY_CONFIRMED`.
- `NORMATIVE_DIFF_v11.2.md` declara 5 cambios (incluye E2-001 y CNT-004 como modificados), pero el CSV y los `.md` solo modifican 3: CNT-002, E1-001 y E3-001. Dice que 36 IDs no cambian y son 38.

**Corrección sugerida:** alinear los cuatro documentos y añadir una prueba que verifique el encabezado de versión y la presencia de los cinco estados en todos los archivos de instrucciones.

#### H-08 — Robustez de asociaciones por grupos
- **Ubicación:** `src/groups.js` (`groupDeploymentAssociations`) y `src/deployment.js`.
- **Reproducción:** 21 estructuras sintéticas.
  - Resuelven correctamente de forma conservadora:
    - dos componentes bajo el mismo grupo superior;
    - un grupo de componente con gestor y API;
    - un grupo de pareja con dos grupos padre;
    - dos parejas bajo un mismo superior;
    - parejas con dos flujos o sin capa;
    - sin grupo;
    - páginas diferentes con los mismos IDs;
    - contenedor envolvente.
  - Resuelven sin avisar de la anomalía:
    - un grupo que se contiene a sí mismo;
    - un ciclo S1↔S2;
    - un miembro inexistente en el grupo superior o en el de la pareja;
    - el componente en dos grupos hermanos.
  - La contención directa prevalece sobre un grupo que apunta a otro componente.
  - Una capa que contiene dos componentes se resuelve por grupo a uno de ellos.
- **Real:** el estado de la asociación sigue siendo `RESOLVED_BY_*` y la contradicción solo se ve inspeccionando `groups[]`. El grupo con miembro inexistente queda `PARTIAL`, pero la asociación no hereda ese estado.
- **Impacto:** no hay una asociación inventada por cercanía, pero el agente no ve el aviso en la asociación.
- **Corrección sugerida:** propagar a `deploymentAssociations[].conflicts` los casos de ciclo, miembro inexistente, múltiple pertenencia y contradicción contención↔grupo. Para la contradicción, preferir `AMBIGUOUS` frente a elegir una de las dos fuentes.

#### H-09 — Componentes invocados `UMLClassBlock` sin tipo y sin procedimiento
- **Datos:** páginas MIXED/OPERATIONAL del corpus: 1 a 13 `UMLClassBlock` sin tipo por página (por ejemplo, 13 en `createCustomizedCardConsulta` y `createVirtualCard`; 6 en `initiateVirtualAccount`).
- **Real:** quedan sin tipo servicios `Entidad`, APIs marcadas "Clasificación API", eventos y plantillas. La decisión de no tipar por el texto funcional es correcta, pero la Skill no indica cómo decidir qué es API, servicio o evento a partir de `textAreas` para API-001…003, SRV-001…003 y EVT-001…003.
- **Impacto:** resultados inconsistentes entre ejecuciones del agente.
- **Corrección sugerida:** una guía en la Skill (no en el motor) sobre cómo leer `textAreas`, con ejemplos neutros.

#### H-10 — Tamaño del JSON compacto
- **Real:** el compacto pesa entre 3,3 y 4,5 veces el original de las páginas seleccionadas (por ejemplo, 102 839 bytes frente a 25 009 en Currency; 574 788 frente a 171 854 en Debit Card Issuance).
- **Causa:** en Currency, `architecturalDomain`, `rootContainer` y `structuralParent` repetidos por componente suman unos 43 000 de 90 600 bytes de `components`.
- **Impacto:** riesgo de rebasar el contexto de Copilot en blueprints grandes.
- **Corrección sugerida:** no eliminar campos sin una demostración. Los tres objetos se derivan de `containerChainIds` y de un índice de contenedores, de modo que se puede mover cada contenedor una sola vez a una tabla de la página y dejar referencias por ID. Prueba: reconstrucción equivalente.

### P3

| ID | Hallazgo | Ubicación y reproducción | Corrección |
|---|---|---|---|
| H-11 | Con ninguna página seleccionada el análisis "se completa" con 0 páginas y se pueden descargar JSON vacíos | `ui/app.js`; deseleccionar todo y analizar: `pages:0`, `omitted:6` | Bloquear con aviso |
| H-12 | La selección inicial deja marcadas las plantillas (`nombreOperacion3`, `Page 6`) y solo desmarca BDD | `ui/app.js`; cargar `Escenario2_Original.json` | Preseleccionar según `pageClassification.kind` |
| H-13 | El gancho de pruebas `window.__BES__` queda en el HTML de producción | `ui/app.js` línea 41 | Documentarlo o eliminarlo del build |
| H-14 | Residuos en la rama pública: el fixture `custom-domain.json` usa el rótulo `RECAUDOS` (dominio real) y el árbol público reconstruido produce 63 589 bytes frente a 63 588 del HTML confirmado (un salto de línea final) | Rama pública | Rótulo genérico; fijar fin de línea en el build |
| H-15 | `customData` con entradas `null` o no arreglo (objeto o texto) hace fallar todo el análisis | `src/containment.js`, `src/roles.js`; `customData:[null,…]` | Tolerar y registrar incidencia (los exports reales usan arreglos, así que el riesgo es bajo) |
| H-16 | El conflicto entre productores (`CONFLICTING_MULTIPLE_PRODUCERS`) vive solo en `domainResolution` del diagnóstico; el compacto muestra `NO_COMPLETE_STRUCTURAL_ROLE_CANDIDATE` | Dos productores sintéticos | Copiar el estado a `scenario.conflicts` |
| H-17 | La Skill no dice qué preguntar cuando `scenario` es `NO_DETERMINADO` (no hay principal identificado) | `SKILL.md`, paso 4 | Pregunta general con explicación de la incertidumbre |
| H-18 | Los cinco `.md` con encabezado "v11.1" y el `CHANGELOG` no están separados por versión | `references/` | Limpieza editorial |

---

## D. Matrices

### D.1 Cobertura de las 41 reglas contra el JSON compacto

Leyenda:
- **D**: disponible en el compacto.
- **P**: parcial.
- **H**: requiere respuesta humana.
- **X**: imposible de certificar con los exports reales.
- **Dg**: solo en el diagnóstico.

Esta matriz es analítica (lectura de criterios y de campos), no una ejecución del agente.

| Regla | Evidencia requerida | Campo compacto | Cob. |
|---|---|---|---|
| CNT-001 | contenedores padre reconocidos | `components[].architecturalDomain`, `domainRole`, `rootContainer` | D |
| CNT-002 | dominio efectivo del hijo | `scenario`, hijo `architecturalDomain` | D |
| CNT-003 | contenido de INTEGRACIÓN | `structuralParent`, `containerChainIds`, `domainRole` | D |
| CNT-004 | contenido del productor | ídem; rol inferido por estructura | D (inferido) |
| CNT-005 | contenido de SISTEMAS EXTERNOS | ídem | D |
| CNT-006 | contención sin proximidad | `structuralParent.status`, `issues` | D |
| EXT-001 | contenido del auxiliar | `SISTEMA_EXTERNO_AUXILIAR`, `containedComponentIds` | D |
| EXT-002 | conexión al auxiliar | `connections[]` | D |
| GW-001 | gateway y caminos | `lucidchartType`, `connections[]` | D |
| API-001 | nombre | `name`, `textAreas` | D (API principal); P (invocadas, H-09) |
| API-002 | operación | `operation`, `textAreas` | D / P |
| API-003 | tipo y modelo | `textAreas` | P (H-09) |
| API-004 | MCI y Capa/Flujo | respuesta de la analista + `deploymentAssociations` | H |
| SRV-001 | nombre del servicio | `name` | D (`ms`); P (resto) |
| SRV-002 | operación | `textAreas` | P |
| SRV-003 | tipo | `textAreas` | P |
| EVT-001 | nombre del evento | `textAreas` | P (H-09) |
| EVT-002 | operación | `textAreas` | P |
| EVT-003 | clasificación | `textAreas`; `customData` perdido (H-01) | P |
| EVT-004 | MCI, Capa y Flujo | analista + asociaciones | H |
| EVT-005 | contención | `structuralParent` | D |
| EVT-006 | tópicos p/s | `textAreas` | P |
| EVT-007 | formato del tópico | `textAreas` | P |
| EVT-008 | sentido | `connections[]` estilos | D / P |
| CA-001 | patrón Capa | `architecturalType=CAPA`, `name` | D |
| CA-002 | asociación | `deploymentAssociations` | D |
| FT-001 | patrón Flujo | `FLUJO`, `name` | D |
| FT-002 | asociación | `deploymentAssociations` | D |
| E1-001 | escenario E1 | `scenario` | D (HIPOTESIS) |
| E2-001 | escenario E2 | `scenario` | D (HIPOTESIS) |
| E3-001 | escenario E3 | `scenario` | D (HIPOTESIS) |
| E1/E2/E3 (Inicio) | subtipo Inicio | `customData` del evento | X: 0 de 341 eventos reales traen `customData`, por lo que `CONFIRMADO` es inalcanzable con los exports actuales |
| MOD-001 | entrada y salida | `MODELO`, `groups`; marcas `ENTRADA`/`SALIDA` perdidas | **P (H-01)** |
| COM-001 | actividad relacionada | `connections`, `textAreas` | P |
| COM-002 | comando↔API | `connections` | D |
| COM-003 | comando↔servicio | `connections` | D |
| COM-004 | comando↔gestor | `connections`, `GESTOR_COLAS` | D |
| MQ-001 | gestor | `GESTOR_COLAS`, `name` | D |
| MQ-002 | gestor externo | `structuralParent` | D |
| MQ-003 | MCI o Federado | analista + etiqueta | H |
| MQ-004 | Capa y Flujo | `deploymentAssociations` | D |
| MQ-005 | gestor↔servicio | `connections` | D |

Dg (solo en el diagnóstico): `principalInteractionPaths`, `relations`, `domainResolution` (conflicto de productores), `evidence.lines` completas y `functionalClassification` (derivable de `textAreas`).

### D.2 Comparación normativa v11.1.2 → v11.2.0 (comparación celda a celda de los CSV)

| ID | Cambio real | Autorizado (F-13) |
|---|---|---|
| CNT-002 | "fuera del dominio productor" → "no gestionado dentro del DOMINIO PRODUCTOR" en E1/E3; "gestionado dentro de INTEGRACIÓN" en E2 | Sí |
| E1-001 | hijo con dominio efectivo DOMINIO PRODUCTOR | Sí |
| E3-001 | principal e hijo en el mismo DOMINIO PRODUCTOR | Sí |
| Los otros 38 | Sin cambio en CSV | Sí |

- E2-001 y CNT-004 no cambian, aunque `NORMATIVE_DIFF_v11.2.md` los lista como modificados (H-07).
- No se detectaron alteraciones accidentales.
- La decisión de conexión directa frente a declarada permanece intacta y no se reinterpretó.
- El `.md` de estructura (CNT-002) y los de escenarios (E1, E3) coinciden con el CSV.

### D.3 Asociaciones Flujo/Capa principales (reconstruidas del JSON original)

| Caso | Cadena original | Compacto | Resultado |
|---|---|---|---|
| Currency, gestor `4Oc~oPj98AFn` | Flujo `4Oc~UAg.ChZ2` contiene capa `4Oc~STvzS7WZ` y gestor; la capa contiene el gestor; el grupo `4Oc~Xod2f2AN` reúne flujo y capa; dominio INTEGRACIÓN; 4 líneas del gestor | Flujo y capa correctos, `RESOLVED_BY_DIRECT_CONTAINMENT`, fuente `JSON.contains`, una sola asociación; las otras dos parejas (hijo y la que solo contiene un evento) no se atribuyen al gestor | **Verificado.** No equivale a cumplimiento MQ-004 |
| Currency, hijo `TJ7m.cKnR-~v` | Flujo/capa `x6OM…` contienen un único componente de tipo API/gestor/hijo | Asociado por contención | Verificado (M-8, ver E) |
| Currency, pareja `AwQG…` | La capa solo contiene un evento | `PENDING_NO_COMMON_SUPERIOR_GROUP` | Verificado |
| nombreOperacion1, API `3gn9iRxfHfin` | Pareja `3gn9KcIquAF8` y componente `3gn9dZVeQSQU` bajo el superior `3gn9Z0fP~kxr` (único) | `RESOLVED_BY_EXPLICIT_SUPERIOR_GROUP`, superior `3gn9Z0fP~kxr` | Verificado |
| nombreOperacion1, hijo `TJ7m.cKnR-~v` | contención `x6OM…` | `RESOLVED_BY_DIRECT_CONTAINMENT` | Verificado |
| nombreOperacion1, gestor `~ez.jtoEp~8-` | contención `rj5D…` | `RESOLVED_BY_DIRECT_CONTAINMENT` | Verificado |
| nombreOperacion1, pareja `Th5D…` | solo un evento | pendiente | Verificado |

Ninguna asociación se resolvió por cercanía, mismo dominio o único candidato restante.

### D.4 Escenarios E1/E2/E3

| Caso | Esperado | Real | Justificación estructural | Estado |
|---|---|---|---|---|
| Currency Exchange | E2 HIPOTESIS | E2 HIPOTESIS | API `tQ7mFTFbJ1SW` (API, PRINCIPAL, INTEGRACIÓN) → evento `iQ7mp2EXtgT-`; el hijo `TJ7m.cKnR-~v` está en la misma INTEGRACIÓN | PASS |
| Oski (`msDebitAccountPayment`) | E1 HIPOTESIS | E1 HIPOTESIS | API en INTEGRACIÓN; hijo en el dominio productor, inferido por estructura | PASS |
| Virtual Account Opening, op. 1 | E1 HIPOTESIS | E1 HIPOTESIS | Hijo bajo el dominio productor | PASS |
| Virtual Account Opening, op. 2 | E1 HIPOTESIS | E1 HIPOTESIS | Ídem | PASS |
| nombreOperacion1 | E2 HIPOTESIS | E2 HIPOTESIS | API y hijo en la misma INTEGRACIÓN | PASS |
| nombreOperacion2 | (adicional) | E1 HIPOTESIS | Productor declarado | PASS |
| E3 sintético con evento genérico | E3 HIPOTESIS | E3 HIPOTESIS | Sin `customData` | PASS |
| E3 con Inicio explícito válido | E3 CONFIRMADO | E3 CONFIRMADO | `BPMN_EVENT_TYPE=START` | PASS (ver H-05) |

- 0 escenarios sobre BDD o plantillas en las 37 páginas reales.
- En el corpus real, 0 de 341 `BPMNEvent` traen `customData`: todo escenario real es `HIPOTESIS`.
- El catálogo de claves (`BPMN_EVENT_TYPE`, `EVENT_TYPE`, `TIPO_EVENTO_BPMN`) no tiene correspondencia demostrada con exportaciones corporativas. Debe tratarse como **propuesta**, no como convención corporativa certificada. El propio motor lo declara así (`catalogStatus:"PROPOSED_CLOSED_CATALOG"`).

### D.5 Defectos anteriores y estado actual

Ver sección E.

---

## E. Auditoría de regresiones

| ID | Defecto (v0.4.5.0) | Estado v0.4.6.0 | Evidencia |
|---|---|---|---|
| A-1 | Selección de páginas no filtraba `pages[]` | **CERRADO** | 96 comprobaciones sobre descargas reales: `pages[]` == seleccionadas; `omittedPages` == complemento; ninguna página en ambos; conteos de la selección; diagnóstico con todas las páginas |
| A-2 | Inicio certificado por texto libre | **CERRADO con residuo** | Texto, nombre y claves parciales ya no certifican; el catálogo exige claves y valores exactos. Residuo en H-05 |
| A-3 | ZIP con `\` | **CERRADO** | 15 entradas con `/`, 2 de directorio, extracción literal correcta |
| M-1 | Contenedor reservado vacío perdía su rol | **CERRADO** | INTEGRACIÓN y SISTEMAS EXTERNOS (Opcional) vacíos conservan su rol; caso real de nombreOperacion3 correcto |
| M-2 | Dominio personalizado sin roles posibles | **CERRADO con residuo** | Ahora `["PRODUCER","EXTERNAL_SYSTEM"]` mientras no esté resuelto. Residuo en H-03 |
| M-5 | E2/E3 sin comparar ID de dominio | **CERRADO** | Dos INTEGRACIÓN o dos DOMINIO PRODUCTOR distintos → `NO_DETERMINADO` |
| M-6 | Varios padres o dos parejas se resolvían | **CERRADO** | Pareja con dos padres y dos parejas bajo un superior quedan pendientes |
| M-8 | Pareja del hijo y del gestor | **RESUELTO por decisión documentada** | `AGENTS.md` ahora admite la contención explícita Flujo→Capa→Componente. Ninguna asociación se infiere por proximidad. Para una capa con más de un componente directo se queda pendiente; la decisión de la analista sobre extender esa regla sigue abierta |

---

## F. Riesgos residuales

| Riesgo | Impacto real |
|---|---|
| Catálogo BPMN propuesto | Sin respaldo en exports reales; `CONFIRMADO` no se alcanza con el corpus actual. El riesgo es que la analista lo tome por convención corporativa. H-05 añade un caso de sobreconfirmación. Mantener la etiqueta `PROPOSED_CLOSED_CATALOG` visible en la Skill |
| Ciclos de grupos | No producen asociaciones falsas, pero tampoco avisan en la asociación (H-08) |
| Externo reservado con estructura productora | Un `SISTEMAS EXTERNOS` que contiene el hijo no se convierte en productor (verificado); el escenario queda `NO_DETERMINADO` |
| Resto de contenedores personalizados | Quedan como `EXTERNAL_SYSTEM` "por descarte" cuando hay un productor único. Está etiquetado con su fuente, pero contrasta con la regla de no inferir por descarte; confirmar con la analista que es una excepción aprobada |
| Conexión directa frente a declarada | Pendiente de decisión funcional; no se reinterpretó |
| Instalación real de la Skill en Copilot | No ejecutado. Un ZIP con rutas portables ya no impide la carga, pero no se probó en Copilot |
| Compatibilidad contrato–agente | El contrato `copilot-factual-v0.4.6.0` no se menciona en el ZIP; la Skill no puede comprobar con qué versión de JSON trabaja (H-02) |

---

## G. Recomendaciones para Codex (priorizadas, sin funciones nuevas)

1. **H-01** — Exportar `customData` de todas las figuras que lo tengan.
   - Prueba: para cada figura del original con `customData`, el compacto lo contiene tal cual (corpus real).
   - Decisión funcional previa: ¿`ENTRADA`/`SALIDA` debe generar tipo `MODELO`?
2. **H-02 + H-07** — Añadir al ZIP el diccionario del compacto y la matriz regla→campo.
   - Retirar `CORPORATE_PARENT_DOMAIN_CONVENTION` y las referencias a estructuras que solo existen en el diagnóstico.
   - Unificar los cinco estados y corregir los encabezados.
   - Pruebas: ningún `.md` de la Skill cita campos ausentes del compacto, y los cinco estados aparecen en cada documento de instrucciones.
3. **H-05** — Declaraciones adicionales no reconocidas, vacías, negativas o no textuales deben impedir `CONFIRMADO`.
   - Pruebas: los cuatro casos de la tabla de H-05.
4. **H-03** — `possibleDomainRoles` vacío cuando `domainRole` esté resuelto.
   - Prueba: invariante sobre todo el corpus.
5. **H-04 y H-06** — Normalizar `SERVICIO`; `role`/`architecturalType` principal solo con candidato `INFERRED`; `INVOCADO` solo con orientación verificada.
   - Pruebas: las dos reproducciones de H-06 y el conjunto de valores del contrato.
6. **H-08** — Propagar ciclos, miembros inexistentes y contradicciones contención↔grupo a la asociación.
   - Pruebas: los casos sintéticos de la sección H-08.
7. **H-10** — Evaluar una tabla de contenedores por página para reducir el tamaño sin pérdida.
   - Prueba: reconstrucción equivalente de `structuralParent`, `rootContainer` y `architecturalDomain`.
8. **H-09, H-11…H-18** — Mejoras de la Skill y de la interfaz, en ese orden.

No tocar durante estas correcciones: los 41 textos normativos (salvo los autorizados), la decisión conexión directa/declarada, ni las expectativas de las pruebas existentes.

---

## Resumen para la analista

- **Pruebas:** unas 270 comprobaciones propias más las 58 de las suites existentes.
- **Errores reales:** 2 P1, 8 P2 y 8 P3 (18 hallazgos). Ninguno es P0.
- **Riesgos principales:** MOD-001 no puede evaluarse con el compacto (H-01); la Skill describe un contrato que ya no existe (H-02); el catálogo de eventos de Inicio no tiene soporte en exports reales.
- **Veredicto:** NO APTO tal como se entregó. APTO CON RESERVAS tras cerrar H-01 y H-02.
- **Pendiente:** Fase 8 (prueba del agente en Copilot) NO EJECUTADA.
