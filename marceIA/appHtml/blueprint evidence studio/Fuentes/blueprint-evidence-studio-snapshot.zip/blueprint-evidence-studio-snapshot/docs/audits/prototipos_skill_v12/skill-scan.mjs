import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
const S = 'C:/Users/ABIMARU/AppData/Local/Temp/claude/C--Users-ABIMARU-Desktop-Desarrollo-blueprint-evidence-studio/d58e4513-4869-481b-9616-ebce70ebdfe5/scratchpad/';
const PK = { analyst37: S + 'analyst-zip/validar-blueprint-integracion-v11.2.2/validar-blueprint-integracion/', repo41: 'C:/Users/ABIMARU/Desktop/Desarrollo/blueprint-evidence-studio/skills/validar-blueprint-integracion/' };
const norm = s => s.toLowerCase().replace(/[`*_>#|-]/g, ' ').replace(/\s+/g, ' ').trim();
const tok = s => Math.round(s.length / 3.6); // rough Spanish estimate: ~3.6 chars/token
const walk = d => fs.readdirSync(d, { withFileTypes: true }).flatMap(e => e.isDirectory() ? walk(path.join(d, e.name)) : [path.join(d, e.name)]);
const res = {};
for (const [name, root] of Object.entries(PK)) {
  const files = walk(root).map(f => ({ rel: path.relative(root, f).replace(/\\/g, '/'), text: fs.readFileSync(f, 'utf8').replace(/^\uFEFF/, '').replace(/\r/g, '') }));
  const info = files.map(f => ({ rel: f.rel, bytes: Buffer.byteLength(f.text), lines: f.text.split('\n').length, tokens: tok(f.text), n37: (f.text.match(/\b37\b/g) || []).length, n41: (f.text.match(/\b41\b/g) || []).length }));
  // sentence/bullet fingerprints (>= 60 chars) found in >= 2 files
  const fp = new Map();
  for (const f of files) {
    const parts = f.text.split(/\n|(?<=[.;:])\s+/).map(norm).filter(x => x.length >= 60);
    for (const p of new Set(parts)) { const h = crypto.createHash('md5').update(p).digest('hex').slice(0, 10); (fp.get(h) ?? fp.set(h, { p, files: new Set(), n: 0 }).get(h)).files.add(f.rel); }
  }
  const dups = [...fp.values()].filter(x => x.files.size >= 2).sort((a, b) => b.files.size - a.files.size || b.p.length - a.p.length);
  // repeated within rule files (same sentence in >= 3 rules)
  const ruleFiles = files.filter(f => /reglas/.test(f.rel));
  const within = new Map();
  for (const f of ruleFiles) for (const p of f.text.split(/\n|(?<=[.;:])\s+/).map(norm).filter(x => x.length >= 50)) within.set(p, (within.get(p) || 0) + 1);
  const rep = [...within.entries()].filter(([, n]) => n >= 3).sort((a, b) => b[1] * b[0].length - a[1] * a[0].length);
  const repChars = rep.reduce((a, [p, n]) => a + p.length * (n - 1), 0);
  // referenced file names that do not exist
  const names = new Set(files.map(f => path.basename(f.rel)));
  const missing = [];
  for (const f of files) for (const m of f.text.matchAll(/[`(\s]([A-Za-z0-9._-]+\.(?:md|csv|json))\b/g)) if (!names.has(m[1]) && !/^(CONTRATO|SKILL)\.md$/.test(m[1]) || (m[1] && !names.has(m[1]))) missing.push(f.rel + ' -> ' + m[1]);
  res[name] = { info, totalBytes: info.reduce((a, f) => a + f.bytes, 0), totalTokens: info.reduce((a, f) => a + f.tokens, 0), crossFileDups: dups.length, crossFileDupSamples: dups.slice(0, 14).map(d => [...d.files].join(' + ') + ' :: ' + d.p.slice(0, 110)), withinRuleRepeated: rep.length, withinRuleRepeatedChars: repChars, withinSamples: rep.slice(0, 8).map(([p, n]) => n + '× ' + p.slice(0, 100)), missing: [...new Set(missing)] };
}
console.log(JSON.stringify(res, null, 1));
