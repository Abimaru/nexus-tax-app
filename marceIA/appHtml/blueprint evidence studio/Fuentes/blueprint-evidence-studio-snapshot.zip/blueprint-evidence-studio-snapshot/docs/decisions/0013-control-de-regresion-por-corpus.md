# ADR-0013: todo cambio del Studio se verifica contra el corpus completo antes y después

Estado: aceptada (03/11/2026).

## Contexto
Los cambios de reconocimiento tienen efectos de cola (el arreglo del nombre del hijo tocó 38 páginas). Las pruebas unitarias no detectan que un cambio altere tipos o asociaciones de BP que nadie volvió a mirar. El HTML no puede ejecutarse en este entorno, así que no hay prueba visual.

## Decisión
1. Antes de editar: exportar el JSON compacto de **todas** las páginas del corpus (`Blueprints_ejemplos`) a un snapshot (`snap_before`).
2. Después de editar: exportar de nuevo (`snap_after`) y comparar campo por campo agrupando diferencias por ruta.
3. Solo pueden cambiar los campos previstos; cualquier otra diferencia es un defecto o requiere decisión.
4. Rehacer la línea base de `test/ui-contract-invariance.test.js` solo después de la comparación.
5. `npm test` debe pasar completo; el ZIP se valida con `scripts/validate-skill-zip.mjs` (11 archivos, rutas con `/`).

Procedimiento paso a paso: `docs/processes/PROCESO-control-regresion.md`.

## Consecuencias
- Cada entrada del `CHANGELOG.md` puede afirmar qué cambió y qué no, con números.
- Los scripts auxiliares viven en el directorio temporal de la sesión; el procedimiento los describe para poder recrearlos.
