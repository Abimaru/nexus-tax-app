# ADR-0004: el Studio reconoce, la Skill decide

Estado: aceptada (vigente desde 0.6.0, reafirmada en 0.8.x). Fecha de registro: 03/11/2026.

## Contexto
Cada vez que un veredicto del agente parecía equivocado, la corrección podía hacerse en tres lugares (HTML, Skill o instrucciones del agente) y a veces se hacía en el equivocado. Mezclar reglas en el HTML duplica la norma y la hace inauditable.

## Decisión
- El **Studio** solo produce inventario y reconocimiento: tipo certificado, candidato o sin tipo, asociaciones, relaciones y pendientes. No evalúa reglas ni emite estados.
- La **Skill** es el único lugar donde viven las reglas, las fichas operativas y la doctrina de estados.
- El **agente** hace las preguntas MCI, cierra cada regla y cita «Nombre (id)».
- Las instrucciones del agente se mantienen mínimas: solo lo que la Skill no dice.

## Consecuencias
- Un cambio de regla toca solo `skills/`; un cambio de reconocimiento toca solo `src/`.
- El HTML nunca muestra cumplimiento.
- La prueba de invariancia (`ui-contract-invariance`) protege que el JSON compacto no cambie por accidente.
- Diagnóstico de un veredicto dudoso: JSON enriquecido primero, Skill después, agente al final (caso CNT-002, ADR-0010).
