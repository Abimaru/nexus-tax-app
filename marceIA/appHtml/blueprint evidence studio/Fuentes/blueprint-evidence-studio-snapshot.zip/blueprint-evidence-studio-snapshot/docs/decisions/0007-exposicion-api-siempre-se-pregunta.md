# ADR-0007: la exposición de la API principal se pregunta siempre que falte; la homologación no toca API-003

Estado: aceptada, confirmada por la analista (02/11 y 03/11/2026). Skill 11.8.1 y 11.8.2.

## Contexto
Cuando la API principal no traía tipo de exposición el agente ya no preguntaba, pese a que la exposición determina la obligación de Capa y Flujo (API-004). La analista pidió restituir la pregunta sin que eso cambie API-003.

## Decisión
- Si la tercera sección de la API principal no trae exposición, el agente **siempre** pregunta (en el mismo mensaje que las preguntas MCI).
- Homologación solo para decidir si se pregunta: `privada` → `private`, `pública` → `public`, `partner` sin cambio. Si ya viene `private`, `public` o `partner` (inglés) no se pregunta.
- La respuesta decide la obligación de Capa y Flujo; **no** modifica el texto de la tercera sección ni el veredicto de API-003.
- Sin preguntas aplicables (por ejemplo, E3 sin API principal por preguntar) el agente continúa con las 38 reglas y entrega el resultado; no espera confirmación (ADR-0012).

## Consecuencias
- Las instrucciones del agente y `SKILL.md` repiten la misma frase; hay pruebas de texto en `test/v080.test.js`.
