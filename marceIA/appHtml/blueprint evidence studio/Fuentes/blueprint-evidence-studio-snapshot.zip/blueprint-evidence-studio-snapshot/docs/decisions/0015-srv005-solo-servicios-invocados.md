# ADR-0015: SRV-005 aplica solo a servicios invocados; el servicio principal de E3 queda fuera

Estado: aceptada por la analista (03/11/2026). Skill 11.8.5; Studio sin cambios.

## Contexto
En ms_account (register y retrieve) SRV-005 pasó a No cumple porque el servicio principal (`PRINCIPAL`) tiene una línea hacia un evento BPMN. Esa línea es la de inicio de E3 (`scenario.connection`), que exige E3-001. La tabla de parejas de `08-fichas.md` mandaba `EVENTO_BPMN+SERVICIO` a SRV-005 sin filtrar por rol, mientras la regla hablaba de «servicio invocado»: el agente seguía la ficha. El texto era idéntico en 11.7.0, así que era una ambigüedad latente.

## Decisión
- SRV-005 aplica solo a servicios **invocados** (id distinto de `scenario.mainComponentId`). Quedan fuera el servicio principal de E3 y el hijo principal.
- La línea del principal hacia el evento de Inicio la evalúa solo E3-001. Las demás conexiones del principal (con API, servicios, auxiliares o eventos) no las evalúa SRV-005.
- Se conserva la prohibición servicio invocado–evento.
- Una página E3 cuya única conexión de servicio es la de inicio: SRV-005 No aplica. Si E3-001 es No verificable por el subtipo Inicio, SRV-005 no castiga esa conexión.

## Alineación (criterio permanente)
Todo cambio de regla se refleja a la vez en regla, fichas, procedimiento, reglas vecinas, instrucciones del agente y HTML cuando corresponda, con una prueba de texto que lo ancle (`test/v080.test.js`).

## Consecuencias
- Riesgo asumido: una conexión del principal con un evento distinto del de Inicio no la evalúa ninguna regla de conexión.
- Sin cambios en el Studio ni en la línea base de invariancia.
