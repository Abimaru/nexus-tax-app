# ADR-0006: Capa de Tópicos se certifica por contención de un evento de integración certificado

Estado: aceptada, confirmada por la analista (02/11/2026). Studio 0.8.1.

## Contexto
En Debit Card `createVirtualCard` dos contenedores de tópicos no tenían `architecturalType`: el Studio no tenía tipo para ellos, así que EVT-001..006 no podían ubicar el evento.

## Decisión
- Nuevo tipo `CAPA_TOPICOS`: contenedor UML que contiene **directamente** un evento de integración **certificado** (regla `TOPIC_LAYER_BY_CONTAINED_INTEGRATION_EVENT`).
- Si solo contiene un evento candidato, queda candidato `["CAPA_TOPICOS"]`.
- El nombre del contenedor no se usa.
- `inventory.capasTopicos` (con `topicos` y `eventoIds`) y `ubicacion.capaTopicosId` en el evento; el nivel del evento deja de ser `OTRO`.

## Consecuencias
- Debit Card `createVirtualCard`: los dos tópicos quedan certificados.
- Investment y Escenario2 («Nombre Evento») quedan candidatos hasta nombrar el evento y completar su tercera sección.
- Las fichas EVT-001..006 leen `capasTopicos` en lugar de reconocer el contenedor por su nombre.
