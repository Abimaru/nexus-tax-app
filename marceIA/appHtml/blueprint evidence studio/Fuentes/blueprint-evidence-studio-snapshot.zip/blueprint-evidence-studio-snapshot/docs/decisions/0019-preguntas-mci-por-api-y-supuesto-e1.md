# ADR-0019: preguntas MCI por nombre de API y supuesto del hijo de E1

Fecha: 08/11/2026. Estado: candidato (Skill 11.8.6).

## Contexto
Hasta 11.8.5 se preguntaba por página: MCI de la API, MCI del hijo (E1 y E2) y exposición. Con varias páginas de una misma API se repetían las preguntas, y en E1 el hijo vive en el DOMINIO PRODUCTOR, donde la analista no espera capas MCI. Corpus: 7 de 9 BP multipágina repiten el nombre de la API; 0 de 18 páginas E1 tienen capa o flujo asociados al hijo.

## Decisión
- MCI de la API y exposición: una vez por nombre de API (primera sección con versión, normalizada) entre las páginas evaluables; la exposición solo por las páginas que no la traen.
- Hijo de E2: una pregunta por cada hijo (no se agrupa).
- Hijo de E1: sin pregunta; supuesto no MCI registrado como `SUPUESTO_E1_HIJO_NO_MCI`, evaluado en SRV-004 como un hijo declarado no MCI.
- E3: sin preguntas (ya era así).
- Contenido de capas en CNT-003/004/005 con el nivel del inventario; `nivel: OTRO` es No verificable.

## Consecuencias
Solo cambian texto de la Skill, instrucciones, prompt maestro y ZIP; el Studio y el JSON no cambian. Riesgo: la agrupación depende de que el agente compare bien los nombres; no se ha corrido con Copilot.

## Actualización 11.8.7
Tras la prueba con Sufi Loan Modification, la pregunta agrupada cita el nombre de la API una sola vez y los ids juntos («Nombre (id1 y id2)»), sin nombrar la operación ni repetir el nombre por página.
