# ADR-0020 — Línea nueva: comandos y modelos por etiqueta, COM fusionada y bloqueo solo por extremos sueltos

Fecha: 20/11/2026. Estado: aceptada por la analista (respuestas del 19–20/11/2026). Aplicada en Studio 0.10.0 y Skill 12.1.0 (fusionada en la carpeta principal el 24/11/2026). Catálogo actual: 38 reglas (SRV-006 agregada el 24/11/2026).

## Decisiones
1. La etiqueta de la figura (`customData`) manda sobre la conexión para identificar comandos, modelos y subtipos de evento; sin etiqueta, la figura queda no verificable (comandos por conexión se conservan para BP antiguos).
2. COM-002 a COM-006 se fusionan en COM-002 (existencia y bidireccionalidad del `SERVICE_TASK`); COM-007 pasa a COM-003. Catálogo: 37 reglas.
3. EXT-002 se fusiona en CNT-003/004/005; EXT-001 solo valida el nombre; GEN-001 (operación = nombre de página, camelCase, exacta) y MOD-002 (modelos sin texto de plantilla) son nuevas.
4. API-001 usa `_vMayor.Menor.Parche`. Las figuras `THIRD_PARTY_API`, `THIRD_PARTY_SERVICE` y `THIRD_PARTY_MQ_SERVICE` van en SISTEMAS EXTERNOS.
5. El HTML bloquea el JSON solo por conectores con un extremo suelto; las terminaciones las evalúan las reglas; None–None y líneas de anotaciones quedan exentas.

## Consecuencias
Los BP antiguos (sin etiquetas) conservan el JSON byte a byte (prueba de invariancia). La unión con la línea estable queda pendiente de la analista.
