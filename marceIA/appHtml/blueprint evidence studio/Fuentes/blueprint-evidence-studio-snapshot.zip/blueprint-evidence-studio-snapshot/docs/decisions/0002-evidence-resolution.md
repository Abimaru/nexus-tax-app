# ADR-0002: resolución conservadora de evidencia

Estado: aceptada, 2026-10-21.

Solo `JSON.contains` participa en la contención estructural. La pareja Flujo/Capa se reconoce cuando el flujo contiene la capa; el propietario se resuelve únicamente con un descendiente compatible inequívoco. Grupos, coordenadas, orden, nombres parecidos y exclusión de alternativas no certifican propiedad. Los dominios personalizados no se etiquetan como productores automáticamente.
