# ADR-0008: API-004 es Cumple si las capas exigidas están resueltas, aunque existan parejas sin propietario (solo API)

Estado: aceptada, confirmada por la analista (03/11/2026). Skill 11.8.2.

## Contexto
En Debit Card, la API principal tenía capa y flujo resueltos por contención directa (`RESOLVED_BY_DIRECT_CONTAINMENT`), pero otra pareja Capa–Flujo de la página no tenía propietario. La regla trataba esa pareja como candidata y dejaba API-004 en No verificable, aunque la evidencia positiva sobre la API principal era completa.

## Decisión
- API-004 es **Cumple** cuando la API principal tiene resueltas por contención directa todas las Capas que su exposición exige; las parejas, Capas o Flujos sin propietario no bloquean.
- API-004 es **No verificable** solo si falta algo requerido de la API principal.
- La excepción es **solo para API-004**. SRV-004 y MQ-002 conservan la regla de parejas sin propietario; extenderla queda como decisión abierta con la analista.

## Consecuencias
- Cambia solo texto de la Skill (`02-reglas-api-servicios.md`, `00-procedimiento.md` 4.1, `08-fichas.md`); el Studio no cambia.
- Riesgo asumido: una pareja sin propietario que en realidad perteneciera a la API principal no se marca. Se acepta porque la evidencia resuelta ya cubre la obligación.
