# ADR-0009: EXT-001 es No verificable con una actividad BPMN sin tipo dentro del auxiliar

Estado: aceptada, confirmada por la analista (03/11/2026). Studio 0.8.2 / Skill 11.8.2.

## Contexto
Entre 11.8.0 y 11.8.1 EXT-001 pasó de No verificable a Cumple en Debit Card sin cambio de diagrama. Causa: «sin tipo se ignora» hacía que cuatro actividades BPMN sin tipo (que parecen modelos de datos) dentro de un auxiliar se descartaran silenciosamente. El agente tampoco era consistente entre corridas.

## Decisión
- Las actividades BPMN sin tipo dentro de un contenedor salen en `contiene.ACTIVIDAD_SIN_TIPO` (aparte de `SIN_TIPO`, que sigue siendo anotaciones y conceptos).
- EXT-001: una actividad BPMN sin tipo dentro del auxiliar deja la regla **No verificable**, porque no se puede demostrar que todo el contenido sea una categoría permitida.
- No se les asigna tipo por su texto (no se promueven a `MODELO`).

## Consecuencias
- Determinista: el mismo JSON da el mismo veredicto.
- Efecto lateral: en otros BP con actividades sin tipo dentro de un auxiliar, EXT-001 puede pasar de Cumple a No verificable. No medido en todo el corpus (ver HANDOFF, próximos pasos).
- Corregirlo en el diagrama: dar a la actividad la señal de modelo (`customData` ENTRADA/SALIDA o nombre con MODELO).
