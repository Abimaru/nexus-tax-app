# ADR-0023 — Carpeta única y versionado semver

Fecha: 24/11/2026. Estado: decisión del autor.

## Contexto
Hubo dos líneas de código: la estable (`blueprint-evidence-studio-snapshot`, Studio 0.8.3 / Skill 11.8.7) y una de prueba (`...-nueva`, versiones con sufijo `-nueva.N`).

## Decisión
- Todo vive en `blueprint-evidence-studio-snapshot`; la línea nueva se fusionó y su carpeta quedó archivada (`ARCHIVADO-blueprint-evidence-studio-nueva`, solo por `node_modules`). Respaldo de la versión anterior en un `.zip` de la carpeta superior.
- Versiones sin sufijos y con semver: parche = corrección, menor = cambio de comportamiento de una regla o dato nuevo, mayor = cambio de contrato/estructura. Studio y Skill versionan por separado.
- Los entregables llevan la versión en el nombre y no se sobrescriben; los antiguos quedan en `dist/` como historial.

## Consecuencias
Una sola fuente de verdad (`src/version.js`). Las versiones intermedias nunca entregadas (0.10.1 / 12.1.1) se eliminaron de `dist/` y quedan anotadas en el CHANGELOG.
