# ADR-0021 — GW-001 solo evalúa compuertas exclusivas e inclusivas

Fecha: 25/11/2026. Estado: decisión de la analista. Aplicada en Studio 0.11.0 y Skill 12.2.0.

## Contexto
GW-001 validaba que toda compuerta con texto tuviera caminos con respuestas y no distinguía el subtipo. En compuertas paralelas o basadas en evento los caminos pueden llevar palabras que indican el camino sin que exista una pregunta.

## Decisión
- Solo las compuertas exclusivas e inclusivas deben tener pregunta o decisión y caminos con etiquetas que respondan a ella.
- Paralela, basada en evento y paralela basada en evento no se validan (no se exige pregunta aunque sus caminos tengan palabras).
- Si la página solo tiene compuertas de esos subtipos: `No aplica`.
- El Studio expone `inventory.compuertas[].subtipo` (`EXCLUSIVE`, `INCLUSIVE`, `PARALLEL`, `EVENT_BASED`, `PARALLEL_EVENT_BASED`) según la etiqueta de la figura.
- Compuerta sin etiqueta de subtipo (BP antiguos, 336 de 394 en el corpus): se evalúa como exclusiva o inclusiva, sin `No verificable` por ese motivo (mismo criterio transitorio que los comandos sin etiqueta).

## Consecuencias
Menos falsos «No verificable» en compuertas paralelas. Pendiente: si la analista prefiere que una compuerta sin etiqueta sea `No verificable`, es un cambio pequeño en la ficha y la regla.
