# ADR-0010: el nombre de una figura es el primer texto no vacío entre Title, Text y FloatingTitle

Estado: aceptada (03/11/2026). Studio 0.8.3.

## Contexto
La analista reportó CNT-002 en No cumple para dos blueprints cuyo hijo principal sí tenía nombre (`ms_key_management_spi`; `ms_account (register)`). El JSON enriquecido traía `name: ""` y ponía el texto en `operation`. Causa raíz: `cleanName` tomaba `FloatingTitle` aunque estuviera vacío y el texto real estaba en `Text`. El defecto existía desde al menos 0.7.0. El agente respondió con coherencia al JSON («el nombre está vacío»); el error no era suyo ni de la regla.

## Decisión
- `cleanName` = primer texto **no vacío** entre `Title`, `Text` y `FloatingTitle` (en el orden de `textAreas`).
- Los contenedores (`*ContainerBlock`) llevan `operation: null`: el texto de un contenedor es su nombre, no una operación.
- La ficha de CNT-002 indica `serviciosHijo[].name` como nombre del hijo; vacío cuenta como ausente.

## Alcance verificado
Comparación antes/después sobre 90 páginas del corpus: cambian 38 nombres de hijo y la `operation` de 47 contenedores; tipos, candidatos, asociaciones, relaciones y escenarios, idénticos.

## Consecuencias
- Hijos con «NOMBRE SERVICIO» ahora muestran ese nombre y CNT-002 los rechaza por plantilla (No cumple correcto).
- Hijos con ambos textos vacíos (Debit Card `createVirtualCard`) siguen sin nombre; no se usa texto suelto cercano.
