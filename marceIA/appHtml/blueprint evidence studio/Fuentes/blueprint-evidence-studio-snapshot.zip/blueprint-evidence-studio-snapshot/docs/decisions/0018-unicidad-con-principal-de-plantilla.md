# ADR-0018: unicidad con principal de plantilla

Fecha: 04/11/2026. Estado: candidato. Modifica el criterio de camino operativo (ADR-0016 lo había dejado como causa PLACEHOLDER_MAIN).

## Contexto
`retrieveInformationDetail` (Access Entitlement) tiene un único principal conectado con línea certificada al evento de Inicio, pero con nombre de plantilla («Nombre Producto - Nombre API vX.0.0»). El clasificador exigía origen sin nombre de plantilla, así que la página salía TEMPLATE_OR_LEGEND aunque la unicidad estaba dada.

## Decisión
El camino operativo acepta un origen con nombre de plantilla solo si: (1) no hay ningún origen con nombre propio con línea certificada a un evento; (2) hay exactamente un origen de plantilla distinto con línea certificada (`VERIFIED_BY_TERMINATIONS`); (3) la página tiene otras APIs/servicios con nombre propio. La condición 3 mantiene como plantilla vacía las 8 páginas en blanco del corpus. `pageClassification.placeholderMainAccepted=true` deja rastro. El nombre de plantilla se evalúa en las reglas de nombre de la Skill (No cumple), sin cambios en la Skill.

## Alternativas descartadas
Aceptar sin la condición 3 (convertía en MIXED las 8 plantillas vacías); inferir escenario sin conexión certificada (rechazado por la analista).

## Consecuencias
Cambian 3 páginas del corpus y los conteos de `v048`/`v1131`. El resto del JSON es idéntico (invariancia). Se agrega un aviso informativo de flechas con extremo suelto (solo UI).
