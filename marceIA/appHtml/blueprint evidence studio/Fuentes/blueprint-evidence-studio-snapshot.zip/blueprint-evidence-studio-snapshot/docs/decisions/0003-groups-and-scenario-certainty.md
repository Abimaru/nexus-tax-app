# ADR 0003: grupos y certeza de escenarios

Se adopta un grafo derivado de `items.groups` sin convertir grupos en contención. Las asociaciones de despliegue requieren grupo superior común inequívoco.

E1/E2/E3 usan `CONFIRMADO`, `HIPOTESIS` y `NO_DETERMINADO`. Un patrón único con BPMNEvent genérico es hipótesis; confirmar exige evidencia explícita de Inicio. Ningún estado evalúa las 41 reglas.
