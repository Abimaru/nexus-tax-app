# ADR-0001: núcleo modular aditivo

Estado: sustituida por motor único en v0.4.3, 2026-10-21.

v0.4.2 conservó la aplicación HTML v0.4.1 e introdujo un núcleo separado. La auditoría demostró que esa duplicación hacía que pruebas y producto ejecutaran motores distintos. v0.4.3 sustituye la decisión: la UI importa el núcleo y el build empaqueta esa misma implementación; una prueba E2E compara la descarga con la ejecución directa.
