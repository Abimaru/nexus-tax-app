# ADR-0014: API-003 acepta entidad, utilidad o tarea en SISTEMAS EXTERNOS

Estado: aceptada por la analista (03/11/2026). Skill 11.8.4; Studio sin cambios.

## Contexto
API-003 exigía en SISTEMAS EXTERNOS una tercera sección «funcional, específica, no genérica». Una API con «Entidad», «Utilidad» o «Tarea» se evaluaba como genérica y daba No cumple, aunque son valores del catálogo corporativo.

## Decisión
- En SISTEMAS EXTERNOS (directamente o dentro de un auxiliar de ese dominio) la tercera sección es válida con información funcional, específica y distinta de una plantilla, **o** con `entidad`, `utilidad` o `tarea` (solos o con otro texto, sin distinguir mayúsculas). Esos valores no son genéricos.
- En INTEGRACIÓN, incluido un auxiliar dentro de INTEGRACIÓN, no cambia: `private`/`public`/`partner` + `entidad`/`utilidad`/`tarea`, minúsculas, un solo guion.
- La exposición declarada por la analista sigue sin corregir API-003 (ADR-0007).

## Consecuencias
- Cambio solo de texto en `02-reglas-api-servicios.md`; sin impacto en el Studio ni en la línea base de invariancia.
- APIs de SISTEMAS EXTERNOS con solo un modelo en la tercera sección pasan de No cumple a Cumple.
