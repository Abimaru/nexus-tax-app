# ADR-0005: certificado, candidato y sin tipo; el candidato deja la regla en No verificable

Estado: aceptada (0.5.0 a 0.8.0). Fecha de registro: 03/11/2026.

## Contexto
Una figura puede tener señal suficiente, señal parcial o ninguna. Tratar todo como «tipo conocido o desconocido» producía veredictos falsos: candidatos tomados por ausencia (API-004, MOD-001 en la prueba de Real Time Payments) y actividades sin relación tomadas por población.

## Decisión
| Resultado | JSON | Efecto en las reglas |
|---|---|---|
| Certificado | `architecturalType` con tipo | Entra a la población de las reglas de su tipo |
| Candidato | `architecturalType: null` y `possibleTypes` | La regla de esos tipos queda **No verificable**, por encima de cualquier certificado (incluido un incumplimiento, que se cita como observación) |
| Sin tipo | `null` sin `possibleTypes` | Se ignora |

- El Studio nunca decide por nombre, color, posición ni cercanía.
- Una declaración de la analista (respuesta MCI) determina si una obligación aplica; **no** certifica tipos.
- Candidato `["API"]` no toca reglas de servicio; `["API","SERVICIO"]` toca ambas.
- Excepciones explícitas se escriben en la regla, nunca en la doctrina general (ADR-0008, ADR-0009).

## Consecuencias
- La doctrina está en un solo lugar (apartado 8 de `00-procedimiento.md`); se eliminaron las 31 repeticiones de «prevalece No cumple».
- Convertir un candidato en certificado exige cambiar el diagrama (tabla en el anexo `ANEXO-certificado-vs-candidato`).
