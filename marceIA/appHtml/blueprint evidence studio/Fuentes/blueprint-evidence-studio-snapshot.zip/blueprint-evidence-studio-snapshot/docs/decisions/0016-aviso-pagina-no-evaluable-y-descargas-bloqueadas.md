# ADR-0016: aviso y bloqueo de descargas cuando una página seleccionada queda como plantilla

Estado: solicitada por la analista (03/11/2026). Studio 0.8.3 (interfaz); Skill sin cambios.

## Contexto
`retrievePocketTransactions` (Deposit Account Pocket Transaction Information) tiene API y servicios reales, pero el flujo está modelado sin una línea certificada de la API o servicio principal al evento BPMN de Inicio del hijo (una línea llega al evento sin origen pegado). El clasificador exige esa línea para marcar la página como `MIXED`/`OPERATIONAL`; sin ella, con leyenda presente, queda como `TEMPLATE_OR_LEGEND` y el agente no la evalúa, sin que la analista sepa por qué.

## Decisión
- La analista **no** acepta la excepción de escenario por contención. El criterio de clasificación no cambia y el escenario no se infiere sin conexión certificada.
- El Studio muestra un aviso llamativo con la causa y lo que debe revisar en Lucidchart (la conexión entre la API/servicio principal y el evento de Inicio del hijo), y deshabilita las descargas mientras alguna página seleccionada sea `TEMPLATE_OR_LEGEND`. La analista corrige en Lucid y vuelve a cargar el JSON, o desmarca la página.
- Causas descriptivas en `pageClassification.reason` (solo en páginas `TEMPLATE_OR_LEGEND`): `TEMPLATE_EMPTY`, `PLACEHOLDER_MAIN`, `API_EVENT_LINE_NOT_VERIFIED`, `NO_API_EVENT_LINE`.

## Consecuencias
- Ningún JSON enriquecido con una página `TEMPLATE_OR_LEGEND` seleccionada llega al agente. La Skill sigue tratando esas páginas como no evaluables.
- No cubre `UNRESOLVED` (sin leyenda ni plantilla) ni páginas BDD (`/BDD/i` en el título): siguen igual.
- Alternativa descartada, por si se reabre: hipótesis de escenario por contención (E1/E2/E3) con conexión pendiente. Debilidad principal: en E3 casi nunca hay un único servicio candidato.
- Versión del motor sin cambio porque las instrucciones del agente 11.8.5 citan «Studio 0.8.3».
