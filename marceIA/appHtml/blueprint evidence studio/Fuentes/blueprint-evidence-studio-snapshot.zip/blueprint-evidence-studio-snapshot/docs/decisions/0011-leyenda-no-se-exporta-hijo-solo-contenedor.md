# ADR-0011: la leyenda y la descripción de API no se exportan; el hijo es solo el contenedor del hijo principal

Estado: aceptada (02/11/2026). Studio 0.8.0.

## Contexto
La leyenda de notación aportaba de 38 a 51 figuras por página y el bloque de descripción de API («Descripción Operación», «Método», «Path», «Seguridad») salía en 20 de 22 páginas evaluables: ruido para el agente que además podía contarse como población. Además cualquier rectángulo plano se tomaba como hijo y ocultaba bloques reales del DOMINIO PRODUCTOR.

## Decisión
- Esas figuras no salen del JSON enriquecido en ninguna parte (`components`, `groups`, `connections`, `inventory`, `pageClassification`); desaparece `legendShapeIds`.
- Hijo = el contenedor que señala `scenario.mainChildServiceId`. El dominio que lo envuelve no es el hijo.
- Todo `BPMNGroup` dentro de un dominio es sistema externo auxiliar, con o sin texto (sin nombre, EXT-001 = No cumple).
- Dentro del hijo no se clasifican API, servicios ni eventos de integración.
- Evento de integración exige tipo (Aplicación o Empresarial) y clasificación (Event, Query o Command); con una sola parte es candidato.

## Consecuencias
- TXN 0026 y TXN0011 (Debit Card) pasan a servicios certificados en el productor.
- Se retiró la comprobación de invariancia contra 0.6.0; la línea base se rehizo con 0.8.0.
