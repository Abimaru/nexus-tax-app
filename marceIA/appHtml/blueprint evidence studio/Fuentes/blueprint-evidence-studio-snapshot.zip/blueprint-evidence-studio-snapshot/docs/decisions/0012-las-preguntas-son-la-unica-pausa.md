# ADR-0012: las preguntas MCI son la única pausa del agente

Estado: aceptada (02/11/2026). Skill 11.8.1.

## Contexto
En escenarios sin preguntas aplicables (E3) el agente se quedaba esperando confirmación de la analista aunque no tenía nada que preguntar.

## Decisión
- El agente hace las preguntas MCI (y la de exposición si falta) en **un solo mensaje**.
- Sin preguntas aplicables continúa con las 38 reglas y entrega el resultado, sin pedir confirmación.
- Antes del resultado solo se descargan botones; el HTML no resume análisis (los analistas no leen el resumen).
- La tarjeta de descargas (JSON enriquecido, diagnóstico, impresión) va antes del «Resultado factual».

## Consecuencias
- `SKILL.md` paso 5 y 5 de `00-procedimiento.md` lo declaran; las instrucciones del agente lo repiten en una frase.
