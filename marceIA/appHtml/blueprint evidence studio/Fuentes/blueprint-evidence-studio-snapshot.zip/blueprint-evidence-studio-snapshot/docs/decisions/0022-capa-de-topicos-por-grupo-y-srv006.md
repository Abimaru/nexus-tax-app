# ADR-0022 — Capa de Tópicos del servicio MQ por grupo de la figura y SRV-006

Fecha: 24–25/11/2026. Estado: decisión de la analista. Studio 0.10.1 y Skill 12.1.1 (incluidas en 0.11.0 / 12.2.0).

## Contexto
SRV-006 (nueva) exige que todo servicio consumido por colas tenga Capa de Tópicos con tópicos reales. En la biblioteca nueva la capa `TOPIC_LAYER`, el grupo `SERVICE` y, si existe, el auxiliar (`EXT_AUX`) van **en un grupo** con la etiqueta de la figura (`OWN_UMG_MQ_SERVICE`, `THIRD_PARTY_MQ_SERVICE`…); la capa no contiene al servicio. El Studio solo buscaba la capa por contención y devolvía `capaTopicos: null` (caso `consultar_marcacion_gmf_cuenta_sti`).

## Decisión
- «Servicio consumido por colas» = figura de biblioteca con `MQ_` en la etiqueta (cualquier prefijo).
- La capa se asocia por contención o por el grupo de la figura MQ (`asociadaPor: GRUPO`).
- Varias capas de tópicos en el grupo: `capaTopicos: null` + `capasTopicosCandidatas` → `No verificable`. Las capas de despliegue no cuentan.
- SRV-006 aplica a servicios invocados con MQ; excluye el principal de E3 y el hijo. Tópicos de plantilla (`nombrecolapeticion`, `nombrecolarespuesta`, `nombre…`) incumplen.

## Consecuencias
Código en `mqInfo` (`src/exporter.js`), regla y ficha SRV-006, pruebas en `test/v0101gruposmq.test.js`. La página «Page 3» de plantilla del BP (5) es `TEMPLATE_OR_LEGEND` y no se evalúa.
