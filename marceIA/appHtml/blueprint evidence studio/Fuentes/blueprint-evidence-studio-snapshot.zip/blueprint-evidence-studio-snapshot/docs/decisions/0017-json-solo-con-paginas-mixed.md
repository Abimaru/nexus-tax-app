# ADR-0017: el JSON solo se genera si todas las páginas seleccionadas son MIXED u OPERATIONAL

Fecha: 04/11/2026. Estado: candidato. Reemplaza el alcance y el texto del aviso de ADR-0016.

## Contexto
Con ADR-0016 solo bloqueaba `TEMPLATE_OR_LEGEND`. Una página `UNRESOLVED` o BDD marcada junto a una MIXED permitía descargar un JSON con páginas inservibles, y la analista no lo notaba. Caso real: Access Entitlement Features Information (BDD, MIXED y dos plantillas).

## Decisión
- Descarga habilitada solo si toda página seleccionada es `MIXED` u `OPERATIONAL`. Cualquier otra (`TEMPLATE_OR_LEGEND`, `UNRESOLVED`, `BDD_OR_REQUIREMENTS`) bloquea JSON enriquecido y diagnóstico; Imprimir sigue habilitado.
- El mensaje informa el estado y que por eso no se genera; no explica la causa. Se conservan `reason`/`reasonDetail` en el JSON.
- La casilla de cada página ya viene desmarcada para las no evaluables; la analista puede desmarcar y analizar de nuevo.

## Consecuencias
No cambia la clasificación ni el JSON de páginas evaluables. `OPERATIONAL` (sin leyenda) se mantiene permitida: es evaluable.
