# Proceso — Mantener la documentación y el handoff al día

Obligatorio para toda IA o persona que modifique el proyecto. Un cambio no está terminado hasta cumplir este proceso.

## 1. Cuándo
Siempre que cambie: una regla, una ficha, el procedimiento, las instrucciones del agente, el HTML/UI, el Studio (`src/`), el contrato del JSON, el corpus de pruebas, las versiones o los entregables; y siempre que la analista tome una decisión.

## 2. Qué actualizar (checklist)
| Documento | Qué poner |
|---|---|
| `CHANGELOG.md` | Entrada nueva **arriba**: versión de Studio y Skill, fecha, qué cambió, por qué, quién lo decidió, pruebas (cuántas pasan), entregables. |
| `HANDOFF.md` | §2 estado vigente (versiones, pruebas, entregables, corpus); §9.1 decisiones de la analista; §10 pendientes (cerrar los resueltos, abrir los nuevos). Fecha de «Última actualización». |
| `README.md` | Versión vigente, nombres de entregables, número de pruebas. |
| `AGENTS.md` | Solo si cambia una regla permanente de trabajo o una obligación. |
| `docs/decisions/NNNN-*.md` | Un ADR por decisión nueva (contexto, decisión, consecuencias, versión en la que aplica). Siguiente número libre. |
| `docs/architecture/ARCHITECTURE.md` | Si cambia un módulo, el flujo o un campo del inventario. |
| `docs/contracts/` | Si cambia la forma del JSON. |
| `../docs/INDICE_DOCUMENTACION.md` | Si se agrega un documento importante o un paquete de entrega. |
| `AUTORIA.md` | Solo para agregar colaboradores (nunca quitar a los existentes). |

## 3. Orden recomendado
1. Hacer el cambio y sus tests. 2. `npm test` (todo verde o fallos explicados). 3. Subir versión si corresponde (`HANDOFF.md` §8.5). 4. Reconstruir entregables (§8.6). 5. Actualizar la documentación de la tabla. 6. Copiar los entregables y la documentación a `../docs/validacion_skill_analista/entrega-<skill>/`. 7. Verificar coherencia: versión, conteo de pruebas y nombres de archivos iguales en `README.md`, `HANDOFF.md`, `AGENTS.md` y `CHANGELOG.md`.

## 4. Alineación de reglas
Cuando cambie una regla, la misma redacción debe quedar en: la regla, su ficha, el procedimiento (si afecta preguntas/estados/precedencias), `SKILL.md`, `MANIFEST.md` (conteos), las instrucciones del agente, el HTML si muestra el dato, el Studio si el inventario necesita un campo, y los tests que citan el texto. Busca con `grep -rn "<ID de regla>" skills dist/INSTRUCCIONES-AGENTE-*.md test src ui`.

## 5. Autoría
Al crear documentos o paquetes nuevos (presentaciones, resúmenes, guías, repositorios, skills o agentes derivados), incluir la atribución de `AUTORIA.md`. No eliminarla al recortar o reescribir.

## 6. Mensaje para la analista
Cada entrega termina con un mensaje corto para ella: archivos nuevos, qué cambió en lenguaje de negocio, qué debe probar, qué decisiones quedan abiertas. La IA lo redacta; la persona lo envía.
