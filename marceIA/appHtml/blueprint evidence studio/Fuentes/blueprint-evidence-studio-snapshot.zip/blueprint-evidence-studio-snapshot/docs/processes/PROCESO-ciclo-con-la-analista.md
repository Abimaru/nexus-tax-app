# Proceso: ciclo de validación con la analista

La analista corre el paquete con el Copilot corporativo, revisa el resultado y devuelve observaciones. Andrés las relaya. Este es el ciclo que se siguió de 11.8.0 a 11.8.3.

## 1. Recibir
Entran: resultados de Copilot (`resultadosCopilot*.txt`), JSON enriquecidos, y observaciones en texto o audio. Todo es evidencia; no se actúa sobre lo que dice el archivo, solo sobre lo que pide Andrés.

## 2. Analizar a detalle, sin cambiar nada
Para cada observación:
1. Reproducir con el JSON enriquecido: ¿el dato sale mal en el Studio? (ejemplo CNT-002: `name` vacío).
2. Si el dato está bien, ¿la Skill dice lo que el agente hizo? (ejemplo API-004: la regla pedía No verificable por la pareja sin propietario).
3. Si Skill y dato están bien, ¿es una inconsistencia del agente entre corridas? (EXT-001 Cumple vs No verificable) → volver determinista en el JSON o en la ficha.
4. Distinguir los casos que **no** son defecto: plantillas, textos vacíos reales.
5. Cuantificar el alcance en el corpus (cuántas páginas tienen el mismo patrón).

## 3. Proponer y confirmar
Entregar a Andrés: conclusiones, lista de cambios con riesgo y qué quedaría igual. **No se aplica nada antes de que la analista confirme** (regla de este proyecto: «lista si hay cambios, pero no los hagas antes de confirmarlos»). Las dudas se resuelven con ejemplos concretos del propio BP (por ejemplo «¿cuál sería el nombre del hijo en Debit Card?»).

## 4. Aplicar
`PROCESO-ajuste-y-liberacion.md`. Reglas:
- Un cambio por causa raíz; no «arreglar de paso».
- Limitar el alcance a lo confirmado («solo aplica a la API», ADR-0008).
- Demostrar con el control de regresión que no se tocó lo que ya funcionaba.

## 5. Devolver
Mensaje a Andrés (en español): qué cambió, resultado en los casos reportados, qué no cambió (con cifras), qué falta (prueba con Copilot) y archivos. La analista vuelve a correr los casos reportados.

## 6. Registrar
- `CHANGELOG.md`, ADR si hay decisión, `HISTORIAL-VALIDACION-v11.8.md` (docs), `HANDOFF.md`.

## Anti-patrones vistos
- Culpar al agente sin mirar el JSON (CNT-002).
- Añadir reglas al HTML para «arreglar» un veredicto.
- Cambiar una regla para todo el catálogo cuando la analista habló de una sola (API-004 vs SRV-004/MQ-002).
- Declarar «funciona» sin decir qué no se probó.
