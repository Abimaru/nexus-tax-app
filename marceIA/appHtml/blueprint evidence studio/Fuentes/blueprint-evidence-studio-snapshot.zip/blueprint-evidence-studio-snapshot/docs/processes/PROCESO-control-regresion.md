# Proceso: control de regresión por corpus (ADR-0013)

Objetivo: demostrar que un cambio del Studio altera solo lo previsto. Corpus = todos los JSON de `Blueprints_ejemplos/` (11 BP, 90 páginas con exportación completa).

## Herramientas (se recrean en el directorio temporal de la sesión)
- `allbp.txt`: lista de archivos JSON del corpus, una ruta por línea (`find Blueprints_ejemplos -name '*.json'`).
- `snap.mjs <salida.json>`: para cada archivo, `analyzeBlueprint(json)` → `copilotExport(model, {selectedPageIds: todas})` y guarda un mapa `archivo#idPágina → página exportada`.
- `cmp.mjs`: carga `snap_before.json` y `snap_after.json`, recorre ambos y agrupa las diferencias por ruta normalizada (`/inventory/serviciosHijo/[]/name`, etc.), con cantidad y un ejemplo; imprime total y número de páginas.

## Pasos
1. **Antes de editar**: `node snap.mjs snap_before.json`.
2. Editar el código.
3. **Después**: `node snap.mjs snap_after.json`.
4. `node cmp.mjs`. Interpretar cada ruta distinta:
   - ¿Estaba prevista? → anotar cantidad en el CHANGELOG.
   - ¿No estaba prevista? → defecto, o decisión nueva que se documenta antes de seguir.
5. Comprobaciones puntuales de los casos que motivaron el cambio (ejemplos de 0.8.3: Real Time Payments `createKey`, `ms_account-register`, Debit Card `createVirtualCard`): imprimir el campo y comparar con lo esperado.
6. Rehacer la línea base de `ui-contract-invariance`; `npm test`.

## Resultado de referencia (0.8.3)
- 90 páginas comparadas.
- Cambios: `name` de hijo en 38 páginas; `operation` de 47 contenedores (pasa a `null`); reflejos del nombre en `inventory.nombres`.
- Sin cambios: tipos, candidatos, asociaciones, relaciones, escenarios, compuertas, modelos.

## Qué no cubre
- No ejecuta el agente: un cambio de Skill se prueba con Copilot (la analista).
- No abre el HTML en un navegador.
- Solo cubre el corpus disponible; BP nuevos pueden mostrar casos no vistos.
