# Proceso: ajustar y liberar un paquete (Studio + Skill)

Aplica a cada versión «candidata» (ejemplo: Studio 0.8.3 / Skill 11.8.3). Ejecutado en macOS; las rutas son del snapshot (`blueprint-evidence-studio-snapshot/`).

## 0. Decidir dónde va el cambio (ADR-0004)

| Síntoma | Se corrige en |
|---|---|
| Una figura sale con tipo, nombre, asociación o relación equivocada | `src/` (Studio) |
| Una regla se evalúa con criterio equivocado | `skills/validar-blueprint-integracion/` |
| El agente no pregunta, espera, o cita mal | `SKILL.md` / instrucciones del agente |
| El analista no encuentra un botón o texto | `ui/` |

Primero se revisa el JSON enriquecido: si el dato ya viene mal, el agente no es el problema (ADR-0010).

## 1. Línea base
```bash
npm test                      # debe pasar completo antes de tocar nada
```
Guardar copia del archivo que se va a editar (`cp src/exporter.js <scratchpad>/exporter.beforeXYZ.js`) y generar el snapshot del corpus (`PROCESO-control-regresion.md`, paso 1).

## 2. Cambiar
- Studio: editar `src/` (y `ui/` si hay interfaz). Subir `src/version.js` y `package.json`.
- Skill: editar los 11 archivos de `skills/validar-blueprint-integracion/` (no se agregan archivos). Cambiar la etiqueta de versión en todos los encabezados y en `MANIFEST.md`.
- Tests: agregar casos a `test/v080.test.js` (o el archivo de versión vigente). Si el cambio toca texto exigido por pruebas (por ejemplo «preguntas de condición MCI del paso 4 de `SKILL.md`»), mantener la frase.

## 3. Comparar contra el corpus
`PROCESO-control-regresion.md`, pasos 2–4. Solo pueden cambiar los campos previstos.

## 4. Reconstruir el HTML
El script `npm run build` usa `esbuild` (devDependency). El snapshot no trae `node_modules`; opciones:
1. `npm install` y `npm run build`.
2. Sin red: usar un binario de `esbuild` ya descargado para empaquetar `ui/app.js` (`--bundle --format=iife --target=es2022`) y ensamblar con el mismo reemplazo de `__VERSION__`, `__CONTRACT_VERSION__` y `__APP_BUNDLE__` sobre `ui/index.html` que hace `scripts/build.mjs`; escribir en `dist/BlueprintEvidenceStudio.html` con saltos `\n` y un salto final.

Verificar: sin URLs remotas, tamaño razonable (0.8.3: 118.704 bytes).

## 5. Rehacer la línea base de invariancia
Tras la comparación aprobada, recalcular los hashes de los casos de `test/ui-contract-invariance.test.js` con la salida nueva (`copilotExport` sobre las páginas operativas/mixtas) y reescribirlos en el archivo. Volver a ejecutar `npm test`.

## 6. Empaquetar la Skill
```bash
cd skills && rm -f ../dist/validar-blueprint-integracion-v<versión>.zip && zip -r ../dist/validar-blueprint-integracion-v<versión>.zip validar-blueprint-integracion
cd .. && node scripts/validate-skill-zip.mjs     # 11 archivos, rutas con /
```
Actualizar el nombre del ZIP dentro de `scripts/validate-skill-zip.mjs` y las pruebas que lo citan.

## 7. Instrucciones del agente
Escribir `dist/INSTRUCCIONES-AGENTE-v<versión>.md`: solo lo que la Skill no dice (menos de 8.000 caracteres, límite de Copilot). Una prueba exige la frase de las preguntas MCI.

## 8. Entregar a la analista
Copiar a `../docs/validacion_skill_analista/`:
- `BlueprintEvidenceStudio-v<versión>.html`, ZIP e instrucciones.
- `pruebas-v<versión>/`: JSON ENRIQUECIDO de los casos relevantes y `GUIA-PRUEBA-v<versión>.md` (qué abrir, qué esperar).
- Los dos anexos (`ANEXO-certificado-vs-candidato`, `ANEXO-como-el-Studio-determina-tipos`) con la versión nueva.

## 9. Documentar
- `CHANGELOG.md`: entrada con fecha, cambios y qué no cambió (con cifras de la comparación).
- ADR nuevo si hay decisión nueva; `HANDOFF.md` y `HISTORIAL-VALIDACION` actualizados.

## Lista de comprobación
- [ ] `npm test` completo (hoy 132) sin fallos
- [ ] Comparación del corpus: solo cambios previstos
- [ ] HTML reconstruido, sin URLs remotas
- [ ] Línea base de invariancia rehecha
- [ ] ZIP validado (11 archivos)
- [ ] Instrucciones del agente actualizadas
- [ ] Copias en `docs/validacion_skill_analista/`
- [ ] CHANGELOG, ADR, HANDOFF
- [ ] Anotado qué **no** se verificó (Copilot, navegador, E2E)
