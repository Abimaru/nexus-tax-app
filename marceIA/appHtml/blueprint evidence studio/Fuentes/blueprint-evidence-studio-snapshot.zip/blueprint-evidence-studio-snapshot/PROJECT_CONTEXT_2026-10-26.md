# Contexto vigente del proyecto — 26/10/2026

> **Actualización de cierre (26/10/2026):** la Skill vigente es v11.2.4 (37 reglas, diez archivos, candidata funcional). Las referencias a v11.2.3 y a 41 reglas son históricas. Ver `HANDOFF.md`.

Archivo privado (nombra material corporativo y la Skill; no va a la rama pública). Sustituye como contexto vigente a `PROJECT_CONTEXT_2026-10-25.md`, que se conserva como registro histórico sin reescribir. Ningún informe histórico es fuente superior al catálogo vigente de la Skill ni a `AGENTS.md`.

Leyenda: **[V]** verificado · **[A]** decisión aprobada · **[I]** inferencia · **[P]** pendiente.

## 1. Estado en una línea
Motor de Evidence Studio v0.4.6.1 sin cambios (`src/` idéntico al último commit) y **candidato visual v0.4.7** en la interfaz (cuatro paneles descriptivos, hecho el 25/10 por la tarde, pendiente de revisión visual y de la analista, no estable); Skill v11.2.3 preparada y validada en 3 casos sintéticos (sin regresión frente a v11.2.2), **no estable**; 41 obligaciones intactas a la espera del consolidado normativo de la analista; repositorio ahora privado; nada confirmado ni publicado.

## 2. Git y repositorio
- [V] `Abimaru/blueprint-evidence-studio` es **PRIVADO** (`gh repo view`, 26/10/2026; cambio confirmado por Andrés). No se crea otro repositorio. `origin/main` = `1a1bb45` (solo `README.md`).
- [V] Rama `feature/evidence-studio-v0.4.6.1-private` (`81b7542`), cambios sin confirmar; ramas `public/*` independientes. Sin commit, push, merge ni PR.
- [A] Intención: conservar el proyecto completo y, al terminar de consolidarlo, llevar los cambios autorizados a `main`.
- [P] Antes de cualquier push: confirmar con Andrés qué categorías se suben (código, `qa/` sin `runs/`, Skill y normativa, blueprints reales, auditorías). Pasar a privado reduce el riesgo del destino, pero no autoriza por sí solo subir material corporativo.

## 3. Versiones y hashes
- [V] Evidence Studio: motor v0.4.6.1 · contrato `copilot-factual-v0.4.6.1` (sin cambios). El HTML distribuible tiene **dos estados**:
  - Anterior (v0.4.6.1 puro): 67 359 B, SHA-256 `a93f293d1e04fa0f874ae13f4a0e9c6309572c99f35d465ea7bfa5bf4d82a247`. Con este HTML se generaron los compactos y se hicieron las 6 sesiones de validación de la Skill.
  - Vigente en disco, **candidato v0.4.7** (`UI_VERSION 0.4.7-candidate`): 77 481 B, SHA-256 `205cc88ea198c175002e86d1a65696d3e2d7260a8e8b86bdcfdb98b68eae93f5`, 0 URLs remotas. Cambia solo `ui/app.js`, `ui/index.html`, dos pruebas nuevas y `package.json` (las añade a `test` y `test:e2e`). Detalle: `docs/audits/DIFFERENCES_v0.4.6.1_vs_v0.4.7_CANDIDATE.md`.
- [V] Invariancia del contrato: la prueba `ui-contract-invariance` fija el SHA-256 del compacto de Oski, Currency Exchange, Virtual Account Opening y Debit Card sin cambios; además, al regenerar con el HTML candidato los 9 compactos sintéticos de `qa/cases/`, **los 9 resultaron idénticos byte a byte** (solo cambió la procedencia registrada, `htmlSha256`).
- [I] El candidato v0.4.7 lo produjo otro proceso en el equipo de Andrés (no esta sesión); se revisó el diff: no hay llamadas de red, las inserciones en pantalla escapan el HTML y los paneles no interpretan nombre, posición ni texto libre como Inicio ni usan `MODELO` como criterio. Los E2E del candidato (8/8, según su documento) no se re-ejecutaron aquí.
- [V] Skill v11.2.3: `dist/validar-blueprint-integracion-v11.2.3.zip`, 29 908 B, SHA-256 `e15c8bda8bef0eb4913ea671c1bfc8ad97b10e026112a51c4455be8f75939330`. Anteriores conservadas: v11.2.2 `9b35a98e…c704d`, v11.2.1 (`qa/skill-locks/`).
- [V] Pruebas: `npm test` 69/69 con el candidato (68/68 antes de él), audit y build OK antes de él, selftest del banco 123/123, preflight del banco 105/105 (v11.2.3) y 38/38 (v11.2.2) tras actualizar la procedencia de los compactos. E2E (`test:e2e`) y build del candidato no se re-ejecutaron en esta sesión.

## 4. Skill v11.2.3 y sus resultados reales
- [V] Cambios solo operativos (sección «Interpretación operativa (v11.2.3)»): tipo (`SERVICIO_HIJO`) ≠ rol (`HIJO_PRINCIPAL`); un hijo principal no equivale a `SERVICIO`/`INVOCADO` ni amplía SRV; `PRODUCER` exige procedencia, certeza y conflictos; HIPOTESIS/CONFIRMADO no son estados normativos; E1/E2/E3-001 no dan Cumple sin Inicio certificado; API-004, CA-001 y FT-001 se evalúan por separado; No cumple exige evidencia suficiente. CNT-002 y API-003 sin cambios.
- [V] Validación funcional (6 sesiones: 3 casos × v11.2.3 y v11.2.2, una ejecución cada una): 0 FAIL técnicos en v11.2.3; solo 4 reglas difieren entre versiones (CNT-002 y CNT-004 en un caso; EVT-007 en dos). Los casos **no discriminan** los ajustes: v11.2.2 ya se comportaba igual; la diferencia visible es la justificación. Informe: `docs/audits/VALIDACION_FUNCIONAL_SKILL_V11.2.3_2026-10-26.md`.
- [V] Consumo: costo de lista v11.2.3 USD 2,3732 vs v11.2.2 USD 2,1936 (+8,2 %), tokens +5,0 %. Costo de lista ≠ consumo estimado del plan ≠ cargo real.
- [I] La frase «no se extiende a CNT-002» pudo inducir el Cumple de CNT-002/CNT-004 en un caso; con n=1 no se separa de la variabilidad.
- [V] Se halló y corrigió un defecto del controlador QA (lectura de conteos); las 6 sesiones se reevaluaron sin llamar al modelo.

## 5. Evidencia estructural verificada
- [V] **Corpus histórico frente a subconjunto actual:** las auditorías anteriores citaban «0 de 341 BPMNEvent con `customData`»; el subconjunto auditado el 25–26/10 (7 blueprints: Oski, Currency Exchange, Virtual Account Opening, Debit Card, Mortgage, QR Payment, Escenario2) tiene **260** `BPMNEvent` y **0** con `customData`. La cifra 341 abarcaba más archivos del corpus y no se reconcilió hoy; ambas conducen a la misma conclusión (todo escenario real es HIPOTESIS) pero no son el mismo conjunto. Los 12 escenarios del subconjunto son HIPOTESIS con subtipo NO_VERIFICABLE.
- [V] **MOD-001:** 160 figuras con `customData` ENTRADA/SALIDA (clase `BPMNActivity`) y las 160 se preservan literalmente (ID, clase, `customData`, texto, grupos). `architecturalType: MODELO` se asigna por nombre: 99 de las 160 tienen tipo `null`, y las etiquetas «Modelo de Salida/Lectura» sí son `MODELO`. La asociación al principal no siempre es certificable: 10 de 14 páginas evaluables tienen ENTRADA y SALIDA en un grupo único con el principal; 2 tienen principal sin esa asociación; 2 no resuelven principal; hay 59 modelos en grupos sin el principal y 43 sin grupo. Si la pertenencia a un grupo basta es una interpretación pendiente.
- [V] **Contenedores hijo:** 25 `RectangleContainerBlock` (20 en páginas operativas). Tipo por figura (`SERVICIO_HIJO`), rol por escenario (`HIJO_PRINCIPAL` solo para `mainChildServiceId`). 8 sin nombre (todos en Debit Card; 6 agrupan 21–68 figuras), 6 sin padre, 2 anidados.
- [A] Q1 cerrada: `PRODUCER` por evidencia estructural (RECAUDOS en Oski, CORE GLOBAL ACCOUNT en Virtual Account Opening), sin inferir por descarte.

## 6. Decisiones Q1–Q10 (estado)
- **Cerradas:** Q1 (productor estructural), Q10 (`qa/` forma parte del proyecto privado; sin `qa/runs/`, transcripciones sensibles ni temporales; nunca en la distribución pública).
- **Parciales:** Q2 (HIPOTESIS≠No cumple, CONFIRMADO≠Cumple; falta la lectura de «escenario certificado» en CNT-002), Q5 (ausencia de figura ≠ No aplica; sin obligación universal de gestor; falta la pregunta MQ), Q6 (No cumple exige evidencia suficiente; falta definir cobertura completa), Q8 (evaluación independiente aprobada; falta el reparto cuando coinciden API-004/CA-001/FT-001).
- **Pendientes:** Q3 (directa/declarada; redacción sin homogeneizar), Q4 (población de SRV-001..003), Q7 (población de CNT-006), Q9 (destino y alcance del repositorio; ahora privado, falta alcance).
- Detalle y fuentes: `docs/audits/CIERRE_ETAPA_2026-10-25.md`, Parte IX (histórico, no se reescribe).

## 7. Futuro consolidado normativo
- [P] La analista prepara una actualización. Hasta recibirla, las 41 obligaciones y sus IDs permanecen intactas y no se implementan reglas nuevas.
- [V] Mecanismo listo: `qa/tools/compare-normative.mjs` (detecta por ID, texto, aplicabilidad, evidencia y criterio, y la evidencia disponible en el contrato) y `qa/templates/COMPARACION_NORMATIVA.md`.

## 8. Propuestas pendientes de aprobación
- Evidence Studio v0.4.7 (priorizada en el informe de validación, §7). **Ya implementados en el candidato visual** (pendientes de revisión y aceptación de la analista): panel «Eventos BPMN con subtipo no certificado», procedencia de `PRODUCER`, tipo vs rol de los contenedores hijo y listado de modelos ENTRADA/SALIDA sin inferir propietario. **Aún sin implementar:** advertencias de trazabilidad de contenedores hijo (sin nombre/sin padre/anidado) como campos del contrato, indicador de cobertura y reducción del compacto. Riesgos del candidato: la procedencia del productor usa solo campos ya publicados; los eventos ajenos a `scenario.event` muestran `SIN_CERTIFICACION_PUBLICADA` (ausencia, no clasificación); el conteo de hijos es de inmediatos, no de descendientes.
- Propuesta BPMN (`docs/audits/PROPUESTA_CERTIFICACION_BPMN_2026-10-25.md`, renombrada el 26/10): sin convención `customData` nueva; `PROPOSED_CLOSED_CATALOG` se mantiene.
- Skill: aclaración de MOD-001 y neutralización de la frase sobre CNT-002, solo con aprobación y junto al consolidado de la analista.

## 9. Riesgos
1. v11.2.3 no probada con la analista; resultados de 3 casos sintéticos, n=1.
2. Escenarios siempre HIPOTESIS: E1/E2/E3-001 no pueden llegar a Cumple en blueprints reales hasta poder certificar el subtipo.
3. Variabilidad de CNT-002/CNT-004 entre ejecuciones.
4. MQ-001..004 se evalúan como No aplica de forma sistemática (C15-Q1 abierta).
5. Mapeo de preguntas del simulador por palabras clave.
6. Material corporativo en ramas privadas sin alcance autorizado para el remoto.

## 10. Próximos pasos
1. Pruebas funcionales con la analista usando v11.2.3 (sin declararla estable).
2. Recibir su consolidado y compararlo con la plantilla.
3. Decidir con Andrés el alcance Git (qué sube a `main` privado).
4. Revisión visual y aceptación de la analista del candidato v0.4.7; después autorizar, por orden, lo que falta (advertencias de contenedores hijo en el contrato, cobertura).
5. Solo después, la batería de 16 casos.
