import { shapeKind, shapeText, normalizeLabel, isNotationLabel, customDataEntries } from './lucidchart.js';

const RESERVED_EXACT = new Map([['INTEGRACION','INTEGRATION'],['SISTEMA EXTERNO','EXTERNAL_SYSTEM'],['SISTEMAS EXTERNOS','EXTERNAL_SYSTEM'],['SISTEMA EXTERNO (OPCIONAL)','EXTERNAL_SYSTEM'],['SISTEMAS EXTERNOS (OPCIONAL)','EXTERNAL_SYSTEM'],['DOMINIO PRODUCTOR','PRODUCER']]);
const RESERVED_VARIANT = /^(INTEGRACION|SISTEMAS? EXTERNOS?|DOMINIO PRODUCTOR)(?:\b|\s*[-(])/;

export function reconstructContainment(page) {
  const byId = new Map(page.shapes.map(s => [s.id, s]));
  const duplicateIds = page.shapes.map(s => s.id).filter((id, i, all) => id == null || all.indexOf(id) !== i).map(id => ({ code: id == null ? 'MISSING_ID' : 'DUPLICATE_ID', id, status: 'CONFLICTING' }));
  const claims = new Map(), missingReferences = [];
  for (const parent of page.shapes) for (const childId of parent.contains?.shapes ?? []) {
    if (!byId.has(childId)) { missingReferences.push({ parentId: parent.id, childId, source: 'JSON.contains' }); continue; }
    if (!claims.has(childId)) claims.set(childId, new Set()); claims.get(childId).add(parent.id);
  }
  const children = new Map();
  for (const [child, parents] of claims) for (const parent of parents) { if (!children.has(parent)) children.set(parent, new Set()); children.get(parent).add(child); }
  const reachability = new Map();
  for (const id of byId.keys()) { const found=new Set(),stack=[...(children.get(id)??[])]; while(stack.length){const next=stack.pop();if(found.has(next))continue;found.add(next);stack.push(...(children.get(next)??[]));} reachability.set(id,found); }
  const reaches=(from,target)=>from===target||reachability.get(from)?.has(target)===true;
  const directParent=new Map(),issues=[];
  for(const shape of page.shapes){const all=[...(claims.get(shape.id)??[])],cyclic=all.some(parent=>reaches(shape.id,parent));const immediate=all.filter(parent=>!all.some(other=>other!==parent&&reaches(parent,other)));if(!cyclic&&immediate.length===1)directParent.set(shape.id,immediate[0]);else if(cyclic||immediate.length>1)issues.push({code:cyclic?'CONTAINMENT_CYCLE':'DIRECT_PARENT_CONFLICT',componentId:shape.id,claimedContainerIds:all,immediateCandidateIds:immediate,status:'CONFLICTING',evidence:'JSON.contains'});}
  const chainFor=id=>{const chain=[],seen=new Set([id]);let cursor=id;while(directParent.has(cursor)){const parent=directParent.get(cursor);if(seen.has(parent))break;seen.add(parent);chain.unshift(parent);cursor=parent;}return chain;};
  const structuralRoots=page.shapes.filter(s=>!directParent.has(s.id));
  const notationContainers=page.shapes.filter(s=>isNotationLabel(shapeText(s))),notationIds=new Set(notationContainers.map(s=>s.id));
  const addDescendants=id=>{for(const child of children.get(id)??[])if(!notationIds.has(child)){notationIds.add(child);addDescendants(child);}}; notationContainers.forEach(s=>addDescendants(s.id));
  for(const group of page.groups)if((group.members??[]).some(id=>notationIds.has(id)))for(const id of group.members??[])notationIds.add(id);
  const structuralRootSet=new Set(structuralRoots.map(s=>s.id));
  const isDomainContainer=s=>{const label=normalizeLabel(shapeText(s)),declared=customDataEntries(s).some(x=>/^(DOMAIN_ROLE|ARCHITECTURAL_ROLE|ROL_DOMINIO)$/i.test(String(x.key??''))),hasContent=(s?.contains?.shapes?.length??0)+(s?.contains?.groups?.length??0)+(s?.contains?.lines?.length??0)>0;return s?.class==='UMLRectangleContainerBlock'&&s.contains&&(hasContent||RESERVED_EXACT.has(label))&&label&&!['FEDERADO','NOTACION'].includes(label)&&!['TRANSACTION_FLOW','ARCHITECTURE_LAYER'].includes(shapeKind(s))&&(structuralRootSet.has(s.id)||RESERVED_EXACT.has(label)||declared);};
  // 0.4.8: hijo = RectangleContainerBlock más interno con al menos una compuerta y una actividad. Un rectángulo plano que envuelve al hijo,
  // o que lleva como texto directo un nombre reservado de dominio, se trata como contenedor padre cuando no hay otro dominio que lo contenga.
  const countClass=(s,cls)=>(s.contains?.shapes??[]).filter(id=>byId.get(id)?.class===cls).length;
  const qualifyingChildren=page.shapes.filter(s=>s.class==='RectangleContainerBlock'&&((countClass(s,'BPMNGateway')>0&&countClass(s,'BPMNActivity')>0)||customDataEntries(s).some(x=>String(x.key??'').trim().toUpperCase()==='SERVICE')));
  const childCandidateIds=qualifyingChildren.filter(s=>!qualifyingChildren.some(o=>o.id!==s.id&&reachability.get(s.id)?.has(o.id))).map(s=>s.id);
  const mainChildId=childCandidateIds.length===1?childCandidateIds[0]:null;
  const promoted=new Map(),isTextBlock=s=>['MinimalTextBlock','AutoGrowTextBlock'].includes(s?.class);
  for(const rect of page.shapes){
    if(rect.class!=='RectangleContainerBlock'||directParent.has(rect.id)||childCandidateIds.includes(rect.id)||notationIds.has(rect.id))continue;
    const reserved=[...new Set((rect.contains?.shapes??[]).map(id=>byId.get(id)).filter(x=>isTextBlock(x)&&directParent.get(x.id)===rect.id).map(x=>RESERVED_EXACT.get(normalizeLabel(shapeText(x)))).filter(Boolean))];
    if(reserved.length===1)promoted.set(rect.id,{kind:'LOOSE_TEXT_NAME',role:reserved[0]});
    else if(mainChildId&&reachability.get(rect.id)?.has(mainChildId))promoted.set(rect.id,{kind:'WRAPS_MAIN_CHILD',role:null});
  }
  const domains=page.shapes.filter(s=>isDomainContainer(s)||promoted.has(s.id)),domainIds=new Set(domains.map(s=>s.id)),domainInfo=new Map();
  for(const domain of domains){
    const name=normalizeLabel(shapeText(domain)),declaredRole=normalizeLabel(customDataEntries(domain).find(x=>/^(DOMAIN_ROLE|ARCHITECTURAL_ROLE|ROL_DOMINIO)$/i.test(String(x.key??'')))?.value),nestedDomainIds=[...(reachability.get(domain.id)??[])].filter(id=>domainIds.has(id));
    const promo=promoted.get(domain.id);
    let role=promo?.role??RESERVED_EXACT.get(name)??(declaredRole==='PRODUCER'?'PRODUCER':null),roleSource=role?(promo?.role?'LOOSE_TEXT_NAME':RESERVED_EXACT.has(name)?'DECLARED_DOMAIN_NAME':'DECLARED_CUSTOM_DATA'):null,roleStatus=role?'RESOLVED':'UNRESOLVED',conflicts=[];
    if(!role&&RESERVED_VARIANT.test(name)){roleStatus='ROLE_UNRESOLVED_RESERVED_NAME_VARIANT';conflicts.push({code:'ROLE_UNRESOLVED_RESERVED_NAME_VARIANT',name:shapeText(domain),status:'CONFLICTING'});}
    else if(!role&&nestedDomainIds.length){roleStatus='CONFLICTING_NESTED_ARCHITECTURAL_DOMAIN';conflicts.push({code:'NESTED_ARCHITECTURAL_DOMAIN',nestedDomainIds,status:'CONFLICTING'});}
    else if(!role){roleStatus='NO_DETERMINADO';}
    domainInfo.set(domain.id,{role,roleSource,roleStatus,conflicts,nestedDomainIds});
  }
  const components=page.shapes.map(shape=>{
    const chain=chainFor(shape.id),ownIssue=issues.find(x=>x.componentId===shape.id),hierarchyIssue=[shape.id,...chain].map(id=>issues.find(x=>x.componentId===id)).find(Boolean),structuralRootId=hierarchyIssue?null:(chain[0]??shape.id),candidateDomainId=[...chain,...(domainIds.has(shape.id)?[shape.id]:[])].reverse().find(id=>domainIds.has(id))??null,domainId=hierarchyIssue?null:candidateDomainId,info=domainInfo.get(domainId),parentId=directParent.get(shape.id)??null,root=byId.get(structuralRootId),domain=byId.get(domainId);
    const structuralParent=ownIssue?{id:null,name:null,type:null,source:'JSON.contains',status:'CONFLICTING',candidateIds:ownIssue.immediateCandidateIds??ownIssue.claimedContainerIds??[]}:{id:parentId,name:parentId?shapeText(byId.get(parentId)):null,type:parentId?shapeKind(byId.get(parentId)):null,source:parentId?'JSON.contains':null,status:parentId?'RESOLVED':'NOT_DECLARED',candidateIds:[]};
    const rootContainer={id:structuralRootId,name:root?shapeText(root):null,type:root?shapeKind(root):null,source:structuralRootId?'derived:direct-containment-chain':null,status:hierarchyIssue?'CONFLICTING':structuralRootId?'RESOLVED':'UNRESOLVED'};
    const architecturalDomain={id:domainId,name:domain?shapeText(domain):null,lucidchartClass:domain?.class??null,source:info?.roleSource??(domainId?'JSON.contains+architectural-container':null),roleSource:info?.roleSource??null,status:hierarchyIssue?'CONFLICTING':info?.roleStatus??'UNRESOLVED',conflicts:structuredClone(hierarchyIssue?[hierarchyIssue]:(info?.conflicts??[]))};
    return{id:shape.id,type:shapeKind(shape),name:shapeText(shape),structuralParent,containerChainIds:chain,rootContainer,architecturalDomain,domainRole:info?.role??null,possibleDomainRoles:info?.role?[]:['PRODUCER','EXTERNAL_SYSTEM'],evidenceSources:{structuralParent:structuralParent.source,containerChain:'derived:JSON.contains',rootContainer:rootContainer.source,architecturalDomain:architecturalDomain.source,domainRole:info?.roleSource??null},structuralParentId:structuralParent.id,structuralParentStatus:structuralParent.status,structuralRootId,rootContainerId:structuralRootId,architecturalDomainId:domainId,explicitDomainRole:info?.role??null,rootRoleSource:info?.roleSource??null,rootRoleStatus:architecturalDomain.status,domainConflicts:structuredClone(architecturalDomain.conflicts),notation:notationIds.has(shape.id)};
  });
  const direct=[...directParent].map(([childId,containerId])=>({childId,containerId,relation:'DIRECT_CONTAINMENT',source:'JSON.contains',status:'RESOLVED'}));
  const ancestors=components.flatMap(c=>c.containerChainIds.filter(id=>id!==c.structuralParentId).map(containerId=>({childId:c.id,containerId,relation:'ANCESTOR_CONTAINMENT',source:'derived:direct-chain',status:'DERIVED'})));
  const rootContainers=domains.map(s=>{const c=components.find(c=>c.id===s.id),info=domainInfo.get(s.id);return{id:s.id,name:shapeText(s),lucidchartClass:s.class,structuralParent:structuredClone(c?.structuralParent??null),containerChainIds:c?.containerChainIds??[],rootContainer:structuredClone(c?.rootContainer??null),architecturalDomain:structuredClone(c?.architecturalDomain??null),domainRole:c?.domainRole??null,evidenceSources:structuredClone(c?.evidenceSources??{}),structuralRootId:c?.structuralRootId??null,structuralParentId:c?.structuralParentId??null,architecturalDomainId:c?.architecturalDomainId??null,role:c?.domainRole??null,roleSource:c?.domainRole?info.roleSource:null,roleStatus:c?.rootRoleStatus??info.roleStatus,nestedDomainIds:info.nestedDomainIds,conflicts:[...info.conflicts,...issues.filter(x=>x.componentId===s.id)]};});
  return{byId,directParent,chainFor,components,childAnalysis:{candidateIds:childCandidateIds,mainChildId,promoted:Object.fromEntries(promoted)},structuralRootIds:structuralRoots.map(s=>s.id),notationIds,rootContainers,relations:[...direct,...ancestors],issues:[...duplicateIds,...page.normalizationIssues,...issues,...rootContainers.flatMap(x=>x.conflicts.map(c=>({...c,containerId:x.id})))],missingReferences};
}
