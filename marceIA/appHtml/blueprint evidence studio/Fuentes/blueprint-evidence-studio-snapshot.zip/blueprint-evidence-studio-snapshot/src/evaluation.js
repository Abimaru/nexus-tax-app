export const EVALUATION_STATES = Object.freeze(['Cumple','No cumple','No verificable','No aplica']);

export function summarizeEvaluations(evaluations, expectedRuleIds) {
  if(!Array.isArray(evaluations)||!Array.isArray(expectedRuleIds))throw new TypeError('evaluations and expectedRuleIds must be arrays');
  const expected=new Set(expectedRuleIds),seen=new Set(),counts=Object.fromEntries(EVALUATION_STATES.map(x=>[x,0]));
  const errors=[];
  for(const item of evaluations){
    if(!item?.rule_id||!expected.has(item.rule_id))errors.push({code:'UNKNOWN_RULE_ID',rule_id:item?.rule_id??null});
    else if(seen.has(item.rule_id))errors.push({code:'DUPLICATE_RULE_ID',rule_id:item.rule_id});
    else seen.add(item.rule_id);
    if(!EVALUATION_STATES.includes(item?.status))errors.push({code:'UNKNOWN_EVALUATION_STATE',rule_id:item?.rule_id??null,status:item?.status??null});
    else counts[item.status]++;
  }
  for(const id of expected)if(!seen.has(id))errors.push({code:'MISSING_RULE_RESULT',rule_id:id});
  if(evaluations.length!==expectedRuleIds.length)errors.push({code:'INCONSISTENT_RESULT_COUNT',expected:expectedRuleIds.length,actual:evaluations.length});
  const denominator=counts.Cumple+counts['No cumple']+counts['No verificable'];
  return{valid:errors.length===0,errors,counts,total:evaluations.length,applicable:denominator,compliancePercentage:denominator?counts.Cumple/denominator*100:null};
}

export function summarizeBlueprint(pageSummaries) {
  const counts=Object.fromEntries(EVALUATION_STATES.map(x=>[x,0]));
  for(const page of pageSummaries)for(const state of EVALUATION_STATES)counts[state]+=page.counts?.[state]??0;
  const denominator=counts.Cumple+counts['No cumple']+counts['No verificable'];
  return{counts,applicable:denominator,compliancePercentage:denominator?counts.Cumple/denominator*100:null};
}
