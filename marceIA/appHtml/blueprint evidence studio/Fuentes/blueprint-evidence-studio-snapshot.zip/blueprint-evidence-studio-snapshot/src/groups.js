import { shapeKind, shapeText, ioModelKey } from './lucidchart.js';

export function reconstructGroups(page) {
  const shapeIds=new Set(page.shapes.map(x=>x.id)),groupsById=new Map(page.groups.map(x=>[x.id,x])),parents=new Map(),missingMembers=[],memberships=new Map();
  for(const group of page.groups)for(const memberId of group.members??[]){
    if(!shapeIds.has(memberId)&&!groupsById.has(memberId))missingMembers.push({groupId:group.id,memberId,code:'GROUP_MEMBER_MISSING',status:'UNRESOLVED'});
    if(groupsById.has(memberId)){if(!parents.has(memberId))parents.set(memberId,new Set());parents.get(memberId).add(group.id);}
    if(shapeIds.has(memberId)){if(!memberships.has(memberId))memberships.set(memberId,new Set());memberships.get(memberId).add(group.id);}
  }
  const ancestors=id=>{const out=[],seen=new Set(),queue=[...(parents.get(id)??[])];while(queue.length){const next=queue.shift();if(seen.has(next))continue;seen.add(next);out.push(next);queue.push(...(parents.get(next)??[]));}return out;};
  const groupIssues=[...missingMembers];
  for(const group of page.groups){const ancestorIds=ancestors(group.id);if((group.members??[]).includes(group.id))groupIssues.push({groupId:group.id,code:'GROUP_SELF_REFERENCE',status:'CONFLICTING'});else if(ancestorIds.includes(group.id))groupIssues.push({groupId:group.id,code:'GROUP_CYCLE',ancestorGroupIds:ancestorIds,status:'CONFLICTING'});}
  for(const [componentId,ids] of memberships)if(ids.size>1)groupIssues.push({componentId,groupIds:[...ids],code:'MULTIPLE_GROUP_MEMBERSHIP',status:'CONFLICTING'});
  const descendantShapes=id=>{const out=new Set(),seen=new Set(),stack=[id];while(stack.length){const next=stack.pop();if(seen.has(next))continue;seen.add(next);for(const member of groupsById.get(next)?.members??[]){if(shapeIds.has(member))out.add(member);else if(groupsById.has(member))stack.push(member);}}return[...out];};
  const groups=page.groups.map(group=>{const parentIds=[...(parents.get(group.id)??[])],componentIds=descendantShapes(group.id),localIssues=groupIssues.filter(x=>x.groupId===group.id);return{id:group.id,directMemberIds:[...(group.members??[])],childGroupIds:(group.members??[]).filter(id=>groupsById.has(id)),parentGroupId:parentIds.length===1?parentIds[0]:null,parentGroupIds:parentIds,ancestorGroupIds:ancestors(group.id),relatedComponentIds:componentIds,source:'JSON.items.groups',status:parentIds.length>1?'CONFLICTING_MULTIPLE_PARENTS':localIssues.some(x=>x.status==='CONFLICTING')?'CONFLICTING':localIssues.length?'PARTIAL':'RESOLVED',conflicts:[...(parentIds.length>1?[{code:'MULTIPLE_GROUP_PARENTS',parentGroupIds:parentIds}]:[]),...localIssues]};});
  // 0.10.0: etiquetas del grupo (customData de la biblioteca nueva), solo si las trae.
  for(const g of groups){const labels=[...new Set((groupsById.get(g.id)?.customData??[]).filter(x=>x&&typeof x==='object').map(x=>String(x.key??'').trim().toUpperCase()).filter(Boolean))];if(labels.length)g.labels=labels;}
  const componentMemberships=page.shapes.map(shape=>{const direct=[...(memberships.get(shape.id)??[])],ancestor=[...new Set(direct.flatMap(ancestors))];return{componentId:shape.id,directGroupIds:direct,ancestorGroupIds:ancestor,multipleMembership:direct.length>1,source:'JSON.items.groups',status:direct.length?'RESOLVED':'NOT_GROUPED'};});
  const relations=[...groups.flatMap(g=>g.directMemberIds.map(memberId=>({relation:'GROUP_MEMBERSHIP',groupId:g.id,memberId,source:'JSON.items.groups',status:shapeIds.has(memberId)||groupsById.has(memberId)?'RESOLVED':'UNRESOLVED'})))];
  return{groups,componentMemberships,relations,issues:groupIssues,groupsById,descendantShapes};
}

export function groupDeploymentAssociations(page,groupGraph){
  const byShape=new Map(page.shapes.map(x=>[x.id,x])),byGroup=new Map(groupGraph.groups.map(x=>[x.id,x])),out=[];
  for(const pairGroup of groupGraph.groups){
    const directShapes=pairGroup.directMemberIds.map(id=>byShape.get(id)).filter(Boolean),flows=directShapes.filter(x=>shapeKind(x)==='TRANSACTION_FLOW'),layers=directShapes.filter(x=>shapeKind(x)==='ARCHITECTURE_LAYER');
    if(flows.length!==1||layers.length!==1)continue;
    const parentIds=pairGroup.parentGroupIds,eligible=[];
    for(const parentId of parentIds){const parent=byGroup.get(parentId),pairSiblings=(parent?.childGroupIds??[]).filter(id=>{const shapes=byGroup.get(id)?.directMemberIds.map(x=>byShape.get(x)).filter(Boolean)??[];return shapes.some(x=>shapeKind(x)==='TRANSACTION_FLOW')&&shapes.some(x=>shapeKind(x)==='ARCHITECTURE_LAYER');});if(parentIds.length!==1||pairSiblings.length!==1)continue;for(const siblingId of parent?.childGroupIds??[]){if(siblingId===pairGroup.id)continue;const sibling=byGroup.get(siblingId),ids=sibling?.relatedComponentIds??[],components=ids.map(id=>byShape.get(id)).filter(x=>shapeKind(x)==='API_OR_SERVICE'||shapeKind(x)==='QUEUE_MANAGER'),models=ids.map(id=>byShape.get(id)).filter(x=>/MODELO/i.test(shapeText(x))||ioModelKey(x));for(const component of components)eligible.push({componentId:component.id,componentGroupId:siblingId,modelIds:models.map(x=>x.id),superiorGroupId:parentId});}}
    const unique=[...new Map(eligible.map(x=>[x.componentId,x])).values()];
    const involvedIds=new Set([pairGroup.id,...parentIds,...unique.flatMap(x=>[x.componentGroupId,x.superiorGroupId])].filter(Boolean)),conflicts=groupGraph.issues.filter(x=>involvedIds.has(x.groupId)||unique.some(c=>c.componentId===x.componentId));
    const resolved=unique.length===1&&!conflicts.length;
    out.push({pairGroupId:pairGroup.id,flowId:flows[0].id,layerId:layers[0].id,resolvedComponentId:resolved?unique[0].componentId:null,superiorGroupId:resolved?unique[0].superiorGroupId:null,componentGroupId:resolved?unique[0].componentGroupId:null,modelIds:resolved?unique[0].modelIds:[],candidateComponents:unique,evidence:[{source:'JSON.items.groups',pairGroupId:pairGroup.id,parentGroupIds:parentIds}],conflicts,relation:'DEPLOYMENT_ASSOCIATION',status:conflicts.length?'AMBIGUOUS_GROUP_CONFLICT':unique.length===1?'RESOLVED_BY_EXPLICIT_SUPERIOR_GROUP':unique.length>1?'AMBIGUOUS_MULTIPLE_COMPONENTS':'PENDING_NO_COMMON_SUPERIOR_GROUP',nonNormative:true});
  }
  return out;
}
