import { normalizeLabel, shapeText } from './lucidchart.js';

export function componentSections(shape) {
  const areas = shape?.textAreas ?? [];
  const get = label => areas.find(x => x.label === label)?.text ?? null;
  return { title: get('Title') ?? get('Text') ?? areas[0]?.text ?? null, operation: get('Text1') ?? areas[1]?.text ?? null, thirdSection: get('Text2') ?? areas[2]?.text ?? null, original: structuredClone(areas) };
}

function functionalClassification(thirdSection) {
  const value=normalizeLabel(thirdSection);
  const service=value.match(/\b(ENTIDAD|UTILIDAD|TAREA)\b/)?.[1]??null;
  const exposure=value.match(/\b(PRIVATE|PUBLIC|PARTNER|PRIVADA|PUBLICA)\b/)?.[1]??null;
  const event=value.match(/\b(QUERY|COMMAND|EVENT)\b/)?.[1]??null;
  const eventType=value.match(/\b(EMPRESARIAL|APLICACION)\b/)?.[1]??null;
  return { raw:thirdSection??null, serviceModel:service?.toLowerCase()??null, exposure:exposure?.toLowerCase()??null, eventClassification:event?.toLowerCase()??null, integrationEventType:eventType?.toLowerCase()??null, source:'textAreas.Text2' };
}

// Evento de integración (0.8.0): la tercera sección declara tipo (empresarial o aplicación) y clasificación (event, query o command). Con una sola parte es candidato.
export const isIntegrationEvent=functional=>Boolean(functional?.eventClassification&&functional?.integrationEventType);
export const isPartialIntegrationEvent=functional=>Boolean((functional?.eventClassification||functional?.integrationEventType)&&!isIntegrationEvent(functional));

// Convención de nombre de servicio: inicia con ms (ms-x, ms_x, ms x, msX), termina con ms (x-ms, x_ms, x ms, x.ms, xMs) o contiene la palabra microservicio o microservice.
export function serviceNamingSignal(title){
  const raw=String(title??'').trim();
  if(/^ms[-_ ](?=\S)/i.test(raw)||/^ms(?=[A-Z])/.test(raw))return'title-prefix';
  if(/[-_ .]ms$/i.test(raw)||/[a-z0-9]Ms$/.test(raw))return'title-suffix';
  if(/\bmicroservic(?:io|e)s?\b/i.test(raw.normalize('NFD').replace(/[\u0300-\u036f]/g,'')))return'title-keyword';
  return null;
}
export const hasServiceNamingBasis=item=>item?.candidate==='service'&&(item.basis==='title-prefix'||item.basis==='title-suffix'||item.basis==='title-keyword');

export function classifyShape(shape) {
  if (!shape) return { technicalType: null, evidence: [], architecturalRoleCandidate: null, status: 'MISSING_REFERENCE' };
  const sections = componentSections(shape); const title = normalizeLabel(sections.title);
  const evidence = [{ source: 'JSON.class', value: shape.class }];
  const inference=[]; let technicalType = null, status = 'UNRESOLVED', role=null;
  if (shape.class === 'BPMNEvent') { technicalType = 'bpmnEvent'; status = 'IDENTIFIED'; }
  else if (shape.class === 'BPMNGroup') { technicalType = 'bpmnGroup'; status = 'IDENTIFIED'; }
  else if (shape.class === 'BPMNGateway') { technicalType = 'bpmnGateway'; status = 'IDENTIFIED'; }
  else if (shape.class === 'BPMNActivity') { technicalType = 'bpmnActivity'; status = 'IDENTIFIED'; }
  else if (shape.class === 'UMLActiveClassBlock') { technicalType = 'queueManager'; status = 'IDENTIFIED'; }
  else if (shape.class === 'RectangleContainerBlock') { technicalType = 'childContainer'; status = 'IDENTIFIED'; }
  else if (shape.class === 'UMLClassBlock') {
    technicalType = 'umlClassComponent'; status = 'CLASS_IDENTIFIED_ROLE_UNRESOLVED';
    const functional=functionalClassification(sections.thirdSection);
    if(functional.serviceModel||functional.exposure||functional.eventClassification||functional.integrationEventType){evidence.push({source:functional.source,value:sections.thirdSection,strength:'FUNCTIONAL_CLASSIFICATION_ONLY'});if(functional.serviceModel)inference.push({candidate:'service',basis:'serviceModel',status:'UNCONFIRMED'});if(functional.exposure)inference.push({candidate:'api',basis:'exposure',status:'UNCONFIRMED'});if(isIntegrationEvent(functional))inference.push({candidate:'integrationEvent',basis:functional.eventClassification?'eventClassification':'integrationEventType',status:'UNCONFIRMED'});}
    const rawTitle=String(sections.title??'').trim(),naming=serviceNamingSignal(rawTitle);
    if (naming) { evidence.push({ source: naming, value: sections.title, strength: 'CONVENTIONAL_SIGNAL', confidence:'MEDIUM' }); inference.push({candidate:'service',basis:naming,status:'UNCONFIRMED',confidence:'MEDIUM'}); }
    role='principal-or-consumed-candidate';
  }
  return { technicalType, functionalClassification:functionalClassification(sections.thirdSection), evidence, inference, architecturalRoleCandidate:role, status, sections };
}
