import { normalizeLabel, shapeKind, shapeText } from './lucidchart.js';
import { connectionOrientation } from './roles.js';

const PLACEHOLDER = /^(NOMBRE SERVICIO|NOMBRE FUNCIONAL|NOMBREFUNCIONALMETODO|CLASIFICACION LOGICA|NOMBRE PRODUCTO|NOMBRE API)(?:\b|$)/;
export const isPlaceholderShape = shape => (shape?.textAreas ?? []).some(area => PLACEHOLDER.test(normalizeLabel(area.text ?? area.value)));
const isPlaceholderTitle=shape=>PLACEHOLDER.test(normalizeLabel((shape?.textAreas??[]).find(x=>x.label==='Title')?.text??shape?.textAreas?.[0]?.text));

export function classifyPage(page, containment, connections) {
  const legendShapeIds = new Set(containment.notationIds);
  const placeholderShapeIds=page.shapes.filter(isPlaceholderShape).map(x=>x.id);
  const operationalPathIds=[],placeholderPaths=[];
  for (const connection of connections) {
    const orientation=connectionOrientation(connection.raw??connection);
    if (orientation.status!=='VERIFIED_BY_TERMINATIONS') continue;
    const source=containment.byId.get(orientation.originId), destination=containment.byId.get(orientation.destinationId);
    if (shapeKind(source)==='API_OR_SERVICE'&&shapeKind(destination)==='BPMN_EVENT'&&!containment.notationIds.has(source.id)&&!containment.notationIds.has(destination.id)) (isPlaceholderTitle(source)?placeholderPaths:operationalPathIds).push({id:connection.id,originId:source.id});
  }
  // 0.8.5: unicidad con nombre de plantilla. Si no hay ningún principal con nombre propio pero UNA sola API/servicio (con nombre de plantilla) tiene línea certificada a un evento y la página tiene otras APIs/servicios con nombre propio (así una plantilla en blanco sigue sin evaluarse), la página es operativa; el nombre de plantilla lo juzgan las reglas, no el clasificador.
  const hasRealApiOrService=page.shapes.some(x=>shapeKind(x)==='API_OR_SERVICE'&&!containment.notationIds.has(x.id)&&!isPlaceholderShape(x));
  const uniquePlaceholderMain=!operationalPathIds.length&&hasRealApiOrService&&new Set(placeholderPaths.map(x=>x.originId)).size===1;
  const pathLines=uniquePlaceholderMain?placeholderPaths:operationalPathIds;
  operationalPathIds.splice(0,operationalPathIds.length,...pathLines.map(x=>x.id));
  const containsLegend=legendShapeIds.size>0;
  const apiOrService=page.shapes.filter(x=>shapeKind(x)==='API_OR_SERVICE'&&!containment.notationIds.has(x.id));
  const hasOperationalStructure=operationalPathIds.length>0;
  const kind=/BDD/i.test(page.title)?'BDD_OR_REQUIREMENTS':hasOperationalStructure?(containsLegend?'MIXED':'OPERATIONAL'):(containsLegend||placeholderShapeIds.length?'TEMPLATE_OR_LEGEND':'UNRESOLVED');
  if(!hasOperationalStructure)placeholderShapeIds.forEach(id=>legendShapeIds.add(id));
  const reason=kind==='TEMPLATE_OR_LEGEND'?templateReason(page,containment,connections,apiOrService):null;
  return {kind,...(uniquePlaceholderMain?{placeholderMainAccepted:true}:{}),...(reason?{reason:reason.code,reasonDetail:reason.detail}:{}),containsNotationLegend:containment.notationIds.size>0,legendShapeIds:[...legendShapeIds],placeholderShapeIds,operationalPathIds,evidence:{pageTitle:page.title,shapeCount:page.shapes.length,groupCount:page.groups.length,connectionCount:page.lines.length},nonNormative:true};
}

// 0.8.3 (UI): causa factual por la que una página con leyenda o figuras de plantilla no tiene camino operativo. Solo describe; no cambia la clasificación.
function templateReason(page,containment,connections,apiOrService){
  const ids=new Set(apiOrService.map(x=>x.id)),isEvent=id=>shapeKind(containment.byId.get(id))==='BPMN_EVENT'&&!containment.notationIds.has(id);
  const real=apiOrService.filter(x=>!isPlaceholderShape(x)),verifiedPlaceholderLines=[],unverifiedLines=[],danglingEventLines=[];
  for(const connection of connections){
    const o=connectionOrientation(connection.raw??connection);
    if(o.status==='VERIFIED_BY_TERMINATIONS'){
      if(ids.has(o.originId)&&isEvent(o.destinationId)&&isPlaceholderTitle(containment.byId.get(o.originId)))verifiedPlaceholderLines.push(connection.id);
      else if(!o.originId&&isEvent(o.destinationId))danglingEventLines.push({id:connection.id,eventId:o.destinationId});
    }else{
      const ends=(o.endpointIds??[]).filter(Boolean);
      if(ends.some(id=>ids.has(id))&&ends.some(isEvent))unverifiedLines.push(connection.id);
    }
  }
  const detail={apiOrServiceIds:real.map(x=>x.id),placeholderShapeIds:apiOrService.filter(isPlaceholderShape).map(x=>x.id),unverifiedLineIds:unverifiedLines,danglingEventLines};
  if(!real.length)return{code:'TEMPLATE_EMPTY',detail};
  if(verifiedPlaceholderLines.length)return{code:'PLACEHOLDER_MAIN',detail:{...detail,placeholderLineIds:verifiedPlaceholderLines}};
  if(unverifiedLines.length)return{code:'API_EVENT_LINE_NOT_VERIFIED',detail};
  return{code:'NO_API_EVENT_LINE',detail};
}

// 0.8.4 (UI): el JSON solo se genera si todas las páginas seleccionadas son evaluables (MIXED u OPERATIONAL). Cualquier otra (TEMPLATE_OR_LEGEND, UNRESOLVED, BDD_OR_REQUIREMENTS) bloquea la descarga. No explica la causa: solo informa el estado.
export const EVALUABLE_KINDS=['MIXED','OPERATIONAL'];
export const blockingPages=result=>(result?.pages??[]).filter(p=>!EVALUABLE_KINDS.includes(p.pageClassification?.kind));
export function blockingMessage(page){
  const kind=page.pageClassification?.kind??'UNRESOLVED',name=page.page?.title||'(sin nombre)';
  return{kind,title:`La página «${name}» está catalogada como ${kind}`,text:`No se permite generar el JSON porque esta página está catalogada como ${kind}. Desmárquela y analice de nuevo; si necesita evaluarla, valide la página en Lucidchart, exporte el JSON y cárguelo otra vez.`,hints:[]};
}

// 0.8.5 (UI, informativo, no bloquea): flechas de flujo con un extremo sin figura asociada. En el SVG parecen conectadas, pero el JSON no trae la conexión. Se calcula sobre el resultado exportado y no altera el JSON.
export function looseArrowNotices(result){
  return (result?.pages??[]).map(page=>{
    const names=new Map((page.components??[]).map(x=>[x.id,x.name]));
    const lines=(page.connections??[]).filter(l=>{const a=l.endpoint1??{},b=l.endpoint2??{};return (!a.connectedTo||!b.connectedTo)&&(a.style==='Arrow'||b.style==='Arrow');}).map(l=>{const loose=!l.endpoint1?.connectedTo?'origen':'destino',other=loose==='origen'?l.endpoint2?.connectedTo:l.endpoint1?.connectedTo;return{id:l.id,looseEnd:loose,otherId:other??null,otherName:other?(names.get(other)||'(sin texto)'):null};});
    return{pageTitle:page.page?.title||'(sin nombre)',lines};
  }).filter(x=>x.lines.length);
}

// 0.10.0 (decisión de la analista, 19-20/11/2026): el JSON no se genera si una conexión tiene un extremo sin figura asociada.
// Las terminaciones (None-Arrow, CircleOpen-Generalization, etc.) NO bloquean: las evalúan las reglas del Skill. Las líneas None-None quedan exentas (20/11/2026) y las que tocan una anotación (BPMNTextAnnotation) también.
export function connectionBlockers(result){
  return (result?.pages??[]).map(page=>{
    const comps=new Map((page.components??[]).map(x=>[x.id,x])),isAnnotation=id=>comps.get(id)?.lucidchartType==='BPMNTextAnnotation';
    const GATE={EXCLUSIVE:'Compuerta exclusiva',PARALLEL:'Compuerta paralela',INCLUSIVE:'Compuerta inclusiva',EVENT_BASED:'Compuerta basada en evento',PARALLEL_EVENT_BASED:'Compuerta paralela basada en evento'},EVT={START:'Evento de inicio',END:'Evento de fin',EVENT:'Evento',EXCEPTION:'Evento de excepción',SIGNAL_SEND:'Evento de envío de señal',SIGNAL_RECEIVE:'Evento de recepción de señal',MESSAGE_SEND:'Evento de envío de mensaje',MESSAGE_RECEIVE:'Evento de recepción de mensaje'},CMD={SERVICE_TASK:'Comando con consumo',SYSTEM_TASK:'Comando sin consumo',SUB_PROCESS:'Subproceso',USER_TASK:'Actividad de usuario'},MODEL={POLITICA:'Política',EXCEPCION:'Mensaje de excepción',CONCEPTO:'Concepto'},ARCH={API:'API',SERVICIO:'Servicio',EVENTO_INTEGRACION:'Evento de integración',GESTOR_COLAS:'Gestor de colas',MODELO:'Modelo',SERVICIO_HIJO:'Servicio hijo',CONTENEDOR_PADRE:'Contenedor de dominio',SISTEMA_EXTERNO_AUXILIAR:'Sistema externo auxiliar',MARCADOR_API:'Marcador de API'};
    const keys=c=>(Array.isArray(c?.customData)?c.customData:[]).map(x=>String(x?.key??'').trim().toUpperCase());
    const kindOf=c=>{if(!c)return null;const cls=c.lucidchartType;
      if(cls==='BPMNGateway')return GATE[keys(c).find(k=>GATE[k])]??'Compuerta';
      if(cls==='BPMNEvent')return EVT[c.eventSubtype]??EVT[keys(c).find(k=>EVT[k])]??'Evento';
      if(cls==='BPMNActivity')return c.commandType?CMD[c.commandType]:c.modelKind?MODEL[c.modelKind]:c.architecturalType==='MODELO'?'Modelo':CMD[keys(c).find(k=>CMD[k])]??'Actividad';
      if(cls==='BPMNTextAnnotation')return 'Anotación';
      return ARCH[c.architecturalType]??c.lucidchartType??'Figura';};
    const label=id=>id?{id,name:comps.get(id)?.name||null,kind:kindOf(comps.get(id))}:null,loose=[];
    for(const l of page.connections??[]){
      const a=l.endpoint1??{},b=l.endpoint2??{};
      if(isAnnotation(a.connectedTo)||isAnnotation(b.connectedTo))continue;
      if(a.connectedTo&&b.connectedTo)continue;
      if(a.style==='None'&&b.style==='None')continue;
      const looseEnd=!a.connectedTo?'origen':'destino';
      loose.push({id:l.id,looseEnd,styles:[a.style??null,b.style??null],other:label(looseEnd==='origen'?b.connectedTo:a.connectedTo)});
    }
    return{pageTitle:page.page?.title||'(sin nombre)',loose,notAllowed:[]};
  }).filter(x=>x.loose.length);
}
