import { normalizeDocument, ioModelKey, customDataEntries } from './lucidchart.js';
import { eventLabelSubtype } from './roles.js';
import { buildInventory } from './inventory.js';
import { reconstructContainment } from './containment.js';
import { reconstructConnections } from './connections.js';
import { deriveDeploymentAssociations, deriveFederatedAssociations } from './deployment.js';
import { classifyShape, isIntegrationEvent, isPartialIntegrationEvent, hasServiceNamingBasis } from './classifier.js';
import { VERSION, COPILOT_CONTRACT, DIAGNOSTIC_CONTRACT } from './version.js';
import { connectionOrientation, deriveArchitecturalRoleCandidates, identifyStructuralScenario } from './roles.js';
import { classifyPage } from './page-classifier.js';
import { reconstructGroups } from './groups.js';
import { resolveDomainRolesFromStructure } from './roles.js';

const diagnosticByCopilot=new WeakMap();
// 0.8.3: el nombre es el primer texto no vacío entre Title, Text y FloatingTitle (en el hijo, FloatingTitle suele estar vacío y el nombre va en Text).
const NAME_LABELS=['Title','Text','FloatingTitle'];
const cleanName=shape=>{const areas=(shape?.textAreas??[]).filter(x=>NAME_LABELS.includes(x.label));return(areas.find(x=>String(x.text??'').trim())??areas[0])?.text??((shape?.textAreas??[]).map(x=>x.text??'').filter(Boolean).join(' | ')||null);};
const placeholder=/^\s*(?:\[.*\]|NOMBRE|PENDIENTE|PLACEHOLDER)\s*$/i;
// 0.8.0: la leyenda/notación y los bloques de descripción de API (Descripción Operación, Método, Path, Seguridad) nunca se exportan.
const DESCRIPTION_TEXT=/Descripci[oó]n Operaci[oó]n/i;
const hiddenShapeIds=full=>{const legend=new Set(full.pageClassification?.legendShapeIds??[]);return new Set(full.evidence.shapes.filter(s=>legend.has(s.id)||(s.class!=='UMLClassBlock'&&(s.textAreas??[]).some(a=>DESCRIPTION_TEXT.test(String(a?.text??''))))).map(s=>s.id));};
const isBlank=shape=>!(shape?.textAreas??[]).some(x=>String(x?.text??'').trim());
// Marcador de API: BPMNEvent de texto vacío, sin líneas, en el mismo grupo que el bloque UML (o en el grupo padre de su subgrupo).
function detectApiMarkers(shapes,groups,connections){
  const byId=new Map(shapes.map(x=>[x.id,x])),linked=new Set(connections.flatMap(x=>[x.originId,x.destinationId,x.endpoint1?.connectedTo,x.endpoint2?.connectedTo]).filter(Boolean)),markers=new Map();
  for(const group of groups){
    const members=(group.directMemberIds??[]).map(id=>byId.get(id)).filter(Boolean),events=members.filter(x=>x.class==='BPMNEvent'&&isBlank(x)&&!linked.has(x.id)),direct=members.filter(x=>x.class==='UMLClassBlock');
    if(!events.length)continue;
    // Bloque en el mismo grupo que el evento; si no hay ninguno directo, el bloque que cuelga de un subgrupo de ese grupo.
    const blocks=direct.length?direct:(group.relatedComponentIds??[]).map(id=>byId.get(id)).filter(x=>x?.class==='UMLClassBlock');
    if(!blocks.length)continue;
    for(const block of blocks){const entry=markers.get(block.id)??{groupIds:[],eventIds:[],ambiguous:false};entry.groupIds.push(group.id);entry.eventIds.push(...events.map(x=>x.id));if(blocks.length>1)entry.ambiguous=true;markers.set(block.id,entry);}
  }
  return markers;
}
// Reglas de la analista (0.4.8): marcador vacío => API; ms sin marcador => servicio; tipo/clasificación en la tercera sección => evento de integración.
// 0.5.0: declaración explícita en Lucid (customData TIPO=SERVICIO) certifica el servicio sin generalizar por ausencia de marcador.
const declaresService=shape=>customDataEntries(shape).some(x=>/^(TIPO|ARCHITECTURAL_TYPE)$/i.test(String(x.key??'').trim())&&/^SERVICIO$/i.test(String(x.value??'').trim()));
// 0.6.0 (decisiones de la analista): auxiliar con EVC/EPC/LDC como palabra completa; nombres de plantilla y de cola.
const AUX_KEYWORD=/\b(EVC|EPC|LDC)\b/i;
const plain=text=>String(text??'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').trim().toLowerCase();
const isTemplateEventName=title=>plain(title)==='nombre evento';
// Nombres de plantilla: no se cuentan ni se asumen servicio (decisión de la analista).
const isTemplateName=title=>/^nombre (servicio|api|evento)$/.test(plain(title));
const QUEUE_NAME=/\b(colas?|mq|kafka|rabbit(?:mq)?)\b/i;
const hasQueueWord=title=>QUEUE_NAME.test(plain(title));
// Prioridad: evento de integración (tercera sección) > servicio (ms o customData) > API (marcador de grupo, conteo en auxiliar EVC/EPC/LDC, tipo public/private/partner/privada/publica) > servicio por dominio productor. Lo demás queda como candidato (ver candidateFor).
function classifyUmlComponent(classification,marker,shape,ctx={}){
  const naming=classification?.inference?.find(hasServiceNamingBasis)??null,functional=classification?.functionalClassification,integration=isIntegrationEvent(functional),contradictions=[],hits=[];
  if(marker&&marker.ambiguous)contradictions.push('MARKER_GROUP_HAS_MULTIPLE_COMPONENTS');
  else if(marker)hits.push({type:'API',rule:'API_BY_EMPTY_BPMN_EVENT_GROUP'});
  if(naming&&!marker)hits.push({type:'SERVICIO',rule:'SERVICE_BY_MS_NAMING'});
  if(naming&&marker)contradictions.push('MARKER_CONFLICTS_WITH_MS_NAMING');
  const declared=declaresService(shape);
  if(declared&&!naming&&!marker)hits.push({type:'SERVICIO',rule:'SERVICE_BY_CUSTOMDATA'});
  if(declared&&marker)contradictions.push('MARKER_CONFLICTS_WITH_DECLARED_SERVICE');
  if(integration)hits.push({type:'EVENTO_INTEGRACION',rule:'INTEGRATION_EVENT_BY_THIRD_SECTION'});
  const exposure=!!functional?.exposure&&!integration&&!naming&&!declared&&!marker;
  if(exposure)hits.push({type:'API',rule:'API_BY_EXPOSURE_TYPE'});
  const title=classification?.sections?.title,partialEvent=isPartialIntegrationEvent(functional);
  if(!hits.length&&!contradictions.length){
    if(ctx.inEvcAux&&ctx.domainRole!=='PRODUCER'&&!isTemplateName(title)&&!isTemplateEventName(title)&&!partialEvent)hits.push({type:'API',rule:'API_BY_EVC_AUXILIAR'});
    else if(ctx.count&&!partialEvent)hits.push({type:'API',rule:'API_BY_MARKER_COUNT_IN_AUXILIAR'});
    else if(!partialEvent&&!isTemplateEventName(title)&&!hasQueueWord(title)&&ctx.producerParent)hits.push({type:'SERVICIO',rule:'SERVICE_BY_PRODUCER_DOMAIN'});
    else if(!partialEvent&&!isTemplateName(title)&&!hasQueueWord(title)&&ctx.noMarker)hits.push({type:'SERVICIO',rule:'SERVICE_BY_NO_MARKER_IN_SCOPE'});
  }
  if(hits.length>1)contradictions.push('MULTIPLE_CLASSIFICATION_RULES');
  const evidence=[...(marker?[{source:'JSON.items.groups',groupIds:marker.groupIds,eventIds:[...new Set(marker.eventIds)]}]:[]),...(naming?(classification.evidence??[]).filter(x=>x.source===naming.basis):[]),...(declared?[{source:'JSON.customData',key:'TIPO',value:'SERVICIO'}]:[]),...(integration?(classification.evidence??[]).filter(x=>x.source==='textAreas.Text2'):[]),...(exposure?[{source:'textAreas.Text2',value:classification.sections?.thirdSection??null}]:[]),...(hits[0]?.rule==='API_BY_MARKER_COUNT_IN_AUXILIAR'?[{source:'JSON.contains',auxiliarOrLayerId:ctx.count.scopeId,eventIds:ctx.count.eventIds}]:[]),...(hits[0]?.rule==='SERVICE_BY_NO_MARKER_IN_SCOPE'?[{source:'JSON.contains',apiMarkersInScope:0}]:[]),...(hits[0]?.rule==='SERVICE_BY_PRODUCER_DOMAIN'?[{source:'JSON.contains',domainRole:'PRODUCER',outsideChild:true}]:[])];
  if(contradictions.length)return{type:null,rule:null,status:'AMBIGUOUS',evidence,contradictions};
  if(hits.length===1)return{type:hits[0].type,rule:hits[0].rule,status:hits[0].rule==='SERVICE_BY_MS_NAMING'?'INFERRED_BY_APPROVED_NAMING_CONVENTION':hits[0].rule==='SERVICE_BY_CUSTOMDATA'?'DECLARED_BY_CUSTOMDATA':'INFERRED_BY_ANALYST_RULE',evidence,contradictions:[]};
  return null;
}
const NON_QUEUE_CLASSES=new Set(['BPMNActivity','BPMNGateway','BPMNEvent','BPMNGroup','BPMNTextAnnotation','RectangleContainerBlock','UMLActiveClassBlock']);
// Candidato no certificado: tipo nulo y possibleTypes con las alternativas. Dentro del hijo no se admiten APIs, servicios, eventos ni colas, por eso no hay candidato.
function candidateFor(shape,classification,ctx){
  if(ctx.inHijo)return null;
  const title=classification?.sections?.title??cleanName(shape);
  if(!NON_QUEUE_CLASSES.has(shape.class)&&hasQueueWord(title))return{possibleTypes:['GESTOR_COLAS'],basis:'QUEUE_WORD_IN_NAME',evidence:[{source:'textAreas.Title',value:title}]};
  if(shape.class!=='UMLClassBlock')return null;
  if(isTemplateEventName(title))return{possibleTypes:['EVENTO_INTEGRACION'],basis:'TEMPLATE_NAME_NOMBRE_EVENTO',evidence:[{source:'textAreas.Title',value:title}]};
  if(isPartialIntegrationEvent(classification?.functionalClassification))return{possibleTypes:['EVENTO_INTEGRACION'],basis:'THIRD_SECTION_EVENT_INCOMPLETE',evidence:[{source:'textAreas.Text2',value:classification?.sections?.thirdSection??null}]};
  if(ctx.producerParent)return null;
  const third=classification?.sections?.thirdSection??null;
  if(classification?.functionalClassification?.serviceModel)return{possibleTypes:['API','SERVICIO'],basis:'THIRD_SECTION_ENTIDAD_UTILIDAD_TAREA',evidence:[{source:'textAreas.Text2',value:third}]};
  return{possibleTypes:['API','SERVICIO'],basis:ctx.inEvcAux?'EVC_EPC_LDC_AUXILIAR_WITHOUT_MARKER_MATCH':'UNCLASSIFIED_OUTSIDE_PRODUCER',evidence:[{source:'JSON.contains',domainRole:ctx.domainRole??null,inEvcAuxiliar:!!ctx.inEvcAux}]};
}
function architecturalType(shape,classification,role,umlRule,containerType){
  if(role?.status==='INFERRED'&&role.inferredArchitecturalType)return role.inferredArchitecturalType==='service'?'SERVICIO':'API';
  if(role?.status==='AMBIGUOUS')return null;
  if(shape.class==='UMLActiveClassBlock')return'GESTOR_COLAS';
  if(shape.class==='BPMNEvent')return'EVENTO_BPMN';
  if(shape.class==='BPMNGroup')return shape.asAux?'SISTEMA_EXTERNO_AUXILIAR':null;
  if(containerType!==undefined)return containerType;
  if(umlRule)return umlRule.type;
  const kind=shape.type;
  if(kind==='TRANSACTION_FLOW')return'FLUJO';if(kind==='ARCHITECTURE_LAYER')return'CAPA';if(kind==='FEDERATED_LAYER')return'FEDERADO';
  if(/MODELO/i.test(cleanName(shape)??'')||ioModelKey(shape))return'MODELO';
  return null;
}
// Contenedores (0.4.8): dominio => CONTENEDOR_PADRE; hijo = RectangleContainerBlock más interno con compuertas y actividades; el resto de rectángulos queda sin determinar.
function containerRuleFor(shape,{domainIds,promoted,candidateIds,mainChildId,countClass}){
  if(domainIds.has(shape.id)){const promo=promoted[shape.id];return{type:'CONTENEDOR_PADRE',inference:promo?{status:'INFERRED_BY_ANALYST_RULE',rule:promo.kind==='LOOSE_TEXT_NAME'?'PARENT_BY_LOOSE_TEXT_NAME':'PARENT_BY_WRAPPING_MAIN_CHILD',evidence:[{source:'JSON.contains',kind:promo.kind}],contradictions:[]}:null};}
  if(shape.class!=='RectangleContainerBlock')return null;
  const candidate=candidateIds.includes(shape.id);
  if(!candidate&&shape.id!==mainChildId)return{type:'CONTENEDOR_NO_DETERMINADO',inference:null};
  if(!candidate)return{type:'SERVICIO_HIJO',inference:null};
  const ambiguous=candidateIds.length>1,evidence=[{source:'JSON.contains',gateways:countClass(shape,'BPMNGateway'),activities:countClass(shape,'BPMNActivity')}];
  return{type:'SERVICIO_HIJO',inference:ambiguous?{status:'AMBIGUOUS',rule:'CHILD_BY_GATEWAYS_AND_ACTIVITIES',evidence,contradictions:['MULTIPLE_CHILD_CANDIDATES']}:{status:'INFERRED_BY_ANALYST_RULE',rule:'CHILD_BY_GATEWAYS_AND_ACTIVITIES',evidence,contradictions:[]}};
}
function compactPage(full){
  const structures=new Map(full.architecturalStructure.components.map(x=>[x.id,x])),classes=new Map(full.classifications.map(x=>[x.id,x])),roles=new Map(full.architecturalRoleCandidates.map(x=>[x.componentId,x])),hiddenIds=hiddenShapeIds(full),connections=full.evidence.connections.filter(x=>![x.originId,x.destinationId,x.endpoint1?.connectedTo,x.endpoint2?.connectedTo].some(i=>i&&hiddenIds.has(i)));
  const deployments=full.architecturalStructure.deploymentPairs,federated=full.architecturalStructure.federatedAssociations??[];
  const childInfo=full.architecturalStructure.childAnalysis??{candidateIds:[],promoted:{}},domainIds=new Set(full.architecturalStructure.rootContainers.map(r=>r.id)),shapeById=new Map(full.evidence.shapes.map(x=>[x.id,x])),countClass=(s,cls)=>(s.contains?.shapes??[]).filter(id=>shapeById.get(id)?.class===cls).length;
  const apiMarkers=detectApiMarkers(full.evidence.shapes,full.architecturalStructure.groupStructure.groups,connections),certainMarkerEvents=new Set();
  // 0.6.0: contexto por componente (dominio, hijo, auxiliar EVC/EPC/LDC) y conteo de marcadores por auxiliar, capa o flujo.
  const legendIds=new Set(full.pageClassification?.legendShapeIds??[]),chainOf=id=>structures.get(id)?.containerChainIds??[],inHijoOf=id=>chainOf(id).some(x=>childInfo.candidateIds.includes(x));
  const evcAuxOf=id=>chainOf(id).find(x=>{const g=shapeById.get(x);return g?.class==='BPMNGroup'&&AUX_KEYWORD.test(cleanName(g)??'');})??null;
  const auxOf=id=>[...chainOf(id)].reverse().find(x=>{const g=shapeById.get(x);return g?.class==='BPMNGroup'&&!domainIds.has(x);})??null;
  const countInfo=new Map(),noMarker=new Set(),ctxFor=shape=>{const domainRole=structures.get(shape.id)?.domainRole??null,inHijo=inHijoOf(shape.id);return{domainRole,inHijo,producerParent:domainRole==='PRODUCER'&&!inHijo,inEvcAux:!!evcAuxOf(shape.id),count:countInfo.get(shape.id)??null,noMarker:noMarker.has(shape.id)};};
  {
    const connected=new Set(connections.flatMap(x=>[x.originId,x.destinationId,x.endpoint1?.connectedTo,x.endpoint2?.connectedTo]).filter(Boolean)),scopes=new Map(),groupedMarker=new Set([...apiMarkers.values()].filter(m=>!m.ambiguous).flatMap(m=>m.eventIds));
    for(const shape of full.evidence.shapes){
      if(inHijoOf(shape.id))continue;
      const evc=evcAuxOf(shape.id),domainId=chainOf(shape.id).find(x=>domainIds.has(x))??chainOf(shape.id)[0]??null;
      // 0.7.1: el conteo de marcadores rige en cualquier auxiliar y, en un dominio de INTEGRACIÓN o SISTEMAS EXTERNOS sin auxiliares, en su nivel padre.
      const aux=evc??auxOf(shape.id)??(domainId&&structures.get(shape.id)?.domainRole!=='PRODUCER'?domainId:null);if(!aux)continue;
      const scope=[...chainOf(shape.id)].reverse().find(x=>x===aux||['ARCHITECTURE_LAYER','TRANSACTION_FLOW'].includes(structures.get(x)?.type))??aux,entry=scopes.get(scope)??{events:[],blocks:[],evc:!!evc,domainId};
      if(shape.class==='BPMNEvent'&&isBlank(shape)&&!connected.has(shape.id)&&!customDataEntries(shape).length&&!groupedMarker.has(shape.id))entry.events.push(shape.id);
      else if(shape.class==='UMLClassBlock'){const marker=apiMarkers.get(shape.id),r=classifyUmlComponent(classes.get(shape.id),marker?.ambiguous?undefined:marker,shape,{...ctxFor(shape),inEvcAux:false,count:null,noMarker:false});if(!r&&roles.get(shape.id)?.status!=='INFERRED'&&!isTemplateName(classes.get(shape.id)?.sections?.title??cleanName(shape)))entry.blocks.push(shape.id);}
      scopes.set(scope,entry);
    }
    for(const [scopeId,e] of scopes){if(!e.blocks.length)continue;if(e.events.length===e.blocks.length){e.blocks.forEach(id=>countInfo.set(id,{scopeId,eventIds:e.events}));e.events.forEach(id=>certainMarkerEvents.add(id));}else if(!e.events.length&&!(scopeId===e.domainId&&[...scopes.values()].some(o=>o.domainId===e.domainId&&o.events.length&&!o.blocks.length)))e.blocks.forEach(id=>noMarker.add(id));}
  }
  const components=full.evidence.shapes.filter(shape=>!hiddenIds.has(shape.id)).map(shape=>{
    const structure=structures.get(shape.id),classification=classes.get(shape.id),role=roles.get(shape.id);
    const touching=connections.filter(x=>x.originId===shape.id||x.destinationId===shape.id),componentConnections=touching.map(x=>x.id),orientations=touching.map(x=>connectionOrientation(x.raw??x));
    const incoming=orientations.filter(x=>x.status==='VERIFIED_BY_TERMINATIONS'&&x.destinationId===shape.id),outgoing=orientations.filter(x=>x.status==='VERIFIED_BY_TERMINATIONS'&&x.originId===shape.id);
    const componentDeployments=deployments.filter(x=>x.associatedComponentId===shape.id||x.directAssociations?.some(a=>a.componentId===shape.id)).map(x=>({flowId:x.flow.id,layerId:x.layer.id,status:x.status,source:x.associationSource,evidence:x.evidence,conflicts:x.conflicts??[]})).concat(federated.filter(x=>x.associatedComponentId===shape.id).map(x=>({modality:'FEDERADO',federatedId:x.federatedId,status:x.status,source:x.associationSource,evidence:x.evidence,conflicts:[]})));
    const ctx=ctxFor(shape),marker=apiMarkers.get(shape.id),umlRule=shape.class==='UMLClassBlock'?classifyUmlComponent(classification,ctx.count&&marker?.ambiguous?undefined:marker,shape,ctx):null;
    if(umlRule?.rule==='API_BY_EMPTY_BPMN_EVENT_GROUP')apiMarkers.get(shape.id).eventIds.forEach(id=>certainMarkerEvents.add(id));
    const containerRule=containerRuleFor(shape,{domainIds,promoted:childInfo.promoted,candidateIds:childInfo.candidateIds,mainChildId:full.structuralScenario.mainChildServiceId,countClass});
    let type=architecturalType({...shape,type:structure?.type,asAux:shape.class==='BPMNGroup'&&(!!(cleanName(shape)?.trim())&&!placeholder.test(cleanName(shape).trim())||chainOf(shape.id).length>0)},classification,role,umlRule,containerRule?containerRule.type:undefined);
    if(type===null&&shape.class==='BPMNGateway'&&!legendIds.has(shape.id))type='COMPUERTA';
    const cand=type===null&&!umlRule&&!legendIds.has(shape.id)&&role?.status!=='AMBIGUOUS'?candidateFor(shape,classification,ctx):null;
    const ROLE_TYPES=['API','SERVICIO','EVENTO_INTEGRACION','GESTOR_COLAS'],architecturalRole=role?.status==='INFERRED'&&(role.roleCandidate==='mainApi'||role.roleCandidate==='mainService')?'PRINCIPAL':role?.status==='AMBIGUOUS'?null:ROLE_TYPES.includes(type)||(cand&&cand.possibleTypes.some(t=>ROLE_TYPES.includes(t)))||(type==='SERVICIO_HIJO'&&full.structuralScenario.mainChildServiceId===shape.id)?'INVOCADO':null;
    const result={id:shape.id,name:cleanName(shape),architecturalType:type,lucidchartType:shape.class??null,role:architecturalRole,operation:/ContainerBlock$/.test(shape.class??'')?null:classification?.sections?.operation??null,textAreas:structuredClone(shape.textAreas??[]),structuralParent:structuredClone(structure?.structuralParent??null),containerChainIds:structure?.containerChainIds??[],rootContainer:structuredClone(structure?.rootContainer??null),architecturalDomain:structuredClone(structure?.architecturalDomain??null),domainRole:structure?.domainRole??null,possibleDomainRoles:structure?.domainRole?[]:(structure?.possibleDomainRoles??[]),connections:componentConnections,deploymentAssociations:componentDeployments,inference:role?{status:role.status,evidence:[{source:'JSON.line.endpoints',id:role.connection.id},{source:'JSON.contains',containerChainIds:role.destinationContainerChainIds},...(umlRule?.rule==='API_BY_EMPTY_BPMN_EVENT_GROUP'?umlRule.evidence.filter(e=>e.source==='JSON.items.groups'):[])],contradictions:role.contradictions}:umlRule?{status:umlRule.status,rule:umlRule.rule,evidence:umlRule.evidence,contradictions:umlRule.contradictions}:containerRule?.inference?containerRule.inference:type==='MODELO'&&ioModelKey(shape)?{status:'INFERRED_BY_ANALYST_RULE',rule:'MODEL_BY_CUSTOMDATA_IO',evidence:[{source:'JSON.customData',key:ioModelKey(shape)}],contradictions:[]}:cand?{status:'CANDIDATE_NOT_CERTIFIED',basis:cand.basis,evidence:cand.evidence,contradictions:[]}:classification?.inference?.length?(type!==null?{status:'INFERRED_BY_APPROVED_NAMING_CONVENTION',evidence:classification.evidence.filter(x=>x.source==='title-prefix'||x.source==='title-suffix'||x.source==='title-keyword'),contradictions:[]}:null):null,containedComponentIds:shape.class==='BPMNGroup'?[...(shape.contains?.shapes??[])]:undefined,...(cand?{possibleTypes:cand.possibleTypes}:{})};
    if(Object.hasOwn(shape,'customData'))result.customData=structuredClone(shape.customData);
    return result;
  });
  const figureGroupOf=new Map();
  // 0.10.0: figura de la biblioteca nueva (etiqueta del grupo raíz: THIRD_PARTY_API, OWN_PRIVATE_API_MCI, ...). Cada componente de un grupo raíz etiquetado recibe `figuraBiblioteca`; manda el grupo más externo.
  {
    const LIB_FIGURES=new Set(['OWN_EXTERNAL_API_MCI','OWN_PRIVATE_API_MCI','OTHER_DOMAIN_API_MCI','OTHER_DOMAIN_API_FED','THIRD_PARTY_API','SERVICE_MCI','OWN_MG_SERVICE_MCI','OWN_MG_SERVICE_FED','OWN_MG_MQ_SERVICE_FED','OWN_MG_MQ_SERVICE_MCI','OWN_UMG_SERVICE','OWN_UMG_MQ_SERVICE','OTHER_DOMAIN_SERVICE','THIRD_PARTY_SERVICE','THIRD_PARTY_MQ_SERVICE','REPLY_EVENT_MCI','EXT_REPLY_EVENT_MCI','EXT_NON_REPLY_EVENT_MCI','NON_REPLY_EVENT_MCI','QUEUE_MANAGER_FED','QUEUE_MANAGER_MCI']);
    const groups=full.architecturalStructure.groupStructure.groups,byGroup=new Map(groups.map(g=>[g.id,g])),figureOf=new Map();
    for(const g of groups.filter(x=>(x.labels??[]).some(l=>LIB_FIGURES.has(l))).sort((x,y)=>(x.ancestorGroupIds??[]).length-(y.ancestorGroupIds??[]).length)){
      const label=g.labels.find(l=>LIB_FIGURES.has(l)),stack=[g.id],seen=new Set();
      while(stack.length){const id=stack.pop();if(seen.has(id))continue;seen.add(id);for(const m of byGroup.get(id)?.directMemberIds??[]){if(byGroup.has(m))stack.push(m);else if(!figureOf.has(m)){figureOf.set(m,label);figureGroupOf.set(m,g.id);}}}
    }
    for(const c of components)if(figureOf.has(c.id))c.figuraBiblioteca=figureOf.get(c.id);
  }
  // 0.10.0: política, excepción y concepto se clasifican como modelos (MODELO) por la etiqueta de la figura (BUSINESS_RULE, BUSINESS_EXCEPTION, BUSINESS_CONCEPT), aunque su figura sea una BPMNActivity. Los modelos de entrada y salida siguen como hasta ahora (ENTRADA, SALIDA).
  {
    const MODEL_LABELS=new Map([['BUSINESS_RULE','POLITICA'],['BUSINESS_EXCEPTION','EXCEPCION'],['BUSINESS_CONCEPT','CONCEPTO']]);
    for(const c of components){
      if(c.lucidchartType==='BPMNEvent'){const sub=eventLabelSubtype(c);if(sub)c.eventSubtype=sub;continue;}
      if(c.lucidchartType!=='BPMNActivity'||c.architecturalType!==null)continue;
      const kinds=[...new Set(customDataEntries(c).map(x=>String(x.key??'').trim().toUpperCase()).filter(k=>MODEL_LABELS.has(k)))];
      if(kinds.length!==1)continue;
      c.architecturalType='MODELO';c.modelKind=MODEL_LABELS.get(kinds[0]);c.inference={status:'DECLARED_BY_CUSTOMDATA',rule:'MODEL_BY_CUSTOMDATA',evidence:[{source:'JSON.customData',key:kinds[0]}],contradictions:[]};
    }
  }
  // 0.10.0: COMANDO por etiqueta de la figura (customData SERVICE_TASK, SYSTEM_TASK, SUB_PROCESS o USER_TASK, de la biblioteca nueva). Certifica el comando y su subtipo sin depender de las conexiones. Una sola etiqueta; con dos o más etiquetas de comando se deja al criterio por conexión.
  {
    const COMMAND_LABELS=new Set(['SERVICE_TASK','SYSTEM_TASK','SUB_PROCESS','USER_TASK']);
    for(const c of components){
      if(c.lucidchartType!=='BPMNActivity'||c.architecturalType!==null)continue;
      const keys=[...new Set(customDataEntries(c).map(x=>String(x.key??'').trim().toUpperCase()).filter(k=>COMMAND_LABELS.has(k)))];
      if(keys.length!==1)continue;
      c.architecturalType='COMANDO';c.commandType=keys[0];c.inference={status:'DECLARED_BY_CUSTOMDATA',rule:'COMMAND_BY_CUSTOMDATA',evidence:[{source:'JSON.customData',key:keys[0]}],contradictions:[]};
    }
  }
  // 0.6.0: COMANDO = BPMNActivity con una conexión a una API, un servicio, un gestor de colas o un auxiliar (o a un candidato a API, servicio o gestor). Una actividad sin esa conexión queda sin tipo.
  {
    const byId=new Map(components.map(c=>[c.id,c])),certain=new Set(['API','SERVICIO','GESTOR_COLAS','SISTEMA_EXTERNO_AUXILIAR']),candidateOk=c=>c.architecturalType===null&&c.possibleTypes?.length&&c.possibleTypes.every(t=>['API','SERVICIO','GESTOR_COLAS'].includes(t));
    for(const c of components){
      if(c.lucidchartType!=='BPMNActivity'||c.architecturalType!==null)continue;
      const links=connections.map(x=>({id:x.id,other:byId.get([x.endpoint1?.connectedTo,x.endpoint2?.connectedTo].find(i=>i&&i!==c.id)),self:[x.endpoint1?.connectedTo,x.endpoint2?.connectedTo].includes(c.id)})).filter(x=>x.self&&x.other&&(certain.has(x.other.architecturalType)||candidateOk(x.other)));
      if(!links.length)continue;
      c.architecturalType='COMANDO';c.inference={status:'INFERRED_BY_ANALYST_RULE',rule:'COMMAND_BY_CONNECTION',evidence:[{source:'JSON.line.endpoints',connectionIds:links.map(x=>x.id),targetIds:links.map(x=>x.other.id)}],contradictions:[]};
    }
  }
  // 0.8.1: Capa de Tópicos = contenedor UML (que no es dominio, flujo, capa de arquitectura ni Federado) que contiene directamente un evento de integración certificado. Con solo un candidato a evento dentro, es candidata.
  {
    const byId=new Map(components.map(c=>[c.id,c]));
    for(const c of components){
      if(c.lucidchartType!=='UMLRectangleContainerBlock'||c.architecturalType!==null||domainIds.has(c.id))continue;
      const inside=(shapeById.get(c.id)?.contains?.shapes??[]).map(id=>byId.get(id)).filter(Boolean),events=inside.filter(x=>x.architecturalType==='EVENTO_INTEGRACION'),candidates=inside.filter(x=>x.architecturalType===null&&x.possibleTypes?.includes('EVENTO_INTEGRACION'));
      if(!events.length&&customDataEntries(shapeById.get(c.id)).some(k=>String(k.key??'').trim().toUpperCase()==='TOPIC_LAYER')){c.architecturalType='CAPA_TOPICOS';c.inference={status:'DECLARED_BY_CUSTOMDATA',rule:'TOPIC_LAYER_BY_CUSTOMDATA',evidence:[{source:'JSON.customData',key:'TOPIC_LAYER'}],contradictions:[]};}
      else if(events.length){c.architecturalType='CAPA_TOPICOS';c.inference={status:'INFERRED_BY_ANALYST_RULE',rule:'TOPIC_LAYER_BY_CONTAINED_INTEGRATION_EVENT',evidence:[{source:'JSON.contains',eventIds:events.map(x=>x.id)}],contradictions:[]};}
      else if(candidates.length){c.possibleTypes=['CAPA_TOPICOS'];c.inference={status:'CANDIDATE_NOT_CERTIFIED',basis:'CONTAINS_EVENT_CANDIDATE',evidence:[{source:'JSON.contains',eventIds:candidates.map(x=>x.id)}],contradictions:[]};}
    }
  }
  // 0.4.8: DefaultSquareBlock sin líneas, contenido, contenedor ni asociaciones (despliegue, modelos, escenario) no se entrega en el JSON compacto.
  const referenced=JSON.stringify([deployments,full.structuralScenario]),rawContains=new Map(full.evidence.shapes.map(x=>[x.id,(x.contains?.shapes??[]).length]));
  const unrelated=new Set(components.filter(c=>c.lucidchartType==='DefaultSquareBlock'&&!c.connections.length&&!c.deploymentAssociations.length&&!c.structuralParent?.id&&!c.containerChainIds.length&&!rawContains.get(c.id)&&!(Array.isArray(c.customData)?c.customData.length:c.customData!=null)&&!referenced.includes(`"${c.id}"`)&&!components.some(o=>o.id!==c.id&&(o.structuralParent?.id===c.id||o.containerChainIds.includes(c.id)||(o.containedComponentIds??[]).includes(c.id)))).map(c=>c.id));
  const strictlyReferenced=JSON.stringify([deployments.map(x=>[x.associatedComponentId,x.modelIds,(x.directAssociations??[]).map(a=>a.componentId)]),full.structuralScenario]);
  // 0.4.8: el BPMN Event vacío que es marcador cierto de una API (la API quedó clasificada por él) no se registra como figura aparte.
  const inUse=id=>components.some(o=>o.id!==id&&(o.structuralParent?.id===id||o.containerChainIds.includes(id))),markerEvents=components.filter(c=>c.lucidchartType==='BPMNEvent'&&certainMarkerEvents.has(c.id)&&!c.connections.length&&!strictlyReferenced.includes(`"${c.id}"`)&&!rawContains.get(c.id)&&!(Array.isArray(c.customData)?c.customData.length:c.customData!=null)&&!inUse(c.id)).map(c=>c.id);
  // 0.5.0 (decisión de la analista): un BPMN Event vacío, sin líneas, sin customData, sin grupo y sin contenido, ubicado en el nivel padre de INTEGRACIÓN o de SISTEMAS EXTERNOS (nunca dentro del hijo principal ni de un grupo BPMN), se clasifica como MARCADOR_API aunque no comparta grupo con el bloque UML. Sigue en el inventario (la analista quiere que el agente lo vea y lo permita en las reglas de contenido), a diferencia del marcador agrupado, que se omite.
  const groupedIds=new Set(full.architecturalStructure.groupStructure.groups.flatMap(g=>[...g.directMemberIds,...g.relatedComponentIds])),mainChildId=full.structuralScenario.mainChildServiceId,
    orphanMarkerEvents=components.filter(c=>c.lucidchartType==='BPMNEvent'&&!markerEvents.includes(c.id)&&(['INTEGRATION','EXTERNAL_SYSTEM'].includes(c.domainRole)&&c.architecturalDomain?.status==='RESOLVED'||c.containerChainIds.some(id=>shapeById.get(id)?.class==='BPMNGroup'))&&!(mainChildId&&c.containerChainIds.includes(mainChildId))&&!(c.textAreas??[]).some(x=>String(x?.text??'').trim())&&!c.connections.length&&!strictlyReferenced.includes(`"${c.id}"`)&&!rawContains.get(c.id)&&!(Array.isArray(c.customData)?c.customData.length:c.customData!=null)&&!inUse(c.id)).map(c=>c.id);
  const orphanSet=new Set(orphanMarkerEvents);
  for(const c of components)if(orphanSet.has(c.id)){c.architecturalType='MARCADOR_API';c.inference={status:'INFERRED_BY_ANALYST_RULE',rule:'API_MARKER_BY_ORPHAN_EMPTY_EVENT',evidence:[{source:'JSON.items.shapes',id:c.id,conditions:['EMPTY_TEXT','NO_CONNECTIONS','NO_CUSTOMDATA','NO_GROUP','NO_CONTENT','OUTSIDE_MAIN_CHILD']}],contradictions:[]};}
  const omitted=new Set([...unrelated,...markerEvents]),dropped=new Set([...omitted,...hiddenIds]),pruneEvidence=evidence=>evidence?.map(e=>Array.isArray(e?.candidateIds)?{...e,candidateIds:e.candidateIds.filter(id=>!dropped.has(id)&&!orphanSet.has(id))}:e),kept=components.filter(c=>!dropped.has(c.id)).map(c=>{const out=c.deploymentAssociations.length?{...c,deploymentAssociations:c.deploymentAssociations.map(d=>({...d,evidence:pruneEvidence(d.evidence)}))}:c;return Array.isArray(out.containedComponentIds)&&out.containedComponentIds.some(id=>dropped.has(id))?{...out,containedComponentIds:out.containedComponentIds.filter(id=>!dropped.has(id))}:out;}),prunedGroups=full.architecturalStructure.groupStructure.groups.map(g=>({...g,directMemberIds:g.directMemberIds.filter(id=>!dropped.has(id)),relatedComponentIds:g.relatedComponentIds.filter(id=>!dropped.has(id)),_h:[...g.directMemberIds,...g.relatedComponentIds].some(id=>hiddenIds.has(id))})).filter(g=>!hiddenIds.has(g.id)&&!(g._h&&!g.directMemberIds.length&&!g.relatedComponentIds.length)).map(({_h,...g})=>({...g,...(Array.isArray(g.childGroupIds)?{childGroupIds:g.childGroupIds.filter(id=>!hiddenIds.has(id))}:{})}));
  const brief=c=>({id:c.id,name:c.name,...(c.figuraBiblioteca?{figura:c.figuraBiblioteca}:{})}),by=t=>kept.filter(c=>c.architecturalType===t).map(brief),
    // 0.10.0: servicio consumido por colas = figura de la biblioteca con MQ en su etiqueta (OWN_MG_MQ_SERVICE_*, OWN_UMG_MQ_SERVICE, THIRD_PARTY_MQ_SERVICE). Su Capa de Tópicos es el contenedor con la etiqueta TOPIC_LAYER que lo contiene; sus tópicos son su texto, uno por palabra. Solo hechos.
    compById=new Map(components.map(c=>[c.id,c])),
    // 0.10.1: la Capa de Tópicos de un servicio con MQ en la figura se reconoce (1) por contención, o (2) por el grupo de la figura (cualquier etiqueta con MQ: OWN_UMG_MQ_SERVICE, THIRD_PARTY_MQ_SERVICE, ...), que agrupa la capa TOPIC_LAYER, el grupo SERVICE y, si existe, el auxiliar. Varias capas de tópicos en el mismo grupo: ambiguo (capaTopicos null + capasTopicosCandidatas).
    isTopicLayer=o=>o&&o.lucidchartType==='UMLRectangleContainerBlock'&&customDataEntries(o).some(k=>String(k.key??'').trim().toUpperCase()==='TOPIC_LAYER'),
    layerInfo=layer=>({id:layer.id,name:layer.name,topicos:(layer.textAreas??[]).flatMap(t=>String(t?.text??'').split(/\s+/)).filter(Boolean)}),
    groupById=new Map(full.architecturalStructure.groupStructure.groups.map(g=>[g.id,g])),
    mqInfo=c=>{
      if(!/(^|_)MQ_/.test(c.figuraBiblioteca??''))return{};
      const byContainment=[...(c.containerChainIds??[])].reverse().map(id=>compById.get(id)).find(isTopicLayer);
      if(byContainment)return{consumidoPorColas:true,capaTopicos:layerInfo(byContainment)};
      const g=groupById.get(figureGroupOf.get(c.id)),layers=(g?.relatedComponentIds??[]).map(id=>compById.get(id)).filter(isTopicLayer);
      if(layers.length===1)return{consumidoPorColas:true,capaTopicos:{...layerInfo(layers[0]),asociadaPor:'GRUPO'}};
      return{consumidoPorColas:true,capaTopicos:null,...(layers.length>1?{capasTopicosCandidatas:layers.map(l=>({id:l.id,name:l.name}))}:{})};
    },
    inventory={apis:by('API'),servicios:kept.filter(c=>c.architecturalType==='SERVICIO').map(c=>({...brief(c),...mqInfo(c)})),eventosIntegracion:by('EVENTO_INTEGRACION'),gestoresCola:by('GESTOR_COLAS'),comandos:kept.filter(c=>c.architecturalType==='COMANDO').map(c=>({...brief(c),...(c.commandType?{tipoComando:c.commandType}:{})})),serviciosHijo:by('SERVICIO_HIJO'),sistemasExternosAuxiliares:by('SISTEMA_EXTERNO_AUXILIAR'),marcadoresApi:by('MARCADOR_API'),candidatos:kept.filter(c=>c.architecturalType===null&&c.possibleTypes?.length).map(c=>({...brief(c),possibleTypes:c.possibleTypes}))};
  // 0.7.0: inventario completo (contenedores, relaciones, modelos, omitidos) y asociación de modelos por conteo; solo hechos, sin reglas.
  const extra=buildInventory({components:kept,connections,groups:prunedGroups,legendIds,base:inventory,omitted:[...unrelated].map(id=>({id,motivo:'NO_CONNECTIONS_CONTAINMENT_OR_ASSOCIATIONS'})).concat(markerEvents.map(id=>({id,motivo:'API_MARKER_EVENT'})))});
  for(const c of kept){const m=extra.modelAssociation.get(c.id);if(m&&Object.keys(m).length)c.modelAssociation=m;}
  return{page:full.page,counts:full.counts,pageClassification:(({legendShapeIds,...rest})=>rest)(full.pageClassification),scenario:full.structuralScenario,inventory:{...inventory,...extra.inventory},components:kept,connections:connections.map(x=>({id:x.id,endpoint1:x.endpoint1,endpoint2:x.endpoint2,textAreas:x.textAreas,customData:x.customData,status:x.status})),groups:prunedGroups,deploymentAssociations:deployments.map(x=>{const markerIds=[...new Set((x.evidence??[]).flatMap(e=>Array.isArray(e?.candidateIds)?e.candidateIds:[]).filter(id=>orphanSet.has(id)))];return{flowId:x.flow.id,layerId:x.layer.id,associatedComponentId:x.associatedComponentId,status:x.status,source:x.associationSource,superiorGroupId:x.superiorGroupId,modelIds:x.modelIds,evidence:pruneEvidence(x.evidence),...(markerIds.length?{markerIds}:{})};}).concat(federated.map(x=>({modality:'FEDERADO',federatedId:x.federatedId,associatedComponentId:x.associatedComponentId,status:x.status,source:x.associationSource,candidateIds:x.candidateIds,evidence:pruneEvidence(x.evidence)}))),issues:full.architecturalStructure.issues,...(omitted.size?{omittedComponents:[...(unrelated.size?[{lucidchartType:'DefaultSquareBlock',count:unrelated.size,reason:'NO_CONNECTIONS_CONTAINMENT_OR_ASSOCIATIONS'}]:[]),...(markerEvents.length?[{lucidchartType:'BPMNEvent',count:markerEvents.length,reason:'API_MARKER_EVENT'}]:[])]}:{})};
}

export function analyzeBlueprint(input, options = {}) {
  const document = normalizeDocument(input, options.sourceName);
  const pages = document.pages.map(page => {
    const containment = reconstructContainment(page);
    const classifications=page.shapes.map(shape => ({ id: shape.id, ...classifyShape(shape) }));
    const connectionData = reconstructConnections(page, containment, classifications);
    const groupStructure=reconstructGroups(page);
    const domainResolution=resolveDomainRolesFromStructure(page,containment,connectionData.connections);
    const pageClassification=classifyPage(page,containment,connectionData.connections);
    const architecturalRoleCandidates=deriveArchitecturalRoleCandidates(page,containment,classifications,connectionData.connections,pageClassification);
    const structuralScenario=identifyStructuralScenario(page,architecturalRoleCandidates,pageClassification);
    if(domainResolution.status==='CONFLICTING_MULTIPLE_PRODUCERS'&&!structuralScenario.conflicts.includes(domainResolution.status))structuralScenario.conflicts.push(domainResolution.status);
    // 0.4.8 (E3) y 0.4.9 (E1): con el productor identificado (el dominio del hijo), los demás dominios sin nombre literal y sin hijo se toman como sistemas externos por descarte.
    if(['E1','E3'].includes(structuralScenario.scenario)&&['HIPOTESIS','CONFIRMADO'].includes(structuralScenario.status)&&structuralScenario.sourceRootDomainId){
      const elimination=`${structuralScenario.scenario}_ELIMINATION`,mark=x=>{x.roleSource=elimination;x.roleStatus='INFERRED_BY_ELIMINATION';};
      for(const r of containment.rootContainers.filter(r=>r.id!==structuralScenario.sourceRootDomainId&&!r.role&&r.id!==containment.components.find(c=>c.id===structuralScenario.mainChildServiceId)?.architecturalDomainId)){
        r.domainRole=r.role='EXTERNAL_SYSTEM';mark(r);r.architecturalDomain.roleSource=elimination;r.architecturalDomain.status='INFERRED_BY_ELIMINATION';
        for(const c of containment.components)if(c.architecturalDomainId===r.id&&c.domainRole==null){c.domainRole=c.explicitDomainRole='EXTERNAL_SYSTEM';c.possibleDomainRoles=[];c.rootRoleSource=c.evidenceSources.domainRole=elimination;c.rootRoleStatus=c.architecturalDomain.status='INFERRED_BY_ELIMINATION';c.architecturalDomain.roleSource=elimination;}
      }
      // Contenedores raíz sin nombre ni texto de dominio (ni hijo, ni API principal, ni notación o leyenda): también son sistemas externos por descarte.
      const childRoot=containment.components.find(c=>c.id===structuralScenario.mainChildServiceId)?.rootContainer?.id,legend=new Set(pageClassification.legendShapeIds??[]),notation=new Set(containment.notationIds??[]);
      const unnamed=new Set(containment.structuralRootIds.filter(id=>{const s=containment.byId.get(id);return s?.class==='RectangleContainerBlock'&&id!==childRoot&&id!==structuralScenario.sourceRootDomainId&&!legend.has(id)&&!notation.has(id)&&containment.components.some(c=>c.rootContainer?.id===id&&c.id!==id)&&!containment.components.some(c=>c.rootContainer?.id===id&&(c.domainRole!=null||c.architecturalDomain?.id));}));
      for(const c of containment.components)if(unnamed.has(c.rootContainer?.id)&&c.domainRole==null&&c.rootContainer.status==='RESOLVED'){const root=containment.byId.get(c.rootContainer.id);c.domainRole=c.explicitDomainRole='EXTERNAL_SYSTEM';c.possibleDomainRoles=[];c.rootRoleSource=c.evidenceSources.domainRole=elimination;c.rootRoleStatus='INFERRED_BY_ELIMINATION';c.architecturalDomain={id:root.id,name:'',lucidchartClass:root.class,source:'JSON.contains+architectural-container',roleSource:elimination,status:'INFERRED_BY_ELIMINATION',conflicts:[]};c.architecturalDomainId=root.id;}
    }
    return {
      page: { id: page.id, title: page.title, index: page.index },
      counts: { shapes: page.shapes.length, connections: page.lines.length, groups: page.groups.length },
      classifications,
      pageClassification,
      domainResolution,
      architecturalRoleCandidates,
      structuralScenario,
      architecturalStructure: {
        structuralRootIds: containment.structuralRootIds,
        rootContainers: containment.rootContainers,
        components: containment.components,
        relations: containment.relations,
        childContainers: containment.components.filter(x => x.type === 'CHILD_CONTAINER'),
        childAnalysis: containment.childAnalysis,
        groupStructure:{groups:groupStructure.groups,componentMemberships:groupStructure.componentMemberships,relations:groupStructure.relations,issues:groupStructure.issues},
        deploymentPairs: deriveDeploymentAssociations(page, containment,groupStructure),
        federatedAssociations: deriveFederatedAssociations(page, containment),
        principalInteractionPaths: connectionData.principalInteractionPaths,
        issues: [...containment.issues, ...containment.missingReferences]
      },
      evidence: {
        shapes: structuredClone(page.shapes), lines: structuredClone(page.lines),
        groups: structuredClone(page.groups), layers: structuredClone(page.layers), connections: connectionData.connections
      }
    };
  });
  return { tool: 'Blueprint Evidence Studio', contract: DIAGNOSTIC_CONTRACT, version: VERSION, nonNormative: true, metadata: { sourceName: options.sourceName ?? null, blueprintId:options.blueprintId??null, blueprintName:options.blueprintName??null, normalizedBlueprintName:options.normalizedBlueprintName??null, selectedPageIds:options.selectedPageIds??document.pages.map(x=>x.id), omittedPages:document.pages.filter(x=>options.selectedPageIds&&!options.selectedPageIds.includes(x.id)).map(x=>({id:x.id,title:x.title,reason:'NOT_SELECTED_BY_ANALYST'})), pageCount: pages.length }, pages };
}

export function copilotExport(model,options={}){
  const selected=options.selectedPageIds??model.metadata.selectedPageIds??model.pages.map(x=>x.page.id),selectedSet=new Set(selected),pages=model.pages.filter(x=>selectedSet.has(x.page.id)).map(compactPage),omitted=model.pages.filter(x=>!selectedSet.has(x.page.id)).map(x=>({id:x.page.id,title:x.page.title,reason:'NOT_SELECTED_BY_ANALYST'}));
  const compact={tool:model.tool,contract:COPILOT_CONTRACT,version:model.version,nonNormative:true,metadata:{...model.metadata,selectedPageIds:selected,omittedPages:omitted,pageCount:pages.length},pages};diagnosticByCopilot.set(compact,model);return compact;
}

export function diagnosticExport(value) {
  const model=diagnosticByCopilot.get(value)??value;
  return { ...structuredClone(model), contract: DIAGNOSTIC_CONTRACT, diagnostics: { generatedAt: new Date().toISOString(), selectedPageIds:value?.metadata?.selectedPageIds??model.metadata.selectedPageIds, unresolvedCount: model.pages.reduce((n, p) => n + p.architecturalStructure.issues.length, 0) } };
}
