import { shapeKind, customDataEntries } from './lucidchart.js';
import { isIntegrationEvent, isPartialIntegrationEvent, hasServiceNamingBasis } from './classifier.js';

export function connectionOrientation(connection) {
  const a=connection.endpoint1??{},b=connection.endpoint2??{};
  if(a.style==='None'&&b.style==='Arrow')return{originId:a.connectedTo??null,destinationId:b.connectedTo??null,status:'VERIFIED_BY_TERMINATIONS',basis:'None->Arrow'};
  if(a.style==='CircleOpen'&&b.style==='Generalization')return{originId:a.connectedTo??null,destinationId:b.connectedTo??null,status:'VERIFIED_BY_TERMINATIONS',basis:'CircleOpen->Generalization'};
  if(b.style==='CircleOpen'&&a.style==='Generalization')return{originId:b.connectedTo??null,destinationId:a.connectedTo??null,status:'VERIFIED_BY_TERMINATIONS',basis:'CircleOpen->Generalization'};
  return{originId:null,destinationId:null,status:'AMBIGUOUS',basis:`${a.style??'?'}<->${b.style??'?'}`,endpointIds:[a.connectedTo??null,b.connectedTo??null]};
}

export function extractBddEvidence(document){return document.pages.filter(p=>/BDD/i.test(p.title)).flatMap(p=>p.shapes.map(s=>({pageId:p.id,shapeId:s.id,textAreas:structuredClone(s.textAreas??[]),text:(s.textAreas??[]).map(x=>x.text??'').join(' | ')})));}

const childFor=(eventStructure,containment)=>[...(eventStructure?.containerChainIds??[])].reverse().find(id=>shapeKind(containment.byId.get(id))==='CHILD_CONTAINER')??null;
const EVENT_TYPE_KEYS=new Set(['BPMN_EVENT_TYPE','EVENT_TYPE','TIPO_EVENTO_BPMN']);
const EVENT_TYPES=new Map([['START','START'],['INICIO','START'],['END','END'],['FIN','END'],['SIGNAL','SIGNAL'],['SENAL','SIGNAL'],['RECEIVE','RECEIVE'],['RECEPCION','RECEIVE'],['EXCEPTION','EXCEPTION'],['EXCEPCION','EXCEPTION']]);
// 0.10.0: subtipo del BPMNEvent por la etiqueta de la figura de la biblioteca nueva (customData START, END, EVENT, EXCEPTION, SIGNAL_SEND, SIGNAL_RECEIVE, MESSAGE_SEND, MESSAGE_RECEIVE).
const EVENT_LABELS=new Set(['START','END','EVENT','EXCEPTION','SIGNAL_SEND','SIGNAL_RECEIVE','MESSAGE_SEND','MESSAGE_RECEIVE']);
export const eventLabelSubtype=shape=>{const keys=[...new Set(customDataEntries(shape).map(x=>String(x.key??'').trim().toUpperCase()).filter(k=>EVENT_LABELS.has(k)))];return keys.length===1?keys[0]:null;};
export function interpretBpmnEventSubtype(event){
  const labelSubtype=eventLabelSubtype(event);
  if(labelSubtype&&!customDataEntries(event).some(x=>EVENT_TYPE_KEYS.has(String(x.key??'').trim().toUpperCase())))return{subtype:labelSubtype,subtypeStatus:'CERTIFIED_BY_FIGURE_LABEL',evidence:[{key:labelSubtype}],conflicts:[],catalogStatus:'PROPOSED_CLOSED_CATALOG'};
  const declarations=customDataEntries(event).filter(x=>EVENT_TYPE_KEYS.has(String(x.key??'').trim().toUpperCase())).map(x=>({key:x.key,value:x.value,normalized:typeof x.value==='string'?x.value.trim().normalize('NFD').replace(/[\u0300-\u036f]/g,'').toUpperCase():null}));
  const evaluated=declarations.map(x=>({...x,subtype:x.normalized?EVENT_TYPES.get(x.normalized)??null:null}));
  const invalid=evaluated.filter(x=>!x.subtype),recognized=evaluated.filter(x=>x.subtype);
  const types=[...new Set(recognized.map(x=>x.subtype))];
  if(types.length>1)return{subtype:null,subtypeStatus:'CONFLICTING_CUSTOM_DATA',evidence:recognized,conflicts:['INCOMPATIBLE_BPMN_EVENT_TYPE_DECLARATIONS'],catalogStatus:'PROPOSED_CLOSED_CATALOG'};
  if(invalid.length)return{subtype:null,subtypeStatus:'NO_VERIFICABLE',evidence:evaluated,conflicts:['UNRECOGNIZED_OR_MALFORMED_BPMN_EVENT_TYPE_DECLARATION'],catalogStatus:'PROPOSED_CLOSED_CATALOG'};
  if(types.length===1)return{subtype:types[0],subtypeStatus:'CERTIFIED_BY_EXPLICIT_CUSTOM_DATA',evidence:recognized,conflicts:[],catalogStatus:'PROPOSED_CLOSED_CATALOG'};
  return{subtype:null,subtypeStatus:'NO_VERIFICABLE',evidence:declarations,conflicts:declarations.length?['UNRECOGNIZED_BPMN_EVENT_TYPE_VALUE']:[],catalogStatus:'PROPOSED_CLOSED_CATALOG'};
}
export function resolveDomainRolesFromStructure(page,containment,connections){
  const components=new Map(containment.components.map(x=>[x.id,x])),producerCandidates=new Map();
  for(const connection of connections){const o=connectionOrientation(connection.raw??connection);if(o.status!=='VERIFIED_BY_TERMINATIONS')continue;const source=containment.byId.get(o.originId),event=containment.byId.get(o.destinationId);if(shapeKind(source)!=='API_OR_SERVICE'||shapeKind(event)!=='BPMN_EVENT')continue;const ss=components.get(source.id),es=components.get(event.id),childId=childFor(es,containment);if(!childId||ss?.containerChainIds?.includes(childId))continue;const sourceRole=ss?.domainRole,destinationRole=es?.domainRole,destinationId=es?.architecturalDomainId;if(!destinationId||destinationRole==='EXTERNAL_SYSTEM')continue;if((sourceRole==='INTEGRATION'&&destinationRole==null)||(sourceRole==null&&ss.architecturalDomainId===destinationId&&destinationRole==null)){if(!producerCandidates.has(destinationId))producerCandidates.set(destinationId,[]);producerCandidates.get(destinationId).push({connectionId:connection.id,componentId:source.id,eventId:event.id,childId});}}
  if(producerCandidates.size!==1)return{producerDomainId:null,candidates:[...producerCandidates].map(([domainId,evidence])=>({domainId,evidence})),status:producerCandidates.size>1?'CONFLICTING_MULTIPLE_PRODUCERS':'NO_DETERMINADO'};
  const [producerDomainId,evidence]=[...producerCandidates][0];
  for(const c of containment.components)if(c.architecturalDomainId===producerDomainId&&c.domainRole==null){c.domainRole=c.explicitDomainRole='PRODUCER';c.possibleDomainRoles=[];c.rootRoleSource=c.evidenceSources.domainRole='STRUCTURAL_CHILD_EVENT_MAIN_PATH';c.rootRoleStatus=c.architecturalDomain.status='INFERRED_BY_OPERATION_STRUCTURE';c.architecturalDomain.roleSource='STRUCTURAL_CHILD_EVENT_MAIN_PATH';}
  for(const r of containment.rootContainers){if(r.id===producerDomainId){r.domainRole=r.role='PRODUCER';r.roleSource='STRUCTURAL_CHILD_EVENT_MAIN_PATH';r.roleStatus='INFERRED_BY_OPERATION_STRUCTURE';r.architecturalDomain.roleSource='STRUCTURAL_CHILD_EVENT_MAIN_PATH';r.architecturalDomain.status='INFERRED_BY_OPERATION_STRUCTURE';}}
  for(const c of containment.components){const root=containment.rootContainers.find(r=>r.id===c.architecturalDomainId);if(root&&c.domainRole==null&&root.role){c.domainRole=c.explicitDomainRole=root.role;c.possibleDomainRoles=[];c.rootRoleSource=root.roleSource;c.rootRoleStatus=root.roleStatus;c.evidenceSources.domainRole=root.roleSource;}}
  return{producerDomainId,candidates:[{domainId:producerDomainId,evidence}],status:'RESOLVED_UNIQUE_PRODUCER',method:'STRUCTURAL_CHILD_EVENT_MAIN_PATH'};
}

export function deriveArchitecturalRoleCandidates(page,containment,classifications,connections,pageClassification={kind:'UNRESOLVED',legendShapeIds:[]}){
  const classById=new Map(classifications.map(x=>[x.id,x])),componentById=new Map(containment.components.map(x=>[x.id,x])),legendIds=new Set(pageClassification.legendShapeIds??[]),results=[];
  for(const connection of connections){
    const orientation=connectionOrientation(connection.raw??connection);let source=containment.byId.get(orientation.originId),event=containment.byId.get(orientation.destinationId);
    if(orientation.status==='AMBIGUOUS'){const ends=orientation.endpointIds??[],uml=ends.find(id=>shapeKind(containment.byId.get(id))==='API_OR_SERVICE'),bpmn=ends.find(id=>shapeKind(containment.byId.get(id))==='BPMN_EVENT');source=containment.byId.get(uml);event=containment.byId.get(bpmn);}
    if(shapeKind(source)!=='API_OR_SERVICE'||shapeKind(event)!=='BPMN_EVENT')continue;
    const classification=classById.get(source.id),functional=classification?.functionalClassification;
    if(isIntegrationEvent(functional)||isPartialIntegrationEvent(functional)||legendIds.has(source.id)||legendIds.has(event.id))continue;
    const sourceStructure=componentById.get(source.id),eventStructure=componentById.get(event.id);if(sourceStructure?.notation||eventStructure?.notation)continue;
    const childId=childFor(eventStructure,containment);
    const sourceRole=sourceStructure?.domainRole??null,destinationRole=eventStructure?.domainRole??null;
    let scenarioHypothesis=null,roleCandidate=null,support='DOMAIN_CONTEXT_INSUFFICIENT';
    if(sourceRole==='INTEGRATION'&&destinationRole==='INTEGRATION'&&sourceStructure.architecturalDomainId===eventStructure.architecturalDomainId){scenarioHypothesis='E2';roleCandidate='mainApi';support='REQUIRED_DOMAINS_RESOLVED';}
    else if(sourceRole==='INTEGRATION'&&destinationRole==='PRODUCER'){scenarioHypothesis='E1';roleCandidate='mainApi';support='REQUIRED_DOMAINS_RESOLVED';}
    else if(sourceRole==='PRODUCER'&&destinationRole==='PRODUCER'&&sourceStructure.architecturalDomainId===eventStructure.architecturalDomainId){scenarioHypothesis='E3';roleCandidate='mainService';support='REQUIRED_DOMAINS_RESOLVED';}
    const contradictions=[];
    if(orientation.status==='AMBIGUOUS')contradictions.push('CONNECTION_ORIENTATION_UNRESOLVED');
    if(childId&&destinationRole==='EXTERNAL_SYSTEM')contradictions.push('CHILD_INSIDE_EXTERNAL_SYSTEM');
    if(childId&&(source.id===childId||sourceStructure?.containerChainIds?.includes(childId)))contradictions.push('MAIN_COMPONENT_INSIDE_CHILD_CONTAINER');
    if(roleCandidate==='mainApi'&&classification?.inference?.some(hasServiceNamingBasis))contradictions.push('SERVICE_NAMING_SIGNAL_CONFLICTS_WITH_MAIN_API_TOPOLOGY');
    contradictions.push(...(sourceStructure?.domainConflicts??[]).map(x=>x.code),...(eventStructure?.domainConflicts??[]).map(x=>x.code));
    const essentialsResolved=orientation.status==='VERIFIED_BY_TERMINATIONS'&&childId&&roleCandidate&&scenarioHypothesis&&!contradictions.length;
    const operation=classification?.sections?.operation??null,child=containment.byId.get(childId);
    const eventSubtype=interpretBpmnEventSubtype(event);
    results.push({pageName:page.title,pageKind:pageClassification.kind,componentId:source.id,mainComponentName:classification?.sections?.title??null,mainComponentOperation:operation,mainChildServiceName:child?(child.textAreas??[]).map(x=>x.text??'').filter(Boolean).join(' | '):null,lucidchartType:source.class,functionalClassification:structuredClone(functional??null),namingSignals:(classification?.evidence??[]).filter(x=>x.source==='title-prefix'||x.source==='title-suffix'||x.source==='title-keyword'),inferredArchitecturalType:roleCandidate==='mainService'?'service':roleCandidate==='mainApi'?'api':null,roleCandidate,scenarioHypothesis,status:essentialsResolved?'INFERRED':orientation.status==='AMBIGUOUS'||contradictions.length?'AMBIGUOUS':roleCandidate?'CANDIDATE':'UNRESOLVED',sourceRootDomainId:sourceStructure?.architecturalDomainId??null,sourceRootDomainRole:sourceRole,sourceRootDomainRoleSource:sourceStructure?.rootRoleSource??null,destinationRootDomainId:eventStructure?.architecturalDomainId??null,destinationRootDomainRole:destinationRole,destinationRootDomainRoleSource:eventStructure?.rootRoleSource??null,sourceContainerChainIds:sourceStructure?.containerChainIds??[],destinationContainerChainIds:eventStructure?.containerChainIds??[],connection:{id:connection.id,endpoint1:structuredClone(connection.endpoint1),endpoint2:structuredClone(connection.endpoint2),orientation},event:{id:event.id,lucidchartType:event.class,...eventSubtype},destinationChildContainerId:childId,bddEvidenceUsed:false,support,contradictions:[...contradictions,...eventSubtype.conflicts],nonNormative:true});
  }
  const groups=new Map();for(const r of results.filter(x=>x.destinationChildContainerId&&x.scenarioHypothesis)){const k=`${r.destinationChildContainerId}|${r.scenarioHypothesis}`;if(!groups.has(k))groups.set(k,[]);groups.get(k).push(r);}for(const group of groups.values())if(group.length>1)for(const r of group){r.status='AMBIGUOUS';if(!r.contradictions.includes('MULTIPLE_STRUCTURAL_CANDIDATES'))r.contradictions.push('MULTIPLE_STRUCTURAL_CANDIDATES');r.otherCandidateComponentIds=group.filter(x=>x!==r).map(x=>x.componentId);}
  return results;
}

const unresolved=(page,conflicts,evidence=[],alternatives=[])=>({pageName:page.title,scenario:null,status:'NO_DETERMINADO',mainComponentId:null,mainRole:null,evidence,conflicts,alternativeCandidateIds:alternatives,inferenceUsed:false,normativeEvaluation:null,nonNormative:true});

export function identifyStructuralScenario(page,candidates,pageClassification={kind:'UNRESOLVED'}){
  if(['TEMPLATE_OR_LEGEND','BDD_OR_REQUIREMENTS'].includes(pageClassification.kind))return unresolved(page,['PAGE_NOT_OPERATIONAL']);
  const inferred=candidates.filter(x=>x.status==='INFERRED'),hypotheses=candidates.filter(x=>x.roleCandidate&&x.scenarioHypothesis);
  if(inferred.length>1)return unresolved(page,['MULTIPLE_STRUCTURAL_CANDIDATES'],inferred.map(x=>({componentId:x.componentId,connectionId:x.connection.id,eventId:x.event.id,childContainerId:x.destinationChildContainerId,scenarioHypothesis:x.scenarioHypothesis})),inferred.map(x=>x.componentId));
  if(inferred.length===0){const relevant=hypotheses.length?hypotheses:candidates,conflicts=[...new Set(relevant.flatMap(x=>x.contradictions))];return unresolved(page,conflicts.length?conflicts:['NO_COMPLETE_STRUCTURAL_ROLE_CANDIDATE'],relevant.map(x=>({componentId:x.componentId,connectionId:x.connection.id,eventId:x.event.id,childContainerId:x.destinationChildContainerId,scenarioHypothesis:x.scenarioHypothesis,status:x.status})),relevant.map(x=>x.componentId));}
  const x=inferred[0];
  return{pageName:page.title,scenario:x.scenarioHypothesis,status:x.event.subtype==='START'&&x.event.subtypeStatus==='CERTIFIED_BY_EXPLICIT_CUSTOM_DATA'?'CONFIRMADO':'HIPOTESIS',mainComponentId:x.componentId,mainComponentName:x.mainComponentName,mainComponentOperation:x.mainComponentOperation,mainChildServiceId:x.destinationChildContainerId,mainChildServiceName:x.mainChildServiceName,mainRole:x.roleCandidate,connection:x.connection,event:x.event,sourceRootDomainId:x.sourceRootDomainId,sourceRootDomainRole:x.sourceRootDomainRole,destinationRootDomainId:x.destinationRootDomainId,destinationRootDomainRole:x.destinationRootDomainRole,evidence:[{source:'JSON.line.endpoints',id:x.connection.id},{source:'JSON.contains',containerChainIds:x.destinationContainerChainIds},{source:x.sourceRootDomainRoleSource,domainId:x.sourceRootDomainId},{source:x.destinationRootDomainRoleSource,domainId:x.destinationRootDomainId}],conflicts:[],alternativeCandidateIds:[],inferenceUsed:[x.sourceRootDomainRoleSource,x.destinationRootDomainRoleSource].some(s=>s&&s!=='DECLARED_DOMAIN_NAME'),normativeEvaluation:null,nonNormative:true};
}
