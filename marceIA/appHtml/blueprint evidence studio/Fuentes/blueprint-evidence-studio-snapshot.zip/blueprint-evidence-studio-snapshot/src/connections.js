import { shapeKind } from './lucidchart.js';
import { connectionOrientation } from './roles.js';

export function reconstructConnections(page, containment, classifications=[]) {
  const byId = containment.byId;
  const connections = page.lines.map(line => ({
    id: line.id,
    endpoint1: structuredClone(line.endpoint1 ?? null), endpoint2: structuredClone(line.endpoint2 ?? null),
    originId: line.endpoint1?.connectedTo ?? null, destinationId: line.endpoint2?.connectedTo ?? null,
    originStyle: line.endpoint1?.style ?? null, destinationStyle: line.endpoint2?.style ?? null,
    textAreas: structuredClone(line.textAreas ?? []), customData: structuredClone(line.customData ?? []),
    raw: structuredClone(line), status: !line.endpoint1?.connectedTo || !line.endpoint2?.connectedTo ? 'PARTIAL' : !byId.has(line.endpoint1.connectedTo) || !byId.has(line.endpoint2.connectedTo) ? 'MISSING_ENDPOINT_REFERENCE' : 'DECLARED'
  }));
  const principalInteractionPaths = [];
  const classificationById=new Map(classifications.map(x=>[x.id,x]));
  for (const c of connections) {
    const orientation=connectionOrientation(c.raw);
    const pairs=orientation.status==='AMBIGUOUS'?[[c.originId,c.destinationId],[c.destinationId,c.originId]].filter(([a,b])=>shapeKind(byId.get(a))==='API_OR_SERVICE'&&shapeKind(byId.get(b))==='BPMN_EVENT'):[[orientation.originId,orientation.destinationId]];
    for (const [candidateId, eventId] of pairs) {
      if (shapeKind(byId.get(candidateId)) !== 'API_OR_SERVICE' || shapeKind(byId.get(eventId)) !== 'BPMN_EVENT') continue;
      if(classificationById.get(candidateId)?.functionalClassification?.eventClassification)continue;
      const chain = containment.chainFor(eventId);
      const childId = [...chain].reverse().find(id => shapeKind(byId.get(id)) === 'CHILD_CONTAINER') ?? null;
      const rootId = containment.components.find(x => x.id === eventId)?.architecturalDomainId ?? null;
      principalInteractionPaths.push({ candidateComponentId: candidateId, connectionId: c.id, bpmnEventId: eventId, childContainerId: childId, rootContainerId: rootId, orientation, source: 'JSON.line.endpoints+containment', status: orientation.status==='AMBIGUOUS'?'AMBIGUOUS':childId&&rootId?'RESOLVED':'PARTIAL' });
    }
  }
  return { connections, principalInteractionPaths };
}
