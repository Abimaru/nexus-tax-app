export const VERSION = '0.11.0';
export const PACKAGE_VERSION = '0.11.0';
export const SKILL_VERSION = '12.2.0';
// El contrato de los JSON no cambia en 0.5.0: se conserva el nombre que cita la Skill. Desde 0.5.0 el Studio no recibe SVG
// y el JSON ya no lleva metadata.svgEvidence (ninguna regla lo leía). La Skill sigue nombrando este contrato.
export const CONTRACT_VERSION = '0.4.6.1';
export const COPILOT_CONTRACT = `copilot-factual-v${CONTRACT_VERSION}`;
export const DIAGNOSTIC_CONTRACT = `diagnostic-v${CONTRACT_VERSION}`;
