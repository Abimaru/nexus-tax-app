import { connectionOrientation } from './roles.js';

// Inventario por página (0.7.0). Solo hechos: figuras, tipos, certeza, contenedores, relaciones y asociación de modelos.
// No evalúa reglas: qué se exige y qué estado resulta lo define la Skill.
const IO = ['ENTRADA', 'SALIDA'];
const CONTAINER_TYPES = new Set(['CONTENEDOR_PADRE', 'SERVICIO_HIJO', 'SISTEMA_EXTERNO_AUXILIAR', 'CAPA', 'FLUJO', 'FEDERADO', 'CAPA_TOPICOS', 'CONTENEDOR_NO_DETERMINADO']);
const OTHER_OWNER_TYPES = ['EVENTO_INTEGRACION', 'GESTOR_COLAS'];
const nonBlank = value => String(value ?? '').trim();
const certainty = c => c.architecturalType ? 'CERTIFICADO' : c.possibleTypes?.length ? 'CANDIDATO' : 'SIN_TIPO';
const typeOf = c => c.architecturalType ?? (c.possibleTypes?.length ? 'CANDIDATO' : 'SIN_TIPO');
// Etiquetas de la figura (customData de la biblioteca nueva, en mayúsculas); solo se exponen en participantes sin tipo.
const labelsOf = c => [...new Set((Array.isArray(c.customData) ? c.customData : []).map(x => nonBlank(x?.key).toUpperCase()).filter(Boolean))];
const brief = c => ({ id: c.id, name: c.name });
const LEVEL = { CONTENEDOR_PADRE: 'PADRE', SERVICIO_HIJO: 'HIJO', SISTEMA_EXTERNO_AUXILIAR: 'AUXILIAR', CAPA: 'CAPA', FLUJO: 'FLUJO', FEDERADO: 'FEDERADO' };
const LISTS = ['apis', 'servicios', 'eventosIntegracion', 'gestoresCola', 'comandos', 'serviciosHijo', 'sistemasExternosAuxiliares', 'candidatos'];
// Texto legible de una figura para citarla ante la analista: primer renglón con texto, o su tipo si no tiene.
const label = (c, tipo) => { const text = nonBlank(c.name).replace(/\s+/g, ' '); return text ? (text.length > 90 ? `${text.slice(0, 87)}...` : text) : `(sin texto: ${tipo})`; };
const ioOf = c => {
  const keys = (Array.isArray(c.customData) ? c.customData : []).map(x => nonBlank(x?.key).toUpperCase()).filter(k => IO.includes(k));
  return new Set(keys).size === 1 ? keys[0] : null;
};

export function buildInventory({ components, connections, groups, legendIds = new Set(), omitted = [], base = {} }) {
  const byId = new Map(components.map(c => [c.id, c])), live = components.filter(c => !legendIds.has(c.id)), liveIds = new Set(live.map(c => c.id));
  const chainTypes = c => (c.containerChainIds ?? []).map(id => byId.get(id)?.architecturalType);
  const inHijo = c => chainTypes(c).includes('SERVICIO_HIJO');
  // Ámbito = auxiliar más interno que contiene la figura (con sus capas y flujos) o, si no hay, el contenedor padre.
  const scopeOf = c => {
    const chain = c.containerChainIds ?? [];
    return [...chain].reverse().find(id => byId.get(id)?.architecturalType === 'SISTEMA_EXTERNO_AUXILIAR') ?? chain.find(id => byId.get(id)?.architecturalType === 'CONTENEDOR_PADRE') ?? null;
  };
  const isCandidateSubject = c => c.architecturalType === null && c.possibleTypes?.some(t => t === 'API' || t === 'SERVICIO');
  const subjects = live.filter(c => (['API', 'SERVICIO'].includes(c.architecturalType) || isCandidateSubject(c)) && !inHijo(c));
  const subjectIds = new Set(subjects.map(c => c.id));

  // Modelos de entrada y salida: asociación explícita por grupo; el resto se asocia por conteo dentro del ámbito.
  const models = live.filter(c => c.architecturalType === 'MODELO'), ioModels = models.filter(c => ioOf(c));
  const matesOf = id => new Set(groups.filter(g => g.relatedComponentIds.includes(id)).flatMap(g => g.relatedComponentIds).filter(x => x !== id));
  const explicit = new Map(), elsewhere = new Set();
  for (const m of ioModels) {
    const mates = [...matesOf(m.id)].filter(id => liveIds.has(id)), owners = mates.filter(id => subjectIds.has(id));
    if (owners.length) explicit.set(m.id, owners);
    else if (mates.some(id => { const x = byId.get(id); return OTHER_OWNER_TYPES.includes(x?.architecturalType) || x?.possibleTypes?.some(t => OTHER_OWNER_TYPES.includes(t)); })) elsewhere.add(m.id);
  }
  const pool = ioModels.filter(m => !inHijo(m) && !explicit.has(m.id) && !elsewhere.has(m.id));
  const association = new Map(subjects.map(s => [s.id, {}])), byCount = new Map();
  for (const io of IO) {
    const key = io.toLowerCase(), mine = pool.filter(m => ioOf(m) === io), pending = [], consumed = new Set();
    for (const s of subjects) {
      const own = ioModels.filter(m => ioOf(m) === io && explicit.get(m.id)?.includes(s.id));
      if (own.length) association.get(s.id)[key] = { status: 'EXPLICIT_GROUP', ids: own.map(m => m.id), scopeId: scopeOf(s) };
    }
    const scopes = new Map();
    for (const s of subjects) if (!association.get(s.id)[key]) { const scope = scopeOf(s); scopes.set(scope, [...(scopes.get(scope) ?? []), s]); }
    for (const [scope, list] of scopes) {
      const inScope = mine.filter(m => scopeOf(m) === scope), hasCandidate = subjects.some(s => scopeOf(s) === scope && isCandidateSubject(s));
      if (!hasCandidate && inScope.length === list.length) {
        inScope.forEach(m => { consumed.add(m.id); byCount.set(m.id, list.map(s => s.id)); });
        list.forEach(s => { association.get(s.id)[key] = { status: 'BY_COUNT', ids: inScope.map(m => m.id), scopeId: scope }; });
      } else pending.push({ scope, list, inScope, hasCandidate });
    }
    const loose = mine.filter(m => !consumed.has(m.id));
    for (const { scope, list, inScope, hasCandidate } of pending) {
      const result = hasCandidate ? { status: 'AMBIGUOUS', basis: 'CANDIDATE_SUBJECT_IN_SCOPE', ids: inScope.map(m => m.id) }
        : inScope.length ? { status: 'AMBIGUOUS', basis: 'COUNT_MISMATCH', ids: inScope.map(m => m.id) }
        : loose.length ? { status: 'AMBIGUOUS', basis: 'LOOSE_MODELS_OUTSIDE_SCOPE', ids: [] }
        : { status: 'MISSING_IN_SCOPE', ids: [] };
      list.forEach(s => { association.get(s.id)[key] = { ...result, scopeId: scope }; });
    }
  }
  const modelState = m => !ioOf(m) ? 'SIN_ENTRADA_SALIDA' : inHijo(m) ? 'EN_HIJO' : explicit.has(m.id) ? 'ASOCIADO_POR_GRUPO' : elsewhere.has(m.id) ? 'DE_OTRO_COMPONENTE' : byCount.has(m.id) ? 'ASOCIADO_POR_CONTEO' : 'SUELTO';
  const modelos = models.map(m => ({ ...brief(m), ...(m.modelKind ? { tipoModelo: m.modelKind } : {}), io: ioOf(m), scopeId: scopeOf(m), estado: modelState(m), componentIds: explicit.get(m.id) ?? byCount.get(m.id) ?? [] }));

  // Contenedores: contenido directo por tipo (ids) para poder contar sin interpretar el dibujo.
  const children = new Map();
  for (const c of live) { const parent = c.structuralParent?.id; if (parent) children.set(parent, [...(children.get(parent) ?? []), c]); }
  const contenedores = live.filter(c => CONTAINER_TYPES.has(c.architecturalType)).map(c => {
    const contiene = {};
    for (const child of children.get(c.id) ?? []) (contiene[child.lucidchartType === 'BPMNActivity' && typeOf(child) === 'SIN_TIPO' ? 'ACTIVIDAD_SIN_TIPO' : typeOf(child)] ??= []).push(child.id);
    return { id: c.id, name: c.name, tipo: c.architecturalType, domainRole: c.domainRole ?? null, domainSource: c.architecturalDomain?.roleSource ?? c.architecturalDomain?.status ?? null, parentId: c.structuralParent?.id ?? null, contiene };
  });

  // Capas de Tópicos: texto literal de la capa separado por espacios o saltos de línea (los tópicos) y los eventos que contiene directamente.
  const capasTopicos = live.filter(c => c.architecturalType === 'CAPA_TOPICOS').map(c => ({ ...brief(c), topicos: (c.textAreas ?? []).flatMap(t => nonBlank(t?.text).split(/\s+/)).filter(Boolean), eventoIds: (children.get(c.id) ?? []).filter(x => x.architecturalType === 'EVENTO_INTEGRACION').map(x => x.id), padreId: c.structuralParent?.id ?? null }));

  // Relaciones: una entrada por pareja de participantes; cada línea con sus extremos, estilos y origen/destino por terminaciones.
  const lineIds = new Set(connections.map(x => x.id)), pairs = new Map();
  const lineById = new Map(connections.map(x => [x.id, x]));
  const known = id => { const c = byId.get(id); return c ? { id, name: c.name, tipo: typeOf(c), certeza: certainty(c), ...(c.commandType ? { tipoComando: c.commandType } : {}), ...(c.modelKind ? { tipoModelo: c.modelKind } : {}), ...(c.eventSubtype ? { subtipoEvento: c.eventSubtype } : {}), ...(typeOf(c) === 'SIN_TIPO' && labelsOf(c).length ? { figura: c.lucidchartType, etiquetas: labelsOf(c) } : {}), ...(c.possibleTypes?.length && !c.architecturalType ? { posiblesTipos: c.possibleTypes } : {}) } : null; };
  // Una línea que nace de otra línea consta como participante LINEA, con los extremos de esa línea en `conecta`.
  const participant = id => known(id) ?? (lineIds.has(id) ? { id, tipo: 'LINEA', certeza: 'SIN_TIPO', conecta: [lineById.get(id).endpoint1?.connectedTo, lineById.get(id).endpoint2?.connectedTo].filter(Boolean).map(x => known(x) ?? { id: x, tipo: 'DESCONOCIDO' }) } : { id, tipo: 'DESCONOCIDO', certeza: 'SIN_TIPO' });
  for (const x of connections) {
    const a = x.endpoint1?.connectedTo ?? null, b = x.endpoint2?.connectedTo ?? null;
    if ([a, b].some(id => id && legendIds.has(id))) continue;
    const key = [a ?? '', b ?? ''].sort().join('|'), o = connectionOrientation(x);
    const entry = pairs.get(key) ?? { participantes: [...new Set([a, b].filter(Boolean))].map(participant), lineas: [] };
    const e1 = x.endpoint1 ?? {}, e2 = x.endpoint2 ?? {}, verified = o.status === 'VERIFIED_BY_TERMINATIONS', first = verified && ((e1.style === 'None' && e2.style === 'Arrow') || (e1.style === 'CircleOpen' && e2.style === 'Generalization'));
    entry.lineas.push({ id: x.id, estado: x.status, origen: o.originId, destino: o.destinationId, ...(verified ? { estiloOrigen: first ? e1.style : e2.style, estiloDestino: first ? e2.style : e1.style } : { estilos: [e1.style ?? null, e2.style ?? null] }), ...(a && b ? {} : { extremoSinConectar: true }), ...((x.textAreas ?? []).some(t => nonBlank(t?.text)) ? { etiqueta: x.textAreas.map(t => nonBlank(t?.text)).filter(Boolean).join(' | ') } : {}) });
    pairs.set(key, entry);
  }
  // Conexiones pendientes: línea con extremo sin conectar, estado distinto de DECLARED o con una línea como participante.
  const conexionesPendientes = [...pairs.values()].flatMap(r => r.lineas.filter(l => l.estado !== 'DECLARED' || l.extremoSinConectar || r.participantes.some(p => ['LINEA', 'DESCONOCIDO'].includes(p.tipo))).map(l => ({ id: l.id, estado: l.estado, participantes: r.participantes.map(p => ({ id: p.id, name: p.name, tipo: p.tipo, ...(p.posiblesTipos ? { posiblesTipos: p.posiblesTipos } : {}) })) })));
  // `par` resume los tipos de los dos participantes (candidato con sus tipos posibles) para filtrar parejas sin leer el dibujo.
  const relaciones = [...pairs.values()].map(r => ({ par: r.participantes.map(p => p.tipo === 'CANDIDATO' ? `CANDIDATO(${(p.posiblesTipos ?? []).join('|')})` : p.tipo).sort().join('+'), ...r }));
  // Compuertas: texto propio y caminos de salida con su etiqueta (null si la línea no tiene texto).
  const exits = new Map();
  for (const x of connections) {
    if ([x.endpoint1?.connectedTo, x.endpoint2?.connectedTo].some(id => id && legendIds.has(id))) continue;
    const o = connectionOrientation(x), label_ = (x.textAreas ?? []).map(t => nonBlank(t?.text)).filter(Boolean).join(' | ') || null;
    if (o.status === 'VERIFIED_BY_TERMINATIONS') { if (o.originId) exits.set(o.originId, [...(exits.get(o.originId) ?? []), { linea: x.id, destino: o.destinationId, etiqueta: label_ }]); }
    else for (const id of [x.endpoint1?.connectedTo, x.endpoint2?.connectedTo]) if (id) exits.set(id, [...(exits.get(id) ?? []), { linea: x.id, destino: null, etiqueta: label_, orientacion: 'NO_VERIFICADA' }]);
  }
  // 0.10.2: subtipo de la compuerta por la etiqueta de la figura (customData EXCLUSIVE, INCLUSIVE, PARALLEL, EVENT_BASED, PARALLEL_EVENT_BASED); sin etiqueta no se declara.
  const GATE_SUBTYPES = ['EXCLUSIVE', 'INCLUSIVE', 'PARALLEL', 'EVENT_BASED', 'PARALLEL_EVENT_BASED'];
  const gateSubtype = c => { const k = (Array.isArray(c.customData) ? c.customData : []).map(x => String(x?.key ?? '').trim().toUpperCase()); return GATE_SUBTYPES.find(t => k.includes(t)); };
  const compuertas = live.filter(c => c.architecturalType === 'COMPUERTA').map(c => ({ ...brief(c), ...(gateSubtype(c) ? { subtipo: gateSubtype(c) } : {}), conTexto: !!nonBlank(c.name), caminos: exits.get(c.id) ?? [] }));
  // Ubicación de cada figura inventariada y nombre legible de cada figura y línea.
  const locate = c => {
    // Las capas, flujos y Federado no son un nivel: la figura queda en el nivel del contenedor que los contiene.
    const chain = (c.containerChainIds ?? []).map(id => byId.get(id)), layer = [...chain].reverse().find(x => ['CAPA', 'FLUJO', 'FEDERADO'].includes(x?.architecturalType)) ?? null;
    const level = [...chain].reverse().find(x => x && !['CAPA', 'FLUJO', 'FEDERADO', 'CAPA_TOPICOS'].includes(x.architecturalType));
    return { dominio: c.domainRole ?? null, nivel: level ? LEVEL[level.architecturalType] ?? 'OTRO' : 'SIN_CONTENEDOR', contenedorId: level?.id ?? null, padreId: chain.find(x => x?.architecturalType === 'CONTENEDOR_PADRE')?.id ?? null, ...(layer ? { capaId: layer.id } : {}), ...(chain.some(x => x?.architecturalType === 'CAPA_TOPICOS') ? { capaTopicosId: [...chain].reverse().find(x => x?.architecturalType === 'CAPA_TOPICOS').id } : {}), ...(chain.some(x => x?.architecturalType === 'SISTEMA_EXTERNO_AUXILIAR') ? { auxiliarId: [...chain].reverse().find(x => x?.architecturalType === 'SISTEMA_EXTERNO_AUXILIAR').id } : {}) };
  };
  const located = Object.fromEntries(LISTS.filter(k => base[k]).map(k => [k, base[k].map(e => ({ ...e, ubicacion: byId.has(e.id) ? locate(byId.get(e.id)) : null }))]));
  const nombres = Object.fromEntries(live.map(c => [c.id, label(c, typeOf(c))]));
  for (const x of connections) {
    const o = connectionOrientation(x), a = x.endpoint1?.connectedTo, b = x.endpoint2?.connectedTo, name = id => id && byId.has(id) ? nombres[id] ?? label(byId.get(id), typeOf(byId.get(id))) : id ? `línea ${id}` : '(extremo sin conectar)';
    nombres[x.id] = o.status === 'VERIFIED_BY_TERMINATIONS' ? `línea ${name(o.originId)} → ${name(o.destinationId)}` : `línea ${name(a)} – ${name(b)}`;
  }
  const by = t => live.filter(c => c.architecturalType === t).map(brief);
  return {
    inventory: {
      contenedoresPadre: live.filter(c => c.architecturalType === 'CONTENEDOR_PADRE').map(c => ({ ...brief(c), domainRole: c.domainRole ?? null })),
      ...located, capasTopicos, capas: by('CAPA'), flujos: by('FLUJO'), federados: by('FEDERADO'), compuertas, eventosBpmn: live.filter(c => c.architecturalType === 'EVENTO_BPMN').map(c => ({ ...brief(c), ...(c.eventSubtype ? { subtipo: c.eventSubtype } : {}) })), modelos,
      contenedores, relaciones, conexionesPendientes, omitidos: omitted, nombres
    },
    modelAssociation: association
  };
}
