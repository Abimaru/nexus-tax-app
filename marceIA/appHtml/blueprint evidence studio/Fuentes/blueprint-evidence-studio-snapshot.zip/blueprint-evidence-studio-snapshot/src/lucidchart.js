export function normalizeDocument(input, sourceName = null) {
  if (!input || typeof input !== 'object' || !Array.isArray(input.pages)) throw new TypeError('Lucidchart JSON must contain pages[]');
  return {
    id: input.id ?? null,
    title: input.title ?? null,
    sourceName,
    pages: input.pages.map((page, index) => normalizePage(page, index)),
    raw: input
  };
}

export function normalizePage(page, index = 0) {
  const items = page.items && !Array.isArray(page.items) ? page.items : {};
  const legacy = Array.isArray(page.items) ? page.items : [];
  const rawShapes = Array.isArray(items.shapes) ? items.shapes : legacy.filter(x => x?.type === 'shape');
  const rawLines = Array.isArray(items.lines) ? items.lines : legacy.filter(x => x?.type === 'line');
  const shapes = rawShapes.filter(Boolean), lines = rawLines.filter(Boolean);
  return {
    id: page.id ?? null,
    title: page.title ?? '',
    index: page.index ?? index,
    shapes,
    lines,
    groups: Array.isArray(items.groups) ? items.groups : [],
    layers: Array.isArray(items.layers) ? items.layers : [],
    customData: Array.isArray(page.customData) ? page.customData : [],
    raw: page,
    normalizationIssues: [
      ...rawShapes.flatMap((x, i) => x ? [] : [{ code: 'NULL_SHAPE', index: i }]),
      ...rawLines.flatMap((x, i) => x ? [] : [{ code: 'NULL_LINE', index: i }]),
      ...shapes.flatMap(shape => !Object.hasOwn(shape, 'customData') || Array.isArray(shape.customData)
        ? []
        : [{ code: 'MALFORMED_CUSTOM_DATA', componentId: shape.id ?? null, actualType: shape.customData === null ? 'null' : typeof shape.customData, status: 'UNRESOLVED' }]),
      ...shapes.flatMap(shape => Array.isArray(shape.customData) && shape.customData.some(entry => !entry || typeof entry !== 'object' || Array.isArray(entry))
        ? [{ code: 'MALFORMED_CUSTOM_DATA_ENTRY', componentId: shape.id ?? null, status: 'UNRESOLVED' }]
        : [])
    ]
  };
}

export const customDataEntries = value => Array.isArray(value?.customData)
  ? value.customData.filter(entry => entry && typeof entry === 'object' && !Array.isArray(entry))
  : [];

// Modelo de entrada/salida: actividad BPMN con customData ENTRADA o SALIDA.
export const ioModelKey = shape => shape?.class === 'BPMNActivity' ? customDataEntries(shape).find(x => /^(ENTRADA|SALIDA)$/i.test(String(x.key ?? '').trim()))?.key ?? null : null;

export const shapeText = shape => (shape?.textAreas ?? []).map(x => x.text ?? x.value ?? '').filter(Boolean).join(' | ');
export const normalizeLabel = value => String(value ?? '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/\s+/g, ' ').trim().toUpperCase();
export const isNotationLabel = value => normalizeLabel(value) === 'NOTACION';

export function shapeKind(shape) {
  if (!shape) return 'MISSING_REFERENCE';
  const label = normalizeLabel(shapeText(shape));
  // Las capas de despliegue solo existen como figura contenedor; un texto suelto con el mismo nombre no cuenta.
  const isContainer = shape.class === 'UMLRectangleContainerBlock';
  if (isContainer && /^FLUJO TRANSACCIONAL\b/.test(label)) return 'TRANSACTION_FLOW';
  if (isContainer && /^CAPA DE ARQUITECTURA\b/.test(label)) return 'ARCHITECTURE_LAYER';
  if (isContainer && label === 'FEDERADO') return 'FEDERATED_LAYER';
  if (['INTEGRACION','SISTEMA EXTERNO','SISTEMAS EXTERNOS','SISTEMA EXTERNO (OPCIONAL)','SISTEMAS EXTERNOS (OPCIONAL)','DOMINIO PRODUCTOR'].includes(label)) return 'ARCHITECTURAL_DOMAIN';
  if (isNotationLabel(label)) return 'OTHER';
  if (shape.class === 'UMLRectangleContainerBlock' && shape.contains) return 'ARCHITECTURAL_DOMAIN_UNCLASSIFIED';
  if (shape.class === 'RectangleContainerBlock') return 'CHILD_CONTAINER';
  if (shape.class === 'UMLClassBlock') return 'API_OR_SERVICE';
  if (shape.class === 'UMLActiveClassBlock') return 'QUEUE_MANAGER';
  if (shape.class === 'BPMNEvent') return 'BPMN_EVENT';
  if (shape.class === 'BPMNActivity') return 'BPMN_ACTIVITY';
  if (shape.class === 'BPMNGroup') return 'BPMN_GROUP';
  return 'OTHER';
}
