## Fichas operativas - v12.2.0

Una ficha dice de dónde sale la población de cada regla. No define la regla: el criterio y los estados están en el archivo de la regla, y la prioridad de estados en el apartado 8 de `00-procedimiento.md`.

### Cómo usar una ficha

1. Toma la población de la clave del inventario que indica la ficha.
2. Antes de leer el criterio, busca candidatos y pendientes en esa población. Con uno solo, el estado es `No verificable` aunque exista un incumplimiento certificado, y no se evalúa más: la justificación nombra el candidato o la pendiente y el dato que falta, y cita en una línea el incumplimiento certificado si ya consta.
3. Sin candidatos ni pendientes, lee la regla en su archivo y decide el estado.
4. Escribe una línea: ID, población, evidencia, estado, justificación y dato pendiente.

### Cómo citar

- Cada figura se escribe «Nombre (id)», con el nombre de `inventory.nombres[id]`: «Wallet (oNQpJ_-l7X-R)». Nunca un id solo, ni en el inventario, la evidencia, las justificaciones, el resumen, las recomendaciones o las preguntas a la analista.
- Una figura sin texto viene como «(sin texto: TIPO)»: «(sin texto: COMPUERTA) (id)».
- Una línea viene como «línea Origen → Destino»: «línea Registrar → Wallet (id)».

### Qué no es población

- Un componente con `architecturalType: null` y sin `possibleTypes` no es candidato ni población.
- Un sistema externo auxiliar no es un dominio SISTEMAS EXTERNOS.
- Un componente no cambia de tipo por su nombre, su posición ni su cercanía.
- La ubicación sale de `ubicacion` (`dominio`, `nivel`, `padreId`, `auxiliarId`) en cada lista del inventario, no del dibujo ni de la memoria. Una figura con `nivel: AUXILIAR` está dentro de un auxiliar y no en el nivel del dominio.

Las claves `inventory.*` son las de `pages[].inventory`.

### Parejas: a qué regla va cada una

Cada entrada de `inventory.relaciones` trae `par` (tipos de sus dos participantes; el candidato con sus tipos posibles). Una pareja va a una sola regla, la de esta tabla. Sin ninguna pareja con el `par` de la regla (ni pendiente que pueda serlo), la regla es `No aplica`, aunque existan los dos tipos por separado.

| `par` | Regla |
|---|---|
| `API+COMANDO` | COM-002 (si el comando es `SYSTEM_TASK` o `SUB_PROCESS`, COM-003) |
| `COMANDO+SERVICIO` | COM-002 (si el comando es `SYSTEM_TASK` o `SUB_PROCESS`, COM-003) |
| `COMANDO+GESTOR_COLAS` | COM-002 (si el comando es `SYSTEM_TASK` o `SUB_PROCESS`, COM-003) |
| `COMANDO+SISTEMA_EXTERNO_AUXILIAR` | COM-002 (si el comando es `SYSTEM_TASK` o `SUB_PROCESS`, COM-003) |
| Cualquier pareja con un comando `SYSTEM_TASK` o `SUB_PROCESS` (`tipoComando` del participante): `COMANDO+COMANDO`, `COMANDO+COMPUERTA`, `COMANDO+EVENTO_BPMN`, `COMANDO+SIN_TIPO`, `COMANDO+MODELO`, `COMANDO+EVENTO_INTEGRACION` y las anteriores | COM-003 (las demás reglas COM no reciben esta pareja) |
| `CANDIDATO(API\|SERVICIO\|GESTOR_COLAS)+COMANDO` | COM-002: `No verificable` |
| `API+SERVICIO`, `SERVICIO+SERVICIO`, `SERVICIO+SISTEMA_EXTERNO_AUXILIAR`, `EVENTO_BPMN+SERVICIO` | SRV-005, solo si el servicio es invocado (su id no es `scenario.mainComponentId`) |
| Cualquiera de esas parejas con el servicio principal de E3 (`scenario.mainComponentId`) | ninguna regla de conexión; la línea hacia el evento de Inicio (`scenario.connection`) la evalúa E3-001 |
| `CANDIDATO(API\|SERVICIO)` con API, servicio, auxiliar, evento o candidato | SRV-005: `No verificable` |
| `GESTOR_COLAS+SERVICIO`, `GESTOR_COLAS+GESTOR_COLAS`, `EVENTO_BPMN+GESTOR_COLAS` | MQ-003 |
| `CANDIDATO(API\|SERVICIO)+GESTOR_COLAS` | MQ-003: `No verificable`; nunca SRV-005 |
| `API+API`, `API+SISTEMA_EXTERNO_AUXILIAR` | ninguna |

Un candidato solo afecta a las reglas de sus `posiblesTipos`: uno `["API"]` no toca las reglas de servicio. Una pareja con comando nunca va a SRV-005 ni MQ-003. Una línea que llega a un componente encapsulado no llega al auxiliar: el par es el del componente. Una conexión pendiente (apartado 6.1) deja `No verificable` las reglas que su participante conocido podría tocar.

### Estructura (01-reglas-estructura.md)

**CNT-001.** Población: `contenedoresPadre` y `scenario`. Pendiente: contenedor sin dominio (`possibleDomainRoles`). INTEGRACIÓN repetido es válido.

**CNT-002.** Población: `serviciosHijo` y el contenedor padre que lo contiene (`contenedores`). El nombre del hijo es `serviciosHijo[].name`; vacío cuenta como ausente. Los contenedores no traen `operation`. Pendiente: `scenario.status: NO_DETERMINADO` o varios hijos candidatos.

**CNT-003.** Población (un componente con `figura` `THIRD_PARTY_API`, `THIRD_PARTY_SERVICE` o `THIRD_PARTY_MQ_SERVICE` en INTEGRACIÓN incumple; los comandos del hijo se leen en `comandos[].tipoComando`: `USER_TASK` en el hijo incumple): el contenido directo de los `contenedores` con `domainRole: INTEGRATION` y, si hay hijo, su contenido; incluye lo que está dentro de una capa de despliegue (`ubicacion.capaId`) con el `ubicacion.nivel` que trae (`PADRE`); `nivel: OTRO` es `No verificable` para ese componente (apartado 1 del procedimiento). Los auxiliares (`sistemasExternosAuxiliares`; su ubicación está en `parentId` y `domainRole` de `contenedores`) y lo que encapsulan (`ubicacion.nivel: AUXILIAR`, `contiene`) se evalúan aquí. `contiene.ACTIVIDAD_SIN_TIPO` (actividad BPMN sin tipo, ni modelo ni comando) y `contiene.CANDIDATO` dentro de un auxiliar: `No verificable`. `marcadoresApi` están permitidos. Candidato: cualquier entrada de `candidatos` con esa `ubicacion`, sea cual sea su `possibleTypes`: `No verificable`.

**CNT-004.** Población (un componente con `figura` `THIRD_PARTY_*` en el PRODUCTOR incumple; los comandos del hijo se leen en `comandos[].tipoComando`: `USER_TASK` en el hijo incumple): el contenido directo de los `contenedores` con `domainRole: PRODUCER` y, si hay hijo, su contenido; incluye lo que está dentro de una capa de despliegue (`ubicacion.capaId`) con el `ubicacion.nivel` que trae (`PADRE`); `nivel: OTRO` es `No verificable` para ese componente. Los auxiliares y lo que encapsulan se evalúan aquí, como en CNT-003. Candidato: como en CNT-003.

**CNT-005.** Población: `contenedoresPadre` con `domainRole: EXTERNAL_SYSTEM` y su contenido directo (no el de sus auxiliares), incluido lo que está dentro de una capa de despliegue (`ubicacion.capaId`) con el `ubicacion.nivel` que trae; `nivel: OTRO` es `No verificable` para ese componente. Los auxiliares ubicados en este dominio y lo que encapsulan se evalúan aquí, como en CNT-003. Si no hay ninguno ni `possibleDomainRoles` que lo incluya: `No aplica`. Candidato: como en CNT-003.

**EXT-001.** Población: `sistemasExternosAuxiliares`; el nombre es `name` (vacío cuenta como ausente). No evalúa ubicación ni contenido (CNT-003, CNT-004, CNT-005).

**GW-001.** Población: `compuertas` con `subtipo` `EXCLUSIVE` o `INCLUSIVE`, o sin `subtipo` (figura sin etiqueta: se evalúa igual). Excluidas: `PARALLEL`, `EVENT_BASED` y `PARALLEL_EVENT_BASED` (no se exige pregunta ni se evalúan sus etiquetas); si todas son de esos subtipos, `No aplica`. Cada una trae `conTexto` y `caminos` (líneas de salida con su `etiqueta`, `null` si no tiene). Se decide por compuerta, y la regla toma el peor estado:

- línea de `conexionesPendientes` con la compuerta, o camino con `orientacion: NO_VERIFICADA`: `No verificable`;
- `conTexto` y todos los caminos (dos o más) con etiqueta: `Cumple` si las etiquetas distinguen las alternativas; `No cumple` si contradicen el texto;
- `conTexto` y algún camino sin etiqueta, o un solo camino: `No verificable` (pregunta sin respuestas);
- sin texto y algún camino con etiqueta: `No verificable` (respuestas sin pregunta);
- sin texto y ningún camino con etiqueta: `Cumple`.

### API (02-reglas-api-servicios.md)

**API-001, API-002, API-003.** En API-003, la API externa (`THIRD_PARTY_API` o `domainRole: EXTERNAL_SYSTEM`) no se evalúa en la tercera sección: vacía o con cualquier texto, Cumple. Población: `apis` (principal e invocadas); `figura: THIRD_PARTY_API` identifica la API externa. El texto está en `components[].textAreas` y el dominio en `domainRole`. Candidato: cualquier `candidatos` con `API` en `possibleTypes`, esté donde esté: `No verificable` en las tres, aunque las API certificadas cumplan o incumplan.

**API-004.** Población: la API con `role: PRINCIPAL`, solo si se declaró MCI. Asociaciones: `deploymentAssociations`. Pendiente: pareja Capa-Flujo sin propietario, solo si falta alguna asociación exigida por la exposición; con todas resueltas con la API principal, es Cumple.

### Servicios (02-reglas-api-servicios.md)

**SRV-001, SRV-002, SRV-003.** Población: `servicios` (sin `serviciosHijo`). En SRV-003, el servicio en SISTEMAS EXTERNOS (figura `THIRD_PARTY_SERVICE` o `THIRD_PARTY_MQ_SERVICE`, o `domainRole: EXTERNAL_SYSTEM`) no se evalúa en la tercera sección: vacía o con cualquier texto, Cumple. Candidato: cualquier `candidatos` con `SERVICIO` en `possibleTypes`, esté donde esté: `No verificable` en las tres.

**SRV-004.** Población: `servicios` ubicados en el nivel padre de INTEGRACIÓN, más el hijo principal de E2 si se declaró y el de E1 (supuesto no MCI, sin pregunta). Asociaciones: `deploymentAssociations`. Pendiente: pareja Capa-Flujo sin propietario.

**SRV-006.** Población: `servicios` con `consumidoPorColas: true` (figura con MQ) con `role: INVOCADO`; no el servicio principal de E3 ni el hijo. Capa de Tópicos: `capaTopicos` del propio servicio (`id`, `topicos`), por contención o por el grupo de la figura MQ (`asociadaPor: GRUPO`); `null` sin `capasTopicosCandidatas` = sin capa; con `capasTopicosCandidatas` (varias capas de tópicos en el grupo) = `No verificable`. Una capa de despliegue no cuenta. Plantilla: `nombrecolapeticion`, `nombrecolarespuesta` o `nombre…` genérico. Candidato: `candidatos` con `SERVICIO` y figura MQ, o con `CAPA_TOPICOS`: `No verificable`.

**SRV-005.** Población: las parejas que la tabla de parejas asigna a SRV-005, solo de servicios invocados. No entran las parejas con comando ni con gestor, ni ninguna del servicio principal de E3 (`scenario.mainComponentId`) ni del hijo principal. Pendiente: `conexionesPendientes` con un servicio invocado o un candidato a servicio, no con el servicio principal.

### Eventos de integración (03-reglas-eventos.md)

**EVT-001, EVT-002, EVT-003, EVT-004.** Población: `eventosIntegracion`. Candidato: `candidatos` con `EVENTO_INTEGRACION`. Capa de Tópicos de un evento: la entrada de `capasTopicos` cuyo `eventoIds` lo incluye (`ubicacion.capaTopicosId`). Candidato: también `candidatos` con `CAPA_TOPICOS`.

**EVT-005, EVT-006.** Población: eventos con una única Capa de Tópicos y los tópicos de esa capa (`capasTopicos[].topicos`). Candidato: `candidatos` con `EVENTO_INTEGRACION` o `CAPA_TOPICOS`.

**EVT-007.** Población: parejas de `relaciones` de los tópicos `p` y `s` con BPMNEvent y los `eventosBpmn` con `subtipo` `SIGNAL_SEND` o `SIGNAL_RECEIVE` (deben tener una pareja con un evento de integración o su Capa de Tópicos). Pendiente: `conexionesPendientes` con esos eventos.

### Despliegue (04-reglas-despliegue.md)

**CA-001.** Población: `capas`.

**FT-001.** Población: `flujos`.

### Escenarios (05-reglas-escenarios.md)

**E1-001, E2-001, E3-001.** Población: `scenario` (patrón, `mainComponentId`, `mainChildServiceId`, `event`, `connection`). Solo evalúa la regla del patrón identificado; las otras: `No aplica`. Subtipo Inicio: `scenario.event.subtype`. Pendiente: `scenario.status: NO_DETERMINADO` o `alternativeCandidateIds`.

### Generalidades (01-reglas-estructura.md)

**GEN-001.** Población: `scenario.mainComponentId` (la API principal de E1 y E2 o el servicio principal de E3), su `operation` en `components` y el nombre de la página en `page.title`. Pendiente: `scenario.status: NO_DETERMINADO` o `alternativeCandidateIds`.

### Modelos y comandos (06-reglas-modelos-comandos.md)

**MOD-001.** Población: `apis` y `servicios`, cada uno con su `modelAssociation` (`entrada` y `salida`), y los eventos de integración de INTEGRACIÓN. Estados del Studio: `EXPLICIT_GROUP` y `BY_COUNT` = asociado; `MISSING_IN_SCOPE` = falta; `AMBIGUOUS` = pendiente. `modelos` lista cada modelo con su estado.

**MOD-002.** Población: `modelos` (cada uno con su `tipoModelo` o `io`); el texto completo está en `components[].textAreas` del mismo id. Pendiente: modelo sin texto disponible.

**COM-001.** Población: `comandos`; el subtipo está en `tipoComando` (`SERVICE_TASK`, `SYSTEM_TASK`, `SUB_PROCESS`; `USER_TASK` no se evalúa; sin `tipoComando` es comando por conexión y se evalúa como `SERVICE_TASK`).

**COM-002.** Población: los `comandos` con `tipoComando: SERVICE_TASK` (o sin `tipoComando`) y las parejas de `relaciones` que la tabla asigna a COM-002 (`API+COMANDO`, `COMANDO+SERVICIO`, `COMANDO+GESTOR_COLAS`, `COMANDO+SISTEMA_EXTERNO_AUXILIAR`). Existencia: todo `SERVICE_TASK` con etiqueta debe tener al menos una de esas parejas; bidireccionalidad: cada pareja con sus dos sentidos y terminaciones (`lineas`). Sin comandos `SERVICE_TASK` ni parejas: `No aplica`. Pendiente: pareja del comando con candidato a API, servicio o gestor, o `conexionesPendientes` con un comando, una API, un servicio, un gestor o un auxiliar.

**COM-003.** Población: las parejas de `relaciones` con un participante `COMANDO` cuyo `tipoComando` es `SYSTEM_TASK` o `SUB_PROCESS`. Se lee el tipo del otro participante (`tipo`; `tipoModelo` si es `MODELO`; `figura` y `etiquetas` si es `SIN_TIPO`) y los estilos de cada línea (`estiloOrigen` y `estiloDestino`, o `estilos`). Pendiente: participante candidato, `DESCONOCIDO` o `LINEA`, figura `SIN_TIPO` sin etiqueta, o `conexionesPendientes` con el comando.

### Gestores de colas (07-reglas-gestores-colas.md)

**MQ-001.** Población: `gestoresCola` y `candidatos` con `GESTOR_COLAS`.

**MQ-002.** Población: los `gestoresCola` con `ubicacion.nivel: PADRE` y `ubicacion.dominio: INTEGRATION`; los demás no se evalúan. Sin ninguno ni candidato a gestor en ese nivel: `No aplica`. Asociaciones: `deploymentAssociations`.

**MQ-003.** Población: las parejas que la tabla asigna a MQ-003 (el evento BPMN debe ser de tipo Mensaje: `subtipoEvento` `MESSAGE_SEND` o `MESSAGE_RECEIVE`; un evento de señal con un gestor es `No cumple`; no comando). Una pareja con candidato a API o servicio es pendiente: `No verificable`. Pendiente: `conexionesPendientes` con un gestor o un servicio.
