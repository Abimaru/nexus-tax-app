# Changelog

## Documentación, autoría y paquete de código fuente — 25/11/2026 (sin cambio de versión: Studio 0.11.0 / Skill 12.2.0)

- **HANDOFF.md reescrito** como guía para que otra IA o persona retome el proyecto: reglas obligatorias de mantenimiento, qué es y cómo se reparte (Studio / Skill / agente), estado vigente, mapa del repositorio, motor módulo a módulo, etiquetas de la biblioteca, contrato del JSON, Skill y reglas, HTML, recetas (cambiar una regla, agregar una figura, cambiar el HTML, versionar, reconstruir entregables), trabajo con la analista, decisiones vigentes, pendientes y trampas conocidas. El handoff anterior se archivó en `docs/audits/HANDOFF_historico_hasta_2026-11-24.md`.
- **README.md y AGENTS.md** actualizados. AGENTS.md ahora obliga a toda IA o persona a **mantener documentación y handoff al día** y a conservar la autoría.
- **Nuevo** `docs/processes/PROCESO-mantener-documentacion.md` (checklist) y ADR-0021 (GW-001), ADR-0022 (capa de tópicos por grupo y SRV-006), ADR-0023 (carpeta única y semver); `ARCHITECTURE.md` con la actualización 0.11.0; índice general actualizado.
- **Autoría:** nuevo `AUTORIA.md` (creación de Andres Ibarguen, co-diseño e implementación con Claude; atribución obligatoria), `author`/`license` en `package.json`, pie del HTML («Creación de Andres Ibarguen») y comentario de autoría al inicio del HTML generado.
- **Paquete de código fuente** para la analista: `dist/blueprint-evidence-studio-codigo-fuente-v0.11.0.zip` (código, Skill, pruebas, corpus, documentación; sin `node_modules`).
- HTML 0.11.0 regenerado con el pie de autoría (sin cambios funcionales). 177 pruebas pasan.

## Skill 12.2.0 y Studio 0.11.0 — 24/11/2026

- **GW-001 (decisión de la analista):** solo las compuertas **exclusivas e inclusivas** deben tener una pregunta o decisión y caminos con etiquetas que respondan a ella. Las compuertas paralelas, basadas en evento y paralelas basadas en evento ya no se validan (aunque sus caminos tengan palabras, no se exige pregunta). Si la página solo tiene compuertas de esos subtipos: `No aplica`. Una compuerta sin etiqueta de subtipo en la figura (BP antiguos) se sigue evaluando como exclusiva o inclusiva, sin generar `No verificable` por ese motivo.
- **Studio:** `inventory.compuertas[].subtipo` (`EXCLUSIVE`, `INCLUSIVE`, `PARALLEL`, `EVENT_BASED`, `PARALLEL_EVENT_BASED`) por la etiqueta de la figura; ausente si la figura no la trae.
- Incluye lo de 12.1.1 / 0.10.1 (Capa de Tópicos por grupo de la figura MQ, SRV-006 sin el principal de E3, corpus de pruebas actualizado). Estas versiones intermedias no se entregaron; los entregables son `BlueprintEvidenceStudio-v0.11.0.html`, `validar-blueprint-integracion-v12.2.0.zip` e `INSTRUCCIONES-AGENTE-v12.2.0.md`. 177 pruebas pasan.

## Skill 12.1.1 y Studio 0.10.1 (intermedia, no entregada) — 24/11/2026

- **Capa de Tópicos por grupo (corrección):** `inventory.servicios[].capaTopicos` ya no depende solo de que la capa contenga al servicio. Si el servicio tiene MQ en la figura (cualquier etiqueta: `OWN_UMG_MQ_SERVICE`, `THIRD_PARTY_MQ_SERVICE`, `OWN_MG_MQ_SERVICE_*`…), la capa `TOPIC_LAYER` del mismo grupo de la figura (que reúne la capa, el grupo `SERVICE` y, si existe, el auxiliar) se asocia al servicio (`asociadaPor: GRUPO`). Con más de una capa de tópicos en el grupo: `capaTopicos: null` + `capasTopicosCandidatas` (ambiguo, `No verificable`). Las capas de despliegue no cuentan. Caso real: BP Deposit Account Tax Exemption Information, servicio `consultar_marcacion_gmf_cuenta_sti`.
- **SRV-006:** la población excluye el servicio principal de E3 (solo servicios invocados con MQ en la figura); texto, ficha y tests alineados.
- **Corpus de pruebas:** se agregó el BP «Deposit Account Tax Exemption Information (5)» (página «Page 3» = plantilla de la biblioteca, `TEMPLATE_OR_LEGEND`, no se evalúa). Los tres tests de conteo del corpus se actualizaron al corpus actual (34 BP, 61 páginas evaluables: 35 con escenario, 5 páginas de BP antiguos sin etiquetas y sin hijo certificado). 175 pruebas pasan.
- Entregables: `BlueprintEvidenceStudio-v0.10.1.html`, `validar-blueprint-integracion-v12.1.1.zip`, `INSTRUCCIONES-AGENTE-v12.1.1.md`.

## Skill 12.1.0 y Studio 0.10.0 — 24/11/2026

Desde el 24/11/2026 la línea que se probó aparte (`blueprint-evidence-studio-nueva`, versiones con sufijo `-nueva.1`) está fusionada en esta carpeta (`blueprint-evidence-studio-snapshot`); la versión anterior (Studio 0.8.3, Skill 11.8.7) queda en `../blueprint-evidence-studio-snapshot-respaldo-2026-11-24-antes-de-12.1.0.zip`. Numeración: Skill 12.1.0 (12.0.0 ya se había entregado; la regla SRV-006 y los cambios de la tercera sección son un cambio menor) y Studio 0.10.0 (funciones nuevas en el inventario y en la interfaz). Decisiones de la analista del 19/11/2026:

- **Sexta tanda (24/11/2026, pedido de la analista para su entrega):** (HTML) nombre principal «Blueprint Evidence Studio», encabezado negro con el logo en la esquina superior derecha (dibujado en el HTML, sobre un recuadro blanco) y la versión solo en el pie; se quitan «candidato» y «Explicación factual y trazabilidad · motor · contrato»; subtítulo «Del dibujo a la evidencia» con la descripción de la herramienta; la lista de páginas solo muestra las OPERATIONAL y MIXED (no aparecen Escenarios BDD ni TEMPLATE_OR_LEGEND); las líneas con un extremo suelto indican el tipo y el texto de la figura que sí está conectada (por ejemplo «Compuerta exclusiva «¿Cliente válido?» (id)», «Comando sin consumo «…»»). (Skill) el escenario se escribe E1 (API directo al backend), E2 (API con servicio de integración) y E3 (Servicio no gestionado); API-003 y SRV-003 aceptan la tercera sección vacía (o con cualquier texto) en SISTEMAS EXTERNOS; nueva regla SRV-006 (servicio consumido por colas, figura con MQ: Capa de Tópicos y tópicos escritos, sin plantilla). Catálogo: 38 reglas. (Studio) `inventory.servicios[]` trae `consumidoPorColas` y `capaTopicos {id, topicos}` para las figuras MQ; un contenedor con la etiqueta `TOPIC_LAYER` se certifica como Capa de Tópicos aunque no contenga eventos.
- **Biblioteca BlueGuard (3) y Excel de equivalencias (quinta tanda):** sin cambios de reglas de ubicación (la columna Ubicación del Excel se omite; rigen CNT-003/004/005 como están). `USER_TASK` no se permite en el blueprint. `MODEL_GROUP` se permite en INTEGRACIÓN, DOMINIO PRODUCTOR y SISTEMAS EXTERNOS (el Studio no lo lee). `SERVICE` y `SERVICE_MCI` certifican servicio: un `RectangleContainerBlock` con la etiqueta `SERVICE` es candidato a hijo aunque no tenga compuertas y actividades (`src/containment.js`). Las palabras Partner, Public y Private se siguen validando en las reglas aunque se quiten de la figura.
- **API-001 (API interna):** `Nombre Producto - Nombre API_vMayor.Menor.Parche`; la versión lleva guion bajo previo (el espacio ya no vale), `v` o `V`, tres segmentos. Es API externa (`THIRD_PARTY_API`, SISTEMAS EXTERNOS) solo la ubicada en SISTEMAS EXTERNOS: basta un nombre real y no de plantilla. Toda otra API es interna y exige nombre, operación (API-002) y tercera sección (API-003).
- **API-003, SRV-003, EVT-003:** la tercera sección ya no distingue mayúsculas y minúsculas; los valores permitidos no cambian (`private|public|partner - entidad|utilidad|tarea`; `Aplicacion|Empresarial - Query|Command|Event`, sin tildes).
- **Comandos:** el Studio certifica el comando por la etiqueta de la figura (`SERVICE_TASK`, `SYSTEM_TASK`, `SUB_PROCESS`, `USER_TASK`; `COMMAND_BY_CUSTOMDATA`, `DECLARED_BY_CUSTOMDATA`) y expone `tipoComando` en `inventory.comandos` y en los participantes de `relaciones` (más `figura` y `etiquetas` de las figuras sin tipo con etiqueta). Sin etiqueta sigue valiendo la inferencia por conexión.
- **COM-001:** `SERVICE_TASK` y `SYSTEM_TASK` con verbo en infinitivo; `SUB_PROCESS` con el sustantivo de la acción («Autenticación del cliente»).
- **COM-006 (nueva):** todo `SERVICE_TASK` debe tener relación con una API, servicio, gestor de colas o auxiliar (sin ella, No cumple). **COM-007 (nueva):** `SYSTEM_TASK` y `SUB_PROCESS` solo se conectan con comandos, compuertas y eventos BPMN, y solo con `None`/`Arrow`; no con API, servicios, colas, eventos de integración, auxiliares, modelos, políticas, mensajes de excepción, conceptos ni anotaciones.
- **CNT-003 y CNT-004:** `USER_TASK` no se permite en el hijo de INTEGRACIÓN ni de DOMINIO PRODUCTOR.
- **Anidamiento:** sin cambio; si una figura no viene anidada se sigue con lo construido (el Studio no resuelve la jerarquía por etiqueta todavía).
- Catálogo: **40 reglas** (38 + COM-006 y COM-007). Instrucciones del agente `dist/INSTRUCCIONES-AGENTE-v12.1.0.md`, ZIP `dist/validar-blueprint-integracion-v12.1.0.zip` y HTML `dist/BlueprintEvidenceStudio-v0.10.0.html`.
- **Segunda tanda (20/11/2026):** `SUB_PROCESS` solo valida que inicie con sustantivo (COM-001). Se fusiona EXT-002 en CNT-003, CNT-004 y CNT-005 (ubicación del auxiliar y de todo lo que encapsula, incluido EVC/EPC/LDC); EXT-001 queda solo para el nombre (mismo ID). Regla nueva **GEN-001** (en el archivo 01): la operación del componente principal debe ser exactamente igual al nombre de la página, en E1, E2 y E3. MQ-003: el evento de mensaje con un gestor de colas no exige conexión y, si la hay, es en un solo sentido (hacia o desde el gestor); una señal no se conecta con un gestor. EVT-007: las señales solo se usan con eventos de integración. Catálogo: 40 reglas (−EXT-002, +GEN-001, +COM-006, +COM-007).
- **Motor 0.10.0:** política, excepción y concepto se clasifican como modelos por etiqueta (`MODELO`, `tipoModelo` `POLITICA|EXCEPCION|CONCEPTO`, `MODEL_BY_CUSTOMDATA`); el subtipo del evento BPMN se certifica por etiqueta (`inventory.eventosBpmn[].subtipo`, `subtipoEvento` en los participantes: START, END, EVENT, EXCEPTION, SIGNAL_SEND, SIGNAL_RECEIVE, MESSAGE_SEND, MESSAGE_RECEIVE), también para el Inicio de E1, E2 y E3.
- **HTML 0.10.0:** el JSON enriquecido y el de diagnóstico no se generan si alguna conexión tiene un extremo suelto o terminaciones distintas de None-Arrow, Arrow-None, CircleOpen-Generalization y Generalization-CircleOpen (`connectionBlockers`); el aviso nombra la línea y las figuras. Las líneas que tocan una anotación quedan exentas. Con los ejemplos actuales, 26 de 57 páginas operativas quedarían bloqueadas por extremos sueltos. No se probó en navegador (las pruebas de Playwright necesitan Edge, que no está instalado); la lógica sí tiene pruebas unitarias.
- **Tercera tanda (20/11/2026):** MOD-002 nueva (modelos sin texto de plantilla: «modelo de entrada», «modelo de lectura», «modelo de salida», «política», «excepción de negocio», «concepto»; vacío también incumple). Políticas, mensajes de excepción, conceptos y anotaciones se permiten también en el nivel padre de INTEGRACIÓN, DOMINIO PRODUCTOR y SISTEMAS EXTERNOS. Un auxiliar EVC, EPC o LDC puede encapsular API, servicios y eventos de integración y, si encapsula alguno, debe estar en el nivel padre de INTEGRACIÓN (con la excepción ya vigente de solo eventos Aplicación en el DOMINIO PRODUCTOR). La figura `THIRD_PARTY_API` manda: es API externa (nombre real, sin las tres secciones) y no puede estar en INTEGRACIÓN (CNT-003). EVT-003 acepta `Aplicación` con o sin tilde. GEN-001 aclara que la operación y la página son camelCase. El Studio expone `figuraBiblioteca` (etiqueta del grupo raíz) y `figura` en las listas del inventario. HTML: `None`–`None` es un conector válido. Catálogo: 41 reglas.
- **Cuarta tanda (20/11/2026):** COM-002 a COM-006 se fusionan en una sola regla, **COM-002 «Conexiones del SERVICE_TASK»** (existencia + bidireccionalidad `CircleOpen`/`Generalization` con API, servicio, gestor de colas y auxiliar); COM-007 pasa a **COM-003**. Catálogo: **37 reglas** (COM = COM-001, COM-002, COM-003). El HTML solo bloquea el JSON por conectores con un extremo suelto: las terminaciones no permitidas no bloquean (las evalúan las reglas) y las líneas None–None y de anotaciones quedan exentas. La ubicación en SISTEMAS EXTERNOS se aplica a las figuras `THIRD_PARTY_API`, `THIRD_PARTY_SERVICE` y `THIRD_PARTY_MQ_SERVICE` (en INTEGRACIÓN incumple CNT-003; en el PRODUCTOR, CNT-004). Pendiente: la analista revisa la lista de BP con la capa que no contiene al hijo.
- Pendiente de la analista (sin decidir):
- Pruebas: 161 (`test/v090comandos.test.js` nueva; contadores de 40 reglas). La línea base del JSON de los BP antiguos no cambia (se normaliza solo la versión). Fallan 3 pruebas de conteo del corpus que ya fallaban en la estable porque `Blueprints_ejemplos` creció (Aumento de cupo, Credit Card Security Code, etc.), no por esta versión.

## Skill v11.8.7, formato de la pregunta agrupada por API (candidato) — 08/11/2026

- Procedimiento 5.4 y SKILL.md: la pregunta agrupada lleva el nombre de la API una sola vez y los ids de las páginas afectadas juntos, «Nombre (id1 y id2)», sin repetir el nombre por página ni nombrar la operación; plantillas para la pregunta MCI («Responde Sí o No… se aplicará a todas las páginas indicadas») y la de exposición. Propuesta de la analista tras probar 11.8.6 con Sufi Loan Modification.
- Instrucciones del agente v11.8.7, ZIP `validar-blueprint-integracion-v11.8.7.zip` y prompt maestro v2 (línea de alineación). `SKILL_VERSION` 11.8.7. Studio, HTML y contrato sin cambio.
- Pruebas: 156 (`test/v086preguntas.test.js`).

## Skill v11.8.6, preguntas MCI por API y aclaración del contenido de las capas (candidato) — 08/11/2026

- Preguntas (procedimiento 5.4 y 5.5, SKILL.md pasos 4, 6 y 7, MANIFEST): la condición MCI de la API y la exposición se preguntan una sola vez por nombre de API (primera sección con versión, sin distinguir mayúsculas, tildes ni espacios) aunque el BP tenga varias páginas; el hijo de E2 se pregunta por cada hijo; en E1 no se pregunta por el hijo (se da por no MCI, `SUPUESTO_E1_HIJO_NO_MCI`) y en E3 no hay preguntas. Decisión de la analista (ADR-0019).
- SRV-004: el hijo de E1 se evalúa como no MCI (Cumple sin Capa ni Flujo asociados; No cumple si tiene alguno; un par Capa-Flujo sin propietario en el DOMINIO PRODUCTOR lo deja No verificable). Ya no depende de la declaración MCI en E1.
- CNT-003, CNT-004 y CNT-005 (procedimiento §1 y fichas): las capas de despliegue no son un nivel; un componente con `ubicacion.capaId` se evalúa con su `ubicacion.nivel` (`PADRE`); `nivel: OTRO` (contenedor intermedio sin tipo) es No verificable (decisión de la analista, caso Sufi Loan Modification).
- Instrucciones del agente v11.8.6 y prompt maestro v2. ZIP `validar-blueprint-integracion-v11.8.6.zip`. `SKILL_VERSION` 11.8.6.
- Studio, motor, contrato (0.8.3 / `copilot-factual-v0.4.6.1`) y HTML sin cambio. La regla de E1 con el dominio del hijo sin nombre y el aviso de principal sin contenedor siguen pendientes.
- Pruebas: 155 (`test/v086preguntas.test.js`; textos de `v060`/`v080` actualizados; conteos del corpus de `v048`/`v1131` por los BP nuevos Sufi Loan Modification, Second Security Factor Information y Merchandising Loan: 28 páginas evaluables, 2 sin escenario).

## Studio 0.8.5, unicidad con principal de plantilla y aviso de flechas sueltas (candidato) — 04/11/2026

- Motor (`classifyPage`): si ninguna API/servicio con nombre propio tiene línea certificada a un evento, pero **una sola** API/servicio con nombre de plantilla la tiene (`VERIFIED_BY_TERMINATIONS`, API_OR_SERVICE → BPMN_EVENT) y la página tiene otras APIs/servicios con nombre propio, la página es operativa (MIXED si hay leyenda, OPERATIONAL si no) y `pageClassification` trae `placeholderMainAccepted: true`. El nombre de plantilla lo juzgan las reglas de la Skill («diferentes de textos de plantilla»), no el clasificador (ADR-0018).
- Límites que no cambian: dos principales de plantilla conectados a eventos (sin unicidad), línea no certificada y plantilla en blanco (sin otras APIs/servicios con nombre propio) siguen como `TEMPLATE_OR_LEGEND`; si existe un principal con nombre propio, la ruta operativa es la de siempre.
- Corpus: cambian 3 páginas (Access Entitlement `retrieveInformationDetail` → MIXED; Ejemplo_BP `API-ServicioIntegracion` y `API-Backend` → OPERATIONAL). Las 8 plantillas vacías y Deposit Account no cambian. La línea base de invariancia pasa sin tocarla.
- Interfaz: aviso informativo amarillo que **no bloquea** con las flechas de flujo que tienen un extremo sin figura (parecen conectadas en el SVG pero no lo están). Se calcula sobre el resultado exportado; no cambia el JSON.
- Pruebas: 152 (corpus actualizado; nuevas en `test/v083aviso.test.js` y `test/v084bloqueo.test.js`). Motor y contrato siguen en 0.8.3; interfaz 0.8.5.
- Entregable: `docs/validacion_skill_analista/BlueprintEvidenceStudio-v0.8.5-unicidad.html`.

## Studio 0.8.4 (interfaz), el JSON solo se genera si todas las páginas seleccionadas son MIXED u OPERATIONAL (candidato) — 04/11/2026

- Interfaz: `blockingPages` ahora bloquea cualquier página seleccionada cuya clasificación no sea `MIXED` u `OPERATIONAL` (antes solo `TEMPLATE_OR_LEGEND`; `UNRESOLVED` y `BDD_OR_REQUIREMENTS` pasaban si había otra MIXED). Con una sola página así, no se habilita ninguna descarga.
- El aviso naranja ya no explica la causa: dice que la página está catalogada como TEMPLATE_OR_LEGEND, UNRESOLVED o BDD_OR_REQUIREMENTS, que por eso no se permite generar el JSON y que se puede desmarcar la página o corregir el BP (ADR-0017). `reason` y `reasonDetail` siguen en el JSON de las páginas plantilla.
- Motor y contrato sin cambio (0.8.3); JSON descargable idéntico (línea base de invariancia sin tocar). El HTML y el pie se rotulan 0.8.4.
- Pruebas: 145 (5 nuevas en `test/v084bloqueo.test.js` con el BP Access Entitlement Features Information; conteos del corpus de `test/v048.test.js` y `test/v1131.test.js` actualizados: +1 página MIXED, +5 servicios invocados, +2 marcadores).
- Entregable: `docs/validacion_skill_analista/BlueprintEvidenceStudio-v0.8.4-bloqueo.html` (los anteriores se conservan).

## Studio 0.8.3, interfaz con aviso de páginas no evaluables (candidato) — 03/11/2026

- Interfaz: si una página seleccionada queda como `TEMPLATE_OR_LEGEND`, el Studio muestra un aviso naranja (`role="alert"`) con la causa y lo que debe corregir la analista en Lucidchart, y **deshabilita** «Descargar JSON enriquecido» y «Descargar diagnóstico» hasta que todas las páginas seleccionadas queden evaluables. Imprimir sigue habilitado.
- Motor: `pageClassification` de una página `TEMPLATE_OR_LEGEND` trae `reason` y `reasonDetail` (`TEMPLATE_EMPTY`, `PLACEHOLDER_MAIN`, `API_EVENT_LINE_NOT_VERIFIED`, `NO_API_EVENT_LINE`; líneas sin verificar y líneas que llegan a un evento sin origen pegado). Solo describe: la clasificación no cambia. Las páginas operativas no traen esos campos, por lo que el JSON descargable es idéntico (línea base de invariancia sin cambios).
- No se cambió el criterio de clasificación ni se infirió escenario sin conexión certificada (ADR-0016). Versión del motor sin cambio (0.8.3) porque las instrucciones del agente 11.8.5 la citan; el HTML lo identifica en el pie.
- Pruebas: 140 (7 nuevas en `test/v083aviso.test.js`; `test/v048.test.js` actualizado por el BP Deposit Account Pocket Transaction Information, agregado al corpus el 03/11).
- Entregable: `docs/validacion_skill_analista/BlueprintEvidenceStudio-v0.8.3-aviso.html` (el v0.8.3 anterior se conserva).

## Skill v11.8.5 (candidato) — 03/11/2026

- Skill: SRV-005 aplica solo a servicios invocados. El servicio principal de E3 y el hijo principal quedan fuera: la línea del principal hacia el evento de Inicio (`scenario.connection`) la evalúa solo E3-001 y las demás conexiones del principal no las evalúa SRV-005. La prohibición servicio–evento se conserva para servicios invocados. Antes, la ficha mandaba toda pareja `EVENTO_BPMN+SERVICIO` a SRV-005 sin mirar el rol y el agente daba No cumple en ms_account (register y retrieve).
- Alineado en los cuatro lugares que tocan la regla: `02-reglas-api-servicios.md` (SRV-005), `08-fichas.md` (tabla de parejas y ficha), `00-procedimiento.md` (apartado 6.1 y lista de servicios) y `05-reglas-escenarios.md` (E3-001). Las instrucciones del agente no mencionan SRV-005 y solo cambian de versión. Studio sin cambios (0.8.3): `scenario.mainComponentId` y `scenario.connection` ya vienen en el JSON.
- Pruebas: 133 (nueva: SRV-005 coherente entre regla, fichas, procedimiento y E3-001). Corpus: solo 2 páginas E3 y 2 parejas servicio–evento, ambas del principal.

## Skill v11.8.4 (candidato) — 03/11/2026

- Skill: API-003 en SISTEMAS EXTERNOS (directamente o dentro de un auxiliar de ese dominio) acepta `entidad`, `utilidad` o `tarea`, solos o con otro texto y sin distinguir mayúsculas; esos valores ya no se consideran «genéricos». La tercera sección sigue siendo válida con información funcional, específica y distinta de una plantilla. En INTEGRACIÓN (incluido un auxiliar dentro de INTEGRACIÓN) no cambia: `private`/`public`/`partner` más `entidad`/`utilidad`/`tarea`, en minúsculas y con un solo guion.
- Studio sin cambios (0.8.3); solo cambia la Skill, las instrucciones del agente (etiqueta de versión) y el nombre del ZIP.
- Pruebas: 132 pasan.

## Skill v11.8.3 / Studio 0.8.3 (candidato) — 03/11/2026

- Studio: el nombre de una figura es el primer texto no vacío entre Title, Text y FloatingTitle. Corrige el hijo principal, cuyo nombre iba en `Text` y salía vacío (CNT-002 daba No cumple sin razón). Afectó a 38 páginas del corpus.
- Studio: los contenedores ya no traen `operation`.
- Skill: la ficha de CNT-002 indica `serviciosHijo[].name` como nombre del hijo.
- Comparado con la versión anterior sobre las 90 páginas del corpus: solo cambian esos campos.

## Skill v11.8.2 / Studio 0.8.2 (candidato) — 03/11/2026

- Skill: la exposición de la API principal se homologa solo para decidir la pregunta (`privada` a `private`, `pública` a `public`, `partner` sin cambio). Con `private`, `public` o `partner` en inglés no se pregunta; sin ninguno, se pregunta siempre. API-003 no cambia.
- Skill: API-004 es Cumple si la API principal tiene resueltas por contención directa las Capas que su exposición exige, aunque existan otras Capas, Flujos o parejas sin propietario.
- Studio/Skill: `contiene.ACTIVIDAD_SIN_TIPO` en los contenedores; en EXT-001 una actividad BPMN sin tipo dentro del auxiliar deja la regla No verificable.

## Skill v11.8.1 / Studio 0.8.1 (candidato) — 02/11/2026

- Studio: las descargas pasan a una tarjeta propia antes de «Resultado factual».
- Studio: nuevo tipo `CAPA_TOPICOS` (contenedor UML que contiene directamente un evento de integración certificado); candidata `["CAPA_TOPICOS"]` si solo contiene un candidato a evento. Nuevo `inventory.capasTopicos` (tópicos y `eventoIds`) y `ubicacion.capaTopicosId` en el evento; el nivel del evento deja de ser `OTRO`.
- Skill: la exposición de la API principal se pregunta siempre que su tercera sección no la traiga; no modifica API-003.
- Skill: sin preguntas aplicables (por ejemplo E3) se continúa con las 38 reglas sin esperar confirmación.

## Skill v11.8.0 / Studio 0.8.0 (candidato) — 02/11/2026

- Studio: la leyenda de notación y los bloques de descripción de API («Descripción Operación», «Método», «Path», «Seguridad») no se exportan en ninguna parte del JSON enriquecido; `pageClassification.legendShapeIds` desaparece. Antes salían completos (de 38 a 51 figuras de leyenda por página y el bloque de descripción en 20 de 22 páginas del corpus).
- Studio: el hijo es solo el contenedor del hijo principal. Antes cualquier rectángulo plano se tomaba por hijo y se ocultaban los bloques del DOMINIO PRODUCTOR que lo envuelve (TXN 0026 y TXN0011 en Debit Card) y los de INTEGRACIÓN con nombre suelto.
- Studio: todo `BPMNGroup` dentro de un dominio es sistema externo auxiliar, con o sin texto (EXT-001: sin nombre, No cumple).
- Studio: evento de integración exige tipo (Aplicación o Empresarial) y clasificación (Event, Query o Command); con una sola parte es candidato `["EVENTO_INTEGRACION"]`.
- Studio: auxiliar EVC, EPC o LDC en INTEGRACIÓN o SISTEMAS EXTERNOS: el bloque sin otra señal es API (`API_BY_EVC_AUXILIAR`); la señal explícita de servicio (`ms`, `TIPO: SERVICIO`) va antes. El conteo de marcadores rige en cualquier otro ámbito, también en el nivel padre aunque el dominio tenga auxiliares; sin marcadores en el ámbito, servicio, también con Entidad, Utilidad o Tarea. Un bloque suelto en el nivel padre con un marcador huérfano en el dominio es candidato `["API","SERVICIO"]`. Sin dominio, el ámbito es el contenedor raíz.
- Skill: un candidato o pendiente en la población deja la regla en `No verificable` por encima de cualquier certificado, también en CNT-003, CNT-004 y CNT-005; CNT-004 nombra que no hay API en el productor; `Reconocimiento de tipos` reescrito; se quita la instrucción de excluir `legendShapeIds`; el informe cita «Nombre (id)» en el resumen, las justificaciones y las recomendaciones.
- Instrucciones del agente: recortadas a lo que la Skill no dice (1038 caracteres).
- Pruebas: la línea base de `ui-contract-invariance` se rehace con la salida de 0.8.0 y se retira la comprobación de invariancia contra 0.6.0, que ya no aplica. Corpus (11 BP): 88 API, 44 servicios, 5 eventos certificados y 11 candidatos (antes 84, 33, 5 y 16).
- HTML: se quita el campo «ID Blueprint» (solo queda «Nombre Blueprint»); `metadata.blueprintId` sale `null`. El JSON de diagnóstico no cambia: la analista usa solo «Descargar JSON».
- El HTML sigue sin evaluar reglas.

## Skill v11.7.0 / Studio 0.7.1 (candidato) — 02/11/2026

- Studio: `relaciones[].par` (tipos de los dos participantes, candidato con sus tipos posibles); `compuertas[]` con `conTexto` y `caminos` (línea, destino, etiqueta); `ubicacion` (dominio, nivel, contenedor, padre, auxiliar, capa) en apis, servicios, eventos de integración, gestores, comandos, hijos, auxiliares y candidatos; `nombres` (id a nombre legible, también de líneas); `posiblesTipos` en los candidatos de relaciones y pendientes.
- Skill: `08-fichas.md` con orden fijo (candidatos y pendientes primero), reglas de citación «Nombre (id)», tabla de parejas por `par` y decisión de GW-001, COM-004, COM-005, MQ-002, EXT-001, API y SRV por filtros del inventario. Apartado 6 remite a esa tabla; apartado 8 salta a No verificable al hallar un candidato o pendiente.
- Studio: regla única de marcadores de API en cualquier auxiliar (con o sin EVC/EPC/LDC) y en el nivel padre de INTEGRACIÓN o SISTEMAS EXTERNOS sin auxiliares: marcador agrupado o conteo igual certifica API; conteo distinto deja candidatos; sin marcador y sin Entidad/Utilidad/Tarea ni plantilla, servicio (`SERVICE_BY_NO_MARKER_IN_SCOPE`). En los 11 blueprints de ejemplo cambian ms_account (Wenia) y Escenario2_Original (REUSO 1 API y REUSO 3 API).
- Instrucciones del agente: piden citar figuras como «Nombre (id)».
- El HTML sigue sin evaluar reglas.

## Skill v11.6.0 / Studio 0.7.0 (candidato) — 02/11/2026

- Studio: `inventory` completo por página (`contenedoresPadre`, `capas`, `flujos`, `federados`, `compuertas`, `eventosBpmn`, `modelos`, `contenedores`, `relaciones`, `conexionesPendientes`, `omitidos`). Solo hechos, sin reglas; los demás campos del JSON compacto no cambian (prueba de aditividad contra la línea base 0.6.0).
- Studio: `modelAssociation` por API y servicio (`EXPLICIT_GROUP`, `BY_COUNT`, `MISSING_IN_SCOPE`, `AMBIGUOUS`) con conteo por ámbito (cualquier auxiliar con sus capas y flujos, o el contenedor padre); los modelos dentro del hijo no cuentan.
- Skill: nueva `08-fichas.md` (población de cada regla por clave del inventario); procedimiento con apartado 6 (precedencia de conexiones, conexión pendiente, lectura de una pareja) y apartado 8 (doctrina de estados en un solo lugar). Se eliminan las 31 repeticiones de «prevalece No cumple» de las reglas y el signo § del texto.
- Reglas: una conexión con comando nunca va a SRV-005 ni a MQ-003; conexión pendiente = candidato (No verificable); MOD-001 por `modelAssociation`; CNT-001 acepta INTEGRACIÓN repetido; CNT-005 sin contenedor EXTERNAL_SYSTEM es No aplica; SRV-004 con hijo no MCI sin capas es Cumple.
- Instrucciones del agente: 1.458 caracteres; remiten a `SKILL.md` en lugar de repetir la Skill.
- El HTML no evalúa reglas: solo versión y el JSON enriquecido ampliado.

## Skill v11.5.0 / Studio 0.6.0 (candidato) — 02/11/2026

  - Respuestas de la analista a los resultados de Copilot de 6 blueprints. Contrato `copilot-factual-v0.4.6.1` sin cambios; las conexiones (COM, MQ, SRV, EVT) no se tocan.
  - Marcador de API (corrige el defecto de 0.5.0): un BPMNEvent vacío y sin conexiones dentro de un auxiliar, grupo o capa ya es `MARCADOR_API`; dentro del hijo es `EVENTO_BPMN` (antes `EVENTO`). En un auxiliar con EVC, EPC o LDC como palabra completa (también en sus capas y flujos), si los eventos vacíos igualan a los bloques UML sin tipo, los bloques son API (`API_BY_MARKER_COUNT_IN_AUXILIAR`) y los eventos se omiten (`API_MARKER_EVENT`).
  - Nuevas inferencias del Studio: tipo Public, Private, Partner, Privada o Pública en la tercera sección ⇒ API (`API_BY_EXPOSURE_TYPE`); la palabra `microservicio` o `microservice` ⇒ servicio; bloque sin tipo en el nivel padre o auxiliar del productor ⇒ servicio (`SERVICE_BY_PRODUCER_DOMAIN`); `BPMNGateway` ⇒ `COMPUERTA`; `BPMNActivity` conectada a una API, un servicio, un gestor, un auxiliar o un candidato ⇒ `COMANDO`.
  - Prioridad: evento de integración (tercera sección) > servicio (ms, microservicio, `customData`) > API > servicio por dominio productor > candidato.
  - Candidatos: `possibleTypes` pasa de `["SERVICIO"]` a `["API","SERVICIO"]` (sin señal fuera del productor, solo Entidad/Utilidad/Tarea o auxiliar EVC/EPC/LDC sin coincidencia); `["EVENTO_INTEGRACION"]` para el título exacto «Nombre Evento»; `["GESTOR_COLAS"]` para figuras que no son gestor con cola(s), MQ, Kafka o Rabbit en el nombre. Dentro del hijo no hay candidatos.
  - Roles: solo `PRINCIPAL` e `INVOCADO`. Desaparece `HIJO_PRINCIPAL`: el hijo principal es `INVOCADO` (CNT-002 ajustada). Los candidatos y los gestores también.
  - Cada página lleva `inventory` (APIs, servicios, eventos de integración, gestores, comandos, auxiliares, hijo, marcadores y candidatos) y las instrucciones piden declararlo antes de evaluar.
  - Cierre con candidatos (cambia la doctrina): con al menos un candidato en la población de la regla el estado es `No verificable` aunque haya un incumplimiento certificado, que se cita en la justificación. Se añade la excepción a cada «prevalece No cumple» de la Skill y se corrige la línea 35 de las instrucciones.
  - EXT-001 vuelve a permitir modelos de entrada y salida (se había omitido al adoptar el borrador de la analista) y añade capas y eventos de integración; un auxiliar EVC/EPC/LDC no puede encapsular servicios. EXT-002: un auxiliar EVC/EPC/LDC con eventos de integración de tipo Aplicación también puede estar en el productor; un auxiliar sin esas palabras en INTEGRACIÓN no incumple. SRV-004: en E1 con el hijo no MCI, un par sin propietario en INTEGRACIÓN no es del hijo.
  - Pruebas: 112. Líneas base de invarianza regeneradas.

## Skill v11.4.0 / Studio 0.5.0 (candidato) — 29/10/2026

  - Marcador de API huérfano. El Studio clasifica como `architecturalType: MARCADOR_API` (regla `API_MARKER_BY_ORPHAN_EMPTY_EVENT`) el BPMNEvent sin texto, sin conexiones, sin `customData`, fuera de todo grupo y sin contenido, ubicado fuera del hijo principal en el nivel padre de INTEGRACIÓN o de SISTEMAS EXTERNOS (también dentro de una Capa o un Flujo). Por decisión de la analista permanece en el inventario —el agente debe verlo— en lugar de omitirse; solo el marcador que comparte grupo con su API sigue omitido (`omittedComponents`, `API_MARKER_EVENT`). Corpus: exactamente un marcador por página con API principal (15 páginas); los eventos agrupados del flujo del hijo no se clasifican.
  - Nueva regla SRV-005 «Conexiones del servicio con API, servicios y auxiliares» (catálogo 37 → 38 reglas; métrica y conteos por página actualizados): un servicio puede relacionarse con varias API, servicios o auxiliares y un participante puede recibir varias relaciones; cada relación exige dos conexiones (una por sentido) con `CircleOpen` en el origen y `Generalization` en el destino; sin conexiones de ese tipo → No aplica. Válidas: servicio-servicio, servicio-API y servicio-auxiliar (aunque encapsule API o servicios), siempre bidireccionales; servicio-evento no se permite (No cumple); servicio-gestor sigue en MQ-003; API-API no se evalúa. Excluye comandos (COM-002/003/005).
  - CNT-003, CNT-005 y EXT-001 se simplifican (audio de la analista: «no hay que ser tan específico»): una sola cláusula «Marcador de API» reemplaza la lista de condiciones de candidato. El componente `MARCADOR_API` se permite en el nivel padre de INTEGRACIÓN, SISTEMAS EXTERNOS y auxiliares sin generar incumplimiento ni incertidumbre; con conexiones, texto funcional o subtipo operativo sigue siendo evento operativo. Se conservan las cláusulas del texto anterior sobre eventos de integración en auxiliares, contenedores candidatos y revisión manual. Longitudes: CNT-003 5 672→4 487 caracteres, CNT-005 4 911→4 339, EXT-001 5 698→3 825.
  - API-004 se condensa (5 710→3 439 caracteres) conservando la decisión de la analista: una Capa, un Flujo o una pareja sin propietario es candidata y produce No verificable aunque encierre un evento BPMN u otra figura; No cumple exige ausencia demostrada. El procedimiento (§4.1) indica que una Capa o Flujo que solo encerraba un marcador omitido queda sin propietario.
  - COM-002, COM-003 y COM-005: varios comandos distintos pueden relacionarse con el mismo destino; cada pareja se evalúa por separado y el total de conexiones no es motivo de incumplimiento (ejemplo: ms_Notificaciones en Investment Product Opening, 8 conexiones = 2 comandos × 2 sentidos + 2 API × 2 sentidos). El procedimiento declara permitidas, y no evaluadas por ninguna regla, las conexiones directas entre API, servicios y auxiliares.
  - Prueba con el agente real (Real Time Payments, `updateInformationKey`): cuatro reglas cerradas mal en la primera pasada (API-004 y MOD-001 como No cumple, CNT-005 como Cumple, COM-003 como No aplica) por tratar candidatos pendientes como ausencia. Cambios: sección «Cómo cerrar cada regla» en las instrucciones (No aplica solo sin población ni candidatos; No cumple por ausencia solo con cobertura completa y sin candidatos; cualquier candidato → No verificable; los modelos se buscan en `groups` y `modelIds`; justificar los candidatos descartados); se retira el «normalmente» de la precedencia; el marcador `MARCADOR_API` sale de `candidateIds` de la pareja Capa-Flujo y consta en `markerIds` (es contenido, no dueño); se recortan de las instrucciones las repeticiones de reglas (Federado, comandos, fórmula, dominios).
  - Reconocimiento del servicio (decisión de la analista, opciones A y B). B: `customData` `TIPO: SERVICIO` (o `ARCHITECTURAL_TYPE`) en un bloque UML certifica el servicio (`SERVICE_BY_CUSTOMDATA`, estado `DECLARED_BY_CUSTOMDATA`); con marcador de API es contradicción. A: el bloque UML sin marcador ni `ms` con tercera sección Entidad, Utilidad o Tarea lleva `possibleTypes: ["SERVICIO"]` y `inference.status: CANDIDATE_NOT_CERTIFIED` (antes mostraba una inferencia por convención de nombres sin evidencia con tipo `null`); no certifica, porque esa sección también la usan las API (32 API del corpus). Las reglas de servicio lo tratan como candidato pendiente. Corpus: 11 candidatos.
  - Skill e instrucciones pasan a v11.4.0 (38 reglas). Pruebas: 102. Corpus actualizado con Investment Product Opening (20 páginas evaluables).

## Studio 0.5.0 (candidato) — 29/10/2026

  - La interfaz ya no pide SVG: solo ID Blueprint, Nombre Blueprint, el JSON de Lucidchart y la selección de páginas. Decisión de la analista tras verificar que el motor nunca leyó el SVG.
  - El JSON enriquecido ya no lleva `metadata.svgEvidence` (ninguna regla de la Skill lo consumía). Contrato `copilot-factual-v0.4.6.1` sin cambios en el nombre; el resto del JSON es idéntico: los cinco hashes de referencia coinciden con los de 0.4.9 al normalizar solo la etiqueta de versión.
  - Skill 11.3.3 sin cambios; las instrucciones solo citan Studio 0.5.0.

## Skill v11.3.3 (paquete de la analista v11.3.3) — 29/10/2026

  - Se adopta el texto definitivo de SRV-001..004 de la analista: SRV-001..003 distinguen servicio gestionado (en el nivel padre de INTEGRACIÓN) y no gestionado, incluido el servicio principal de E3; SRV-003 pasa a «Clasificación del servicio» (minúsculas); SRV-004 pasa a «Capa de Despliegue del servicio gestionado» (MCI o Federada, sin pregunta MCI a la analista). Los títulos se normalizan a nivel `###`.
  - La representación de la modalidad Federada, que SRV-004 dejaba pendiente, queda definida: figura con texto exacto `Federado` → `architecturalType: FEDERADO`; su pertenencia consta en `deploymentAssociations` con `modality: FEDERADO` (`federatedId`, estado `RESOLVED_BY_DIRECT_CONTAINMENT` por contención directa, o `PENDING_NO_CONTAINED_COMPONENT` si no contiene ningún API, servicio ni gestor). MQ-002, SRV-004, procedimiento (§4, §4.1) y MANIFEST lo referencian. La precedencia de asociaciones cubre también las figuras `Federado` pendientes.
  - Respuestas de la analista: SRV-004 vuelve a cubrir el hijo principal de E1 y E2 según la declaración MCI (MCI estricto, sin Federado: MCI → Capa de Arquitectura + Flujo Transaccional; no MCI → no debe tener ninguno de los dos, si los tiene No cumple; sin respuesta → No verificable) y los servicios invocados gestionados (MCI o Federada); quedan excluidos el servicio principal y el hijo principal de E3. Varios componentes dentro de un Federado se asocian cada uno por contención (confirmado). Solo son capas de despliegue las figuras `UMLRectangleContainerBlock` con texto `Federado`, `Capa de Arquitectura` o `Flujo Transaccional`: un texto suelto no se tipifica ni cuenta como candidato (motor: `shapeKind`).
  - Interfaz: el SVG pasó primero a «opcional» y en Studio 0.5.0 se retiró (ver arriba).
  - Studio 0.4.9 (candidato): `FEDERADO` como nuevo `architecturalType`; `federatedAssociations` en el análisis completo y entradas `modality: FEDERADO` en el JSON compacto (componente y página). Las asociaciones MCI no cambian. Nuevo ejemplo en el corpus: «Real Time Payments QR Keys Management» (3 páginas E1). Instrucciones del agente en 7 208 caracteres (límite de Copilot: 8 000); el detalle de inferencia se movió a un anexo fuera de la Skill.

## Skill v11.3.2 (paquete de la analista; v11.3.1 y v11.3.0 de la analista unificados) — 28/10/2026

  - Segunda validación con el paquete completo v11.3.0 de la analista: se adopta su texto de API-001..003 (población «Todas las API principales e invocadas… individualmente»), SRV-001..003 sin cambios respecto a v11.2.4, y la redacción detallada de API-004/SRV-004 combinada con la precedencia de asociaciones de despliegue (§4.1: candidatas pendientes impiden «No cumple»). Se restauran en el procedimiento y el manifiesto las frases de v11.3.0 que el paquete delta había comprimido. Sin cambios en el motor.
  - CNT-001 (E2): un contenedor sin clasificar cuyos únicos roles posibles son PRODUCTOR y/o SISTEMAS EXTERNOS satisface «PRODUCTOR o SISTEMAS EXTERNOS» (decisión de la analista); CNT-004 y CNT-005 quedan No verificable para ese contenedor. Aclarado que MOD-001 exige modelos al componente principal de E3 y no al hijo principal.
  - Precedencia de asociaciones (§4.1) ampliada a EVT-004 y EVT-005: un arreglo vacío en el componente no demuestra ausencia si `pages[].deploymentAssociations` tiene pares Capa-Flujo pendientes de propietario; la declaración MCI hace aplicable la obligación pero no demuestra la asociación, y una candidata pendiente da No verificable, no No cumple, salvo evidencia independiente de incumplimiento (caso reportado: hijo «credit limit operations» con `deploymentAssociations: []` evaluado como No cumple).
  - Studio 0.4.9 (candidato): en E1, igual que en E3, el productor es el dominio que contiene al hijo principal y los demás dominios sin nombre literal (con nombre propio o sin nombre, que no sean API principal, hijo, notación ni leyenda) se marcan `EXTERNAL_SYSTEM` con `roleSource: E1_ELIMINATION`. En E2 solo INTEGRACIÓN es seguro y el otro dominio sin nombre sigue con `possibleDomainRoles: [PRODUCER, EXTERNAL_SYSTEM]`.

El Studio sigue en 0.4.9 y el contrato en `copilot-factual-v0.4.6.1`. Se integra el paquete `paquete-ajustes-validar-blueprint-v11.3.1.zip`.

- **Reglas modificadas por la analista (15):** CNT-001 (E2 exige INTEGRACIÓN y PRODUCTOR o SISTEMAS EXTERNOS), CNT-002 (varios candidatos = incertidumbre; varios hijos certificados = incumplimiento), CNT-003/004/005 (eventos de integración dentro de auxiliares según dominio y nivel; Empresarial no se permite en PRODUCTOR; auxiliares permitidos en PRODUCTOR), EXT-001/002 (ubicación y contenido por nivel), API-004 y SRV-004 (precedencia de asociaciones), EVT-001/002/003 (modalidad para SISTEMAS EXTERNOS), EVT-007 (terminaciones del tópico de suscripción), MOD-001 (aplica también a API y servicios invocados) y MQ-001 (candidatos a gestor por texto).
- **Correcciones al aplicar el paquete:** `02-reglas-api-servicios.md` llegó solo con API-004 y SRV-004; se restauraron API-001..003 y SRV-001..003 de v11.2.4 (37 reglas). `SKILL.md` llegó sin delimitadores de frontmatter y se restauraron. Se unificó la etiqueta de versión (v11.3.0 → v11.3.1), se quitó una cláusula duplicada en EVT-001 y se repusieron frases de v11.2.4 que las pruebas exigen (37 resultados, no evaluable, condiciones textuales de API-001..003).
- **Alineación con el Studio:** el procedimiento ya no contradice el rol `EXTERNAL_SYSTEM` por descarte en E3 (`roleSource: E3_ELIMINATION`): el agente no lo deduce, pero lo toma del JSON.
- **Preguntas MCI obligatorias:** el procedimiento, la Skill y las instrucciones dicen ahora que se preguntan aunque `scenario.status` sea `HIPOTESIS`. Antes se condicionaban a que el componente estuviera «certificado» y a que el escenario «lo confirmara»; en los 15 ejemplos todos los escenarios son hipótesis.
- Instrucciones del agente: `INSTRUCCIONES-AGENTE-v11.3.2.md` (sección de preguntas obligatorias, lectura de despliegue, modelos).
- Pruebas: 91 (`test/v1131.test.js`).

## 0.4.9 — 28/10/2026

Cambio pedido por la analista; el resto del motor no cambia. La Skill sigue en v11.2.4 y el contrato JSON en `copilot-factual-v0.4.6.1`.

- **Modelos de entrada y salida:** una actividad BPMN con `customData` `ENTRADA` o `SALIDA` (sin distinguir mayúsculas) se entrega como `architecturalType: MODELO`, con `inference.rule: MODEL_BY_CUSTOMDATA_IO`. Antes solo era `MODELO` si el nombre contenía "Modelo", lo que ocurría solo en páginas de leyenda; las 121 actividades de páginas evaluables con ENTRADA/SALIDA salían `null`. El resto de actividades sigue en `null`.
- `modelIds` de las asociaciones de despliegue usa la misma regla. En los 15 blueprints de ejemplo no cambia ninguna asociación.
- Verificado: revertir solo los tipos MODELO por `customData` y la cadena de versión reproduce byte a byte las huellas de 0.4.8 de los cuatro blueprints de control.
- Pruebas: 87 (`test/v049.test.js`); se actualizan las huellas del compacto y la prueba de Oski, que antes exigía que ENTRADA/SALIDA no fueran MODELO.

## 0.4.8 — 27/10/2026

Cambios pedidos por la analista; el resto del motor no cambia. La Skill sigue en v11.2.4 y el contrato JSON sigue siendo `copilot-factual-v0.4.6.1` (el cambio es aditivo: un valor nuevo de `architecturalType` y menos figuras en el compacto).

- **API invocada:** un bloque UML agrupado con un BPMN Event de texto vacío y sin líneas (en el mismo grupo o en el grupo padre de su subgrupo; si hay más de un bloque candidato queda ambiguo) se entrega como `architecturalType: API`, `role: INVOCADO` (`inference.rule: API_BY_EMPTY_BPMN_EVENT_GROUP`). Si un grupo reúne varios bloques UML con ese evento, queda ambiguo.
- **Servicio invocado:** un nombre que inicia con `ms` (`ms-x`, `ms_x`, `ms x`, `msX`) o termina con `ms` (`x-ms`, `x_ms`, `x ms`, `x.ms`, `xMs`) y que no tiene el marcador se entrega como `SERVICIO`, `INVOCADO`. Con marcador y `ms` a la vez queda ambiguo (`MARKER_CONFLICTS_WITH_MS_NAMING`).
- **Evento de integración:** una tercera sección con tipo (`empresarial`, `aplicación`) o clasificación (`event`, `query`, `command`) se entrega como `architecturalType: EVENTO_INTEGRACION`. Deja de ser candidato interno sin confirmar y se sigue excluyendo como principal de los escenarios.
- **Sin regla aplicable:** `architecturalType: null` (no determinado), como hasta ahora. Si dos reglas chocan, `inference.status: AMBIGUOUS` con sus `contradictions`; el Studio no elige.
- **`DefaultSquareBlock`:** se omite del JSON compacto cuando no tiene líneas, contenido, contenedor, `customData` ni asociaciones (despliegue, modelos, escenario). La pertenencia a un grupo no cuenta como asociación; los miembros omitidos también se retiran de las listas de los grupos. Cada página informa en `omittedComponents` (lista por tipo, con `count` y `reason`) lo que se omitió. El diagnóstico completo no cambia.
- **Marcador de la API:** el BPMN Event vacío que pertenece con certeza a una API (la API quedó clasificada por él) no se registra como figura aparte: solo se entrega la API. Se omite también de las listas de grupos, de contenido de sistemas externos auxiliares y de candidatos de la evidencia de despliegue; su id queda solo en `inference.evidence` (`eventIds`) de la API, principal o invocada. Si la clasificación es ambigua, o el evento tiene `customData`, líneas o una asociación real, se conserva.
- **Hijo único:** el hijo es el `RectangleContainerBlock` más interno con al menos una compuerta y una actividad (`CHILD_BY_GATEWAYS_AND_ACTIVITIES`). Los demás rectángulos ya no se tipan como hijo. Si hay más de un candidato, todos quedan `AMBIGUOUS` (`MULTIPLE_CHILD_CANDIDATES`). En los 15 casos de `Blueprints_ejemplos` sale exactamente uno por página y coincide con el destino de la API principal.
- **Contenedores padre:** los dominios se entregan como `architecturalType: CONTENEDOR_PADRE` con su rol en `domainRole`. Un rectángulo plano raíz que lleva como texto directo un nombre reservado de dominio es ese contenedor (`PARENT_BY_LOOSE_TEXT_NAME`); uno que envuelve al hijo y no está dentro de otro dominio es contenedor padre con rol por inferencia estructural (`PARENT_BY_WRAPPING_MAIN_CHILD`). El resto de rectángulos es `CONTENEDOR_NO_DETERMINADO`. Con esto `createVirtualCard` y `createCustomizedCardConsulta` pasan de `NO_DETERMINADO` a hipótesis de E1.
- **Sistemas externos sin hijo:** un sistema externo que contenga al hijo marca `CHILD_INSIDE_EXTERNAL_SYSTEM` y el escenario no se determina.
- **E3 por descarte:** en un E3 identificado, los demás dominios sin nombre literal ni hijo se marcan como sistemas externos (`roleSource: E3_ELIMINATION`). En E1 y E2 siguen sin rol. Probado solo con casos sintéticos: no hay E3 en los ejemplos.
- La interfaz muestra por separado la versión del motor (0.4.8) y la del contrato (0.4.6.1).
- Pruebas: 85 (27 en `test/v048.test.js`); se actualizan las huellas del compacto, el rol del servicio `ms-` y la prueba de `customData` del corpus.
- Instrucciones del agente reforzadas (verificación del archivo, lectura de tipos, figuras omitidas, limitaciones).

## Skill v11.2.4 (candidata funcional, no estable) — 26/10/2026

- Skill simplificada a diez archivos con las 37 reglas confirmadas por la analista (SRV-001 y SRV-002 con texto definitivo). Se retiran el catálogo CSV, la matriz de evidencia de 41 reglas, el contrato compacto, la guía de textAreas, las instrucciones del agente y el changelog dentro de la Skill.
- Páginas evaluables: `OPERATIONAL` y `MIXED` producen 37 resultados; plantilla/leyenda y BDD se informan como no evaluables con su motivo, sin filas; `UNRESOLVED` queda sin dictamen.
- El procedimiento remite a API-001, API-002 y API-003 para sus condiciones textuales.
- Motor y contrato sin cambios (`copilot-factual-v0.4.6.1`). Banco de QA, pruebas y documentación alineados a 37 reglas; los casos y herramientas de la Skill de 41 reglas pasan a `qa/legacy-41/`.
- Instrucciones del agente reescritas para 37 reglas y el flujo del HTML; se entregan en `dist/INSTRUCCIONES-AGENTE-v11.2.4.md`, fuera de la Skill.
- Pendiente: prueba funcional con Copilot corporativo.

## 0.4.6.1

- Conserva `customData` literal de todas las figuras en el compacto y tolera datos malformados con incidencias.
- Elimina roles/tipos definitivos ante candidaturas ambiguas; normaliza SERVICIO y endurece BPMN.
- Propaga conflictos de productor y agrupación; no infiere dominios externos por descarte.
- Bloquea análisis sin páginas y preselecciona por clasificación real.
- Skill v11.2.3 (preparación, no estable): ajustes operativos sin cambio normativo (tipo vs rol del hijo, procedencia de PRODUCER, Inicio certificado en E1/E2/E3-001, evaluación independiente de API-004/CA-001/FT-001, No cumple con evidencia suficiente); las 41 obligaciones no cambian.
- Skill v11.2.2: páginas no evaluables, criterio de población para No aplica y diccionario ampliado; las 41 obligaciones no cambian.
- Sincroniza Skill v11.2.1 con cuatro estados, fórmula definitiva, diccionario y matriz de 41 reglas.

## 0.4.6.0

- Añade contrato Copilot compacto con inventario único y selección efectiva de páginas; diagnóstico completo separado.
- Elimina `functionalClassification` de la proyección compacta y conserva `textAreas` originales.
- Certifica subtipos BPMN solo mediante catálogo cerrado de `customData`; corrige falsos positivos de texto libre.
- Resuelve Flujo→Capa→Componente por contención directa y conserva la alternativa por grupo superior inequívoco.
- Clasifica servicios `ms` y BPMNGroup nominales como evidencia arquitectónica contextual.
- Actualiza Skill a v11.2.0, corrige F-13 sin cambiar los 41 IDs y adopta métricas/preguntas por página.
- Empaqueta ZIP portátil con separadores `/`.

## 0.4.5.0

- Productor único por operación sustentado por hijo, evento, pertenencia y ruta principal.
- Grafo factual de grupos y asociaciones Flujo/Capa por grupo superior inequívoco.
- Estados `CONFIRMADO`, `HIPOTESIS` y `NO_DETERMINADO`; un BPMNEvent genérico produce hipótesis.
- Metadatos obligatorios, nombre normalizado, hasta diez SVG, selección de operaciones y botón Limpiar.
- Skill v11.1.2 sin cambios en las 41 reglas v11.1.

## 0.4.4.2

- Bloquea escenarios con destino no resuelto/externo, principal dentro del hijo u orientación contradictoria.
- Separa raíz estructural y dominio efectivo; detecta envolventes y variantes reservadas conflictivas.
- Clasifica páginas operativas, plantillas/leyendas, mixtas y no resueltas; elimina los cuatro falsos E1 de plantilla.
- Conserva señales funcionales, de nomenclatura y topología por separado y registra conflictos `ms-`/`mainApi`.
- Garantiza `normativeEvaluation:null` y `nonNormative:true` en todos los estados.
- Actualiza la Skill operativa a v11.1.1 sin alterar los 41 requisitos v11.1 ni resolver F-13.
- Expone por separado padre inmediato, cadena completa, raíz estructural, dominio arquitectónico y rol; los conflictos no inventan jerarquía.

## 0.4.4.1 - 2026-10-22

- Convención determinista de dominio padre, con fuente declarada o inferida.
- Nueva sección `structuralScenario` separada del dictamen normativo.
- E1/E2/E3 estructurales identificados desde conexión, hijo y dominios; no requieren certificar subtipo Inicio.
- Página, componente, operación y servicio hijo conservados como propiedades independientes.
- Señal de servicio `ms-`, `ms_`, `ms ` y camel case `msX`; evita palabras arbitrarias que empiezan por `ms`.
- BDD y nombre de pestaña eliminados como evidencia decisoria.
- Regresiones negativas para candidatos múltiples, inversión, ausencias, NOTACIÓN y nomenclatura.

## 0.4.4 - 2026-10-21

- Nueva colección factual `architecturalRoleCandidates[]` para candidaturas `mainApi`/`mainService`.
- Orientación por terminaciones; conexiones invertidas y ambiguas no se equiparan.
- Evidencia BDD, dominios, ancestros, hijo y conexión original en cada candidatura.
- Clasificador funcional compuesto: exposición, modelo de servicio y clasificación de evento separados.
- Query/Command/Event excluidos de rutas principales.
- `deploymentPairs[]` amplía contenido de Flujo/Capa y estado de propiedad sin asignación automática.
- Espera E2E basada en generación completada y oráculos independientes del JSON original.

## 0.4.3 - 2026-10-21

- El HTML se compila desde el mismo núcleo que prueban los tests; eliminado el segundo motor inline.
- E2E real en Edge: carga, análisis, descarga y comparación exacta HTML↔núcleo.
- Conexiones completas, clasificador único, secciones originales y `deploymentPairs[]` explícito.
- Raíz estructural separada del dominio, dominios personalizados y leyenda NOTACIÓN.
- Robustez para nulos, IDs duplicados, extremos ausentes, ciclos y referencias incompatibles.
- CSV CNT-002 corregido y validado con parser real.
- Preparación de historia pública limpia sin materiales corporativos.

## 0.4.2 / Skill 11.1 - 2026-10-21

- Núcleo modular para JSON Lucidchart, contención, conexiones, despliegue y exportaciones.
- Padre inmediato único, cadenas completas, dominios raíz sin suponer productor, conflictos/ciclos explícitos.
- Asociaciones de despliegue y rutas principales no normativas con fuente y estado.
- Pruebas reales para E2 Currency Exchange, E1 Oski, Debit Card, multipágina, modelos y casos sintéticos.
- HTML autocontenido v0.4.2 y ZIP instalable de Skill v11.1.
- Skill alineada con dominio arquitectónico raíz y conexión verificable al evento de Inicio; 41 IDs preservados.
