$ErrorActionPreference='Stop'
$repo=(Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$stage=Join-Path $repo ('.public-staging-'+[guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $stage | Out-Null
$paths=@('.gitignore','README.md','CHANGELOG.md','AGENTS.md','src','ui','scripts/build.mjs','fixtures/synthetic','docs/architecture','docs/contracts','docs/decisions','docs/PUBLIC_DISTRIBUTION.md','dist/BlueprintEvidenceStudio.html')
foreach($rel in $paths){$source=Join-Path $repo $rel;$dest=Join-Path $stage $rel;$parent=Split-Path $dest -Parent;New-Item -ItemType Directory -Force -Path $parent|Out-Null;Copy-Item -LiteralPath $source -Destination $dest -Recurse -Force}
New-Item -ItemType Directory -Force -Path (Join-Path $stage 'test')|Out-Null
Copy-Item -LiteralPath (Join-Path $repo 'public\public.test.js') -Destination (Join-Path $stage 'test\public.test.js')
Copy-Item -LiteralPath (Join-Path $repo 'public\public-e2e.test.js') -Destination (Join-Path $stage 'test\public-e2e.test.js')
Copy-Item -LiteralPath (Join-Path $repo 'public\package.json') -Destination (Join-Path $stage 'package.json')
git -C $stage init -b public/evidence-studio-v0.4.6.1 | Out-Null
git -C $stage config user.name 'Blueprint Evidence Studio'
git -C $stage config user.email 'noreply@example.invalid'
git -C $stage add --all
git -C $stage commit -m 'feat: publish sanitized evidence studio 0.4.6.1' | Out-Null
git fetch -f $stage 'public/evidence-studio-v0.4.6.1:public/evidence-studio-v0.4.6.1'
Write-Output "Prepared public/evidence-studio-v0.4.6.1 from independent root commit. Staging retained at $stage for inspection."
