import { readFile } from 'node:fs/promises';
const file='dist/validar-blueprint-integracion-v12.2.0.zip',data=await readFile(file),names=[];
for(let offset=0;offset<=data.length-46;offset++)if(data.readUInt32LE(offset)===0x02014b50){const length=data.readUInt16LE(offset+28),extra=data.readUInt16LE(offset+30),comment=data.readUInt16LE(offset+32);names.push(data.subarray(offset+46,offset+46+length).toString('utf8'));offset+=45+length+extra+comment;}
if(!names.length)throw new Error('ZIP without central-directory entries');
if(names.some(x=>x.includes('\\')))throw new Error('ZIP contains non-portable backslash paths');
const R='validar-blueprint-integracion/',required=['SKILL.md',...['MANIFEST','00-procedimiento','08-fichas','01-reglas-estructura','02-reglas-api-servicios','03-reglas-eventos','04-reglas-despliegue','05-reglas-escenarios','06-reglas-modelos-comandos','07-reglas-gestores-colas'].map(x=>`references/${x}.md`)].map(x=>R+x);
for(const r of required)if(!names.includes(r))throw new Error(`Missing ZIP entry: ${r}`);
const files=names.filter(x=>!x.endsWith('/'));
if(files.length!==11)throw new Error(`Expected 11 content files, found ${files.length}`);
console.log(`Validated ${files.length} portable ZIP content files`);
