import { access, readdir, readFile, mkdir, writeFile } from 'node:fs/promises';
import { join, extname } from 'node:path';
import { analyzeBlueprint, copilotExport, diagnosticExport } from '../src/index.js';
async function walk(dir) {
  const nested = await Promise.all((await readdir(dir, { withFileTypes: true })).map(e => e.isDirectory() ? walk(join(dir, e.name)) : extname(e.name).toLowerCase() === '.json' && !e.name.startsWith('blueprint_evidence_') && !/(?:ENRIQUECIDO|DIAGNOSTICO)/i.test(e.name) ? [join(dir, e.name)] : []));
  return nested.flat();
}
const files = await walk('Blueprints_ejemplos');
const adjustmentSource = join('Solicitud Ajustes', 'Escenario2_Original.json');
try {
  await access(adjustmentSource);
  files.push(adjustmentSource);
} catch {
  // The corporate adjustment source is intentionally absent from public clones.
}
const rows = [];
await mkdir('artifacts/private-evidence', { recursive: true });
for (const file of files) {
  const parsed = JSON.parse((await readFile(file, 'utf8')).replace(/^\uFEFF/, ''));
  const report = analyzeBlueprint(parsed, { sourceName: file });
  const compact = copilotExport(report, { selectedPageIds: report.pages.map(x=>x.page.id) });
  const safe=file.replace(/^Blueprints_ejemplos[\\/]/,'').replace(/^Solicitud Ajustes[\\/]/,'Solicitud_Ajustes_').replace(/[\\/:*?"<>| ]+/g,'_').replace(/\.json$/i,'');
  await writeFile(join('artifacts/private-evidence',safe+'.copilot.json'),JSON.stringify(compact,null,2));
  await writeFile(join('artifacts/private-evidence',safe+'.diagnostic.json'),JSON.stringify(diagnosticExport(report),null,2));
  for (const page of report.pages) rows.push({ source: file, ...page.page, ...page.counts, deploymentPairs: page.architecturalStructure.deploymentPairs.length, issues: page.architecturalStructure.issues.length });
}
await mkdir('docs/audits', { recursive: true });
await writeFile('docs/audits/blueprint-inventory.json', JSON.stringify(rows, null, 2));
console.log(JSON.stringify(rows, null, 2));
