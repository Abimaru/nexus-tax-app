$ErrorActionPreference = 'Stop'
$root = Resolve-Path (Join-Path $PSScriptRoot '..')
$skill = Join-Path $root 'skills\validar-blueprint-integracion'
$outDir = Join-Path $root 'dist'
$zip = Join-Path $outDir 'validar-blueprint-integracion-v12.2.0.zip'
New-Item -ItemType Directory -Force -Path $outDir | Out-Null
if (Test-Path -LiteralPath $zip) { Remove-Item -LiteralPath $zip }
Push-Location (Split-Path $skill -Parent)
try { & tar.exe -a -c -f $zip (Split-Path $skill -Leaf) } finally { Pop-Location }
Write-Output "Created $zip"
