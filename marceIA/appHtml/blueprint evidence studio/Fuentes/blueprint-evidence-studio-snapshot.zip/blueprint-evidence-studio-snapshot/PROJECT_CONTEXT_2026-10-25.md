> **Histórico.** Sustituido como contexto vigente por `PROJECT_CONTEXT_2026-10-26.md`. Se conserva sin reescribir.

# Contexto del proyecto — punto de control 25/10/2026

Archivo privado. No debe incluirse en la rama pública (nombra material corporativo y la Skill). Los informes históricos no son fuente superior al catálogo vigente de la Skill ni a `AGENTS.md`.

Leyenda: **[V]** hecho verificado · **[A]** decisión aprobada · **[I]** inferencia · **[P]** pendiente.

## 1. Objetivo
- [A] Evidence Studio convierte un JSON de Lucidchart en evidencia estructural y en una proyección compacta; la Skill `validar-blueprint-integracion` evalúa 41 reglas sobre esa proyección; Evidence Studio no determina cumplimiento normativo.

## 2. Arquitectura
- [V] Un solo motor en `src/` (esbuild → `dist/BlueprintEvidenceStudio.html`, 67 359 B, SHA-256 `a93f293d…`), interfaz en `ui/app.js`. Salidas: diagnóstico completo y JSON Copilot compacto (`pages[].components`, `connections`, `groups`, `deploymentAssociations`, `scenario`, `issues`, `pageClassification`, `counts`).
- [A] Preservación literal de IDs, endpoints, estilos, `connectedTo`, `customData`, grupos, modelos y páginas.

## 3. Versiones
- [V] Evidence Studio v0.4.6.1 · contrato `copilot-factual-v0.4.6.1` · Skill v11.2.3 preparada, no estable (ZIP `dist/validar-blueprint-integracion-v11.2.3.zip`, SHA-256 `e15c8bda…9330`, 41 IDs, 16 archivos). Anterior v11.2.2: SHA-256 `9b35a98e…c704d`, conservada. Detalle: `docs/audits/ITERACION_SKILL_V11.2.3_2026-10-25.md`.
- [V] `npm test` 68/68, `npm run audit` y `npm run build` OK (HTML sin cambios), selftest del banco 118/118, preflight 72/72. E2E no se re-ejecutó.

## 4. Contratos y estructura
- [A] Padre inmediato, cadena de ancestros y dominio raíz son propiedades distintas. Un solo padre puede ser `DIRECT_CONTAINMENT`; ancestros superiores `ANCESTOR_CONTAINMENT`; conflictos, ciclos y ausentes quedan sin resolver.
- [A] Grupos = asociación, no contención. Asociación de despliegue: contención explícita Flujo→Capa→Componente o grupo superior común inequívoco; nunca por proximidad, orden o descarte.
- [V] `architecturalType` = `SERVICIO_HIJO` para toda `RectangleContainerBlock`; `role: HIJO_PRINCIPAL` solo para `mainChildServiceId`. `INVOCADO` no se emite en el corpus. Rol de dominio resuelto ⇒ `possibleDomainRoles: []`.

## 5. Escenarios
- [A] E1/E3: hijo no gestionado en DOMINIO PRODUCTOR; E2: hijo gestionado en INTEGRACIÓN (F-13). CONFIRMADO exige `customData` de subtipo Inicio en el catálogo cerrado.
- [V] 0 de 341 BPMNEvent reales traen `customData` ⇒ todos los escenarios reales son HIPOTESIS.
- [P] Conexión directa frente a declarada (E3 dice «directa», E1/E2 «declarada»).

## 6. Normativa y métrica
- [A] 41 reglas, cuatro estados, `Cumple / (Cumple + No cumple + No verificable) × 100`, sin No aplica; blueprint = suma ponderada de evaluaciones regla–página; denominador 0 = no calculable.
- [A] Páginas: OPERATIONAL y MIXED se evalúan; TEMPLATE_OR_LEGEND y BDD_OR_REQUIREMENTS no; UNRESOLVED exige revisar la clasificación; contradicción con evidencia de operación ⇒ preguntar a la analista.
- [A] MCI y exposición se preguntan por página y se registran `DECLARADO_POR_ANALISTA`; reutilizar entre páginas solo con confirmación explícita.
- [P] C14-Q3, C15-Q1 (MQ-001..004, GW-001, EXT-001/002), C15-Q2 (CNT-001), C15-Q3 (CNT-006) y las observaciones O2–O4, O6, O7 del piloto.

## 7. Banco de pruebas independiente (`qa/`, privado)
- [V] Skill oficial sin modificar + agente delgado + controlador externo; sesiones `claude -p` aisladas (aislamiento verificado por el entorno). Casos: c14, c15, P1–P4 (una ejecución cada uno). Resultados del piloto: P1 39,29 %, P2 13,04 %, P3 9,09 %, P4 pa 14,81 % / pb 11,54 %; blueprint P4 13,21 % (7/53).
- [V] Costo de lista del piloto ≈ USD 3,34 (≈ 802 k tokens); el consumo real del plan no es medible.
- [P] Batería de 16 casos y repeticiones: no autorizadas.

## 8. Riesgos
- [V] El remoto `origin` es público; no debe recibir ramas privadas.
- [I] Con escenario siempre HIPOTESIS, CNT-002 y E1/E2/E3-001 no pueden llegar a Cumple en blueprints reales.
- [I] La Skill no relaciona `SERVICIO_HIJO`/`HIJO_PRINCIPAL` con las reglas; el mapeo de preguntas del controlador es por palabras clave.

## 9. Git
- [V] Rama actual `feature/evidence-studio-v0.4.6.1-private` (`81b7542`), con cambios sin confirmar; `main` local = `origin/main` = `1a1bb45` (solo README); 7 ramas `public/*` independientes; sin commits, push ni PR en esta etapa.
- [P] Repositorio privado con `main` y destino/visibilidad/archivos por aprobar (ver `docs/audits/CIERRE_ETAPA_2026-10-25.md`, parte VI).

## 9 bis. Decisiones Q1–Q10 consolidadas (detalle en `CIERRE_ETAPA_2026-10-25.md`, Parte IX)
Categorías: DPC = decisión previa confirmada · CCV = criterio conservador vigente · DNP = decisión normativa pendiente.
- **Q1 [DPC, cerrada]:** `PRODUCER` se identifica por evidencia estructural aunque el contenedor tenga nombre propio (RECAUDOS en Oski, CORE GLOBAL ACCOUNT en Virtual Account Opening); sin inferir por descarte. El catálogo usa «DOMINIO PRODUCTOR» como dominio efectivo; no exige nombre literal. CNT-002/CNT-004 sin cambios.
- **Q2 [CCV + DNP]:** HIPOTESIS ≠ No cumple; CONFIRMADO ≠ Cumple; sin Inicio certificado, las reglas integrales (E1/E2/E3-001) no dan Cumple. CNT-002 admite dos lecturas de «escenario certificado» ⇒ DNP.
- **Q3 [DNP]:** directa/declarada; redacción conservada, sin homogeneizar.
- **Q4 [DNP]:** población de SRV-001..003; `SERVICIO_HIJO + HIJO_PRINCIPAL` ≠ `SERVICIO + INVOCADO`.
- **Q5 [CCV + DNP]:** la ausencia de una figura no demuestra No aplica; sin obligación universal de gestor.
- **Q6 [CCV + DNP]:** No cumple exige evidencia suficiente; definición verificable de «cobertura completa» pendiente.
- **Q7 [CCV + DNP]:** propuesta operativa de CNT-006 no incorporada como norma aprobada; población por confirmar.
- **Q8 [DPC + DNP]:** evaluación independiente aprobada; API-004, CA-001 y FT-001 solo solapan cuando la causa es la ausencia de la figura; el reparto queda pendiente; no se fusionan ni se ajustan estados.
- **Q9 [CCV + DNP]:** el remoto es público; no se sube la rama privada; destino privado sin autorizar.
- **Q10 [DPC, cerrada]:** `qa/` forma parte del proyecto privado autorizado; excluye `qa/runs/`, transcripciones sensibles y temporales; nunca en la distribución pública.

## 10. Próximos pasos
1. La analista responde las 8 preguntas reducidas (Parte IX.5 del informe de cierre).
2. Skill v11.2.3 solo con los ajustes operativos de IX.7 (no altera texto ni hashes de las 41 reglas), tras aprobación, con `skill:pack` y `skill:zip:validate`.
3. Autorizar destino Git privado y alcance por categoría (código, QA, Skill/normativa, blueprints, auditorías) antes de cualquier push.
4. Dirección para Evidence Studio (informe, Parte X.3): facilitar la declaración del subtipo Inicio, mostrar tipo vs. rol y procedencia del productor, verificar modelos ENTRADA/SALIDA, indicador de cobertura.
5. Después, la batería de 16 casos.

Documentos de referencia: `docs/audits/CIERRE_ETAPA_2026-10-25.md`, `docs/audits/MATRIZ_41_REGLAS_2026-10-25.md|csv`, `qa/DECISIONES.md`, `qa/DECISIONES_PENDIENTES.md`, `qa/PILOTO_FASE2.md`.
