# HANDOFF — Blueprint Evidence Studio

> **Para la IA (o persona) que retome este proyecto.** Este documento es la puerta de entrada. Léelo completo antes de tocar nada.
> Última actualización: **25/11/2026** — Studio **0.11.0**, Skill **12.2.0**, contrato `copilot-factual-v0.4.6.1`.
> Autoría: ver `AUTORIA.md` (consérvala y propágala al actualizar o trasladar este material; no hace falta mencionarla al explicar el proyecto).

## 0. Reglas para quien mantenga este proyecto (obligatorias)

1. **Mantén la documentación al día, siempre.** Al terminar cualquier cambio (código, regla, HTML, instrucciones, tests) actualiza en el mismo trabajo: `CHANGELOG.md` (entrada nueva arriba), **este `HANDOFF.md`** (secciones 2, 10 y 11 como mínimo), `README.md` (versión vigente y entregables), `AGENTS.md` (si cambia una regla permanente) y, si hay una decisión nueva, un ADR en `docs/decisions/`. Cambio sin documentar = cambio sin terminar. Detalle: `docs/processes/PROCESO-mantener-documentacion.md`.
2. **Alinea todo cuando cambie una regla**: texto de la regla (`skills/.../references/0X-*.md`), su ficha (`08-fichas.md`), el procedimiento (`00-procedimiento.md`), `SKILL.md`, `MANIFEST.md`, las instrucciones del agente (`dist/INSTRUCCIONES-AGENTE-v*.md`), el HTML/UI si muestra algo relacionado, el Studio si el inventario debe exponer un dato nuevo, y los tests. Una regla cambiada solo en un lugar genera contradicciones entre agente y Studio.
3. **No apliques cambios pedidos por la analista sin que estén confirmados** (ver sección 9). Si dudas, pregunta; si la duda es de redacción, propón texto.
4. **Versiona con criterio** (sección 8.5) y no sobrescribas entregables ya entregados: crea archivos con la versión nueva.
5. **Corre `npm test` antes y después** de cada cambio, y compara el corpus antes/después si tocas el Studio (`docs/processes/PROCESO-control-regresion.md`).
6. **Autoría:** conserva `AUTORIA.md`, el `author` de `package.json`, el pie del HTML y el comentario inicial del HTML generado. Si copias o resumes este software en otro sitio, lleva la atribución.
7. Este directorio **no es un repositorio Git** (copias manuales con respaldos `.zip` en la carpeta superior). Si se inicializa Git, respeta `.gitignore` y `docs/PUBLIC_DISTRIBUTION.md` (confidencialidad).

## 1. Qué es el proyecto

**Blueprint Evidence Studio — «Del dibujo a la evidencia».** Los equipos dibujan *blueprints* de integración en Lucidchart. Se exporta el JSON del diagrama y se quiere validar, con 38 reglas definidas por la analista de arquitectura, si cada blueprint las cumple. El problema: un modelo de lenguaje no debe «adivinar» qué es cada figura. La solución son tres piezas con responsabilidades que **no se mezclan** (ADR-0004):

| Pieza | Dónde | Hace | No hace |
|---|---|---|---|
| **Studio** | `src/` + `ui/` → HTML autocontenido `dist/BlueprintEvidenceStudio-v<x>.html` | Lee el JSON de Lucidchart y emite un JSON enriquecido (`-ENRIQUECIDO.json`): tipo de cada figura (certificado / candidato / sin tipo), contención, grupos, conexiones, asociaciones de despliegue, escenario E1/E2/E3 como hipótesis, y un `inventory` por página. | No evalúa reglas, no emite veredictos, no pregunta. |
| **Skill** `validar-blueprint-integracion` | `skills/validar-blueprint-integracion/` (11 archivos) → `dist/validar-blueprint-integracion-v<x>.zip` | Contiene las 38 reglas, las fichas operativas (de dónde sale la población de cada regla), el procedimiento y los 4 estados (Cumple, No cumple, No verificable, No aplica). | No reconoce figuras por su cuenta. |
| **Agente** (Copilot corporativo) | Instrucciones en `dist/INSTRUCCIONES-AGENTE-v<x>.md` (fuera de la Skill, ≤ 2500 caracteres) | Carga la Skill, recibe el JSON enriquecido, hace las preguntas autorizadas (MCI, exposición) y entrega el informe por página citando «Nombre (id)». | No corrige tipos ni los infiere por nombre, color o posición. |

Flujo de uso: analista exporta JSON de Lucidchart → abre el HTML del Studio → carga el JSON, escribe el Nombre del Blueprint, selecciona páginas → descarga `<Nombre>-ENRIQUECIDO.json` → lo sube al agente con la Skill → recibe el informe.

Principio de evidencia: **solo se afirma lo que el JSON demuestra**. Evidencia parcial, ambigua o contradictoria → `No verificable`. Nada se certifica por geometría, color, orden o descarte. Los textos libres no certifican el tipo, salvo las reglas de nombre ya aceptadas por la analista.

## 2. Estado vigente (25/11/2026)

- **Versiones:** Studio `0.11.0`, Skill `12.2.0`, contrato `copilot-factual-v0.4.6.1`. Línea única: ya no hay «línea estable» y «línea nueva» (se fusionaron el 24/11/2026; la anterior 0.8.3 / 11.8.7 está en `../blueprint-evidence-studio-snapshot-respaldo-2026-11-24-antes-de-12.1.0.zip`; la carpeta `../ARCHIVADO-blueprint-evidence-studio-nueva` solo se conserva por su `node_modules`).
- **Pruebas:** `npm test` → **177 pasan, 0 fallan**. Las pruebas E2E (`npm run test:e2e`, Playwright) **no se han podido ejecutar** en este entorno (falta Edge). El HTML se validó a mano en el navegador integrado de Claude (encabezado, pie, filtrado de páginas), sin errores de consola, pero no con una batería E2E.
- **Falta una corrida del paquete 12.2.0 con Copilot** (la analista lo hará).
- **Catálogo:** 38 reglas (CNT 5, EXT 1, GEN 1, GW 1, API 4, SRV 6, EVT 7, CA 1, FT 1, E1 1, E2 1, E3 1, MOD 2, COM 3, MQ 3). Inventario oficial en `skills/.../references/MANIFEST.md`.
- **Entregables vigentes en `dist/`:** `BlueprintEvidenceStudio-v0.11.0.html` (= `BlueprintEvidenceStudio.html`), `validar-blueprint-integracion-v12.2.0.zip` (11 archivos), `INSTRUCCIONES-AGENTE-v12.2.0.md`. Copias para la analista: `../docs/validacion_skill_analista/entrega-12.2.0/` y el paquete de código fuente `dist/blueprint-evidence-studio-codigo-fuente-v0.11.0.zip`. Las versiones antiguas en `dist/` son historial.
- **Corpus de pruebas:** `Blueprints_ejemplos/` (34 BP reales; 61 páginas evaluables: 35 con escenario, 21 `NO_DETERMINADO` con hijo, 5 de BP antiguos sin etiquetas y sin hijo certificado). Los tests de conteo del corpus (`v048`, `v1131`) tienen números fijos: **al agregar BP al corpus hay que actualizarlos** (ver 9.2).

## 3. Mapa del repositorio

```
AUTORIA.md  README.md  AGENTS.md  HANDOFF.md  CHANGELOG.md   ← documentos de entrada
package.json  scripts/            ← build (esbuild), empaquetado y validación del ZIP de la Skill, auditoría
src/                              ← motor (módulos ES). Un solo motor para HTML y tests
ui/index.html  ui/app.js          ← interfaz (plantilla HTML con marcadores __VERSION__, __APP_BUNDLE__…)
skills/validar-blueprint-integracion/   ← la Skill: SKILL.md + references/ (00..08 + MANIFEST) = 11 archivos
dist/                             ← entregables generados (HTML, ZIP de la Skill, instrucciones del agente) y su historial
test/                             ← pruebas (node:test); corpus real en Blueprints_ejemplos/
Blueprints_ejemplos/              ← 34 BP reales de Lucidchart (JSON) para pruebas de regresión. CONFIDENCIAL
Inventario_nuevo/                 ← biblioteca de figuras (.lcsl) y excel de equivalencias de la analista
docs/                             ← architecture/, contracts/, decisions/ (ADR), processes/, audits/ (histórico)
qa/  fixtures/  public/           ← QA anterior, fixtures sintéticos, rama pública (ver PUBLIC_DISTRIBUTION.md)
Solicitud Ajustes/  PROJECT_CONTEXT_*.md   ← material de contexto histórico
```

Fuera de la carpeta (nivel superior `Blueprints/`): `docs/validacion_skill_analista/` (paquetes entregados a la analista, anexos e historial), `docs/INDICE_DOCUMENTACION.md`, respaldos `.zip`.

## 4. Cómo funciona el Studio (motor)

Entrada: JSON de Lucidchart (`pages[].items.{shapes,lines,groups,layers}`). Salida: modelo normalizado → dos proyecciones: **JSON Copilot compacto** (`copilotExport`, lo que consume la Skill) y **diagnóstico** (`diagnosticExport`, evidencia técnica completa). `analyzeBlueprint(json)` es el punto de entrada; los dos exports parten del mismo resultado.

| Módulo | Qué hace |
|---|---|
| `lucidchart.js` | Normaliza documento/páginas/figuras; helpers (`customDataEntries`, `shapeText`…). |
| `containment.js` | Contención (`contains`): padre inmediato, cadena de ancestros, dominio raíz; hijo principal (`qualifyingChildren`: `RectangleContainerBlock` con compuerta+actividad, o con etiqueta `SERVICE`). |
| `groups.js` | Grupos y su jerarquía; **etiquetas de grupo** (`customData` de la biblioteca nueva) → `groups[].labels`. Pertenencia a grupo = evidencia asociativa, no contención. |
| `connections.js`, `roles.js` | Conexiones crudas, orientación (`connectionOrientation`), subtipo de eventos BPMN, rol de API/servicio principal. |
| `deployment.js` | Parejas Capa de Arquitectura–Flujo Transaccional y su dueño (por contención o grupo superior inequívoco; nunca por cercanía). |
| `classifier.js` | Clasificación técnica de figuras (clase Lucidchart). |
| `page-classifier.js` | Clase de página: `OPERATIONAL`, `MIXED`, `TEMPLATE_OR_LEGEND`, `BDD_OR_REQUIREMENTS`, `UNRESOLVED`; `connectionBlockers` (conectores con extremo suelto que bloquean el JSON); descripción de figura por tipo y texto. |
| `exporter.js` | El corazón: asigna `architecturalType` por reglas con prioridad (ver `00-procedimiento.md` §6, lista de 8 pasos), `figuraBiblioteca` por el grupo raíz etiquetado, comandos/modelos/eventos por etiqueta, `CAPA_TOPICOS`, escenario E1/E2/E3, `mqInfo` (capa de tópicos del servicio MQ), `copilotExport`/`diagnosticExport`. |
| `inventory.js` | `pages[].inventory`: listas `{id,name,figura,ubicacion}` por tipo, `contenedores`, `relaciones` (pares de tipos con líneas), `compuertas` (con `subtipo`, `conTexto`, `caminos`), `modelos`, capas, etc. La Skill toma las poblaciones de aquí. |
| `evaluation.js` | Validación de los 4 estados y métricas (usado por tests y el diagnóstico). |
| `version.js` | `VERSION` (Studio), `SKILL_VERSION`, `CONTRACT_VERSION`. Fuente de verdad de versiones. |

Nota de estilo: el código es **denso** (líneas largas, muchos `const` encadenados). Para modificarlo con seguridad: lee la función completa, cambia lo mínimo, corre `npm test` y compara el corpus.

### 4.1 Reconocimiento en tres estados (ADR-0005)
Cada figura sale **certificada** (`architecturalType` definido, con `inference.rule` y `status`), **candidata** (`architecturalType: null` + `possibleTypes`) o **sin tipo**. Una figura candidata dentro de la población de una regla deja esa regla en `No verificable`.

### 4.2 Etiquetas de la biblioteca (línea con etiquetas, ADR-0020)
Desde 0.10.0 la biblioteca de figuras de la analista (`Inventario_nuevo/*.lcsl`) pone etiquetas en `customData` de grupos y figuras. El Studio las usa como evidencia primaria:
- **Figura de biblioteca** (`figuraBiblioteca` / `figura`): etiqueta del grupo raíz, p. ej. `THIRD_PARTY_API`, `OWN_PRIVATE_API_MCI`, `OWN_UMG_SERVICE`, `OWN_UMG_MQ_SERVICE`, `THIRD_PARTY_MQ_SERVICE`, `QUEUE_MANAGER_MCI`… Lista cerrada `LIB_FIGURES` en `src/exporter.js`. Cualquier etiqueta con `MQ_` = servicio consumido por colas.
- **Comandos:** `SERVICE_TASK`, `SYSTEM_TASK`, `SUB_PROCESS`, `USER_TASK` (no permitido en el hijo). **Modelos:** `ENTRADA`, `SALIDA`, `BUSINESS_RULE`, `BUSINESS_EXCEPTION`, `BUSINESS_CONCEPT`. **Eventos:** `START`, `END`, `EVENT`, `EXCEPTION`, `SIGNAL_SEND/RECEIVE`, `MESSAGE_SEND/RECEIVE`. **Compuertas:** `EXCLUSIVE`, `INCLUSIVE`, `PARALLEL`, `EVENT_BASED`, `PARALLEL_EVENT_BASED`. **Contenedores:** `SERVICE` (certifica servicio e hijo), `SERVICE_MCI`, `TOPIC_LAYER`, `ARCH_LAYER`, `TXN_FLOW`, `API`, `MCI`, `MODEL_GROUP`, `EXT_AUX`.
- **BP antiguos sin etiquetas** siguen funcionando por las reglas de nombre/estructura (el JSON de los BP viejos es byte a byte igual; lo vigila `test/ui-contract-invariance.test.js`).

### 4.3 Capa de Tópicos del servicio MQ (0.10.1)
Un servicio con MQ en la figura (`consumidoPorColas: true`) trae `capaTopicos` en `inventory.servicios[]`: la capa `TOPIC_LAYER` que lo **contiene** o la del **mismo grupo de la figura MQ** (`asociadaPor: GRUPO`). Varias capas de tópicos en el grupo → `capaTopicos: null` + `capasTopicosCandidatas` (ambiguo → `No verificable`). Las capas de despliegue no cuentan. Código: `mqInfo` en `src/exporter.js`.

### 4.4 Bloqueo del JSON (HTML)
El HTML descarga el JSON solo si **todas** las páginas seleccionadas son `OPERATIONAL`/`MIXED` y ningún conector tiene un extremo suelto (`connectionBlockers`; None–None y líneas de anotaciones exentas). La lista de páginas muestra solo las operativas/mixtas (BDD y plantillas/leyendas se ocultan). El mensaje de extremo suelto dice el tipo y texto de la figura conectada.

## 5. Contrato del JSON enriquecido (resumen)

Detalle: `docs/contracts/COPILOT_JSON_CONTRACT.md`. Por página: `page`, `counts`, `pageClassification`, `scenario` (`status`: `HIPOTESIS`/`CONFIRMADO`/`NO_DETERMINADO`; `scenario`: E1/E2/E3; `mainComponentId`, `mainChildServiceId`), `inventory`, `components[]` (con `architecturalType`, `role` PRINCIPAL/INVOCADO, `figuraBiblioteca`, `containerChainIds`, `deploymentAssociations`, `customData`…), `connections`, `groups`, `deploymentAssociations`, `issues`, `omittedComponents`. **Cambiar la forma del JSON rompe el contrato**: sube `CONTRACT_VERSION`, actualiza la Skill, las instrucciones y la línea base de `ui-contract-invariance`.

Escenarios (se escriben siempre con su descripción, nunca la sigla sola): **E1 (API directo al backend)**, **E2 (API con servicio de integración)**, **E3 (Servicio no gestionado)**. Los IDs de regla `E1-001`, `E2-001`, `E3-001` no cambian.

## 6. La Skill y las reglas

- 11 archivos exactos (no se agregan más): `SKILL.md`, `references/00-procedimiento.md` (precedencia de evidencia, preguntas, estados, métrica), `01`–`07` (reglas por familia), `08-fichas.md` (población de cada regla desde el inventario), `MANIFEST.md` (inventario de IDs y controles).
- Estados: **Cumple, No cumple, No verificable, No aplica**. Métrica: `Cumple / (Cumple + No cumple + No verificable) × 100`, sin No aplica; denominador cero = no calculable; no se promedian porcentajes.
- Preguntas autorizadas (único momento en que el agente pausa): MCI de la API principal (una por nombre de API), MCI del hijo de E2 (por hijo), exposición de la API principal si falta (`private`/`public`/`partner`). En E1 el hijo se da por no MCI; en E3 no hay preguntas. Respuestas = `DECLARADO_POR_ANALISTA`; el supuesto de E1 = `SUPUESTO_E1_HIJO_NO_MCI`.
- Cada página evaluable produce exactamente 38 resultados. Páginas no evaluables se informan con su motivo, sin resultados ni porcentaje.
- Definiciones útiles que suelen preguntar: **servicio gestionado** = ubicado directamente en el nivel padre de INTEGRACIÓN (no gestionado: DOMINIO PRODUCTOR o SISTEMAS EXTERNOS; el principal de E3 siempre no gestionado; ver SRV-002). **GW-001** solo evalúa compuertas exclusivas e inclusivas (las demás no se validan; sin etiqueta de subtipo se evalúan igual). **SRV-006**: servicio invocado con MQ en la figura debe tener Capa de Tópicos con tópicos no de plantilla (el principal de E3 y el hijo quedan fuera). **API-003/SRV-003**: en SISTEMAS EXTERNOS la tercera sección no se evalúa.

## 7. HTML / interfaz

`ui/index.html` (plantilla con CSS inline; marcadores `__VERSION__`, `__CONTRACT_VERSION__`, `__APP_BUNDLE__`) + `ui/app.js` (lógica). `npm run build` (esbuild, IIFE) produce **un solo HTML autocontenido sin recursos de red**. Elementos vigentes: encabezado negro, título «Blueprint Evidence Studio», subtítulo «Del dibujo a la evidencia» (1.5em: menor que el título y mayor que la descripción), logo SVG dibujado en el HTML (círculo + tres barras curvas, esquina superior derecha), versión y autoría solo en el pie. `window.__BES__` es un gancho de solo lectura para pruebas E2E.

## 8. Recetas de trabajo

**8.1 Antes de cualquier cambio:** `npm test` (debe dar 177/0). Para tocar el Studio: guarda un snapshot del JSON del corpus antes y compáralo después (`PROCESO-control-regresion.md`); solo deben cambiar los campos previstos.

**8.2 Cambiar o agregar una regla:** editar el texto en `references/0X-*.md` → ficha en `08-fichas.md` → si hay dato nuevo, exponerlo en `src/inventory.js`/`src/exporter.js` → `SKILL.md`/`00-procedimiento.md`/`MANIFEST.md` (conteos por familia y total) → instrucciones del agente → tests (`test/skill.test.js` verifica 38 IDs; busca los tests de la familia) → CHANGELOG/HANDOFF/ADR → versión (8.5) → build y empaquetado (8.6).

**8.3 Agregar una figura de la biblioteca nueva:** agregar su etiqueta a `LIB_FIGURES` (si es figura de grupo raíz) o al mapa de etiquetas que corresponda (comandos, modelos, eventos, compuertas en `exporter.js`/`roles.js`/`inventory.js`/`page-classifier.js`), documentarla en `00-procedimiento.md` §6, actualizar las reglas que la mencionan y agregar un test con un BP sintético.

**8.4 Cambiar el HTML:** editar `ui/index.html` y/o `ui/app.js`; `npm run build`; abrir `dist/BlueprintEvidenceStudio.html` en un navegador y revisar (el panel del navegador de Claude no ejecuta scripts de `file://`: servir por http, p. ej. `python3 -m http.server`). Mantener el HTML autocontenido y sin URLs remotas.

**8.5 Versionado (semver):** *parche* = corrección sin cambio de regla; *menor* = cambio de comportamiento de una regla o dato nuevo; *mayor* = cambio de contrato/estructura. Studio y Skill llevan versión propia (`src/version.js`). Al subir, hay que cambiar: `src/version.js`, `package.json`, `UI_VERSION` en `ui/app.js`, los encabezados `v12.x.x` de `skills/.../references/*.md` y `MANIFEST.md`, `scripts/validate-skill-zip.mjs` y `scripts/package-skill.ps1` (nombre del zip), el nombre y contenido de `dist/INSTRUCCIONES-AGENTE-v*.md`, los regex de versión en `test/` (`skill.test.js`, `v048`, `v060`, `v086preguntas`, `v090comandos`, `v1131`, `ui-contract-invariance`: `replaceAll('<versión>','0.8.3')`), y la documentación. Busca con `grep -rn "12\.2\.0\|0\.11\.0"` (excluye `node_modules` y el corpus). Con macOS: `sed` BSD no soporta `\b`; usa `perl -pi -e`.

**8.6 Reconstruir entregables:**
```bash
npm test
npm run build                       # genera dist/BlueprintEvidenceStudio.html
cp dist/BlueprintEvidenceStudio.html dist/BlueprintEvidenceStudio-v<x>.html
(cd skills && zip -qr ../dist/validar-blueprint-integracion-v<x>.zip validar-blueprint-integracion -x "*.DS_Store")
node scripts/validate-skill-zip.mjs # debe decir 11 archivos
# copiar HTML, zip, instrucciones, CHANGELOG, HANDOFF, README, AGENTS a ../docs/validacion_skill_analista/entrega-<skill>/
```
En Windows existe `npm run skill:pack` (PowerShell). `npm run skill:validate` apunta a una ruta de Codex de otra máquina y no es portable.

**8.7 Entorno:** Node ≥ 20. `node_modules` en esta carpeta es un **enlace simbólico** a `../ARCHIVADO-blueprint-evidence-studio-nueva/node_modules`; en una máquina nueva ejecuta `npm install` (esbuild, playwright, csv-parse). Sin Git.

## 9. Trabajo con la analista

1. La analista define y confirma las reglas; la IA propone, aplica solo lo confirmado, y documenta.
2. Cuando llegan observaciones: analizar contra el corpus, listar conflictos y dudas, responder con evidencia (ids, JSON), proponer texto de regla, esperar confirmación, aplicar, alinear todo (§0.2), subir versión, entregar paquete + mensaje para la analista. Proceso detallado: `docs/processes/PROCESO-ciclo-con-la-analista.md`.
3. Cuando el agente «dice algo raro»: **primero** revisar el JSON enriquecido, **después** la Skill, **al final** el agente. La mayoría de los errores han estado en el Studio o en el dibujo, no en el agente.
4. **La analista puede modificar el código fuente** (HTML, instrucciones, reglas) con otra IA. Quien retome debe: leer el `CHANGELOG` y el diff contra la última versión entregada; correr `npm test`; si hay fallos, distinguir entre un cambio intencional (actualizar el test y documentarlo) y una regresión; y dejar este handoff y el CHANGELOG al día.

### 9.1 Decisiones vigentes de la analista (las más recientes; el resto está en ADR y CHANGELOG)
- Comandos y modelos se identifican por la etiqueta de la figura. `USER_TASK` no se permite en el hijo. `MODEL_GROUP` se permite en INTEGRACIÓN, DOMINIO PRODUCTOR o SISTEMAS EXTERNOS. `SERVICE` y `SERVICE_MCI` certifican servicio (y el contenedor con `SERVICE` certifica el hijo).
- No hay reglas de ubicación por figura (la columna «Ubicación» del Excel se omite; rigen CNT-003/004/005). Las figuras `THIRD_PARTY_*` van en SISTEMAS EXTERNOS.
- API-001: `Nombre Producto - Nombre API_vMayor.Menor.Parche`. API externa = `THIRD_PARTY_API`.
- Tercera sección de API/servicios en SISTEMAS EXTERNOS: vacía o con cualquier texto = Cumple (API-003, SRV-003).
- SRV-006 (nueva, 24/11/2026): Capa de Tópicos para servicios invocados con MQ; excluye el principal de E3 y el hijo. La capa se asocia por contención o por el grupo de la figura MQ (cualquier etiqueta con `MQ_`).
- GW-001 (25/11/2026): solo compuertas exclusivas e inclusivas.
- HTML: nombre «Blueprint Evidence Studio»; sin textos técnicos de versión/contrato en el encabezado; versión solo en el pie; BDD y plantillas ocultas.

## 10. Pendientes y decisiones abiertas

- Corrida del paquete 12.2.0 con Copilot y retroalimentación de la analista.
- La analista revisa la lista de BP donde la capa de despliegue no contiene al hijo: Mortgage Loan Payment Schedule, Currency Exchange Quote Information, Credit Limit information, Customer Relationships Data, Currency Exchange Transactions, Credit Card Administration.
- Correcciones pendientes en la biblioteca/Excel de la analista: «ONW_» → «OWN_» (fila 39), EVENT «Dominio», valor «SI», `OTHER_DOMAIN_SERVICE` con certificación en blanco.
- Política para **BP antiguos sin etiquetas** (hoy se evalúan por nombre/estructura; 5 páginas del corpus quedan sin hijo certificado).
- Reconocimiento de nombres con texto adicional (p. ej. «Aumento de cupo») y del Inicio auxiliar del EVC: **no decidido ni implementado**.
- SRV-004 y MQ-002 conservan la regla de parejas sin propietario (`No verificable`); solo API-004 se relajó (ADR-0008). Falta confirmar si se extiende.
- EXT-001 puede pasar a `No verificable` en BP con actividades BPMN sin tipo dentro de un auxiliar (ADR-0009); no medido en todo el corpus.
- Licencia formal del software (hoy: todos los derechos reservados, `UNLICENSED`): la decide el autor.
- Ejecutar `npm run test:e2e` en una máquina con navegador soportado.
- Inicializar Git cuando se defina destino y alcance.

## 11. Dónde está cada cosa

| Tema | Lugar |
|---|---|
| Historial de versiones | `CHANGELOG.md` |
| Decisiones (ADR-0001 a 0023) | `docs/decisions/` |
| Arquitectura | `docs/architecture/ARCHITECTURE.md` |
| Contrato del JSON | `docs/contracts/` |
| Procesos (ajuste y liberación, regresión, ciclo con la analista, mantener documentación) | `docs/processes/` |
| Handoff anterior (hasta 24/11/2026) y auditorías | `docs/audits/` (`HANDOFF_historico_hasta_2026-11-24.md`) |
| Paquetes entregados, anexos e historial de validación | `../docs/validacion_skill_analista/` |
| Índice general | `../docs/INDICE_DOCUMENTACION.md` |
| Confidencialidad / publicación | `docs/PUBLIC_DISTRIBUTION.md` |
| Autoría | `AUTORIA.md` |

## 12. Trampas conocidas

- Las pruebas de corpus tienen **números fijos**: agregar un BP a `Blueprints_ejemplos/` o cambiar un tipo cambia conteos (`v048`: tally por tipo; `v1131`: páginas con pregunta). Actualízalos con los valores reales, con comentario y fecha; no los relajes.
- `ui-contract-invariance` compara el JSON de 5 BP antiguos con una huella SHA-256 tras reemplazar la versión del Studio por `0.8.3`; al subir versión hay que cambiar ese `replaceAll`.
- `npm run build` genera `dist/BlueprintEvidenceStudio.html` sin versión en el nombre; copia a `-v<x>.html` para entregar.
- Si un grupo de Lucidchart contiene a otro, el grupo **más externo etiquetado** manda para `figuraBiblioteca`.
- El nombre de una figura es **el primer texto no vacío** (Title, Text, FloatingTitle) (ADR-0010).
- No escribas «E1/E2/E3» solos en textos para la analista.
- No publiques `Blueprints_ejemplos/`, `skills/` ni normativa en repositorios públicos.
