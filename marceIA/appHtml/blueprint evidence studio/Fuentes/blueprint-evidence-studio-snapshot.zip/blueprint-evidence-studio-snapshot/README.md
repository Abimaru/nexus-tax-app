# Blueprint Evidence Studio

**Del dibujo a la evidencia.** Lee un blueprint de arquitectura exportado de Lucidchart y lo entrega ordenado, con cada figura identificada, para que revisarlo sea rápido, consistente y explicable.

> Creación de Andres Ibarguen (co-diseño e implementación con Claude, Anthropic). Ver `AUTORIA.md`.
> **Versión vigente (25/11/2026):** Studio **0.11.0** · Skill **12.2.0** (38 reglas) · contrato `copilot-factual-v0.4.6.1`.
> **Empieza por `HANDOFF.md`**: es la guía completa para retomar el proyecto (también con otra IA). Historial: `CHANGELOG.md`.

## Qué hay aquí

| Pieza | Para qué sirve | Dónde |
|---|---|---|
| **Studio** | HTML autocontenido que convierte el JSON de Lucidchart en un JSON enriquecido (`-ENRIQUECIDO.json`) con el tipo de cada figura, contención, grupos, conexiones, escenario E1/E2/E3 e inventario por página. No evalúa reglas. | `src/`, `ui/` → `dist/BlueprintEvidenceStudio-v0.11.0.html` |
| **Skill** `validar-blueprint-integracion` | Las 38 reglas de la analista, sus fichas y el procedimiento de evaluación (Cumple / No cumple / No verificable / No aplica). | `skills/validar-blueprint-integracion/` → `dist/validar-blueprint-integracion-v12.2.0.zip` |
| **Instrucciones del agente** | Texto breve para el agente (Copilot) que usa la Skill. | `dist/INSTRUCCIONES-AGENTE-v12.2.0.md` |

## Uso rápido

Requiere Node.js 20 o superior.

```bash
npm install          # solo la primera vez (esbuild, playwright, csv-parse)
npm test             # 177 pruebas
npm run build        # genera dist/BlueprintEvidenceStudio.html (autocontenido, sin red)
```

Para usarlo: abrir el HTML en un navegador → cargar el JSON de Lucidchart → escribir el Nombre del Blueprint → seleccionar páginas → descargar el JSON enriquecido → subirlo al agente que tiene la Skill.

Empaquetar la Skill y validarla:

```bash
(cd skills && zip -qr ../dist/validar-blueprint-integracion-v12.2.0.zip validar-blueprint-integracion -x "*.DS_Store")
node scripts/validate-skill-zip.mjs     # 11 archivos
```

## Estructura

```
AUTORIA.md README.md AGENTS.md HANDOFF.md CHANGELOG.md   documentos de entrada
src/            motor (módulos ES): normalización, contención, grupos, conexiones, despliegue, exportación, inventario
ui/             interfaz (index.html + app.js) → HTML autocontenido con esbuild
skills/         la Skill (11 archivos)
dist/           entregables generados e historial
test/           pruebas (node:test) sobre el corpus real y casos sintéticos
Blueprints_ejemplos/   34 blueprints reales para regresión (confidencial)
Inventario_nuevo/      biblioteca de figuras y equivalencias de la analista
docs/           arquitectura, contratos, decisiones (ADR), procesos, auditorías
```

## Principios

- El Studio **reconoce**; la Skill **decide**; el agente **pregunta y cierra** (ADR-0004).
- Solo se afirma lo que el JSON demuestra; evidencia parcial o ambigua → `No verificable`.
- Nada se certifica por geometría, color, orden o descarte.
- Una regla cambiada se cambia en todas partes (regla, ficha, procedimiento, instrucciones, HTML, tests).

## Documentación

- Guía para retomar el proyecto: `HANDOFF.md`. Reglas permanentes para quien lo mantenga: `AGENTS.md`.
- Decisiones: `docs/decisions/` (ADR-0001 a 0023). Procesos: `docs/processes/`. Arquitectura: `docs/architecture/ARCHITECTURE.md`. Contrato del JSON: `docs/contracts/`.
- Confidencialidad y publicación: `docs/PUBLIC_DISTRIBUTION.md`. No publicar `Blueprints_ejemplos/`, `skills/` ni normativa.
