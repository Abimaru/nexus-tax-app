import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { analyzeBlueprint, copilotExport } from '../src/index.js';

const refs = 'skills/validar-blueprint-integracion/references/';
const read = async f => (await readFile(f, 'utf8')).replace(/\r/g, '');
const shape = (id, cls, text, key, extra = {}) => ({ id, class: cls, textAreas: [{ label: 'Text', text }], customData: key ? [{ key, value: '' }] : [], linkedData: [], ...extra });
const layer = (id, text) => shape(id, 'UMLRectangleContainerBlock', text, 'TOPIC_LAYER', { contains: { shapes: [], lines: [], groups: [] } });
const svc = id => ({ id, class: 'UMLClassBlock', textAreas: [{ label: 'Title', text: 'Customer Keys - Retrieve Keys' }, { label: 'Text1', text: 'retrieveKeys' }, { label: 'Text2', text: 'Tarea' }], customData: [], linkedData: [] });
const page = (shapes, groups) => {
  const dom = shape('dom', 'UMLRectangleContainerBlock', 'INTEGRACIÓN', null, { contains: { shapes: shapes.map(x => x.id), lines: [], groups: [] } });
  const raw = { id: 'x', title: 'x', pages: [{ id: 'p', title: 'p', index: 0, items: { shapes: [dom, ...shapes], lines: [], groups, layers: [] }, customData: [], linkedData: [] }] };
  const model = analyzeBlueprint(raw, { sourceName: 'x.json' });
  return copilotExport(model, { selectedPageIds: model.pages.map(p => p.page.id) }).pages[0];
};
const grp = (id, key, members) => ({ id, members, customData: [{ key, value: '' }], linkedData: [] });

test('0.10.1: la capa de tópicos se asocia por el grupo de la figura MQ (OWN_UMG_MQ_SERVICE) aunque no contenga al servicio', () => {
  const p = page([layer('tl', 'rutaA rutaB'), svc('s'), shape('in', 'BPMNActivity', 'Modelo de Lectura', 'ENTRADA'), shape('out', 'BPMNActivity', 'Modelo de Salida', 'SALIDA')],
    [grp('mq', 'OWN_UMG_MQ_SERVICE', ['tl', 'sv']), grp('sv', 'SERVICE', ['s', 'in', 'out'])]);
  const s = p.inventory.servicios.find(x => x.id === 's');
  assert.equal(s.consumidoPorColas, true);
  assert.equal(s.capaTopicos.id, 'tl');
  assert.equal(s.capaTopicos.asociadaPor, 'GRUPO');
  assert.deepEqual(s.capaTopicos.topicos, ['rutaA', 'rutaB']);
});

test('0.10.1: cualquier figura con MQ asocia su capa por grupo (THIRD_PARTY_MQ_SERVICE con auxiliar EXT_AUX)', () => {
  const p = page([layer('tl', 'topicoX'), svc('s'), shape('aux', 'UMLClassBlock', 'aux', 'EXT_AUX')],
    [grp('mq', 'THIRD_PARTY_MQ_SERVICE', ['tl', 'sv', 'ax']), grp('sv', 'SERVICE', ['s']), grp('ax', 'EXT_AUX', ['aux'])]);
  const s = p.inventory.servicios.find(x => x.id === 's');
  assert.equal(s.figura, 'THIRD_PARTY_MQ_SERVICE');
  assert.equal(s.capaTopicos?.id, 'tl');
});

test('0.10.1: dos capas de tópicos en el mismo grupo son ambiguas: capaTopicos null y candidatas', () => {
  const p = page([layer('t1', 'a'), layer('t2', 'b'), svc('s')], [grp('mq', 'OWN_UMG_MQ_SERVICE', ['t1', 't2', 'sv']), grp('sv', 'SERVICE', ['s'])]);
  const s = p.inventory.servicios.find(x => x.id === 's');
  assert.equal(s.capaTopicos, null);
  assert.deepEqual(s.capasTopicosCandidatas.map(c => c.id).sort(), ['t1', 't2']);
});

test('0.10.1: un servicio sin MQ en la figura no se marca como consumido por colas', () => {
  const p = page([layer('tl', 'a'), svc('s')], [grp('g', 'OWN_UMG_SERVICE', ['tl', 'sv']), grp('sv', 'SERVICE', ['s'])]);
  const s = p.inventory.servicios.find(x => x.id === 's');
  assert.equal(s?.consumidoPorColas, undefined);
});

test('0.10.1: BP real (5): el servicio consultar_marcacion_gmf_cuenta_sti trae su capa de tópicos por grupo', async () => {
  const dir = 'Blueprints_ejemplos/Deposit Account Tax Exemption Information (5)';
  const { readdirSync } = await import('node:fs');
  const f = readdirSync(dir).find(n => n.endsWith('.json'));
  const out = copilotExport(analyzeBlueprint(JSON.parse((await read(`${dir}/${f}`)).replace(/^﻿/, '')), { sourceName: f }));
  const real = out.pages.find(p => p.page.title === 'retrieveAccountTaxDetails');
  const s = real.inventory.servicios.find(x => x.name === 'consultar_marcacion_gmf_cuenta_sti');
  assert.equal(s.capaTopicos.id, 'W_HPpVI~acGA');
  assert.equal(s.capaTopicos.asociadaPor, 'GRUPO');
  const tpl = out.pages.find(p => p.page.title === 'Page 3');
  assert.equal(tpl.pageClassification.kind, 'TEMPLATE_OR_LEGEND'); // la plantilla de la biblioteca no se evalúa
});

test('0.10.1: SRV-006 documenta la asociación por grupo, la ambigüedad y la exclusión del principal de E3', async () => {
  const srv = await read(`${refs}02-reglas-api-servicios.md`), fichas = await read(`${refs}08-fichas.md`);
  const body = srv.split(/^### SRV-006 -/m)[1].split(/^### /m)[0];
  assert.match(body, /mismo grupo de la figura con MQ/);
  assert.match(body, /THIRD_PARTY_MQ_SERVICE/);
  assert.match(body, /capasTopicosCandidatas/);
  assert.match(body, /servicio principal de E3 y el hijo principal quedan fuera/);
  assert.match(fichas, /asociadaPor: GRUPO/);
  assert.match(fichas, /no el servicio principal de E3 ni el hijo/);
});

// ---- 0.10.2: GW-001 solo para compuertas exclusivas e inclusivas ----
test('0.11.0: el inventario expone el subtipo de la compuerta por la etiqueta de la figura', () => {
  const gate = (id, key) => shape(id, 'BPMNGateway', '', key);
  const p = page([gate('ge', 'EXCLUSIVE'), gate('gi', 'INCLUSIVE'), gate('gp', 'PARALLEL'), gate('gv', 'EVENT_BASED'), gate('gn', null)], []);
  const by = Object.fromEntries(p.inventory.compuertas.map(c => [c.id, c.subtipo]));
  assert.deepEqual(by, { ge: 'EXCLUSIVE', gi: 'INCLUSIVE', gp: 'PARALLEL', gv: 'EVENT_BASED', gn: undefined });
});

test('0.11.0: GW-001 documenta solo exclusivas e inclusivas, la excepción de las demás y la figura sin etiqueta', async () => {
  const est = await read(`${refs}01-reglas-estructura.md`), fichas = await read(`${refs}08-fichas.md`);
  const body = est.split(/^### GW-001 -/m)[1].split(/^### /m)[0];
  assert.match(body, /exclusivas e inclusivas/);
  assert.match(body, /`PARALLEL`, `EVENT_BASED`, `PARALLEL_EVENT_BASED`/);
  assert.match(body, /no se exige pregunta/);
  assert.match(body, /sin etiqueta de subtipo/);
  assert.doesNotMatch(body, /La regla no evalúa el subtipo/);
  assert.match(fichas, /\*\*GW-001\.\*\* Población: `compuertas` con `subtipo` `EXCLUSIVE` o `INCLUSIVE`/);
});
