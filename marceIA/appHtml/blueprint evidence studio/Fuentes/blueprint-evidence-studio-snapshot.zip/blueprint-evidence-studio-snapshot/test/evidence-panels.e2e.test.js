import test from 'node:test';
import assert from 'node:assert/strict';
import { chromium } from 'playwright';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';

const files={
  oski:'Blueprints_ejemplos/Collections_Bill_Payments/NMD - BP -  Collections_Bill_Payments-Pay_Bill U (1).json',
  currency:'Blueprints_ejemplos/Currency Exchange Transaction Pricing 2/MCI - BP - Currency Exchange Transaction Pricing - Currency Receiving.json',
  virtual:'Blueprints_ejemplos/Virtual Account Opening/MCI - BP - Virtual Account Opening - Virtual Account V2.1.0 (2).json',
  debit:'Blueprints_ejemplos/Debit Card Issuance/Copy of MCI - BP - [Debit Card Issuance] - [Management].json'
};
async function open(page){await page.goto(pathToFileURL(resolve('dist/BlueprintEvidenceStudio.html')).href);await page.fill('#blueprintName','Visual Evidence Candidate');}
async function run(page,file){await page.setInputFiles('#jsonFile',resolve(file));await page.waitForSelector('.pageChoice');if(await page.locator('.pageChoice:checked').count()===0)await page.locator('.pageChoice').first().check();const before=await page.evaluate(()=>window.__BES__.getGeneration());await page.click('#analyze');await page.waitForFunction(x=>window.__BES__.getGeneration()>x,before);assert.equal(await page.evaluate(()=>window.__BES__.UI_VERSION),'0.4.7-candidate');}

test('four evidence panels explain real Oski, Currency, Virtual Account and Debit Card data',async()=>{const browser=await chromium.launch({channel:'msedge',headless:true});try{const page=await browser.newPage();await open(page);
  await run(page,files.oski);assert.ok(await page.locator('#bpmnRows tr').count()>0);assert.ok(await page.locator('#producerRows tr').count()>0);assert.ok(await page.locator('#childRows tr').count()>0);assert.equal(await page.locator('#modelRows tr').count(),13);assert.doesNotMatch(await page.locator('#bpmnRows').innerText(),/CERTIFIED_BY_EXPLICIT_CUSTOM_DATA/);
  await run(page,files.currency);assert.equal(await page.locator('#modelRows tr').count(),6);assert.match(await page.locator('#producerRows').innerText(),/No hay dominios/);
  await run(page,files.virtual);assert.ok(await page.locator('#producerRows tr').count()>=2);assert.match(await page.locator('#producerRows').innerText(),/STRUCTURAL_CHILD_EVENT_MAIN_PATH/);
  await run(page,files.debit);assert.match(await page.locator('#childRows').innerText(),/Rol no determinado/);assert.match(await page.locator('#childRows').innerText(),/\(sin nombre\)/);
}finally{await browser.close();}});

test('panels tolerate absent, empty and conflicting evidence without normative indicators',async()=>{const browser=await chromium.launch({channel:'msedge',headless:true});try{const page=await browser.newPage();await open(page);await run(page,'qa/cases/v123-a-inicio/lucid.json');assert.match(await page.locator('#bpmnRows').innerText(),/Sin declaración customData|customData vacío/);assert.doesNotMatch(await page.locator('#results').innerText(),/\bNo cumple\b|\bCumple\b|\d+(?:[.,]\d+)?\s*%/);await run(page,'qa/cases/p3-contradiction/lucid.json');assert.equal(await page.locator('#results').isVisible(),true);assert.match(await page.locator('#bpmnSummary').innerText(),/no es un indicador normativo/i);
}finally{await browser.close();}});

test('manually selected non-evaluable page remains labeled as factual evidence',async()=>{const browser=await chromium.launch({channel:'msedge',headless:true});try{const page=await browser.newPage();await open(page);await page.setInputFiles('#jsonFile',resolve(files.oski));await page.waitForSelector('.pageChoice');await page.evaluate(()=>document.querySelectorAll('.pageChoice').forEach(x=>x.checked=false));await page.locator('label',{hasText:'Escenarios BDD'}).locator('input').check();const before=await page.evaluate(()=>window.__BES__.getGeneration());await page.click('#analyze');await page.waitForFunction(x=>window.__BES__.getGeneration()>x,before);assert.match(await page.locator('#pages').innerText(),/BDD_OR_REQUIREMENTS/);assert.doesNotMatch(await page.locator('#results').innerText(),/\bNo cumple\b|\bCumple\b|\d+(?:[.,]\d+)?\s*%/);
}finally{await browser.close();}});
