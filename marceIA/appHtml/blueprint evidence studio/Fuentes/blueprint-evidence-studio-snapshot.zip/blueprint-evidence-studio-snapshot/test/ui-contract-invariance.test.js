import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { analyzeBlueprint, copilotExport } from '../src/index.js';

const cases=[
  ['Oski','Blueprints_ejemplos/Collections_Bill_Payments/NMD - BP -  Collections_Bill_Payments-Pay_Bill U (1).json','06f3790b576d1b4d286611814a68734db7228bfe17f119186e6b290d3a6eb8f1','268ea0b24638ab7e6bf4a43ef68599a85d732e7a7566c694a9d2f571a67875e3'],
  ['Currency Exchange','Blueprints_ejemplos/Currency Exchange Transaction Pricing 2/MCI - BP - Currency Exchange Transaction Pricing - Currency Receiving.json','33215c64f31ffea0e056b0d99dd4317f86ece60eab6e341fb64fa75f5d4584cb','d71a02bba22f497d59a8f8098189bafbb2075fdc62bb8852ccb4d51a59771335'],
  ['Virtual Account Opening','Blueprints_ejemplos/Virtual Account Opening/MCI - BP - Virtual Account Opening - Virtual Account V2.1.0 (2).json','7f22ef17f6fa8b236808ebb4f93e20fc60b60b4ddec4e5bac51c05e6f58b727c','244a190d2996f6fa6b1071891cfc1aa4215e806ced3735b9f1f12756732a8cc1'],
  ['Debit Card','Blueprints_ejemplos/Debit Card Issuance/Copy of MCI - BP - [Debit Card Issuance] - [Management].json','e0209876dd8e017c31f709fa1c2449fa354bac521ee7bdbd6b16abe5fe403928','c080d5608f0715dc4818bc1a7cf7ccc20a27aae428e33739f69cdff9e54c82b9'],
  ['Real Time Payments','Blueprints_ejemplos/Real Time Payments QR Keys Management/MCI - BP - Real Time Payments QR Keys Management - Commerce Keys (1).json','d67d9b3909021e2bea6a0278bc80375e9426c6eb934a5a1f3ae6dc5cfa922973','19962da22da4c25b8e3f2367835eb2d315a9643ec10c9bdaa82de3821976750e']
];
// 0.8.3 cambia deliberadamente el JSON respecto de 0.6.0 (sin leyenda, hijo real, BPMNGroup auxiliar, tipos por ámbito): la línea base se rehace con la salida de 0.8.3.
const exportOf=async file=>{const raw=JSON.parse((await readFile(file,'utf8')).replace(/^\uFEFF/,'')),model=analyzeBlueprint(raw,{sourceName:file}),selectedPageIds=model.pages.filter(p=>['OPERATIONAL','MIXED'].includes(p.pageClassification.kind)).map(p=>p.page.id);return copilotExport(model,{selectedPageIds});};
// 0.10.0: el JSON lleva la versión del Studio; se normaliza a 0.8.3 para comprobar que, sin etiquetas nuevas, el resto del contenido no cambia.
const sha=value=>createHash('sha256').update(JSON.stringify(value).replaceAll('0.11.0','0.8.3')).digest('hex');

test('v0.8.3 compact JSON baseline stays byte-identical for real selections',async()=>{for(const[name,file,expected]of cases)assert.equal(sha(await exportOf(file)),expected,name);});

