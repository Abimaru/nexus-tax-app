﻿import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { analyzeBlueprint, reconstructContainment, normalizePage } from '../src/index.js';

const load = async path => JSON.parse((await readFile(path, 'utf8')).replace(/^\uFEFF/, ''));
const examples = {
  e2: 'Blueprints_ejemplos/Ejemplo E2/MCI - BP - Currency Exchange Transaction Pricing - Currency Receiving (3).json',
  debit: 'Blueprints_ejemplos/Debit Card Issuance/Copy of MCI - BP - [Debit Card Issuance] - [Management].json',
  oski: 'Blueprints_ejemplos/Collections_Bill_Payments/NMD - BP -  Collections_Bill_Payments-Pay_Bill U (1).json',
  multi: 'Blueprints_ejemplos/QR Payment Transactions Reporting/MCI - BP - QR Payment Transactions Reporting - Payment Transactions.json'
};

test('E2 preserves baseline counts and the three known deployment pairs', async () => {
  const out = analyzeBlueprint(await load(examples.e2));
  const page = out.pages.find(p => p.page.title === 'executeTransactionCurrencyExchange');
  assert.deepEqual([page.counts.shapes, page.counts.connections], [99, 20]);
  const pairs = new Set(page.architecturalStructure.deploymentPairs.map(x => `${x.flow.id}/${x.layer.id}`));
  for (const expected of ['4Oc~UAg.ChZ2/4Oc~STvzS7WZ','x6OMy7H_BdmL/x6OMFCgq99Xl','AwQGL8iVQ5bP/AwQGN0rfikTW']) assert.ok(pairs.has(expected));
  assert.ok(page.architecturalStructure.deploymentPairs.every(x => x.resolvedOwnerId === null));
});

test('known baselines and multipage operations are preserved', async () => {
  const debit = analyzeBlueprint(await load(examples.debit)).pages.find(p => p.page.title === 'createCustomizedCardConsulta');
  const oski = analyzeBlueprint(await load(examples.oski)).pages.find(p => p.page.title === 'msDebitAccountPayment');
  assert.deepEqual([debit.counts.shapes, debit.counts.connections], [170, 78]);
  assert.deepEqual([oski.counts.shapes, oski.counts.connections], [126, 30]);
  assert.equal(analyzeBlueprint(await load(examples.multi)).pages.length, 5);
});
test('connection IDs, endpoints, custom data, groups and models survive factual export', async () => {
  const input = await load(examples.e2); const out = analyzeBlueprint(input);
  const raw = input.pages[1].items; const evidence = out.pages[1].evidence;
  assert.deepEqual(evidence.lines, raw.lines); assert.deepEqual(evidence.groups, raw.groups);
  assert.equal(evidence.shapes.find(x => x.id === 'tQ7mv8VyFaR3').customData[0].key, 'ENTRADA');
  assert.equal(evidence.shapes.find(x => x.id === 'tQ7mOxCbJC2l').customData[0].key, 'SALIDA');
  assert.deepEqual(evidence.lines.find(x => x.id === '4Oc~L8JMez3-').endpoint1, raw.lines.find(x => x.id === '4Oc~L8JMez3-').endpoint1);
});

test('conflicts, cycles and missing references are unresolved rather than invented', () => {
  const page = normalizePage({ id:'p', items:{ shapes:[
    {id:'a',class:'RectangleContainerBlock',contains:{shapes:['x','b']}},
    {id:'b',class:'RectangleContainerBlock',contains:{shapes:['x','a','missing']}},
    {id:'x',class:'UMLClassBlock'}], lines:[], groups:[], layers:[] }});
  const c = reconstructContainment(page);
  assert.equal(c.directParent.has('x'), false);
  assert.ok(c.issues.some(x => x.code === 'CONTAINMENT_CYCLE'));
  assert.equal(c.missingReferences[0].childId, 'missing');
});

test('absence of flow/layer stays absence of evidence', async () => {
  const out = analyzeBlueprint(await load(examples.e2));
  const page = out.pages[1];
  const without = page.architecturalStructure.components.filter(c => !page.architecturalStructure.deploymentPairs.some(a => a.relatedCandidates.some(x => x.id === c.id)));
  assert.ok(without.length > 0);
  assert.ok(without.every(x => !('compliance' in x)));
});

test('multiple principal candidates remain separate', () => {
  const input={pages:[{id:'p',title:'p',items:{shapes:[{id:'api1',class:'UMLClassBlock'},{id:'api2',class:'UMLClassBlock'},{id:'event',class:'BPMNEvent'}],lines:[{id:'l1',endpoint1:{style:'None',connectedTo:'api1'},endpoint2:{style:'Arrow',connectedTo:'event'}},{id:'l2',endpoint1:{style:'None',connectedTo:'api2'},endpoint2:{style:'Arrow',connectedTo:'event'}}],groups:[],layers:[]}}]};
  assert.equal(analyzeBlueprint(input).pages[0].architecturalStructure.principalInteractionPaths.length,2);
});

test('custom domains and notation membership stay distinct', async () => {
  const out=analyzeBlueprint(await load('fixtures/synthetic/custom-domain.json')).pages[0];
  const domain=out.architecturalStructure.rootContainers.find(x=>x.id==='domain');
  assert.equal(domain.role,'PRODUCER'); assert.equal(domain.roleStatus,'RESOLVED');
  assert.equal(out.architecturalStructure.components.find(x=>x.id==='legend-api').notation,true);
  assert.equal(out.architecturalStructure.deploymentPairs.length,0);
});

// End of core regression suite.
