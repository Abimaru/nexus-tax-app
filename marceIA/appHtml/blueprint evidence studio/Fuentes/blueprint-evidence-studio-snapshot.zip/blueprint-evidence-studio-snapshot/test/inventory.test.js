import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { analyzeBlueprint, copilotExport } from '../src/index.js';

const uml = (id, title, third = '') => ({ id, class: 'UMLClassBlock', textAreas: [{ label: 'Title', text: title }, { label: 'Text1', text: 'op' }, { label: 'Text2', text: third }] });
const api = (id, third = 'Private - Entidad') => uml(id, `Cuenta ${id} - Consultar v1.0.0`, third);
const model = (id, io) => ({ id, class: 'BPMNActivity', textAreas: [{ label: 'Text', text: `campo ${id}` }], customData: io ? [{ key: io, value: '' }] : [] });
const box = (id, text, contains = [], cls = 'UMLRectangleContainerBlock') => ({ id, class: cls, textAreas: [{ label: 'Text', text }], contains: { shapes: contains, lines: [], groups: [] } });
const run = (shapes, lines = [], groups = []) => copilotExport(analyzeBlueprint({ pages: [{ id: 'p', title: 'p', items: { shapes, lines, groups, layers: [] } }] }), { selectedPageIds: ['p'] }).pages[0];
const get = (page, id) => page.components.find(c => c.id === id);
const aux = (id, name, ids) => box(id, name, ids, 'BPMNGroup');
const integration = (inner, topLevel = []) => [box('I', 'INTEGRACIÓN', inner.map(x => x.id)), ...inner, ...topLevel];

test('inventario: contenedores padre con dominio y contenido directo por tipo', () => {
  const a = api('a');
  const page = run([...integration([aux('X', 'EVC Pagos', ['a']), a]), box('P', 'DOMINIO PRODUCTOR', [])]);
  assert.ok(page.inventory.contenedoresPadre.some(c => c.name === 'INTEGRACIÓN' && c.domainRole === 'INTEGRATION'));
  const x = page.inventory.contenedores.find(c => c.id === 'X');
  assert.equal(x.tipo, 'SISTEMA_EXTERNO_AUXILIAR');
  assert.equal(x.parentId, 'I');
  assert.ok(Object.values(x.contiene).flat().includes('a'));
  for (const key of ['capas', 'flujos', 'federados', 'compuertas', 'eventosBpmn', 'modelos', 'relaciones', 'omitidos']) assert.ok(Array.isArray(page.inventory[key]), key);
});

test('relaciones: una entrada por pareja con sus líneas, origen por terminaciones, extremo suelto y línea como participante', () => {
  const a = api('a'), c = { id: 'c', class: 'BPMNActivity', textAreas: [{ label: 'Text', text: 'Consultar cuenta' }] };
  const l1 = { id: 'l1', endpoint1: { style: 'CircleOpen', connectedTo: 'c' }, endpoint2: { style: 'Generalization', connectedTo: 'a' } };
  const l2 = { id: 'l2', endpoint1: { style: 'Generalization', connectedTo: 'c' }, endpoint2: { style: 'CircleOpen', connectedTo: 'a' } };
  const loose = { id: 'l3', endpoint1: { style: 'CircleOpen', connectedTo: 'a' }, endpoint2: { style: 'Generalization' } };
  const fromLine = { id: 'l4', endpoint1: { style: 'CircleOpen', connectedTo: 'l1' }, endpoint2: { style: 'Generalization', connectedTo: 'a' } };
  const page = run([...integration([a]), c], [l1, l2, loose, fromLine]);
  const pair = page.inventory.relaciones.find(r => r.participantes.some(p => p.id === 'c') && r.participantes.some(p => p.id === 'a'));
  assert.equal(pair.lineas.length, 2);
  assert.deepEqual(pair.participantes.map(p => p.tipo).sort(), ['API', 'COMANDO']);
  assert.deepEqual(pair.lineas.map(l => [l.origen, l.destino]).sort(), [['a', 'c'], ['c', 'a']]);
  const suelta = page.inventory.relaciones.flatMap(r => r.lineas).find(l => l.id === 'l3');
  assert.equal(suelta.extremoSinConectar, true);
  assert.equal(suelta.estado, 'PARTIAL');
  assert.deepEqual([suelta.estiloOrigen, suelta.estiloDestino], ['CircleOpen', 'Generalization']);
  assert.deepEqual(page.inventory.conexionesPendientes.map(x => x.id).sort(), ['l3', 'l4']);
  const nace = page.inventory.relaciones.find(r => r.lineas.some(l => l.id === 'l4'));
  assert.ok(nace.participantes.some(p => p.tipo === 'LINEA' && p.id === 'l1'));
  assert.deepEqual(nace.participantes.find(p => p.id === 'l1').conecta.map(x => x.tipo).sort(), ['API', 'COMANDO']);
});

test('modelos: un auxiliar con N APIs, N entradas y N salidas se asocia por conteo', () => {
  const page = run(integration([aux('X', 'Cualquier auxiliar', ['a', 'me', 'ms']), api('a'), model('me', 'ENTRADA'), model('ms', 'SALIDA')]));
  const m = get(page, 'a').modelAssociation;
  assert.equal(m.entrada.status, 'BY_COUNT');
  assert.deepEqual(m.entrada.ids, ['me']);
  assert.equal(m.salida.status, 'BY_COUNT');
  assert.equal(m.entrada.scopeId, 'X');
  assert.equal(page.inventory.modelos.find(x => x.id === 'me').estado, 'ASOCIADO_POR_CONTEO');
});

test('modelos: dos APIs con un solo par es ambiguo; una API sin salida y sin modelos sueltos es ausencia en el ámbito', () => {
  const two = run(integration([aux('X', 'EVC Pagos', ['a', 'b', 'me', 'ms']), api('a'), api('b'), model('me', 'ENTRADA'), model('ms', 'SALIDA')]));
  assert.deepEqual([get(two, 'a').modelAssociation.entrada.status, get(two, 'a').modelAssociation.entrada.basis], ['AMBIGUOUS', 'COUNT_MISMATCH']);
  assert.equal(get(two, 'b').modelAssociation.salida.status, 'AMBIGUOUS');
  const half = run(integration([aux('X', 'EVC Pagos', ['a', 'me']), api('a'), model('me', 'ENTRADA')]));
  assert.equal(get(half, 'a').modelAssociation.entrada.status, 'BY_COUNT');
  assert.deepEqual(get(half, 'a').modelAssociation.salida, { status: 'MISSING_IN_SCOPE', ids: [], scopeId: 'X' });
});

test('modelos: sueltos en otro ámbito vuelven ambigua la ausencia; los modelos dentro del hijo no cuentan', () => {
  const stray = run(integration([aux('X', 'EVC Pagos', ['a']), api('a'), model('ms', 'SALIDA'), model('me', 'ENTRADA')]));
  assert.equal(get(stray, 'a').modelAssociation.salida.status, 'AMBIGUOUS');
  assert.equal(get(stray, 'a').modelAssociation.salida.basis, 'LOOSE_MODELS_OUTSIDE_SCOPE');
  const gate = { id: 'g', class: 'BPMNGateway', textAreas: [] }, act = { id: 'c', class: 'BPMNActivity', textAreas: [{ label: 'Text', text: 'Hacer algo' }] };
  const inHijo = run([box('I', 'INTEGRACIÓN', ['a']), api('a'), box('P', 'DOMINIO PRODUCTOR', ['H']), box('H', 'Servicio principal', ['g', 'c', 'mh'], 'RectangleContainerBlock'), gate, act, model('mh', 'SALIDA')]);
  const mh = inHijo.inventory.modelos.find(x => x.id === 'mh');
  assert.equal(mh.estado, 'EN_HIJO');
  assert.equal(get(inHijo, 'a')?.modelAssociation?.salida?.status, 'MISSING_IN_SCOPE');
});

test('modelos: la asociación explícita por grupo gana sobre el conteo y un modelo sin ENTRADA/SALIDA no entra en el pool', () => {
  const groups = [{ id: 'g1', members: ['a', 'me'] }];
  const page = run(integration([aux('X', 'EVC Pagos', ['a', 'me', 'ms', 'sin']), api('a'), model('me', 'ENTRADA'), model('ms', 'SALIDA'), { ...model('sin', null) }]), [], groups);
  const m = get(page, 'a').modelAssociation;
  assert.deepEqual([m.entrada.status, m.entrada.ids], ['EXPLICIT_GROUP', ['me']]);
  assert.equal(m.salida.status, 'BY_COUNT');
  const sin = page.inventory.modelos.find(x => x.id === 'sin');
  assert.equal(sin, undefined, 'una BPMNActivity sin ENTRADA/SALIDA no es modelo');
});

test('omitidos: figuras sueltas descartadas constan con su id y motivo', () => {
  const lone = { id: 'z', class: 'DefaultSquareBlock', textAreas: [{ label: 'Text', text: 'suelta' }] };
  const page = run([...integration([api('a')]), lone]);
  assert.deepEqual(page.inventory.omitidos.find(o => o.id === 'z'), { id: 'z', motivo: 'NO_CONNECTIONS_CONTAINMENT_OR_ASSOCIATIONS' });
});

test('0.8.3: cada pareja trae su par de tipos, cada compuerta sus caminos, cada figura su ubicación y cada id un nombre', async () => {
  const file = 'Blueprints_ejemplos/Real Time Payments QR Keys Management/MCI - BP - Real Time Payments QR Keys Management - Commerce Keys (1).json';
  const raw = JSON.parse((await readFile(file, 'utf8')).replace(/^﻿/, '')), model = analyzeBlueprint(raw, { sourceName: file });
  const out = copilotExport(model, { selectedPageIds: model.pages.filter(p => ['OPERATIONAL', 'MIXED'].includes(p.pageClassification.kind)).map(p => p.page.id) });
  const pages = out.pages.filter(p => p.inventory.relaciones.length);
  assert.ok(pages.length);
  for (const { inventory: i } of pages) {
    for (const r of i.relaciones) {
      assert.match(r.par, /^[A-Z_()|]+(\+[A-Z_()|]+)?$/);
      for (const p of r.participantes) assert.ok(i.nombres[p.id] !== undefined || p.tipo === 'LINEA' || p.tipo === 'DESCONOCIDO', p.id);
      for (const p of r.participantes.filter(x => x.certeza === 'CANDIDATO')) assert.ok(p.posiblesTipos.length);
    }
    for (const g of i.compuertas) { assert.equal(typeof g.conTexto, 'boolean'); assert.ok(Array.isArray(g.caminos)); }
    for (const k of ['apis', 'servicios', 'gestoresCola', 'comandos', 'candidatos', 'sistemasExternosAuxiliares']) for (const e of i[k]) assert.ok(e.ubicacion && 'nivel' in e.ubicacion && 'dominio' in e.ubicacion, `${k} ${e.id}`);
  }
  const all = pages.flatMap(p => p.inventory.relaciones.map(r => r.par));
  assert.ok(all.includes('COMANDO+SERVICIO'), 'recepcion_callback (Tarea, sin marcador) es servicio y su pareja con el comando es COM-003');
  assert.ok(pages.some(p => p.inventory.gestoresCola.some(g => g.ubicacion.dominio === 'PRODUCER' && g.ubicacion.nivel === 'PADRE')));
});

test('auxiliar sin EVC/EPC/LDC: tantos marcadores de API como bloques sin tipo certifica API; con otra cantidad siguen siendo candidatos API o SERVICIO', () => {
  const marker = id => ({ id, class: 'BPMNEvent', textAreas: [{ label: 'Text', text: '' }] });
  const block = id => uml(id, `Cuenta ${id}`, 'Entidad');
  const one = run(integration([aux('X', 'Wenia', ['b1', 'm1']), block('b1'), marker('m1')]));
  assert.equal(get(one, 'b1').architecturalType, 'API');
  assert.equal(get(one, 'b1').inference.rule, 'API_BY_MARKER_COUNT_IN_AUXILIAR');
  const two = run(integration([aux('X', 'Wenia', ['b1', 'b2', 'm1']), block('b1'), block('b2'), marker('m1')]));
  assert.deepEqual(get(two, 'b1').possibleTypes, ['API', 'SERVICIO']);
  assert.deepEqual(get(two, 'b2').possibleTypes, ['API', 'SERVICIO']);
});
