import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile, readdir } from 'node:fs/promises';
import { createHash } from 'node:crypto';

const root='skills/validar-blueprint-integracion',refs=`${root}/references`;
const RULE_FILES=['01-reglas-estructura','02-reglas-api-servicios','03-reglas-eventos','04-reglas-despliegue','05-reglas-escenarios','06-reglas-modelos-comandos','07-reglas-gestores-colas'];
const read=async x=>(await readFile(x,'utf8')).replace(/\r/g,'');
const all=async()=>Promise.all([`${root}/SKILL.md`,...(await readdir(refs)).map(x=>`${refs}/${x}`)].map(read));

test('skill v12.2.0 has exactly eleven files',async()=>{const names=await readdir(refs);assert.equal(names.length+1,11);for(const n of['MANIFEST.md','00-procedimiento.md','08-fichas.md',...RULE_FILES.map(x=>`${x}.md`)])assert.ok(names.includes(n),n);});

test('38 unique active IDs, matching the manifest',async()=>{const ids=[];for(const f of RULE_FILES)ids.push(...[...(await read(`${refs}/${f}.md`)).matchAll(/^#+ *([A-Z]+[0-9]?-[0-9]{3}) -/gm)].map(x=>x[1]));assert.equal(ids.length,38);assert.equal(new Set(ids).size,38);const manifest=await read(`${refs}/MANIFEST.md`);for(const id of ids)assert.ok(manifest.includes(id),id);});

test('only the four states; no references to missing files or retired content',async()=>{const text=(await all()).join('\n');for(const s of['Cumple','No cumple','No verificable','No aplica'])assert.ok(text.includes(s));assert.doesNotMatch(text,/Parcialmente cumple|Cumple parcial/);const present=new Set(['SKILL.md','MANIFEST.md','00-procedimiento.md','08-fichas.md',...RULE_FILES.map(x=>`${x}.md`)]);for(const ref of new Set(text.match(/[A-Za-z0-9_.-]+\.(?:md|csv)/g)))assert.ok(present.has(ref),`missing ${ref}`);assert.doesNotMatch(text,/MATRIZ-EVIDENCIA|CONTRATO-COMPACTO|GUIA-TEXTAREAS|INSTRUCCIONES-AGENTE|v11\.2\.[123]/);});

test('version and contract are consistent',async()=>{const text=(await all()).join('\n');assert.match(await read(`${refs}/MANIFEST.md`),/v12\.2\.0/);assert.match(await read(`${refs}/00-procedimiento.md`),/copilot-factual-v0\.4\.6\.1/);const{COPILOT_CONTRACT}=await import('../src/version.js');assert.equal(COPILOT_CONTRACT,'copilot-factual-v0.4.6.1');assert.ok(text.includes(COPILOT_CONTRACT));});

test('evaluable pages produce 38 results; non-evaluable pages are reported without rule rows',async()=>{const proc=await read(`${refs}/00-procedimiento.md`),skill=await read(`${root}/SKILL.md`),man=await read(`${refs}/MANIFEST.md`);for(const t of[proc,skill,man])assert.match(t,/38 resultados/);assert.match(proc,/TEMPLATE_OR_LEGEND/);assert.match(proc,/no evaluable/i);assert.match(skill,/no evaluable/i);});

test('API text conditions live only in API-001..003',async()=>{const proc=await read(`${refs}/00-procedimiento.md`);assert.match(proc,/API-001, API-002 y API-003/);assert.doesNotMatch(proc,/modalidad reducida|estándar completo/i);});

test('SKILL.md frontmatter is valid',async()=>{const m=(await read(`${root}/SKILL.md`)).match(/^---\nname: ([a-z0-9-]+)\ndescription: (.+)\n---\n/);assert.ok(m);assert.equal(m[1],'validar-blueprint-integracion');});

test('agent instructions live in dist, outside the skill, are minimal and point to the 38-rule skill',async()=>{const ins=await read('dist/INSTRUCCIONES-AGENTE-v12.2.0.md'),skillText=(await all()).join('\n');assert.match(ins,/v12\.2\.0/);assert.ok([...ins].length<=8000,'Copilot limita las instrucciones a 8000 caracteres');assert.ok([...ins].length<=2500,'las instrucciones remiten a la Skill y no la repiten');assert.match(ins,/copilot-factual-v0\.4\.6\.1/);assert.match(ins,/38 resultados/);assert.match(ins,/Evidence Studio 0\.11\.0/);assert.match(ins,/SKILL\.md/);assert.doesNotMatch(ins,/\b42\b/);for(const s of['Cumple','No cumple','No verificable','No aplica','DECLARADO_POR_ANALISTA','TEMPLATE_OR_LEGEND','omittedComponents','tipo no determinado','E3_ELIMINATION','CHILD_INSIDE_EXTERNAL_SYSTEM','MULTIPLE_CHILD_CANDIDATES'])assert.ok(skillText.includes(s),s);assert.ok(!(await readdir(refs)).some(n=>/INSTRUCCIONES/.test(n)));});
