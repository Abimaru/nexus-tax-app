import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { analyzeBlueprint, copilotExport, interpretBpmnEventSubtype } from '../src/index.js';

const currencyPath='Blueprints_ejemplos/Currency Exchange Transaction Pricing 2/MCI - BP - Currency Exchange Transaction Pricing - Currency Receiving.json';
const load=async path=>JSON.parse((await readFile(path,'utf8')).replace(/^\uFEFF/,''));

test('Currency duplicate is byte-identical and compact inventory is unambiguous',async()=>{
  const original=await readFile('Blueprints_ejemplos/Ejemplo E2/MCI - BP - Currency Exchange Transaction Pricing - Currency Receiving (3).json','utf8');
  const duplicate=await readFile(currencyPath,'utf8');assert.equal(duplicate,original);
  const model=analyzeBlueprint(JSON.parse(duplicate)),compact=copilotExport(model,{selectedPageIds:['21B5THC7XEuN']}),page=compact.pages[0];
  assert.equal(compact.pages.length,1);assert.equal(compact.metadata.pageCount,1);assert.equal(compact.metadata.omittedPages.length,1);
  const principal=page.components.find(x=>x.id==='tQ7mFTFbJ1SW');assert.deepEqual({type:principal.architecturalType,role:principal.role,domain:principal.domainRole},{type:'API',role:'PRINCIPAL',domain:'INTEGRATION'});assert.equal('functionalClassification'in principal,false);assert.equal(principal.lucidchartType,'UMLClassBlock');assert.equal(principal.textAreas.length,3);
  const service=page.components.find(x=>x.name==='ms-transfer-service-context');assert.equal(service.architecturalType,'SERVICIO');assert.equal(service.role,'INVOCADO');
  for(const name of['COMEX - CIB','COMEX - NUBE','Iseries']){const item=page.components.find(x=>x.name===name);if(item)assert.equal(item.architecturalType,'SISTEMA_EXTERNO_AUXILIAR');}
  const queue=page.components.find(x=>x.id==='4Oc~oPj98AFn');assert.equal(queue.architecturalType,'GESTOR_COLAS');assert.equal(queue.domainRole,'INTEGRATION');assert.deepEqual(queue.deploymentAssociations.map(x=>[x.flowId,x.layerId]),[['4Oc~UAg.ChZ2','4Oc~STvzS7WZ']]);assert.ok(queue.connections.length>0);
  assert.equal(page.scenario.scenario,'E2');assert.equal(page.scenario.status,'HIPOTESIS');
});

test('BPMN subtype ignores free text and unrelated customData',()=>{
  for(const event of[
    {textAreas:[{text:'No es un evento de inicio'}]},
    {textAreas:[{text:'Start-up failed'}]},
    {textAreas:[{text:'Inicio de sesión'}]},
    {customData:[{key:'restart_policy',value:'START'}]},
    {textAreas:[{text:'Start dentro de una descripción'}]}
  ])assert.equal(interpretBpmnEventSubtype(event).subtypeStatus,'NO_VERIFICABLE');
  const conflict=interpretBpmnEventSubtype({customData:[{key:'BPMN_EVENT_TYPE',value:'START'},{key:'EVENT_TYPE',value:'END'}]});assert.equal(conflict.subtypeStatus,'CONFLICTING_CUSTOM_DATA');assert.equal(conflict.subtype,null);
});

test('E3 generic event is hypothesis and explicit valid customData confirms it',async()=>{
  const input=await load('fixtures/synthetic/e3-role-candidate.json'),confirmed=analyzeBlueprint(input).pages[1];assert.equal(confirmed.structuralScenario.status,'CONFIRMADO');
  const generic=structuredClone(input);generic.pages[1].items.shapes.find(x=>x.id==='event').customData=[];assert.equal(analyzeBlueprint(generic).pages[1].structuralScenario.status,'HIPOTESIS');
});

test('empty reserved domains retain their declared role',()=>{for(const [name,role]of[['INTEGRACIÓN','INTEGRATION'],['SISTEMAS EXTERNOS (OPCIONAL)','EXTERNAL_SYSTEM'],['DOMINIO PRODUCTOR','PRODUCER']]){const shape={id:'d',class:'UMLRectangleContainerBlock',textAreas:[{text:name}],contains:{shapes:[],lines:[],groups:[]}},page=analyzeBlueprint({pages:[{id:'p',items:{shapes:[shape],lines:[],groups:[],layers:[]}}]}).pages[0];assert.equal(page.architecturalStructure.rootContainers[0].role,role);}});

test('unnamed and placeholder BPMNGroups are not external auxiliaries',()=>{const shapes=[{id:'empty',class:'BPMNGroup',textAreas:[{text:' '}]},{id:'placeholder',class:'BPMNGroup',textAreas:[{text:'[NOMBRE]'}]}],page=copilotExport(analyzeBlueprint({pages:[{id:'p',items:{shapes,lines:[],groups:[],layers:[]}}]})).pages[0];assert.ok(page.components.every(x=>x.architecturalType===null));});
