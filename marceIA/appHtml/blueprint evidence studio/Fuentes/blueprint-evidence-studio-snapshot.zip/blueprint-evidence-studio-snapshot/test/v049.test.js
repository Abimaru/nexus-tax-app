import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { analyzeBlueprint, copilotExport } from '../src/index.js';
import { ioModelKey } from '../src/lucidchart.js';

const activity = (id, customData) => ({ id, class: 'BPMNActivity', textAreas: [{ label: 'Text', text: 'customer{ id }' }], ...(customData ? { customData } : {}) });

test('ioModelKey recognises ENTRADA or SALIDA on a BPMN activity only, in any case', () => {
  assert.equal(ioModelKey(activity('a', [{ key: 'ENTRADA', value: '' }])), 'ENTRADA');
  assert.equal(ioModelKey(activity('b', [{ key: 'salida', value: '' }])), 'salida');
  assert.equal(ioModelKey(activity('c', [{ key: 'OTRA', value: '' }])), null);
  assert.equal(ioModelKey(activity('d')), null);
  assert.equal(ioModelKey({ id: 'e', class: 'BPMNGateway', customData: [{ key: 'ENTRADA', value: '' }] }), null);
});

test('over the example corpus every activity with ENTRADA or SALIDA is MODELO and no other activity is', async () => {
  const { readdirSync, statSync } = await import('node:fs');
  const { join } = await import('node:path');
  const files = [];
  (function walk(d) { for (const f of readdirSync(d)) { const p = join(d, f); if (statSync(p).isDirectory()) walk(p); else if (f.endsWith('.json') && !/ENRIQUECIDO|blueprint_evidence/.test(f)) files.push(p); } })('Blueprints_ejemplos');
  let io = 0, other = 0;
  for (const f of files) {
    const out = copilotExport(analyzeBlueprint(JSON.parse((await readFile(f, 'utf8')).replace(/^﻿/, '')), { sourceName: f }));
    for (const p of out.pages) for (const c of p.components) {
      if (c.lucidchartType !== 'BPMNActivity') continue;
      const marked = Array.isArray(c.customData) && c.customData.some(d => /^(ENTRADA|SALIDA)$/i.test(d?.key));
      if (marked) { io++; assert.equal(c.architecturalType, 'MODELO'); } else { other++; assert.ok([null, 'COMANDO'].includes(c.architecturalType) || (c.architecturalType === 'MODELO' && c.inference?.rule === 'MODEL_BY_CUSTOMDATA')); }
    }
  }
  assert.ok(io >= 159 && other >= 473, 'sin la leyenda ni las descripciones de API quedan 473 actividades no modelo');
});
