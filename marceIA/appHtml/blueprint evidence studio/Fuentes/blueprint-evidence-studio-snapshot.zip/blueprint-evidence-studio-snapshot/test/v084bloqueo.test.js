import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { analyzeBlueprint, copilotExport, blockingPages, blockingMessage, looseArrowNotices } from '../src/index.js';

const file = 'Blueprints_ejemplos/Access Entitlement Features Information/21 - MCI - BP - Access Entitlement Features Information - Information.json';
const load = async () => {
  const raw = JSON.parse((await readFile(file, 'utf8')).replace(/^\uFEFF/, ''));
  return analyzeBlueprint(raw, { sourceName: file });
};
const kindOf = (model, title) => model.pages.find(p => p.page.title === title).pageClassification.kind;
const select = (model, titles) => copilotExport(model, { selectedPageIds: model.pages.filter(p => titles.includes(p.page.title)).map(p => p.page.id) });

test('Access Entitlement: solo la página MIXED se puede exportar', async () => {
  const model = await load();
  assert.equal(kindOf(model, 'retrieveInformation'), 'MIXED');
  assert.equal(blockingPages(select(model, ['retrieveInformation'])).length, 0);
});

test('Access Entitlement: retrieveInformationDetail ya es MIXED (principal con nombre de plantilla y única conexión certificada, 0.8.5)', async () => {
  const model = await load();
  assert.equal(kindOf(model, 'retrieveInformationDetail'), 'MIXED');
  assert.equal(blockingPages(select(model, ['retrieveInformation', 'retrieveInformationDetail'])).length, 0);
});

test('Access Entitlement: MIXED junto con la plantilla vacía (página sin nombre) bloquea el JSON', async () => {
  const model = await load();
  const empty = model.pages.find(p => p.pageClassification.reason === 'TEMPLATE_EMPTY');
  const main = model.pages.find(p => p.page.title === 'retrieveInformation');
  const out = copilotExport(model, { selectedPageIds: [main.page.id, empty.page.id] });
  assert.deepEqual(blockingPages(out).map(p => p.page.id), [empty.page.id]);
});

test('Access Entitlement: MIXED junto con una página BDD bloquea el JSON', async () => {
  const model = await load();
  const blocked = blockingPages(select(model, ['retrieveInformation', 'Escenarios BDD']));
  assert.deepEqual(blocked.map(p => p.page.title), ['Escenarios BDD']);
});

test('una página UNRESOLVED seleccionada junto con una MIXED bloquea el JSON', () => {
  const out = { pages: [{ page: { title: 'a' }, pageClassification: { kind: 'MIXED' } }, { page: { title: 'b' }, pageClassification: { kind: 'UNRESOLVED' } }, { page: { title: 'c' }, pageClassification: { kind: 'OPERATIONAL' } }] };
  assert.deepEqual(blockingPages(out).map(p => p.page.title), ['b']);
});

test('el mensaje informa el estado y no la causa', () => {
  const m = blockingMessage({ page: { title: 'b' }, pageClassification: { kind: 'UNRESOLVED', reason: 'NO_API_EVENT_LINE' } });
  assert.match(m.title, /UNRESOLVED/);
  assert.match(m.text, /No se permite generar el JSON/);
  assert.doesNotMatch(m.text + m.title, /conexión|evento|plantilla/i);
  assert.deepEqual(m.hints, []);
});

test('0.8.5: aviso informativo de flechas con extremo suelto (no altera el JSON ni bloquea)', async () => {
  const model = await load();
  const out = select(model, ['retrieveInformation', 'retrieveInformationDetail']);
  const notices = looseArrowNotices(out);
  assert.deepEqual(notices.map(n => n.pageTitle).sort(), ['retrieveInformation', 'retrieveInformationDetail']);
  const detail = notices.find(n => n.pageTitle === 'retrieveInformationDetail');
  assert.ok(detail.lines.some(l => l.id === 'Vq8~K4Tr68jg' && l.looseEnd === 'origen'));
  assert.equal(blockingPages(out).length, 0);
});

test('0.8.5: flecha con ambos extremos pegados no genera aviso', () => {
  const out = { pages: [{ page: { title: 'p' }, components: [], connections: [{ id: 'l', endpoint1: { style: 'None', connectedTo: 'a' }, endpoint2: { style: 'Arrow', connectedTo: 'b' } }, { id: 'g', endpoint1: { style: 'CircleOpen', connectedTo: null }, endpoint2: { style: 'Generalization', connectedTo: 'b' } }] }] };
  assert.deepEqual(looseArrowNotices(out), []);
});
