import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile, readdir, stat } from 'node:fs/promises';
import { join } from 'node:path';
import { analyzeBlueprint, copilotExport } from '../src/index.js';

const read = async x => (await readFile(x, 'utf8')).replace(/\r/g, '');

test('the six API and service rules kept from the delta package are present in order', async () => {
  const text = await read('skills/validar-blueprint-integracion/references/02-reglas-api-servicios.md');
  const ids = [...text.matchAll(/^### ((?:API|SRV)-00\d) -/gm)].map(x => x[1]);
  assert.deepEqual(ids, ['API-001', 'API-002', 'API-003', 'API-004', 'SRV-001', 'SRV-002', 'SRV-003', 'SRV-004', 'SRV-005', 'SRV-006']);
});

test('every skill file carries the same version label and no rule text is duplicated inside a sentence', async () => {
  const dir = 'skills/validar-blueprint-integracion/references';
  for (const f of await readdir(dir)) {
    const t = await read(join(dir, f));
    assert.doesNotMatch(t, /v11\.3\.[01]|v11\.2\./, f);
  }
  const ev = await read(`${dir}/03-reglas-eventos.md`);
  assert.doesNotMatch(ev, /(no puede determinarse si está ubicado en INTEGRACIÓN, DOMINIO PRODUCTOR o SISTEMAS EXTERNOS;)\s*\1/);
});

test('the MCI questions are mandatory in the procedure, the skill and the agent instructions, also under HIPOTESIS', async () => {
  const proc = await read('skills/validar-blueprint-integracion/references/00-procedimiento.md');
  const skill = await read('skills/validar-blueprint-integracion/SKILL.md');
  const ins = await read('dist/INSTRUCCIONES-AGENTE-v12.2.0.md');
  for (const t of [proc]) { assert.match(t, /HIPOTESIS/); assert.match(t, /¿La API principal “\[nombre\]” \(`\[id\]`\) tiene Capa de Despliegue MCI\?/); assert.match(t, /¿El hijo principal “\[nombre\]” \(`\[id\]`\)/); }
  assert.match(skill, /obligatorias aunque `scenario.status` sea `HIPOTESIS`/);
  assert.match(ins, /preguntas de condición MCI del paso 4 de `SKILL\.md`/);
  assert.doesNotMatch(ins, /solo cuando el escenario lo confirma/);
});

test('over the example corpus every evaluable page yields one API question and one child question', async () => {
  const { readdirSync, statSync } = await import('node:fs');
  const files = [];
  (function walk(d) { for (const f of readdirSync(d)) { const p = join(d, f); if (statSync(p).isDirectory()) walk(p); else if (f.endsWith('.json') && !/ENRIQUECIDO|blueprint_evidence/.test(f)) files.push(p); } })('Blueprints_ejemplos');
  let pages = 0; const undetermined = [];
  for (const f of files) {
    const out = copilotExport(analyzeBlueprint(JSON.parse((await read(f)).replace(/^﻿/, '')), { sourceName: f }));
    for (const p of out.pages) {
      if (!['OPERATIONAL', 'MIXED'].includes(p.pageClassification?.kind)) continue;
      if (p.scenario.status === 'NO_DETERMINADO') { undetermined.push(p.page.title); continue; } // sin API principal ni hijo certificados: no se pregunta
      pages++;
      assert.equal(p.components.filter(c => c.architecturalType === 'API' && c.role === 'PRINCIPAL').length, 1);
      assert.equal(p.components.filter(c => c.architecturalType === 'SERVICIO_HIJO' && c.role === 'INVOCADO').length, 1);
    }
  }
  assert.equal(pages, 35); // 24/11/2026: corpus de 34 BP
  assert.equal(undetermined.length, 26); // páginas sin API principal ni hijo certificados (BP antiguos sin etiquetas y plantillas): no se preguntan
});

test('the full 11.3.0 coverage wording and the deployment-association precedence are both kept', async () => {
  const text = await read('skills/validar-blueprint-integracion/references/02-reglas-api-servicios.md');
  for (const id of ['API-001', 'API-002', 'API-003']) {
    const body = text.split(new RegExp(`^### ${id} -`, 'm'))[1].split(/^### /m)[0];
    assert.match(body, /Todas las API principales e invocadas[^\n]*Cada API de ambos roles se incluye individualmente/, id);
  }
  for (const id of ['API-004', 'SRV-004']) {
    const body = text.split(new RegExp(`^### ${id} -`, 'm'))[1].split(/^### /m)[0];
    assert.match(body, /apartado 4\.1/, id);
    assert.match(body, /associatedComponentId: null/, id);
    assert.match(body, /no existen [^\n]*(candidat|pendiente)/, id);
  }
  const proc = await read('skills/validar-blueprint-integracion/references/00-procedimiento.md');
  for (const s of ['encapsulados conservan su tipo funcional', 'PROPOSED_CLOSED_CATALOG', 'Evaluar una vez cada ID activo', 'ni 38 filas']) assert.ok(proc.includes(s), s);
});

test('CNT-001 accepts an unclassified E2 container that can only be PRODUCER or EXTERNAL_SYSTEM, while CNT-004 and CNT-005 stay unverifiable', async () => {
  const text = await read('skills/validar-blueprint-integracion/references/01-reglas-estructura.md');
  const body = id => text.split(new RegExp(`^### ${id} -`, 'm'))[1].split(/^### /m)[0];
  assert.match(body('CNT-001'), /possibleDomainRoles[^\n]*únicamente DOMINIO PRODUCTOR y\/o SISTEMAS EXTERNOS[^\n]*no aplica a E1 ni a E3/);
  for (const id of ['CNT-004', 'CNT-005']) assert.match(body(id), /roles posibles PRODUCTOR y SISTEMAS EXTERNOS[^\n]*No verificable/, id);
});

test('over the corpus the unclassified E2 containers expose exactly PRODUCER and EXTERNAL_SYSTEM as possible roles', async () => {
  const dir = 'Blueprints_ejemplos';
  const files = [];
  const walk = async d => { for (const f of await readdir(d)) { const p = join(d, f); if ((await stat(p)).isDirectory()) await walk(p); else if (f.endsWith('.json') && !/ENRIQUECIDO|blueprint_evidence/.test(f)) files.push(p); } };
  await walk(dir);
  let seen = 0;
  for (const f of files) {
    const out = copilotExport(analyzeBlueprint(JSON.parse(await readFile(f, 'utf8')), { sourceName: f }));
    for (const p of out.pages.filter(x => x.scenario?.scenario === 'E2'))
      for (const c of p.components.filter(c => /^CONTENEDOR/.test(c.architecturalType || '') && !c.structuralParent?.id && c.domainRole == null)) {
        assert.deepEqual([...c.possibleDomainRoles].sort(), ['EXTERNAL_SYSTEM', 'PRODUCER']);
        seen++;
      }
  }
  assert.ok(seen >= 4, `unclassified E2 roots seen: ${seen}`);
});

test('the deployment-association precedence also covers integration events and states the page-level pending pairs rule', async () => {
  const dir = 'skills/validar-blueprint-integracion/references';
  const proc = await read(`${dir}/00-procedimiento.md`);
  assert.match(proc, /API-004, SRV-004, MQ-002, EVT-004 y EVT-005/);
  assert.match(proc, /pares Capa-Flujo pendientes de propietario/);
  assert.match(proc, /conduce a `No verificable`; si hay otra evidencia independiente de incumplimiento/);
  const ev = await read(`${dir}/03-reglas-eventos.md`);
  for (const id of ['EVT-004', 'EVT-005']) assert.match(ev.split(new RegExp(`^### ${id} -`, 'm'))[1].split(/^### /m)[0], /apartado 4\.1/, id);
});

test('SRV-004 and MQ-002 define how the Federado layer is represented in the enriched JSON', async () => {
  const srv = await read('skills/validar-blueprint-integracion/references/02-reglas-api-servicios.md');
  const mq = await read('skills/validar-blueprint-integracion/references/07-reglas-gestores-colas.md');
  const proc = await read('skills/validar-blueprint-integracion/references/00-procedimiento.md');
  assert.match(srv, /modality: FEDERADO/);
  assert.doesNotMatch(srv, /queda pendiente de definición|todavía no contiene una representación/);
  assert.match(mq, /architecturalType: FEDERADO/);
  assert.match(proc, /modality: FEDERADO/);
  assert.match(proc, /SRV-004 usa la respuesta sobre el hijo principal/);
  const ins = await read('dist/INSTRUCCIONES-AGENTE-v12.2.0.md');
  assert.match(proc, /FEDERADO/);
  assert.ok([...ins].length <= 8000);
});

test('Real Time Payments: every Federado figure is typed FEDERADO and each queue manager inside it carries the federated association', async () => {
  const f = 'Blueprints_ejemplos/Real Time Payments QR Keys Management/MCI - BP - Real Time Payments QR Keys Management - Commerce Keys (1).json';
  const out = copilotExport(analyzeBlueprint(JSON.parse((await read(f)).replace(/^﻿/, '')), { sourceName: f }));
  let managers = 0;
  for (const p of out.pages) {
    const fed = p.components.filter(c => /^federado$/i.test(c.name ?? ''));
    assert.ok(fed.every(c => c.architecturalType === 'FEDERADO'));
    for (const m of p.components.filter(c => c.architecturalType === 'GESTOR_COLAS')) {
      managers++;
      const a = m.deploymentAssociations.filter(d => d.modality === 'FEDERADO');
      assert.equal(a.length, 1, m.id);
      assert.equal(a[0].status, 'RESOLVED_BY_DIRECT_CONTAINMENT');
      assert.ok(fed.some(c => c.id === a[0].federatedId));
      assert.ok(p.deploymentAssociations.some(d => d.modality === 'FEDERADO' && d.associatedComponentId === m.id && d.federatedId === a[0].federatedId));
    }
  }
  assert.equal(managers, 3);
});

test('a Federado figure without contained components stays pending and unowned', () => {
  const sh = (id, cls, text, contains) => ({ id, class: cls, textAreas: [{ label: 'Text', text }], ...(contains ? { contains: { shapes: contains, lines: [], groups: [] } } : {}) });
  const raw = { pages: [{ id: 'p', title: 'p', items: { shapes: [sh('F', 'UMLRectangleContainerBlock', 'Federado', []), sh('T', 'MinimalTextBlock', 'Federado')], lines: [], groups: [] } }] };
  const a = analyzeBlueprint(raw).pages[0].architecturalStructure.federatedAssociations;
  assert.equal(a.length, 1, 'un texto suelto «Federado» no es capa de despliegue');
  assert.ok(a.every(x => x.associatedComponentId === null && x.status === 'PENDING_NO_CONTAINED_COMPONENT'));
});

test('an orphan empty BPMN Event at the parent level of INTEGRACIÓN is classified MARCADOR_API and stays in the inventory; any other signal leaves it unclassified', () => {
  const sh = (id, cls, text, contains) => ({ id, class: cls, textAreas: [{ label: 'Text', text }], ...(contains ? { contains: { shapes: contains, lines: [], groups: [] } } : {}) });
  const build = (event, extra = {}) => ({ pages: [{ id: 'p', title: 'p', items: { shapes: [sh('I', 'UMLRectangleContainerBlock', 'INTEGRACIÓN', ['E']), event], lines: extra.lines ?? [], groups: extra.groups ?? [] } }] });
  const run = raw => copilotExport(analyzeBlueprint(raw), { selectedPageIds: ['p'] }).pages[0];
  const typeOf = (raw) => run(raw).components.find(c => c.id === 'E')?.architecturalType;
  const orphan = run(build(sh('E', 'BPMNEvent', '')));
  const e = orphan.components.find(c => c.id === 'E');
  assert.equal(e.architecturalType, 'MARCADOR_API');
  assert.equal(e.inference.rule, 'API_MARKER_BY_ORPHAN_EMPTY_EVENT');
  assert.equal((orphan.omittedComponents ?? []).some(o => o.basis === 'ORPHAN_EMPTY_EVENT'), false);
  assert.notEqual(typeOf(build(sh('E', 'BPMNEvent', 'Inicio'))), 'MARCADOR_API', 'con texto no');
  assert.notEqual(typeOf(build({ ...sh('E', 'BPMNEvent', ''), customData: [{ key: 'k', value: 'v' }] })), 'MARCADOR_API', 'con customData no');
  assert.equal(typeOf(build(sh('E', 'BPMNEvent', ''), { groups: [{ id: 'g', members: ['E'] }] })), 'MARCADOR_API', 'sin conexiones, aunque esté en un grupo, también es marcador');
  const lined = build(sh('E', 'BPMNEvent', ''), { lines: [{ id: 'l', endpoint1: { connectedTo: 'E' }, endpoint2: { connectedTo: 'I' } }] });
  assert.notEqual(typeOf(lined), 'MARCADOR_API', 'con conexión no');
});

test('Real Time Payments and Investment: each page classifies exactly one orphan marker and keeps the grouped events of the child flow unclassified', async () => {
  for (const [file, expected] of [['Blueprints_ejemplos/Real Time Payments QR Keys Management/MCI - BP - Real Time Payments QR Keys Management - Commerce Keys (1).json', 3], ['Blueprints_ejemplos/Investment Product Opening] - [Investment/MCI - BP - [Investment Product Opening] - [Investment].json', 2]]) {
    const raw = JSON.parse((await read(file)).replace(/^\uFEFF/, '')), model = analyzeBlueprint(raw);
    const out = copilotExport(model, { selectedPageIds: model.pages.filter(p => ['OPERATIONAL', 'MIXED'].includes(p.pageClassification.kind)).map(p => p.page.id) });
    assert.equal(out.pages.length, expected);
    for (const p of out.pages) {
      assert.ok(p.components.filter(c => c.architecturalType === 'MARCADOR_API').length >= 1, p.page.title);
      assert.ok(p.components.filter(c => c.lucidchartType === 'BPMNEvent' && c.architecturalType !== 'MARCADOR_API').length > 5, 'los eventos agrupados del flujo del hijo siguen sin clasificar');
      const markers = p.components.filter(c => c.architecturalType === 'MARCADOR_API').map(c => c.id);
      const pair = p.deploymentAssociations.find(d => d.associatedComponentId === null && !d.modality && (d.markerIds ?? []).length);
      assert.ok(pair, 'la pareja Capa-Flujo del marcador sigue pendiente de propietario');
      assert.ok(pair.markerIds.every(id => markers.includes(id)), 'el marcador consta como contenido, no como candidato');
      assert.ok(p.deploymentAssociations.every(d => (d.evidence ?? []).every(e => !(e.candidateIds ?? []).some(id => markers.includes(id)))), 'el marcador no es candidato a propietario');
    }
  }
});

test('the marker rules, the multiple-command clarification and the direct-connection note are in the skill', async () => {
  const dir = 'skills/validar-blueprint-integracion/references';
  const est = await read(`${dir}/01-reglas-estructura.md`), com = await read(`${dir}/06-reglas-modelos-comandos.md`), proc = await read(`${dir}/00-procedimiento.md`);
  assert.equal((est.match(/MARCADOR_API/g) ?? []).length >= 3, true, 'CNT-003, CNT-005 y EXT-001');
  for (const id of ['COM-002']) assert.match(com.split(new RegExp(`^### ${id} -`, 'm'))[1].split(/^### /m)[0], /Varios comandos distintos pueden relacionarse/, id);
  assert.match(proc, /servicio invocado con API invocada, otro servicio invocado o auxiliar/);
  assert.match(proc, /markerIds/);
  const srv5 = (await read(`${dir}/02-reglas-api-servicios.md`)).split(/^### SRV-005 -/m)[1];
  assert.match(srv5, /Un servicio invocado no puede conectarse con un evento/);
  assert.match(srv5, /servicio principal de E3/);
  assert.match(srv5, /de servicio a auxiliar, aunque este encapsule/);
});

test('service recognition: customData TIPO=SERVICIO certifies it; Entidad/Utilidad/Tarea without marker or ms is only a non-certified candidate', () => {
  const uml = (id, title, third, customData) => ({ id, class: 'UMLClassBlock', textAreas: [{ label: 'Title', text: title }, { label: 'Text1', text: 'doSomething' }, { label: 'Text2', text: third }], ...(customData ? { customData } : {}) });
  const run = shapes => copilotExport(analyzeBlueprint({ pages: [{ id: 'p', title: 'p', items: { shapes, lines: [], groups: [] } }] }), { selectedPageIds: ['p'] }).pages[0];
  const get = (page, id) => page.components.find(c => c.id === id);
  const declared = get(run([uml('S', 'recepcion_callback', 'Tarea', [{ key: 'TIPO', value: 'SERVICIO' }])]), 'S');
  assert.equal(declared.architecturalType, 'SERVICIO');
  assert.equal(declared.inference.rule, 'SERVICE_BY_CUSTOMDATA');
  assert.equal(declared.inference.status, 'DECLARED_BY_CUSTOMDATA');
  assert.equal(declared.possibleTypes, undefined);
  const candidate = get(run([uml('C', 'recepcion_callback', 'Tarea')]), 'C');
  assert.equal(candidate.architecturalType, null);
  assert.deepEqual(candidate.possibleTypes, ['API', 'SERVICIO']);
  assert.equal(candidate.inference.status, 'CANDIDATE_NOT_CERTIFIED');
  const plain = get(run([uml('P', 'Legacy block', 'Clasificación de lógica')]), 'P');
  assert.equal(plain.architecturalType, null);
  assert.deepEqual(plain.possibleTypes, ['API', 'SERVICIO']);
  assert.equal(plain.inference.basis, 'UNCLASSIFIED_OUTSIDE_PRODUCER');
  const msService = get(run([uml('M', 'ms_notificaciones', 'Tarea')]), 'M');
  assert.equal(msService.architecturalType, 'SERVICIO');
  assert.equal(msService.possibleTypes, undefined);
});
