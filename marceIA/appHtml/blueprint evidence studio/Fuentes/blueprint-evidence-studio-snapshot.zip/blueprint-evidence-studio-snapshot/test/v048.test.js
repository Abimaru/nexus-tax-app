import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { createRequire } from 'node:module';
const require_ = createRequire(import.meta.url);
import { analyzeBlueprint, copilotExport, serviceNamingSignal, VERSION, COPILOT_CONTRACT } from '../src/index.js';

const text = t => ({ textAreas: [{ label: 'Title', text: t }] });
const uml = (id, title, third = '') => ({ id, class: 'UMLClassBlock', textAreas: [{ label: 'Title', text: title }, { label: 'Text1', text: '' }, { label: 'Text2', text: third }] });
const emptyEvent = id => ({ id, class: 'BPMNEvent', textAreas: [{ label: 'Text', text: '' }] });
const compactOf = (shapes, groups = [], lines = []) => copilotExport(analyzeBlueprint({ pages: [{ id: 'p', title: 'p', items: { shapes, lines, groups, layers: [] } }] })).pages[0];
const byId = (page, id) => page.components.find(x => x.id === id);

test('version 0.8.3 keeps the 0.4.6.1 contract named by the Skill', () => {
  assert.equal(VERSION, '0.11.0');
  assert.equal(COPILOT_CONTRACT, 'copilot-factual-v0.4.6.1');
});

test('UML block grouped with an empty unconnected BPMN event is an invoked API', () => {
  const page = compactOf([uml('a', 'Customer Account - Account v2.0.1', 'Entidad'), emptyEvent('m')], [{ id: 'g', members: ['a', 'm'] }]);
  const a = byId(page, 'a');
  assert.equal(a.architecturalType, 'API');
  assert.equal(a.role, 'INVOCADO');
  assert.equal(a.inference.rule, 'API_BY_EMPTY_BPMN_EVENT_GROUP');
  assert.deepEqual(a.inference.evidence[0].eventIds, ['m']);
});

test('the empty marker event of a certain API is not registered as a separate component', () => {
  const page = compactOf([uml('a', 'Customer Account - Account v2.0.1', 'Entidad'), emptyEvent('m')], [{ id: 'g', members: ['a', 'm'] }]);
  assert.equal(byId(page, 'm'), undefined);
  assert.deepEqual(page.omittedComponents, [{ lucidchartType: 'BPMNEvent', count: 1, reason: 'API_MARKER_EVENT' }]);
  assert.deepEqual(page.groups[0].directMemberIds, ['a']);
  assert.deepEqual(page.groups[0].relatedComponentIds, ['a']);
});

test('an empty event in the parent group of the block subgroup is also its marker', () => {
  const act = { id: 'act', class: 'BPMNActivity', textAreas: [{ text: '' }] };
  const page = compactOf([uml('a', 'Accounts', 'Entidad'), act, emptyEvent('m')], [{ id: 'sub', members: ['a', 'act'] }, { id: 'top', members: ['sub', 'm'] }]);
  assert.equal(byId(page, 'a').architecturalType, 'API');
  assert.equal(byId(page, 'a').role, 'INVOCADO');
  assert.equal(byId(page, 'm'), undefined);
  assert.deepEqual(page.omittedComponents, [{ lucidchartType: 'BPMNEvent', count: 1, reason: 'API_MARKER_EVENT' }]);
});

test('nested marker with two candidate blocks stays ambiguous and keeps the event', () => {
  const page = compactOf([uml('a', 'A - Uno v1.0.0'), uml('b', 'B - Dos v1.0.0'), emptyEvent('m')], [{ id: 's1', members: ['a'] }, { id: 's2', members: ['b'] }, { id: 'top', members: ['s1', 's2', 'm'] }]);
  assert.equal(byId(page, 'a').architecturalType, null);
  assert.equal(byId(page, 'b').architecturalType, null);
  assert.ok(byId(page, 'm'));
});

test('a principal API keeps its marker id in the inference evidence', () => {
  const { readFileSync } = require_('node:fs');
  const raw = JSON.parse(readFileSync('Blueprints_ejemplos/QR Payment Transactions Reporting/MCI - BP - QR Payment Transactions Reporting - Payment Transactions.json', 'utf8'));
  const page = copilotExport(analyzeBlueprint(raw)).pages.find(p => p.page.title === 'retrieveTransactionSummary');
  const main = page.components.find(c => c.role === 'PRINCIPAL');
  assert.equal(main.architecturalType, 'API');
  const marker = main.inference.evidence.find(e => e.source === 'JSON.items.groups');
  assert.ok(marker && marker.eventIds.length === 1);
  assert.equal(page.components.some(c => c.id === marker.eventIds[0]), false);
});

test('the marker event stays when the API is not certain or the event carries data', () => {
  const multi = compactOf([uml('a', 'A - Uno v1.0.0'), uml('b', 'B - Dos v1.0.0'), emptyEvent('m')], [{ id: 'g', members: ['a', 'b', 'm'] }]);
  assert.ok(byId(multi, 'm'), 'several blocks in one group');
  const conflict = compactOf([uml('s', 'ms-depositos'), emptyEvent('m')], [{ id: 'g', members: ['s', 'm'] }]);
  assert.ok(byId(conflict, 'm'), 'marker plus ms naming');
  const withData = { ...emptyEvent('m'), customData: [{ key: 'BPMN_EVENT_TYPE', value: 'START' }] };
  assert.ok(byId(compactOf([uml('a', 'X - Y v1.0.0'), withData], [{ id: 'g', members: ['a', 'm'] }]), 'm'), 'event with customData');
  assert.equal(byId(compactOf([uml('a', 'X - Y v1.0.0'), withData], [{ id: 'g', members: ['a', 'm'] }]), 'a').architecturalType, 'API');
});

test('omitted marker ids are removed from BPMN group contents', () => {
  const external = { id: 'x', class: 'BPMNGroup', textAreas: [{ text: 'Sistema Externo Auxiliar' }], contains: { shapes: ['a', 'm'], lines: [], groups: [] } };
  const page = compactOf([external, uml('a', 'X - Y v1.0.0'), emptyEvent('m')], [{ id: 'g', members: ['a', 'm'] }]);
  assert.equal(byId(page, 'm'), undefined);
  assert.deepEqual(byId(page, 'x').containedComponentIds, ['a']);
});

test('an event with text, a connected event or a different group is not an API marker', () => {
  const named = { id: 'm', class: 'BPMNEvent', textAreas: [{ text: 'Inicio' }] };
  assert.equal(byId(compactOf([uml('a', 'X - Y v1.0.0'), named], [{ id: 'g', members: ['a', 'm'] }]), 'a').architecturalType, null);
  const line = { id: 'l', endpoint1: { connectedTo: 'm', style: 'None' }, endpoint2: { connectedTo: 'a', style: 'Arrow' } };
  assert.equal(byId(compactOf([uml('a', 'X - Y v1.0.0'), emptyEvent('m')], [{ id: 'g', members: ['a', 'm'] }], [line]), 'a').architecturalType, null);
  assert.equal(byId(compactOf([uml('a', 'X - Y v1.0.0'), emptyEvent('m')], [{ id: 'g1', members: ['a'] }, { id: 'g2', members: ['m'] }]), 'a').architecturalType, null);
});

test('a group with several UML blocks and one empty event stays ambiguous', () => {
  const page = compactOf([uml('a', 'A - Uno v1.0.0'), uml('b', 'B - Dos v1.0.0'), emptyEvent('m')], [{ id: 'g', members: ['a', 'b', 'm'] }]);
  for (const id of ['a', 'b']) { const c = byId(page, id); assert.equal(c.architecturalType, null); assert.equal(c.inference.status, 'AMBIGUOUS'); assert.ok(c.inference.contradictions.includes('MARKER_GROUP_HAS_MULTIPLE_COMPONENTS')); }
});

test('ms prefix or suffix without marker is an invoked service; with marker it is ambiguous', () => {
  for (const name of ['ms-depositos', 'ms_depositos', 'ms depositos', 'msDepositos', 'depositos-ms', 'depositos_ms', 'depositos ms', 'depositosMs']) {
    const c = byId(compactOf([uml('s', name)]), 's');
    assert.equal(c.architecturalType, 'SERVICIO', name);
    assert.equal(c.role, 'INVOCADO', name);
  }
  for (const name of ['Items', 'Send SMS', 'Customer Items', 'msg', 'Programs']) assert.equal(serviceNamingSignal(name), null, name);
  const both = byId(compactOf([uml('s', 'ms-depositos'), emptyEvent('m')], [{ id: 'g', members: ['s', 'm'] }]), 's');
  assert.equal(both.architecturalType, null);
  assert.ok(both.inference.contradictions.includes('MARKER_CONFLICTS_WITH_MS_NAMING'));
});

test('third section with type or classification is an integration event, not an API', () => {
  for (const third of ['Aplicacion', 'Query', 'Tipo: empresarial']) {
    const c = byId(compactOf([uml('e', 'Debit Card - Failure_V1.0.0', third)]), 'e');
    assert.equal(c.architecturalType, null, third);
    assert.deepEqual(c.possibleTypes, ['EVENTO_INTEGRACION'], third);
    assert.equal(c.inference.basis, 'THIRD_SECTION_EVENT_INCOMPLETE', third);
  }
  for (const third of ['Empresarial - Event', 'Aplicación - Command', 'Empresarial - Query']) {
    const c = byId(compactOf([uml('e', 'Debit Card - Failure_V1.0.0', third)]), 'e');
    assert.equal(c.architecturalType, 'EVENTO_INTEGRACION', third);
    assert.equal(c.role, 'INVOCADO', third);
    assert.equal(c.inference.rule, 'INTEGRATION_EVENT_BY_THIRD_SECTION', third);
  }
  for (const third of ['Entidad', 'Clasificación API', 'Clasificación de lógica', '']) assert.equal(byId(compactOf([uml('e', 'Algo - Otro v1.0.0', third)]), 'e').architecturalType, null, third);
});

test('integration event plus marker or ms naming is ambiguous, never forced', () => {
  const withMarker = byId(compactOf([uml('e', 'X - Y v1.0.0', 'Empresarial - Event'), emptyEvent('m')], [{ id: 'g', members: ['e', 'm'] }]), 'e');
  assert.equal(withMarker.architecturalType, null);
  assert.ok(withMarker.inference.contradictions.includes('MULTIPLE_CLASSIFICATION_RULES'));
  const withMs = byId(compactOf([uml('e', 'ms-evento', 'Aplicación - Event')]), 'e');
  assert.equal(withMs.architecturalType, null);
});

test('components without any rule stay undetermined as before', () => {
  const c = byId(compactOf([uml('x', 'TXN 0026', 'Clasificación de lógica'), uml('y', 'Accounts', 'Entidad')]), 'x');
  assert.equal(c.architecturalType, null);
  assert.equal(byId(compactOf([uml('y', 'Accounts', 'Entidad')]), 'y').architecturalType, null);
});

const dsb = (id, extra = {}) => ({ id, class: 'DefaultSquareBlock', textAreas: [{ label: 'Text', text: 'Nota' }], ...extra });

test('unrelated DefaultSquareBlock is omitted from the compact JSON and counted', () => {
  const page = compactOf([dsb('n1'), dsb('n2', { customData: [] }), uml('a', 'ms-x')]);
  assert.deepEqual(page.components.map(x => x.id), ['a']);
  assert.deepEqual(page.omittedComponents, [{ lucidchartType: 'DefaultSquareBlock', count: 2, reason: 'NO_CONNECTIONS_CONTAINMENT_OR_ASSOCIATIONS' }]);
});

test('DefaultSquareBlock with line, content, container, customData or group of kept members survives or is pruned coherently', () => {
  const line = { id: 'l', endpoint1: { connectedTo: 'n1', style: 'None' }, endpoint2: { connectedTo: 'a', style: 'Arrow' } };
  assert.ok(byId(compactOf([dsb('n1'), uml('a', 'ms-x')], [], [line]), 'n1'), 'connected');
  assert.ok(byId(compactOf([dsb('n1', { contains: { shapes: ['a'], lines: [], groups: [] } }), uml('a', 'ms-x')]), 'n1'), 'with content');
  assert.ok(byId(compactOf([dsb('n1', { customData: [{ key: 'K', value: 'V' }] })]), 'n1'), 'with customData');
  const container = { id: 'c', class: 'RectangleContainerBlock', textAreas: [{ text: 'hijo' }], contains: { shapes: ['n1'], lines: [], groups: [] } };
  assert.ok(byId(compactOf([container, dsb('n1')]), 'n1'), 'inside container');
  const grouped = compactOf([dsb('n1'), uml('a', 'ms-x')], [{ id: 'g', members: ['n1', 'a'] }]);
  assert.equal(byId(grouped, 'n1'), undefined);
  assert.deepEqual(grouped.groups[0].directMemberIds, ['a']);
  assert.deepEqual(grouped.groups[0].relatedComponentIds, ['a']);
});

test('a DefaultSquareBlock listed as content of a BPMN group survives', () => {
  const external = { id: 'x', class: 'BPMNGroup', textAreas: [{ text: 'Sistema Externo Auxiliar' }], contains: { shapes: ['n1'], lines: [], groups: [] } };
  assert.ok(byId(compactOf([external, dsb('n1')]), 'n1'));
});

test('pages without omitted figures carry no omittedComponents field', () => {
  assert.equal('omittedComponents' in compactOf([uml('a', 'ms-x')]), false);
});

test('0.8.3 over the example corpus: 64 invoked APIs, 60 invoked services, 4 integration events, 7 candidates, none undetermined (the real child only)', async () => {
  const { readdir } = await import('node:fs/promises');
  const files = [];
  const walk = async d => { for (const e of await readdir(d, { withFileTypes: true })) { const p = `${d}/${e.name}`; if (e.isDirectory()) await walk(p); else if (e.name.endsWith('.json') && !/ENRIQUECIDO|blueprint_evidence/.test(e.name)) files.push(p); } };
  await walk('Blueprints_ejemplos');
  const tally = {}; let omitted = 0, markers = 0, orphans = 0, markerComponents = 0, dsbOmitted = 0;
  for (const f of files) {
    const compact = copilotExport(analyzeBlueprint(JSON.parse((await readFile(f, 'utf8')).replace(/^﻿/, ''))));
    for (const p of compact.pages) {
      for (const o of p.omittedComponents ?? []) { omitted += o.count; if (o.lucidchartType === 'BPMNEvent') { if (o.basis === 'ORPHAN_EMPTY_EVENT') orphans += o.count; else markers += o.count; } else dsbOmitted += o.count; }
      markerComponents += p.components.filter(c => c.architecturalType === 'MARCADOR_API').length;
      if (!['OPERATIONAL', 'MIXED'].includes(p.pageClassification.kind)) continue;
      const legend = new Set(p.pageClassification.legendShapeIds ?? []);
      for (const c of p.components) if (c.lucidchartType === 'UMLClassBlock' && !legend.has(c.id)) { const k = `${c.architecturalType ?? 'null'}|${c.role ?? '-'}`; tally[k] = (tally[k] ?? 0) + 1; }
    }
  }
  // 24/11/2026: el corpus pasó a 34 BP (ya con etiquetas de la biblioteca nueva); las cifras históricas (0.8.3) eran de 20 BP.
  assert.deepEqual(tally, { 'SERVICIO|INVOCADO': 104, 'API|PRINCIPAL': 35, 'API|INVOCADO': 96, 'null|INVOCADO': 19, 'null|-': 12, 'EVENTO_INTEGRACION|INVOCADO': 4 });
  // El corpus incluye desde 03/11/2026 Deposit Account Pocket Transaction Information (aporta 1 DefaultSquareBlock aislado y 1 MARCADOR_API; su página real no se evalúa).
  assert.equal(dsbOmitted, 18, 'la leyenda ya no se exporta: solo quedan los DefaultSquareBlock aislados del diagrama');
  assert.equal(markers, 83);
  assert.equal(orphans, 0, 'el marcador huérfano ya no se omite: queda como MARCADOR_API');
  assert.equal(omitted, 18 + 83);
  assert.equal(markerComponents, 41); // 0.8.5: las 3 páginas con principal de plantilla único ahora se evalúan; sus 2 marcadores pasan de componentes a omitidos (markers 66→68)
});


// ---- Hijo único y contenedores padre (reglas de la analista) ----
const box = (id, shapes = [], text = '', cls = 'RectangleContainerBlock') => ({ id, class: cls, textAreas: text ? [{ label: 'Title', text }] : [], contains: { shapes, lines: [], groups: [] } });
const bpmn = (id, cls, text = '') => ({ id, class: cls, textAreas: [{ label: 'Text', text }] });
const domainOf = (id, name, shapes) => box(id, shapes, name, 'UMLRectangleContainerBlock');
const startLine = (from, to) => ({ id: `l-${from}-${to}`, endpoint1: { connectedTo: from, style: 'None' }, endpoint2: { connectedTo: to, style: 'Arrow' } });
const analyze = (shapes, lines = []) => analyzeBlueprint({ pages: [{ id: 'p', title: 'p', items: { shapes, lines, groups: [], layers: [] } }] }).pages[0];

test('the main child is the innermost rectangle with at least one gateway and one activity', () => {
  const inner = box('C', ['gw', 'act']), outer = box('B', ['C', 'gw', 'act']);
  const page = compactOf([outer, inner, bpmn('gw', 'BPMNGateway'), bpmn('act', 'BPMNActivity')]);
  assert.equal(byId(page, 'C').architecturalType, 'SERVICIO_HIJO');
  assert.equal(byId(page, 'C').inference.rule, 'CHILD_BY_GATEWAYS_AND_ACTIVITIES');
  assert.deepEqual(byId(page, 'C').inference.evidence[0], { source: 'JSON.contains', gateways: 1, activities: 1 });
  assert.equal(byId(page, 'B').architecturalType, 'CONTENEDOR_PADRE');
});

test('a rectangle with only activities or only gateways is not a child', () => {
  const onlyActivities = compactOf([box('R', ['act']), bpmn('act', 'BPMNActivity')]);
  assert.equal(byId(onlyActivities, 'R').architecturalType, 'CONTENEDOR_NO_DETERMINADO');
  const onlyGateways = compactOf([box('R', ['gw']), bpmn('gw', 'BPMNGateway')]);
  assert.equal(byId(onlyGateways, 'R').architecturalType, 'CONTENEDOR_NO_DETERMINADO');
});

test('two sibling rectangles with gateways and activities are both candidates and stay ambiguous', () => {
  const page = compactOf([box('R1', ['g1', 'a1']), box('R2', ['g2', 'a2']), bpmn('g1', 'BPMNGateway'), bpmn('a1', 'BPMNActivity'), bpmn('g2', 'BPMNGateway'), bpmn('a2', 'BPMNActivity')]);
  for (const id of ['R1', 'R2']) { const c = byId(page, id); assert.equal(c.architecturalType, 'SERVICIO_HIJO'); assert.equal(c.inference.status, 'AMBIGUOUS'); assert.deepEqual(c.inference.contradictions, ['MULTIPLE_CHILD_CANDIDATES']); }
});

test('a root rectangle with a direct text naming a reserved domain is that parent container', () => {
  const page = compactOf([box('A', ['t', 'q']), { id: 't', class: 'MinimalTextBlock', textAreas: [{ text: 'INTEGRACIÓN' }] }, uml('q', 'ms-x')]);
  const a = byId(page, 'A');
  assert.equal(a.architecturalType, 'CONTENEDOR_PADRE');
  assert.equal(a.domainRole, 'INTEGRATION');
  assert.equal(a.inference.rule, 'PARENT_BY_LOOSE_TEXT_NAME');
  const nested = compactOf([box('A', ['N', 't']), box('N', ['t']), { id: 't', class: 'MinimalTextBlock', textAreas: [{ text: 'INTEGRACIÓN' }] }]);
  assert.equal(byId(nested, 'A').architecturalType, 'CONTENEDOR_NO_DETERMINADO', 'text that is not a direct child does not name the container');
});

test('unnamed rectangle wrapping the child becomes the producer and the page is an E1 hypothesis', () => {
  const shapes = [
    domainOf('dom', 'INTEGRACIÓN', ['api']), uml('api', 'Debit Card - Management v1.0.0'),
    box('B', ['C', 'gw', 'act', 'ev']), box('C', ['gw', 'act', 'ev']), bpmn('gw', 'BPMNGateway'), bpmn('act', 'BPMNActivity'), bpmn('ev', 'BPMNEvent', 'Inicio'),
    box('A', ['t', 'q']), { id: 't', class: 'MinimalTextBlock', textAreas: [{ text: 'INTEGRACIÓN' }] }, uml('q', 'Master Catalogue - Information')
  ];
  const model = analyze(shapes, [startLine('api', 'ev')]);
  assert.equal(model.structuralScenario.scenario, 'E1');
  assert.equal(model.structuralScenario.status, 'HIPOTESIS');
  assert.equal(model.structuralScenario.mainChildServiceId, 'C');
  const roles = Object.fromEntries(model.architecturalStructure.rootContainers.map(r => [r.id, r.role]));
  assert.deepEqual(roles, { dom: 'INTEGRATION', B: 'PRODUCER', A: 'INTEGRATION' });
  const page = copilotExport(analyzeBlueprint({ pages: [{ id: 'p', title: 'p', items: { shapes, lines: [startLine('api', 'ev')], groups: [], layers: [] } }] })).pages[0];
  assert.equal(byId(page, 'C').role, 'INVOCADO');
  assert.equal(byId(page, 'B').architecturalType, 'CONTENEDOR_PADRE');
  assert.equal(byId(page, 'B').domainRole, 'PRODUCER');
  assert.equal(byId(page, 'api').role, 'PRINCIPAL');
});

test('E1 labels another domain as an external system by elimination: the producer is the domain holding the child', () => {
  const shapes = [
    domainOf('dom', 'INTEGRACIÓN', ['api']), uml('api', 'Debit Card - Management v1.0.0'),
    box('B', ['C', 'gw', 'act', 'ev']), box('C', ['gw', 'act', 'ev']), bpmn('gw', 'BPMNGateway'), bpmn('act', 'BPMNActivity'), bpmn('ev', 'BPMNEvent', 'Inicio'),
    domainOf('Y', 'CORE EXTERNO', ['ya']), uml('ya', 'Algo - Externo v1.0.0'),
    box('X', ['xa']), uml('xa', 'Otro - Externo v1.0.0')
  ];
  const lines = [startLine('api', 'ev')];
  const model = analyze(shapes, lines);
  assert.equal(model.structuralScenario.scenario, 'E1');
  const roots = model.architecturalStructure.rootContainers;
  assert.equal(roots.find(r => r.id === 'B').role, 'PRODUCER');
  assert.equal(roots.find(r => r.id === 'dom').role, 'INTEGRATION');
  assert.equal(roots.find(r => r.id === 'Y').role, 'EXTERNAL_SYSTEM');
  assert.equal(roots.find(r => r.id === 'Y').roleSource, 'E1_ELIMINATION');
  const page = copilotExport(analyzeBlueprint({ pages: [{ id: 'p', title: 'p', items: { shapes, lines, groups: [], layers: [] } }] })).pages[0];
  for (const id of ['X', 'xa']) { assert.equal(byId(page, id).domainRole, 'EXTERNAL_SYSTEM', id); assert.deepEqual(byId(page, id).possibleDomainRoles, [], id); assert.equal(byId(page, id).architecturalDomain.roleSource, 'E1_ELIMINATION', id); }
  assert.equal(byId(page, 'B').domainRole, 'PRODUCER');
});

test('an external system cannot hold the child: the scenario is not determined', () => {
  const shapes = [
    domainOf('dom', 'INTEGRACIÓN', ['api']), uml('api', 'Debit Card - Management v1.0.0'),
    domainOf('ext', 'SISTEMAS EXTERNOS', ['C', 'gw', 'act', 'ev']), box('C', ['gw', 'act', 'ev']), bpmn('gw', 'BPMNGateway'), bpmn('act', 'BPMNActivity'), bpmn('ev', 'BPMNEvent', 'Inicio')
  ];
  const model = analyze(shapes, [startLine('api', 'ev')]);
  assert.equal(model.structuralScenario.status, 'NO_DETERMINADO');
  assert.ok(model.architecturalRoleCandidates[0].contradictions.includes('CHILD_INSIDE_EXTERNAL_SYSTEM'));
});

test('E3 labels other unnamed domains as external systems by elimination, and never in E2', async () => {
  const input = JSON.parse(await readFile('fixtures/synthetic/e3-role-candidate.json', 'utf8'));
  input.pages[1].items.shapes.push(box('extdom', ['extapi'], 'CORE EXTERNO', 'UMLRectangleContainerBlock'), uml('extapi', 'Algo - Externo v1.0.0'));
  const model = analyzeBlueprint(input).pages[1];
  assert.equal(model.structuralScenario.scenario, 'E3');
  const ext = model.architecturalStructure.rootContainers.find(r => r.id === 'extdom');
  assert.equal(ext.role, 'EXTERNAL_SYSTEM');
  assert.equal(ext.roleSource, 'E3_ELIMINATION');
  const inner = model.architecturalStructure.components.find(c => c.id === 'extapi');
  assert.equal(inner.domainRole, 'EXTERNAL_SYSTEM');
  const e2 = analyze([domainOf('dom', 'INTEGRACIÓN', ['api', 'C', 'gw', 'act', 'ev']), uml('api', 'Debit Card - Management v1.0.0'), box('C', ['gw', 'act', 'ev']), bpmn('gw', 'BPMNGateway'), bpmn('act', 'BPMNActivity'), bpmn('ev', 'BPMNEvent', 'Inicio'), domainOf('other', 'CORE LIBRE', ['q']), uml('q', 'Otro - Libre v1.0.0')], [startLine('api', 'ev')]);
  assert.equal(e2.structuralScenario.scenario, 'E2');
  assert.equal(e2.architecturalStructure.rootContainers.find(r => r.id === 'other').role, null);
});

test('over the example corpus every evaluable page has exactly one child and it is the main child', async () => {
  const { readdir } = await import('node:fs/promises');
  const files = [];
  const walk = async d => { for (const e of await readdir(d, { withFileTypes: true })) { const p = `${d}/${e.name}`; if (e.isDirectory()) await walk(p); else if (e.name.endsWith('.json') && !/ENRIQUECIDO|blueprint_evidence/.test(e.name)) files.push(p); } };
  await walk('Blueprints_ejemplos');
  let pages = 0; const scenarios = {}, withoutChild = [];
  for (const f of files) {
    const compact = copilotExport(analyzeBlueprint(JSON.parse((await readFile(f, 'utf8')).replace(/^\uFEFF/, ''))));
    for (const p of compact.pages) {
      if (!['OPERATIONAL', 'MIXED'].includes(p.pageClassification.kind)) continue;
      pages++;
      const children = p.components.filter(c => c.architecturalType === 'SERVICIO_HIJO');
      if (children.length === 0) { withoutChild.push(p.page.title); continue; } // BP antiguos sin etiquetas de la biblioteca nueva: sin hijo certificado
      assert.equal(children.length, 1, `${f}:${p.page.title}`);
      if (p.scenario.status !== 'NO_DETERMINADO') assert.equal(children[0].role, 'INVOCADO', `${f}:${p.page.title}`); // sin escenario el hijo no tiene rol
      const k = `${p.scenario.status}/${p.scenario.scenario}`; scenarios[k] = (scenarios[k] ?? 0) + 1;
    }
  }
  assert.equal(pages, 61); // 24/11/2026: corpus de 34 BP (antes 28 páginas evaluables)
  assert.deepEqual(scenarios, { 'HIPOTESIS/E1': 21, 'HIPOTESIS/E2': 14, 'NO_DETERMINADO/null': 21 }); // las 5 páginas sin hijo no entran en este conteo
  assert.deepEqual(withoutChild.sort(), ['log', 'retrieve', 'retrieveAvailableStatements', 'retrieveDocument', 'validate']); // 5 páginas de BP sin etiquetas de la biblioteca nueva: sin hijo certificado
});
