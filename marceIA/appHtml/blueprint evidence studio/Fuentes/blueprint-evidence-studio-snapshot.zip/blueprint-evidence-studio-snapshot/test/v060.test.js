import test from 'node:test';
import assert from 'node:assert/strict';
import { analyzeBlueprint, copilotExport } from '../src/index.js';

const uml = (id, title, third = '', extra = {}) => ({ id, class: 'UMLClassBlock', textAreas: [{ label: 'Title', text: title }, { label: 'Text1', text: 'op' }, { label: 'Text2', text: third }], ...extra });
const evt = (id, text = '') => ({ id, class: 'BPMNEvent', textAreas: [{ label: 'Text', text }] });
const box = (id, text, contains = [], cls = 'UMLRectangleContainerBlock') => ({ id, class: cls, textAreas: [{ label: 'Text', text }], contains: { shapes: contains, lines: [], groups: [] } });
const run = (shapes, lines = []) => copilotExport(analyzeBlueprint({ pages: [{ id: 'p', title: 'p', items: { shapes, lines, groups: [], layers: [] } }] }), { selectedPageIds: ['p'] }).pages[0];
const get = (page, id) => page.components.find(c => c.id === id);
const inIntegration = (...inner) => [box('I', 'INTEGRACIÓN', inner.map(x => x.id)), ...inner];
const inProducer = (...inner) => [box('P', 'DOMINIO PRODUCTOR', inner.map(x => x.id)), ...inner];

test('tipo public/private/partner/privada/publica certifica API sin importar mayúsculas; Entidad, Utilidad o Tarea no son señal', () => {
  for (const third of ['Private - Entidad', 'PUBLIC', 'partner - tarea', 'Privada', 'publica - utilidad']) {
    const c = get(run(inIntegration(uml('a', 'Cuenta - Consultar v1.0.0', third))), 'a');
    assert.equal(c.architecturalType, 'API', third);
    assert.equal(c.inference.rule, 'API_BY_EXPOSURE_TYPE', third);
    assert.equal(c.role, 'INVOCADO');
  }
  const only = get(run(inIntegration(uml('a', 'Cuenta - Consultar v1.0.0', 'Entidad'))), 'a');
  assert.equal(only.architecturalType, 'SERVICIO', 'Entidad no es señal: sin marcador en el ámbito es servicio');
  assert.equal(only.inference.rule, 'SERVICE_BY_NO_MARKER_IN_SCOPE');
  const withMarker = get(run(inIntegration(uml('a', 'Cuenta - Consultar v1.0.0', 'Entidad'), evt('e1'))), 'a');
  assert.equal(withMarker.architecturalType, 'API', 'Entidad con su marcador es API');
});

test('tipo y clasificación de evento en la tercera sección ganan sobre el tipo de API; Nombre Evento sin ellos es solo candidato a evento', () => {
  assert.equal(get(run(inIntegration(uml('a', 'X v1.0.0', 'Private - Empresarial - Query'))), 'a').architecturalType, 'EVENTO_INTEGRACION');
  assert.equal(get(run(inIntegration(uml('a', 'X v1.0.0', 'Private - Empresarial'))), 'a').architecturalType, 'API', 'tipo sin clasificación no es evento: manda Private');
  const t = get(run(inIntegration(uml('a', 'Nombre Evento', 'Tipo - Clasificación'))), 'a');
  assert.equal(t.architecturalType, null);
  assert.deepEqual(t.possibleTypes, ['EVENTO_INTEGRACION']);
  assert.equal(get(run(inIntegration(uml('a', 'Nombre Evento', 'Aplicación - Event'))), 'a').architecturalType, 'EVENTO_INTEGRACION');
  assert.equal(get(run(inIntegration(uml('a', 'Evento Cliente Creado', ''))), 'a').possibleTypes?.includes('EVENTO_INTEGRACION') ?? false, false, 'solo se toma literal Nombre Evento');
  const op = get(run(inProducer(uml('a', 'recepcion', 'Tarea', { textAreas: [{ label: 'Title', text: 'recepcion' }, { label: 'Text1', text: 'registerKeyEvent' }, { label: 'Text2', text: '' }] }))), 'a');
  assert.equal(op.architecturalType, 'SERVICIO', 'event en la operación no cuenta');
});

test('bloque sin tipo en el padre o auxiliar del productor es servicio invocado; dentro del hijo no se clasifica', () => {
  const c = get(run(inProducer(uml('a', 'politicasApertura', ''))), 'a');
  assert.equal(c.architecturalType, 'SERVICIO');
  assert.equal(c.inference.rule, 'SERVICE_BY_PRODUCER_DOMAIN');
  assert.equal(c.role, 'INVOCADO');
});

test('sin señal ni marcador en el ámbito: servicio, también con Entidad, Utilidad o Tarea; los nombres de plantilla siguen como candidato API o SERVICIO', () => {
  const s = get(run(inIntegration(uml('a', 'Legacy', 'Clasificación de lógica'))), 'a');
  assert.equal(s.architecturalType, 'SERVICIO');
  assert.equal(s.role, 'INVOCADO');
  assert.equal(s.inference.rule, 'SERVICE_BY_NO_MARKER_IN_SCOPE');
  for (const third of ['Entidad', 'Tarea', 'Utilidad']) assert.equal(get(run(inIntegration(uml('a', 'Legacy', third))), 'a').architecturalType, 'SERVICIO', third);
  const uneven = run(inIntegration(uml('a', 'A', 'Entidad'), uml('b', 'B', 'Entidad'), evt('e1')));
  assert.deepEqual(get(uneven, 'a').possibleTypes, ['API', 'SERVICIO'], 'marcadores distintos de bloques: candidato');
});

test('conteo de marcadores sin auxiliar: solo en un dominio sin auxiliares; con auxiliares las figuras sueltas no se infieren por conteo', () => {
  const evt = id => ({ id, class: 'BPMNEvent', textAreas: [{ label: 'Text', text: '' }] });
  const ok = run(inIntegration(uml('a', 'A v1.0.0', ''), evt('e1')));
  assert.equal(get(ok, 'a').architecturalType, 'API');
  assert.equal(get(ok, 'a').inference.rule, 'API_BY_MARKER_COUNT_IN_AUXILIAR');
  const bad = run(inIntegration(uml('a', 'A v1.0.0', ''), uml('b', 'B v1.0.0', ''), evt('e1')));
  assert.deepEqual(get(bad, 'a').possibleTypes, ['API', 'SERVICIO']);
  const tpl = run(inIntegration(uml('a', 'A v1.0.0', ''), uml('t', 'Nombre Servicio', 'Clasificación de lógica'), evt('e1')));
  assert.equal(get(tpl, 'a').architecturalType, 'API', 'la plantilla no se cuenta');
  assert.equal(get(tpl, 't')?.architecturalType ?? null, null, 'la plantilla no se certifica');
});

test('auxiliar EVC/EPC/LDC: el bloque sin otra señal es API (iguales a eventos vacíos los omite); otro auxiliar: conteo igual => API, distinto => candidato; ms gana', () => {
  const aux = (name, ids) => box('X', name, ids, 'BPMNGroup');
  const ok = run([box('I', 'INTEGRACIÓN', ['X']), aux('EVC Pagos', ['a', 'b', 'e1', 'e2']), uml('a', 'A v1.0.0', ''), uml('b', 'B v1.0.0', ''), evt('e1'), evt('e2')]);
  assert.equal(get(ok, 'a').architecturalType, 'API');
  assert.equal(get(ok, 'a').inference.rule, 'API_BY_EVC_AUXILIAR');
  assert.equal(get(ok, 'e1'), undefined);
  assert.equal(ok.omittedComponents.find(o => o.reason === 'API_MARKER_EVENT').count, 2);
  const evcUneven = run([box('I', 'INTEGRACIÓN', ['X']), aux('EVC Pagos', ['a', 'b', 'e1']), uml('a', 'A v1.0.0', ''), uml('b', 'B v1.0.0', ''), evt('e1')]);
  assert.equal(get(evcUneven, 'a').architecturalType, 'API', 'en EVC/EPC/LDC no hace falta que el conteo coincida');
  const bad = run([box('I', 'INTEGRACIÓN', ['X']), aux('Otro auxiliar', ['a', 'b', 'e1']), uml('a', 'A v1.0.0', ''), uml('b', 'B v1.0.0', ''), evt('e1')]);
  assert.equal(get(bad, 'a').architecturalType, null);
  assert.deepEqual(get(bad, 'a').possibleTypes, ['API', 'SERVICIO']);
  assert.equal(get(bad, 'e1').architecturalType, 'MARCADOR_API');
  const noKeyword = run([box('I', 'INTEGRACIÓN', ['X']), aux('Otro auxiliar', ['a', 'e1']), uml('a', 'A v1.0.0', ''), evt('e1')]);
  assert.equal(get(noKeyword, 'a').architecturalType, 'API', 'sin EVC/EPC/LDC también se infiere por conteo');
  const noMarker = run([box('I', 'INTEGRACIÓN', ['X']), aux('EVC Pagos', ['a']), uml('a', 'Legacy', '')]);
  assert.equal(get(noMarker, 'a').architecturalType, 'API', 'en EVC/EPC/LDC, sin otra señal, es API');
  const plainNoMarker = run([box('I', 'INTEGRACIÓN', ['X']), aux('Otro auxiliar', ['a']), uml('a', 'Legacy', '')]);
  assert.equal(get(plainNoMarker, 'a').architecturalType, 'SERVICIO', 'sin marcador en un auxiliar que no es EVC: servicio');
  const ms = run([box('I', 'INTEGRACIÓN', ['X']), aux('EVC Pagos', ['a', 'e1']), uml('a', 'ms-pagos', ''), evt('e1')]);
  assert.equal(get(ms, 'a').architecturalType, 'SERVICIO', 'ms gana sobre la inferencia de API');
});

test('gestor de colas prospecto por nombre; compuerta y evento BPMN tienen tipo propio; comando solo con conexión a API, servicio, cola o auxiliar', () => {
  const q = get(run(inIntegration(uml('q', 'Cola de pagos', ''))), 'q');
  assert.deepEqual(q.possibleTypes, ['GESTOR_COLAS']);
  assert.equal(q.role, 'INVOCADO');
  const gate = { id: 'g', class: 'BPMNGateway', textAreas: [] }, act = { id: 'c', class: 'BPMNActivity', textAreas: [{ label: 'Text', text: 'Publicar en cola' }] }, lone = { id: 'z', class: 'BPMNActivity', textAreas: [{ label: 'Text', text: 'Solo' }] };
  const api = uml('a', 'Cuenta - Consultar v1.0.0', 'Private - Entidad');
  const line = { id: 'l', endpoint1: { style: 'None', connectedTo: 'c' }, endpoint2: { style: 'Arrow', connectedTo: 'a' } };
  const page = run([...inIntegration(api), gate, act, lone, evt('ev', 'Inicio')], [line]);
  assert.equal(get(page, 'g').architecturalType, 'COMPUERTA');
  assert.equal(get(page, 'ev').architecturalType, 'EVENTO_BPMN');
  assert.equal(get(page, 'c').architecturalType, 'COMANDO');
  assert.equal(get(page, 'c').inference.rule, 'COMMAND_BY_CONNECTION');
  assert.equal(get(page, 'z').architecturalType, null, 'actividad sin conexión no es comando');
  assert.equal(get(page, 'c').possibleTypes, undefined, 'la actividad nunca es candidato a cola por su nombre');
});

test('el JSON de cada página trae un inventory por tipo con candidatos', () => {
  const page = run(inIntegration(uml('a', 'Cuenta v1.0.0', 'Private'), uml('b', 'Legacy', 'Entidad'), uml('c', 'Otro', ''), uml('s', 'ms-x', ''), evt('e1')));
  assert.deepEqual(page.inventory.apis.map(x => x.id), ['a']);
  assert.deepEqual(page.inventory.servicios.map(x => x.id), ['s']);
  assert.deepEqual(page.inventory.candidatos.map(x => [x.id, x.possibleTypes]), [['b', ['API', 'SERVICIO']], ['c', ['API', 'SERVICIO']]]);
});

test('la palabra microservicio o microservice en el título certifica el servicio; ms solo al inicio o al final', () => {
  for (const title of ['Microservicio de pagos', 'pagos microservice', 'ms-pagos', 'pagos-ms']) assert.equal(get(run(inIntegration(uml('a', title, ''))), 'a').architecturalType, 'SERVICIO', title);
  for (const title of ['forms', 'items v1.0.0', 'mensajes']) assert.notEqual(get(run(inIntegration(uml('a', title, ''))), 'a').inference.rule, 'SERVICE_BY_MS_NAMING', title);
});

test('la Skill y las instrucciones 12.2.0 recogen las decisiones de la analista', async () => {
  const { readFile } = await import('node:fs/promises');
  const read = async f => (await readFile(f, 'utf8')).replace(/\r/g, '');
  const refs = 'skills/validar-blueprint-integracion/references/', all = (await Promise.all(['00-procedimiento', '01-reglas-estructura', '02-reglas-api-servicios'].map(f => read(`${refs}${f}.md`)))).join('\n');
  const ins = await read('dist/INSTRUCCIONES-AGENTE-v12.2.0.md'), proc = await read(`${refs}00-procedimiento.md`), est = await read(`${refs}01-reglas-estructura.md`);
  assert.ok([...ins].length <= 8000);
  assert.match(proc, /Con al menos un candidato o pendiente en la población: `No verificable`, aunque exista un incumplimiento certificado; este se cita en la justificación como observación/);
  assert.match(est, /Las API solo existen en INTEGRACIÓN o SISTEMAS EXTERNOS/);
  assert.match(est, /Todo `BPMNGroup` dentro de un dominio es un auxiliar/);
  assert.doesNotMatch(all, /legendShapeIds/);
  assert.doesNotMatch(ins, /Un incumplimiento certificado sí lo justifica/);
  assert.doesNotMatch(all, /HIJO_PRINCIPAL/);
  assert.doesNotMatch(ins, /HIJO_PRINCIPAL/);
  assert.match(est, /modelos de entrada y salida \(`MODELO`\)/);
  assert.match(est, /puede encapsular API, servicios y eventos de integración/);
  assert.match(est, /también puede estar en el nivel padre del DOMINIO PRODUCTOR/);
  assert.match(await read(`${refs}02-reglas-api-servicios.md`), /Hijo principal no MCI en E1 \(supuesto\)/);
  for (const f of ['01-reglas-estructura', '02-reglas-api-servicios', '03-reglas-eventos', '04-reglas-despliegue', '06-reglas-modelos-comandos', '07-reglas-gestores-colas']) {
    const text = await read(`${refs}${f}.md`);
    const prevalece = (text.match(/prevalece \*\*No cumple\*\*/g) ?? []).length, excepcion = (text.match(/Excepción: con un candidato pendiente/g) ?? []).length;
    assert.equal(excepcion, prevalece, f);
  }
  for (const word of ['pages[].inventory', 'EVENTO_BPMN', 'COMANDO', 'PRINCIPAL', 'INVOCADO']) assert.ok(ins.includes(word) || proc.includes(word), word);
});
