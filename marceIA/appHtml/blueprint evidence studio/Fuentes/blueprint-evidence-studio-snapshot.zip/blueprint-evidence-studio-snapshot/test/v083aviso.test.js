import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { analyzeBlueprint, copilotExport, blockingPages, blockingMessage } from '../src/index.js';

const uml = (id, title) => ({ id, class: 'UMLClassBlock', textAreas: [{ label: 'Title', text: title }, { label: 'Text1', text: 'op' }, { label: 'Text2', text: '' }] });
const evt = id => ({ id, class: 'BPMNEvent', textAreas: [{ label: 'Text', text: '' }] });
const box = (id, text, contains = [], cls = 'UMLRectangleContainerBlock') => ({ id, class: cls, textAreas: [{ label: 'Text', text }], contains: { shapes: contains, lines: [], groups: [] } });
const line = (id, a, b, sa = 'None', sb = 'Arrow') => ({ id, endpoint1: { style: sa, connectedTo: a }, endpoint2: { style: sb, connectedTo: b } });
const legend = [box('N', 'NOTACIÓN', ['n1']), { id: 'n1', class: 'DefaultSquareBlock', textAreas: [{ label: 'Text', text: 'Pública o Partner' }] }];
const run = (shapes, lines = []) => {
  const model = analyzeBlueprint({ pages: [{ id: 'p', title: 'op1', items: { shapes, lines, groups: [], layers: [] } }] });
  return copilotExport(model, { selectedPageIds: ['p'] });
};
const page = out => out.pages[0];

test('plantilla vacía: solo leyenda y figuras de plantilla, sin API ni servicio con nombre propio', () => {
  const out = run([...legend, uml('t1', 'NOMBRE SERVICIO')]);
  assert.equal(page(out).pageClassification.kind, 'TEMPLATE_OR_LEGEND');
  assert.equal(page(out).pageClassification.reason, 'TEMPLATE_EMPTY');
  assert.equal(blockingPages(out).length, 1);
});

test('principal con nombre de plantilla y única línea certificada al evento, con otros servicios reales: la página es evaluable (0.8.5)', () => {
  const out = run([...legend, box('I', 'INTEGRACIÓN', ['a', 'e']), uml('a', 'NOMBRE SERVICIO'), evt('e'), uml('s', 'ms-real')], [line('l1', 'a', 'e')]);
  assert.equal(page(out).pageClassification.kind, 'MIXED');
  assert.equal(page(out).pageClassification.placeholderMainAccepted, true);
  assert.deepEqual(page(out).pageClassification.operationalPathIds, ['l1']);
  assert.equal(blockingPages(out).length, 0);
});

test('dos principales con nombre de plantilla conectados a eventos: no hay unicidad y la página sigue bloqueada', () => {
  const out = run([...legend, box('I', 'INTEGRACIÓN', ['a', 'b', 'e', 'f']), uml('a', 'NOMBRE SERVICIO'), uml('b', 'NOMBRE API'), evt('e'), evt('f'), uml('s', 'ms-real')], [line('l1', 'a', 'e'), line('l2', 'b', 'f')]);
  assert.equal(page(out).pageClassification.kind, 'TEMPLATE_OR_LEGEND');
  assert.equal(page(out).pageClassification.reason, 'PLACEHOLDER_MAIN');
  assert.equal(blockingPages(out).length, 1);
});

test('principal de plantilla conectado al evento pero sin ninguna otra API/servicio con nombre propio: plantilla en blanco, sigue bloqueada', () => {
  const out = run([...legend, box('I', 'INTEGRACIÓN', ['a', 'e']), uml('a', 'NOMBRE SERVICIO'), evt('e')], [line('l1', 'a', 'e')]);
  assert.equal(page(out).pageClassification.kind, 'TEMPLATE_OR_LEGEND');
  assert.equal(page(out).pageClassification.reason, 'TEMPLATE_EMPTY');
});

test('principal de plantilla con línea NO certificada al evento: no se acepta aunque sea el único', () => {
  const out = run([...legend, box('I', 'INTEGRACIÓN', ['a', 'e']), uml('a', 'NOMBRE SERVICIO'), evt('e'), uml('s', 'ms-real')], [line('l1', 'a', 'e', 'None', 'None')]);
  assert.equal(page(out).pageClassification.kind, 'TEMPLATE_OR_LEGEND');
});

test('si existe un principal con nombre propio, el de plantilla no lo desplaza ni cambia la ruta operativa', () => {
  const out = run([...legend, box('I', 'INTEGRACIÓN', ['a', 'b', 'e', 'f']), uml('a', 'Cuenta v1.0.0'), uml('b', 'NOMBRE SERVICIO'), evt('e'), evt('f')], [line('l1', 'a', 'e'), line('l2', 'b', 'f')]);
  assert.equal(page(out).pageClassification.kind, 'MIXED');
  assert.deepEqual(page(out).pageClassification.operationalPathIds, ['l1']);
  assert.equal(page(out).pageClassification.placeholderMainAccepted, undefined);
});

test('sin línea entre la API y un evento: el mensaje pide validar la conexión con el evento de Inicio del hijo', () => {
  const out = run([...legend, box('I', 'INTEGRACIÓN', ['a', 'e']), uml('a', 'Cuenta v1.0.0'), evt('e')]);
  assert.equal(page(out).pageClassification.reason, 'NO_API_EVENT_LINE');
  assert.equal(blockingPages(out).length, 1);
});

test('línea entre la API y el evento sin terminaciones verificables: se informa como no verificada', () => {
  const out = run([...legend, box('I', 'INTEGRACIÓN', ['a', 'e']), uml('a', 'Cuenta v1.0.0'), evt('e')], [line('l1', 'a', 'e', 'None', 'None')]);
  assert.equal(page(out).pageClassification.reason, 'API_EVENT_LINE_NOT_VERIFIED');
  assert.deepEqual(page(out).pageClassification.reasonDetail.unverifiedLineIds, ['l1']);
});

test('línea que llega al evento sin origen pegado: la pista nombra la línea y el evento', () => {
  const out = run([...legend, box('I', 'INTEGRACIÓN', ['a', 'e']), uml('a', 'Cuenta v1.0.0'), evt('e')], [line('l9', null, 'e')]);
  assert.equal(page(out).pageClassification.reason, 'NO_API_EVENT_LINE');
  assert.deepEqual(page(out).pageClassification.reasonDetail.danglingEventLines, [{ id: 'l9', eventId: 'e' }]);
});

test('una página operativa no lleva causa ni bloquea las descargas', () => {
  const out = run([...legend, box('I', 'INTEGRACIÓN', ['a', 'e']), uml('a', 'Cuenta v1.0.0'), evt('e')], [line('l1', 'a', 'e')]);
  assert.equal(page(out).pageClassification.kind, 'MIXED');
  assert.equal(page(out).pageClassification.reason, undefined);
  assert.equal(blockingPages(out).length, 0);
});

test('Deposit Account retrievePocketTransactions: página real sin conexión del principal con el evento queda bloqueada', async () => {
  const file = 'Blueprints_ejemplos/Deposit Account Pocket Transaction Information/MCI - BP - [Deposit Account Pocket Transaction Information] - [Transaction Information] (1).json';
  const raw = JSON.parse((await readFile(file, 'utf8')).replace(/^﻿/, ''));
  const model = analyzeBlueprint(raw, { sourceName: file });
  const target = model.pages.find(p => p.page.title === 'retrievePocketTransactions');
  const out = copilotExport(model, { selectedPageIds: [target.page.id] });
  assert.equal(page(out).pageClassification.kind, 'TEMPLATE_OR_LEGEND');
  assert.equal(page(out).pageClassification.reason, 'NO_API_EVENT_LINE');
  assert.equal(blockingPages(out).length, 1);
  assert.ok(page(out).pageClassification.reasonDetail.danglingEventLines.some(x => x.id === 'mWTLaUW4YBh_'));
});
