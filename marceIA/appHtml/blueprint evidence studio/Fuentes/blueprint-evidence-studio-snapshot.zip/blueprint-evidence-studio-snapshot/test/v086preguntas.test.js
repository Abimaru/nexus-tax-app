import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

const read = async x => (await readFile(x, 'utf8')).replace(/\r/g, '');
const R = 'skills/validar-blueprint-integracion/';

test('12.2.0: las preguntas se agrupan por nombre de API, el hijo de E2 se pregunta por hijo, E1 no pregunta por el hijo y E3 no pregunta', async () => {
  const proc = await read(`${R}references/00-procedimiento.md`), skill = await read(`${R}SKILL.md`), man = await read(`${R}references/MANIFEST.md`), ins = await read('dist/INSTRUCCIONES-AGENTE-v12.2.0.md');
  assert.match(proc, /#### 5\.4 Agrupación por nombre de API/);
  assert.match(proc, /La pregunta del hijo principal de E2 no se agrupa/);
  assert.match(proc, /#### 5\.5 Hijo principal de E1: supuesto no MCI/);
  assert.match(proc, /SUPUESTO_E1_HIJO_NO_MCI/);
  assert.match(proc, /en E3 no se hace ninguna pregunta/);
  assert.match(skill, /una sola vez por cada nombre de API/);
  assert.match(skill, /solo en E2 y una por cada hijo/);
  assert.match(skill, /En E1 no preguntar por el hijo principal/);
  assert.match(man, /En E3 no se hace ninguna pregunta/);
  assert.match(ins, /una sola vez por API/);
  assert.match(ins, /en E1 no se pregunta por el hijo/);
  assert.doesNotMatch(proc, /en E1 o E2, preguntar/);
  assert.doesNotMatch(skill, /solo en E1 o E2/);
});

test('12.2.0: SRV-004 evalúa el hijo de E1 como no MCI y no pide su declaración', async () => {
  const srv = await read(`${R}references/02-reglas-api-servicios.md`), fichas = await read(`${R}references/08-fichas.md`);
  assert.match(srv, /En E1 no se pregunta: se da por no MCI/);
  assert.match(srv, /falta la declaración MCI del hijo principal de E2;/);
  assert.doesNotMatch(srv, /falta la declaración MCI del hijo principal de E1 o E2/);
  assert.match(srv, /DOMINIO PRODUCTOR sí puede pertenecerle/);
  assert.match(fichas, /el de E1 \(supuesto no MCI, sin pregunta\)/);
});

test('12.2.0: el contenido de una capa de despliegue se evalúa con el nivel del inventario y nivel OTRO es No verificable', async () => {
  const proc = await read(`${R}references/00-procedimiento.md`), fichas = await read(`${R}references/08-fichas.md`);
  assert.match(proc, /no son un nivel/);
  assert.match(proc, /`ubicacion\.nivel: OTRO`/);
  for (const id of ['CNT-003', 'CNT-004', 'CNT-005']) assert.match(fichas, new RegExp(`\\*\\*${id}\\.\\*\\*[^\\n]*ubicacion\\.capaId`));
  assert.match(fichas, /`nivel: OTRO` es `No verificable`/);
});

test('12.2.0: la pregunta agrupada por API lleva el nombre una vez y los ids juntos', async () => {
  const proc = await read(`${R}references/00-procedimiento.md`), skill = await read(`${R}SKILL.md`);
  assert.match(proc, /el nombre de la API aparece una sola vez y los ids de todas las páginas afectadas van juntos/);
  assert.match(proc, /¿La API principal “\[nombre\]” \(`\[id1\]` y `\[id2\]`\) tiene Capa de Despliegue MCI\? Responde Sí o No/);
  assert.match(proc, /exposición de la API principal “\[nombre\]” \(`\[id1\]` y `\[id2\]`\)/);
  assert.match(skill, /«Nombre \(id1 y id2\)»/);
});
