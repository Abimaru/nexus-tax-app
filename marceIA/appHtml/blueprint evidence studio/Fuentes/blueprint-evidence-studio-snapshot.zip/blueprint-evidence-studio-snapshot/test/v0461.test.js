import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile, readdir } from 'node:fs/promises';
import { analyzeBlueprint, copilotExport, interpretBpmnEventSubtype, summarizeEvaluations, summarizeBlueprint } from '../src/index.js';

async function jsonFiles(dir){const out=[];for(const item of await readdir(dir,{withFileTypes:true})){const path=`${dir}/${item.name}`;if(item.isDirectory())out.push(...await jsonFiles(path));else if(item.name.endsWith('.json'))out.push(path);}return out;}
const load=async path=>JSON.parse((await readFile(path,'utf8')).replace(/^\uFEFF/,''));

test('compact preserves literal customData for every original shape in the corpus',async()=>{
  let preserved=0;
  for(const file of await jsonFiles('Blueprints_ejemplos')){
    const raw=await load(file);if(!Array.isArray(raw.pages))continue;
    const model=analyzeBlueprint(raw),compact=copilotExport(model);
    for(const sourcePage of raw.pages){const page=compact.pages.find(x=>x.page.id===sourcePage.id);for(const shape of sourcePage.items?.shapes??[]){if(!shape||!Object.hasOwn(shape,'customData'))continue;const component=page.components.find(x=>x.id===shape.id);if(!component){if(new Set(model.pages.find(x=>x.page.id===sourcePage.id)?.pageClassification.legendShapeIds??[]).has(shape.id)||/Descripci[oó]n Operaci[oó]n/i.test(JSON.stringify(shape.textAreas??[])))continue;assert.ok(['DefaultSquareBlock','BPMNEvent'].includes(shape.class),`${file}:${sourcePage.id}:${shape.id}`);assert.equal((shape.customData??[]).length,0);continue;}assert.ok(component,`${file}:${sourcePage.id}:${shape.id}`);assert.ok(Object.hasOwn(component,'customData'));assert.deepEqual(component.customData,shape.customData);preserved++;}}
  }
  assert.ok(preserved>0);
});

test('Oski activities with customData ENTRADA or SALIDA are MODELO by that rule',async()=>{const raw=await load('Blueprints_ejemplos/Collections_Bill_Payments/NMD - BP -  Collections_Bill_Payments-Pay_Bill U (1).json'),page=copilotExport(analyzeBlueprint(raw)).pages.find(x=>x.page.title==='msDebitAccountPayment'),marked=page.components.filter(x=>Array.isArray(x.customData)&&x.customData.some(d=>['ENTRADA','SALIDA'].includes(d?.key)));assert.equal(marked.length,13);assert.ok(marked.every(x=>x.architecturalType==='MODELO'&&x.inference?.rule==='MODEL_BY_CUSTOMDATA_IO'));});

test('resolved domains never retain possible roles',async()=>{for(const file of await jsonFiles('Blueprints_ejemplos')){const raw=await load(file);if(!Array.isArray(raw.pages))continue;for(const page of copilotExport(analyzeBlueprint(raw)).pages)for(const component of page.components)if(component.domainRole)assert.deepEqual(component.possibleDomainRoles,[]);}});

test('BPMN certification rejects doubtful declarations beside START',()=>{for(const customData of[[{key:'EVENT_TYPE',value:'START'},{key:'BPMN_EVENT_TYPE',value:'RESTART'}],[{key:'EVENT_TYPE',value:'START'},{key:'BPMN_EVENT_TYPE',value:''}],[{key:'EVENT_TYPE',value:'START'},{key:'TIPO_EVENTO_BPMN',value:'No es inicio'}],[{key:'EVENT_TYPE',value:['START']}],[{key:'EVENT_TYPE',value:'START'},{key:'BPMN_EVENT_TYPE',value:4}],[{key:'EVENT_TYPE',value:'START'},{key:'BPMN_EVENT_TYPE',value:'END'}]])assert.notEqual(interpretBpmnEventSubtype({customData}).subtypeStatus,'CERTIFIED_BY_EXPLICIT_CUSTOM_DATA');});

test('malformed customData is preserved and reported without aborting',()=>{for(const customData of[null,'START',{key:'EVENT_TYPE',value:'START'},[null,{key:'EVENT_TYPE',value:'START'}]]){const raw={pages:[{id:'p',items:{shapes:[{id:'e',class:'BPMNEvent',customData}],lines:[],groups:[],layers:[]}}]},model=analyzeBlueprint(raw),compact=copilotExport(model);assert.deepEqual(compact.pages[0].components[0].customData,customData);assert.ok(model.pages[0].architecturalStructure.issues.some(x=>x.code.startsWith('MALFORMED_CUSTOM_DATA')));}});

test('ambiguous main API emits neither definitive type nor principal role',()=>{const shapes=[{id:'d',class:'UMLRectangleContainerBlock',textAreas:[{text:'INTEGRACIÓN'}],contains:{shapes:['main','child']}},{id:'main',class:'UMLClassBlock',textAreas:[{label:'Title',text:'ms-main-api'}]},{id:'child',class:'RectangleContainerBlock',contains:{shapes:['event']}},{id:'event',class:'BPMNEvent'}],lines=[{id:'l',endpoint1:{style:'None',connectedTo:'main'},endpoint2:{style:'Arrow',connectedTo:'event'}}],component=copilotExport(analyzeBlueprint({pages:[{id:'p',items:{shapes,lines,groups:[],layers:[]}}]})).pages[0].components.find(x=>x.id==='main');assert.equal(component.architecturalType,null);assert.equal(component.role,null);assert.equal(component.inference.status,'AMBIGUOUS');});

test('four-state metrics validate counts and aggregate rule-page evaluations',()=>{const ids=Array.from({length:37},(_,i)=>`R-${i}`),values=ids.map((rule_id,i)=>({rule_id,status:i<13?'Cumple':i<26?'No verificable':'No aplica'})),page=summarizeEvaluations(values,ids);assert.equal(page.valid,true);assert.equal(page.compliancePercentage,50);assert.equal(summarizeBlueprint([page,page]).compliancePercentage,50);assert.equal(summarizeEvaluations(ids.map(rule_id=>({rule_id,status:'No aplica'})),ids).compliancePercentage,null);assert.equal(summarizeEvaluations([...values,{rule_id:ids[0],status:'Parcialmente cumple'}],ids).valid,false);assert.equal(summarizeEvaluations(values.slice(1),ids).valid,false);});
