import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { analyzeBlueprint, copilotExport, connectionBlockers, VERSION, SKILL_VERSION } from '../src/index.js';

const refs = 'skills/validar-blueprint-integracion/references/';
const read = async f => (await readFile(f, 'utf8')).replace(/\r/g, '');
const keyed = (id, cls, text, key, extra = {}) => ({ id, class: cls, textAreas: [{ label: 'Text', text }], customData: key ? [{ key, value: '' }] : [], linkedData: [], ...extra });
const line = (id, a, sa, b, sb) => ({ id, endpoint1: { style: sa, connectedTo: a }, endpoint2: { style: sb, connectedTo: b }, textAreas: [], customData: [], linkedData: [] });
const exportOf = (shapes, lines) => {
  const raw = { id: 'x', title: 'x', pages: [{ id: 'p', title: 'p', index: 0, items: { shapes, lines, groups: [], layers: [] }, customData: [], linkedData: [] }] };
  const model = analyzeBlueprint(raw, { sourceName: 'x.json' });
  return copilotExport(model, { selectedPageIds: model.pages.map(p => p.page.id) }).pages[0];
};

test('0.10.0: versiones de la línea nueva', () => {
  assert.equal(VERSION, '0.11.0');
  assert.equal(SKILL_VERSION, '12.2.0');
});

test('el comando se certifica por etiqueta con su subtipo y sin depender de conexiones', () => {
  const page = exportOf([
    keyed('a', 'BPMNActivity', 'Consultar cliente', 'SERVICE_TASK'),
    keyed('b', 'BPMNActivity', 'Homologar datos', 'SYSTEM_TASK'),
    keyed('c', 'BPMNActivity', 'Autenticación del cliente', 'SUB_PROCESS'),
    keyed('d', 'BPMNActivity', 'Aprobar solicitud', 'USER_TASK'),
    keyed('e', 'BPMNActivity', 'Sin etiqueta y sin conexión', null),
  ], []);
  const by = Object.fromEntries(page.inventory.comandos.map(c => [c.id, c.tipoComando]));
  assert.deepEqual(by, { a: 'SERVICE_TASK', b: 'SYSTEM_TASK', c: 'SUB_PROCESS', d: 'USER_TASK' });
  const a = page.components.find(c => c.id === 'a');
  assert.equal(a.architecturalType, 'COMANDO');
  assert.equal(a.inference.status, 'DECLARED_BY_CUSTOMDATA');
  assert.equal(a.inference.rule, 'COMMAND_BY_CUSTOMDATA');
  assert.equal(page.components.find(c => c.id === 'e').architecturalType, null);
});

test('la pareja de un SYSTEM_TASK expone su subtipo y la figura sin tipo trae su etiqueta', () => {
  const page = exportOf([
    keyed('b', 'BPMNActivity', 'Homologar datos', 'SYSTEM_TASK'),
    keyed('r', 'BPMNActivity', 'Pendiente de definir', 'TO_BE_DEFINED'),
  ], [line('l', 'b', 'None', 'r', 'Arrow')]);
  const rel = page.inventory.relaciones.find(r => r.participantes.some(p => p.id === 'b'));
  const sys = rel.participantes.find(p => p.id === 'b'), other = rel.participantes.find(p => p.id === 'r');
  assert.equal(sys.tipoComando, 'SYSTEM_TASK');
  assert.equal(other.tipo, 'SIN_TIPO');
  assert.deepEqual(other.etiquetas, ['TO_BE_DEFINED']);
  assert.equal(other.figura, 'BPMNActivity');
});

test('política, excepción y concepto se clasifican como modelos por etiqueta y el subtipo del evento sale de la etiqueta', () => {
  const page = exportOf([
    keyed('p', 'BPMNActivity', 'Regla de acceso', 'BUSINESS_RULE'),
    keyed('x', 'BPMNActivity', 'Mensaje de error', 'BUSINESS_EXCEPTION'),
    keyed('k', 'BPMNActivity', 'Cliente', 'BUSINESS_CONCEPT'),
    keyed('s', 'BPMNEvent', '', 'SIGNAL_SEND'),
    keyed('m', 'BPMNEvent', '', 'MESSAGE_RECEIVE'),
  ], [line('l', 'p', 'None', 's', 'Arrow')]);
  const kinds = Object.fromEntries(page.inventory.modelos.map(m => [m.id, m.tipoModelo]));
  assert.deepEqual(kinds, { p: 'POLITICA', x: 'EXCEPCION', k: 'CONCEPTO' });
  assert.equal(page.components.find(c => c.id === 'p').inference.rule, 'MODEL_BY_CUSTOMDATA');
  const sub = Object.fromEntries(page.inventory.eventosBpmn.map(e => [e.id, e.subtipo]));
  assert.deepEqual(sub, { s: 'SIGNAL_SEND', m: 'MESSAGE_RECEIVE' });
  const rel = page.inventory.relaciones.find(r => r.participantes.some(q => q.id === 's'));
  assert.equal(rel.participantes.find(q => q.id === 's').subtipoEvento, 'SIGNAL_SEND');
  assert.equal(rel.participantes.find(q => q.id === 'p').tipoModelo, 'POLITICA');
});

test('el JSON se bloquea solo con extremos sueltos; None-None, terminaciones no permitidas y anotaciones no bloquean', () => {
  const page = exportOf([
    keyed('a', 'BPMNActivity', 'Consultar cliente', 'SERVICE_TASK'),
    keyed('b', 'BPMNActivity', 'Homologar datos', 'SYSTEM_TASK'),
    keyed('n', 'BPMNTextAnnotation', 'Nota', 'NOTES'),
  ], [line('ok', 'a', 'None', 'b', 'Arrow'), line('mal', 'a', 'Arrow', 'b', 'Arrow'), line('nn', 'a', 'None', 'b', 'None'), line('anot', 'n', 'None', 'a', 'None'), { id: 'suelta', endpoint1: { style: 'None', connectedTo: 'a' }, endpoint2: { style: 'Arrow' }, textAreas: [], customData: [], linkedData: [] }]);
  const res = connectionBlockers({ pages: [page] });
  assert.equal(res.length, 1);
  assert.deepEqual(res[0].notAllowed, []);
  assert.deepEqual(res[0].loose.map(x => x.id), ['suelta']);
  assert.equal(connectionBlockers({ pages: [exportOf([keyed('a', 'BPMNActivity', 'Consultar cliente', 'SERVICE_TASK'), keyed('b', 'BPMNActivity', 'Homologar datos', 'SYSTEM_TASK')], [line('ok', 'a', 'None', 'b', 'Arrow'), line('ok2', 'b', 'CircleOpen', 'a', 'Generalization')])] }).length, 0);
});

test('Skill 12.2.0: nomenclatura de la API interna con guion bajo antes de la versión', async () => {
  const api = await read(`${refs}02-reglas-api-servicios.md`);
  assert.match(api, /Nombre Producto - Nombre API_vMayor\.Menor\.Parche/);
  assert.doesNotMatch(api, /Nombre Producto - Nombre API vMayor/);
  assert.match(api, /THIRD_PARTY_API/);
  assert.match(api, /sin distinguir mayúsculas y minúsculas \(`private - entidad` y `Private - Entidad` cumplen\)/);
});

test('Skill 12.2.0: COM-002 fusionada, COM-003, USER_TASK no permitido en el hijo y catálogo de 37 reglas', async () => {
  const com = await read(`${refs}06-reglas-modelos-comandos.md`), cnt = await read(`${refs}01-reglas-estructura.md`), man = await read(`${refs}MANIFEST.md`), fic = await read(`${refs}08-fichas.md`);
  assert.match(com, /### COM-002 - Conexiones del SERVICE_TASK/);
  assert.match(com, /### COM-003 - Conexiones permitidas de SYSTEM_TASK y SUB_PROCESS/);
  assert.doesNotMatch(com, /### COM-00[4-7] - /);
  assert.match(com, /Autenticación del cliente/);
  assert.equal([...cnt.matchAll(/un `USER_TASK` no se permite en el hijo/g)].length, 2);
  assert.match(man, /COM \(3\): COM-001, COM-002, COM-003/);
  assert.match(fic, /\*\*COM-002\.\*\*/);
  assert.match(fic, /\*\*COM-003\.\*\*/);
  assert.doesNotMatch(fic, /\*\*COM-00[4-7]\.\*\*/);
});

test('Skill 12.2.0: GEN-001, EXT-002 fusionada en los CNT, MQ-003 y SUB_PROCESS', async () => {
  const est = await read(`${refs}01-reglas-estructura.md`), man = await read(`${refs}MANIFEST.md`), mq = await read(`${refs}07-reglas-gestores-colas.md`), com = await read(`${refs}06-reglas-modelos-comandos.md`), evt = await read(`${refs}03-reglas-eventos.md`);
  assert.match(est, /### GEN-001 - Nombre de la operación principal igual al nombre de la página/);
  assert.doesNotMatch(est, /### EXT-002/);
  assert.match(est, /### EXT-001 - Nombre del sistema externo auxiliar/);
  assert.equal([...est.matchAll(/Sistemas externos auxiliares: esta regla evalúa también la ubicación de cada auxiliar/g)].length, 3);
  assert.match(man, /EXT \(1\): EXT-001/);
  assert.match(man, /GEN \(1\): GEN-001/);
  assert.match(mq, /la conexión no es obligatoria\. Si existe, debe ser unidireccional, en un solo sentido/);
  assert.match(mq, /Un evento de señal .* no puede conectarse con un gestor de colas/);
  assert.match(com, /Solo se valida que la primera palabra sea un sustantivo/);
  assert.match(evt, /Los eventos de señal \(Señal de Envío y Señal de Recepción\) se usan únicamente con eventos de integración/);
});

test('Skill 12.2.0: MOD-002, API externa por figura, política y excepción en el nivel padre y EVC con API, servicio o evento', async () => {
  const mod = await read(`${refs}06-reglas-modelos-comandos.md`), est = await read(`${refs}01-reglas-estructura.md`), api = await read(`${refs}02-reglas-api-servicios.md`), evt = await read(`${refs}03-reglas-eventos.md`), man = await read(`${refs}MANIFEST.md`);
  assert.match(mod, /### MOD-002 - Modelos sin texto de plantilla/);
  assert.match(mod, /«modelo de entrada», «modelo de lectura», «modelo de salida», «política», «excepción de negocio» y «concepto»/);
  assert.match(man, /MOD \(2\): MOD-001, MOD-002/);
  assert.match(est, /Un componente cuya figura es `THIRD_PARTY_API`, `THIRD_PARTY_SERVICE` o `THIRD_PARTY_MQ_SERVICE` \(`figura` en `inventory\.apis\[\]`, `servicios\[\]` o `gestoresCola\[\]`\) es externo: no debe estar en INTEGRACIÓN/);
  assert.match(api, /Es API externa la API con la figura `THIRD_PARTY_API`/);
  assert.match(est, /modelos de salida, políticas, mensajes de excepción, conceptos, pendientes, gestores de colas/);
  assert.doesNotMatch(est, /eventos BPMN operativos, políticas, mensajes de excepción ni comandos/);
  assert.match(est, /puede encapsular API, servicios y eventos de integración y, si encapsula alguno, debe estar en el nivel padre de INTEGRACIÓN/);
  assert.match(evt, /`Aplicacion` \(con o sin tilde\)/);
});

test('el inventario expone la figura de la biblioteca (grupo raíz) de la API externa', () => {
  const grp = (id, members, key) => ({ id, members, customData: [{ key, value: '' }], linkedData: [] });
  const raw = { id: 'x', title: 'x', pages: [{ id: 'p', title: 'p', index: 0, items: { shapes: [keyed('u', 'UMLClassBlock', 'Know Your Customer Enterprise v3.0', null), keyed('e', 'BPMNEvent', '', 'API_INDICATOR')], lines: [], groups: [grp('g1', ['u', 'e'], 'API'), grp('g0', ['g1'], 'THIRD_PARTY_API')], layers: [] }, customData: [], linkedData: [] }] };
  const model = analyzeBlueprint(raw, { sourceName: 'x.json' });
  const page = copilotExport(model, { selectedPageIds: model.pages.map(p => p.page.id) }).pages[0];
  const comp = page.components.find(c => c.id === 'u');
  assert.equal(comp.figuraBiblioteca, 'THIRD_PARTY_API');
});

test('24/11/2026: el extremo conectado de una línea suelta se describe con su tipo y su texto', () => {
  const page = exportOf([
    keyed('g', 'BPMNGateway', '¿Cliente válido?', 'EXCLUSIVE'),
    keyed('b', 'BPMNActivity', 'Homologar datos', 'SYSTEM_TASK'),
  ], [{ id: 'suelta', endpoint1: { style: 'None', connectedTo: 'g' }, endpoint2: { style: 'Arrow' }, textAreas: [], customData: [], linkedData: [] }, { id: 'suelta2', endpoint1: { style: 'None' }, endpoint2: { style: 'Arrow', connectedTo: 'b' }, textAreas: [], customData: [], linkedData: [] }]);
  const res = connectionBlockers({ pages: [page] })[0].loose;
  assert.equal(res.find(x => x.id === 'suelta').other.kind, 'Compuerta exclusiva');
  assert.equal(res.find(x => x.id === 'suelta').other.name, '¿Cliente válido?');
  assert.equal(res.find(x => x.id === 'suelta2').other.kind, 'Comando sin consumo');
});

test('24/11/2026: servicio consumido por colas expone su Capa de Tópicos y sus tópicos; la capa certificada no deja el servicio en nivel OTRO', () => {
  const bb = (x, y, w, h) => ({ x, y, w, h });
  const grp = (id, members, key) => ({ id, members, customData: [{ key, value: '' }], linkedData: [] });
  const raw = { id: 'x', title: 'x', pages: [{ id: 'p', title: 'p', index: 0, items: { shapes: [
    keyed('dom', 'UMLRectangleContainerBlock', 'INTEGRACIÓN', null, { boundingBox: bb(0, 0, 900, 700), contains: { shapes: ['tl', 'svc', 'ent', 'sal'] } }),
    keyed('tl', 'UMLRectangleContainerBlock', 'nombrecolapeticion\nnombrecolarespuesta', 'TOPIC_LAYER', { boundingBox: bb(50, 50, 600, 300), contains: { shapes: ['svc'] } }),
    keyed('svc', 'UMLClassBlock', 'Customer Keys - Retrieve Keys\nretrieveKeys\nTarea', null, { boundingBox: bb(100, 100, 300, 150) }),
    keyed('ent', 'BPMNActivity', 'Modelo de Lectura', 'ENTRADA', { boundingBox: bb(100, 400, 100, 100) }),
    keyed('sal', 'BPMNActivity', 'Modelo de Salida', 'SALIDA', { boundingBox: bb(250, 400, 100, 100) })],
  lines: [], groups: [grp('g1', ['svc'], 'SERVICE'), grp('g0', ['tl', 'g1', 'ent', 'sal'], 'OWN_UMG_MQ_SERVICE')], layers: [] }, customData: [], linkedData: [] }] };
  const model = analyzeBlueprint(raw, { sourceName: 'x.json' });
  const svc = copilotExport(model, { selectedPageIds: ['p'] }).pages[0].inventory.servicios.find(x => x.id === 'svc');
  assert.equal(svc.consumidoPorColas, true);
  assert.equal(svc.capaTopicos.id, 'tl');
  assert.deepEqual(svc.capaTopicos.topicos, ['nombrecolapeticion', 'nombrecolarespuesta']);
  assert.equal(svc.ubicacion.nivel, 'PADRE');
});

test('24/11/2026: SRV-006, escenarios con descripción y tercera sección vacía en SISTEMAS EXTERNOS', async () => {
  const srv = await read(`${refs}02-reglas-api-servicios.md`), fichas = await read(`${refs}08-fichas.md`), man = await read(`${refs}MANIFEST.md`), skill = await read('skills/validar-blueprint-integracion/SKILL.md'), proc = await read(`${refs}00-procedimiento.md`), ins = await read('dist/INSTRUCCIONES-AGENTE-v12.2.0.md');
  assert.match(srv, /### SRV-006 - Capa de Tópicos y tópicos del servicio consumido por colas/);
  assert.match(srv, /`nombrecolapeticion`, `nombrecolarespuesta`/);
  assert.match(fichas, /\*\*SRV-006\.\*\*/);
  assert.match(man, /SRV \(6\): SRV-001, SRV-002, SRV-003, SRV-004, SRV-005, SRV-006/);
  for (const t of [skill, proc, ins]) { assert.match(t, /E1 \(API directo al backend\)/); assert.match(t, /E2 \(API con servicio de integración\)/); assert.match(t, /E3 \(Servicio no gestionado\)/); }
  assert.match(srv, /La tercera sección no es obligatoria y no se evalúa: está permitida vacía/);
  assert.match(srv, /\*\*Servicio en SISTEMAS EXTERNOS\*\*/);
});
