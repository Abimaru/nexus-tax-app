import test from 'node:test';
import assert from 'node:assert/strict';
import { analyzeBlueprint, copilotExport } from '../src/index.js';

const uml = (id, title, third = '') => ({ id, class: 'UMLClassBlock', textAreas: [{ label: 'Title', text: title }, { label: 'Text1', text: 'op' }, { label: 'Text2', text: third }] });
const evt = id => ({ id, class: 'BPMNEvent', textAreas: [{ label: 'Text', text: '' }] });
const box = (id, text, contains = [], cls = 'UMLRectangleContainerBlock') => ({ id, class: cls, textAreas: [{ label: 'Text', text }], contains: { shapes: contains, lines: [], groups: [] } });
const run = (shapes, lines = []) => copilotExport(analyzeBlueprint({ pages: [{ id: 'p', title: 'p', items: { shapes, lines, groups: [], layers: [] } }] }), { selectedPageIds: ['p'] }).pages[0];
const get = (page, id) => page.components.find(c => c.id === id);
const inIntegration = (...inner) => [box('I', 'INTEGRACIÓN', inner.map(x => x.id)), ...inner];

test('la leyenda de notación y los bloques de descripción de API no se exportan en ninguna parte', () => {
  const legend = box('N', 'NOTACIÓN', ['n1', 'n2']);
  const sample = { id: 'n1', class: 'DefaultSquareBlock', textAreas: [{ label: 'Text', text: 'Pública o Partner' }] };
  const sampleGroup = { id: 'n2', class: 'BPMNGroup', textAreas: [{ label: 'Text', text: '' }] };
  const desc = { id: 'd1', class: 'VSMDatacellBlock', textAreas: [{ label: 'cell_1', text: 'Descripción Operación: Consulta saldos' }, { label: 'cell_2', text: 'Método: POST' }, { label: 'cell_3', text: 'Path: /saldos' }, { label: 'cell_4', text: 'Seguridad: OAuth' }] };
  const queue = { id: 'q1', class: 'VSMDatacellBlock', textAreas: [{ label: 'cell_1', text: 'Gestor de colas MCI' }] };
  const page = run([...inIntegration(uml('a', 'Cuenta v1.0.0', 'Private'), desc, queue), legend, sample, sampleGroup]);
  const text = JSON.stringify(page);
  for (const needle of ['NOTACIÓN', 'Pública o Partner', 'Descripción Operación', 'Consulta saldos', '/saldos', 'Seguridad', '"n1"', '"n2"', '"d1"']) assert.ok(!text.includes(needle), needle);
  assert.equal(page.pageClassification.legendShapeIds, undefined);
  assert.ok(get(page, 'q1'), 'una celda VSM que no es descripción de API sí se conserva');
  assert.equal(get(page, 'a').architecturalType, 'API');
});

test('solo el hijo real cuenta como hijo: un rectángulo plano sin compuertas ni actividades no oculta sus bloques', () => {
  const plain = box('R', '', ['u'], 'RectangleContainerBlock');
  const page = run([box('I', 'INTEGRACIÓN', ['R']), plain, uml('u', 'Legacy', '')]);
  assert.equal(get(page, 'u').architecturalType, 'SERVICIO');
  assert.equal(get(page, 'u').inference.rule, 'SERVICE_BY_NO_MARKER_IN_SCOPE');
});

test('todo BPMNGroup dentro de un dominio es auxiliar aunque no tenga texto', () => {
  const g = { id: 'g', class: 'BPMNGroup', textAreas: [{ label: 'Text', text: '' }], contains: { shapes: ['a'], lines: [], groups: [] } };
  const page = run([box('I', 'INTEGRACIÓN', ['g']), g, uml('a', 'Cuenta v1.0.0', 'Private')]);
  assert.equal(get(page, 'g').architecturalType, 'SISTEMA_EXTERNO_AUXILIAR');
  assert.equal(page.inventory.sistemasExternosAuxiliares.find(x => x.id === 'g').name, '');
  const loose = run([{ id: 'g2', class: 'BPMNGroup', textAreas: [{ label: 'Text', text: '' }] }, uml('b', 'Cuenta v1.0.0', 'Private')]);
  assert.equal(get(loose, 'g2')?.architecturalType ?? null, null, 'un grupo sin texto fuera de todo contenedor no es auxiliar');
});

test('marcador huérfano en el dominio: el bloque suelto del nivel padre es candidato; si el marcador está en su ámbito, API', () => {
  const layer = (contains) => box('L', 'Capa de Arquitectura - x', contains);
  const orphan = run([box('I', 'INTEGRACIÓN', ['L', 'a']), layer(['e1']), evt('e1'), uml('a', 'Legacy', '')]);
  assert.deepEqual(get(orphan, 'a').possibleTypes, ['API', 'SERVICIO']);
  const owned = run([box('I', 'INTEGRACIÓN', ['L']), layer(['e1', 'a']), evt('e1'), uml('a', 'Legacy', '')]);
  assert.equal(get(owned, 'a').architecturalType, 'API');
  const none = run([box('I', 'INTEGRACIÓN', ['a']), uml('a', 'Legacy', '')]);
  assert.equal(get(none, 'a').architecturalType, 'SERVICIO');
});

test('API explícita en el productor se certifica (CNT-004 la marca); las señales débiles no se aplican allí', () => {
  const prod = run([box('P', 'DOMINIO PRODUCTOR', ['a', 'b']), uml('a', 'Cuenta v1.0.0', 'Private'), uml('b', 'Legacy', 'Entidad')]);
  assert.equal(get(prod, 'a').architecturalType, 'API');
  assert.equal(get(prod, 'b').architecturalType, 'SERVICIO');
  assert.equal(get(prod, 'b').inference.rule, 'SERVICE_BY_PRODUCER_DOMAIN');
});

test('contenedor raíz sin rol es el ámbito de un bloque que no está en ningún dominio', () => {
  const page = run([box('R', '', ['u'], 'RectangleContainerBlock'), uml('u', 'TX002', 'Clasificación de lógica')]);
  assert.equal(get(page, 'u').architecturalType, 'SERVICIO');
});

test('0.8.3: el contenedor que contiene un evento de integración es una Capa de Tópicos; con solo un candidato a evento es candidata; el nombre no la certifica', () => {
  const ev = uml('e1', 'Card Created_v1.0.0', 'Empresarial - Event'), tpl = uml('e2', 'Nombre Evento', '');
  const page = run(inIntegration(box('T1', 'p.card.createdv1\n', ['e1']), ev, box('T2', 'p.card.failv1 s.card.failv1', ['e2']), tpl, box('T3', 'p.sin.eventov1', [])));
  assert.equal(get(page, 'e1').architecturalType, 'EVENTO_INTEGRACION');
  assert.equal(get(page, 'T1').architecturalType, 'CAPA_TOPICOS');
  assert.equal(get(page, 'T1').inference.rule, 'TOPIC_LAYER_BY_CONTAINED_INTEGRATION_EVENT');
  assert.equal(get(page, 'T2').architecturalType, null);
  assert.deepEqual(get(page, 'T2').possibleTypes, ['CAPA_TOPICOS']);
  assert.equal(get(page, 'T3').architecturalType, null);
  assert.equal(get(page, 'T3').possibleTypes, undefined);
  assert.deepEqual(page.inventory.capasTopicos, [{ id: 'T1', name: 'p.card.createdv1\n', topicos: ['p.card.createdv1'], eventoIds: ['e1'], padreId: 'I' }]);
  assert.equal(page.inventory.eventosIntegracion[0].ubicacion.capaTopicosId, 'T1');
  assert.equal(page.inventory.eventosIntegracion[0].ubicacion.nivel, 'PADRE');
});

test('0.8.3: la exposición se pregunta siempre que falte y los escenarios sin preguntas continúan sin confirmación', async () => {
  const { readFile } = await import('node:fs/promises');
  const proc = await readFile('skills/validar-blueprint-integracion/references/00-procedimiento.md', 'utf8'), skill = await readFile('skills/validar-blueprint-integracion/SKILL.md', 'utf8');
  assert.match(proc, /Si no viene ninguno, preguntar, aunque la API ya se haya declarado no MCI/);
  assert.match(proc, /`privada` es `private`; `pública` o `publica` es `public`; `partner` no se homologa/);
  assert.match(proc, /API-003 se evalúa siempre con el texto del JSON/);
  assert.match(proc, /no se pide confirmación ni se espera respuesta/);
  assert.match(skill, /no esperar confirmación: continuar con las reglas y entregar el resultado/);
});

test('0.8.3: API-004 es Cumple con la asociación directa aunque haya parejas sin propietario; EXT-001 trata la actividad sin tipo como no determinada', async () => {
  const { readFile } = await import('node:fs/promises');
  const api = await readFile('skills/validar-blueprint-integracion/references/02-reglas-api-servicios.md', 'utf8'), fichas = await readFile('skills/validar-blueprint-integracion/references/08-fichas.md', 'utf8');
  assert.match(api, /Si las tiene, la regla es \*\*Cumple\*\* aunque existan otras Capas, Flujos o parejas sin propietario/);
  assert.match(fichas, /con todas resueltas con la API principal, es Cumple/);
  assert.match(fichas, /contiene\.ACTIVIDAD_SIN_TIPO/);
  const act = { id: 'a1', class: 'BPMNActivity', textAreas: [{ label: 'Text', text: '"account" "type"' }] }, note = { id: 'n1', class: 'DefaultSquareBlock', textAreas: [{ label: 'Text', text: 'nota' }], customData: [{ key: 'x', value: 'y' }] };
  const grp = { id: 'g', class: 'BPMNGroup', textAreas: [{ label: 'Text', text: 'EVC Cuentas' }], contains: { shapes: ['a1', 'n1'], lines: [], groups: [] } };
  const page = run([box('I', 'INTEGRACIÓN', ['g']), grp, act, note]);
  const aux = page.inventory.contenedores.find(c => c.id === 'g');
  assert.deepEqual(aux.contiene.ACTIVIDAD_SIN_TIPO, ['a1']);
  assert.ok(!(aux.contiene.SIN_TIPO ?? []).includes('a1'));
});

test('0.8.3: el nombre del hijo sale de Text cuando FloatingTitle está vacío; un hijo sin ningún texto sigue sin nombre; los contenedores no traen operation', () => {
  const child = (id, floating, text) => ({ id, class: 'RectangleContainerBlock', textAreas: [{ label: 'FloatingTitle', text: floating }, { label: 'Text', text }], contains: { shapes: [], lines: [], groups: [] } });
  const a = child('c1', '', 'ms_key_management_spi'), b = child('c2', 'Titulo', 'otro'), c = child('c3', '', '');
  const page = run([box('I', 'INTEGRACIÓN', ['c1', 'c2', 'c3']), a, b, c]);
  assert.equal(get(page, 'c1').name, 'ms_key_management_spi');
  assert.equal(get(page, 'c2').name, 'Titulo');
  assert.equal(get(page, 'c3').name, '');
  for (const id of ['c1', 'c2', 'c3', 'I']) assert.equal(get(page, id).operation, null);
});

test('SRV-005 excluye al servicio principal de E3: Skill, fichas y procedimiento dicen lo mismo', async () => {
  const { readFile } = await import('node:fs/promises');
  const dir = 'skills/validar-blueprint-integracion/references/';
  const rule = (await readFile(`${dir}02-reglas-api-servicios.md`, 'utf8')).split(/^### SRV-005 -/m)[1];
  const fichas = await readFile(`${dir}08-fichas.md`, 'utf8'), proc = await readFile(`${dir}00-procedimiento.md`, 'utf8'), esc = await readFile(`${dir}05-reglas-escenarios.md`, 'utf8');
  assert.match(rule, /Excluye al servicio principal de E3 y al hijo principal/);
  assert.match(rule, /Un servicio invocado no puede conectarse con un evento/);
  assert.match(rule, /única conexión de servicio es la del servicio principal con el evento de Inicio es \*\*No aplica\*\*/);
  assert.match(fichas, /solo si el servicio es invocado \(su id no es `scenario\.mainComponentId`\)/);
  assert.match(fichas, /ninguna del servicio principal de E3/);
  assert.match(proc, /El servicio principal de E3 queda fuera de SRV-005/);
  assert.match(esc, /SRV-005 no la evalúa/);
  assert.doesNotMatch(rule, /Un servicio no puede conectarse con un evento/);
});
