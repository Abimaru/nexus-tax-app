---
name: validar-blueprint-integracion
description: Valida blueprints de integración en JSON, identifica E1/E2/E3 y evalúa el catálogo v11.1 de 41 reglas con estados, evidencia, métricas y recomendaciones. Usar cuando el usuario solicite validar, revisar, analizar o clasificar un blueprint.
---
# Validador de blueprints de integración v11.1.2

1. Leer una vez `references/MANIFEST.md`, `references/00-procedimiento.md` y los siete catálogos normativos.
2. Confirmar que el inventario contiene exactamente 41 IDs únicos.
3. Analizar primero la evidencia original; usar `rootContainers`, `groupStructure`, `deploymentPairs`, `architecturalRoleCandidates` y `structuralScenario` solo como índices derivados que deben contrastarse con figuras, grupos, cadenas y extremos originales.
4. Formular un único bloque de preguntas indispensables y continuar tras la respuesta.
5. Determinar E1/E2/E3 por el dominio arquitectónico raíz verificable del hijo y por los extremos declarados, sin pedir al usuario que elija escenario.
6. Evaluar siempre las 41 reglas; usar No aplica para poblaciones ajenas.
7. No inferir asociaciones, propietarios, conexiones, nombres o MCI.
8. Entregar escenario, evidencia estructural, CSV de 41 filas, conteos, métricas, detalle por estado y recomendaciones.
9. Verificar que CSV, métricas, resumen y detalle coincidan y que la suma de estados sea 41.

El padre estructural inmediato, la raíz estructural y el dominio arquitectónico efectivo son hechos distintos. Leer `references/05-reglas-escenarios.md` antes de clasificar: Flujo Transaccional o Capa de Arquitectura pueden ser ancestros intermedios válidos. La fuente `CORPORATE_PARENT_DOMAIN_CONVENTION` permite inferir como productor un contenedor padre arquitectónico personalizado válido; documentarla siempre que `inferenceUsed:true`. No aplicarla a variantes de nombres reservados, envolventes conflictivos, NOTACIÓN ni auxiliares. No sustituir la conexión exigida al evento de Inicio por la mera existencia de cualquier `BPMNEvent`.

Los estados `CONFIRMADO`, `HIPOTESIS` y `NO_DETERMINADO` expresan certeza estructural, nunca cumplimiento. Incluso `CONFIRMADO` nunca equivale a `Cumple`; `normativeEvaluation:null` mantiene pendiente la evaluación de las 41 reglas. `HIPOTESIS` es el estado esperado cuando el patrón es único pero el BPMNEvent no acredita explícitamente el subtipo Inicio. Distinguir `GROUP_MEMBERSHIP`, `DIRECT_CONTAINMENT`, `ANCESTOR_CONTAINMENT` y `DEPLOYMENT_ASSOCIATION`: un grupo superior puede sustentar asociación Flujo/Capa, pero no contención ni cumplimiento MCI. Las páginas `BDD_OR_REQUIREMENTS` y `TEMPLATE_OR_LEGEND` no son operaciones. En páginas `MIXED`, ignorar instancias de leyenda y validar solo participantes operativos demostrables.

Leer `metadata.blueprintId`, `blueprintName`, `selectedPageIds` y `omittedPages`. Mantener separados `pageName`, `mainComponentOperation` y `mainChildServiceName`. Un productor personalizado solo se acepta cuando `domainResolution.status` demuestra productor único mediante hijo, evento, ruta y pertenencia; no por el nombre personalizado aislado.

Existe una contradicción normativa pendiente entre E1-001/E3-001/CNT-002 y CNT-004 sobre pertenencia del hijo al dominio productor. Hasta aprobación de la propuesta en `docs/audits/NORMATIVE_CORRECTION_PROPOSAL_v11.1.md`, no inventar una resolución: marcar las reglas afectadas No verificable y explicar el conflicto.
