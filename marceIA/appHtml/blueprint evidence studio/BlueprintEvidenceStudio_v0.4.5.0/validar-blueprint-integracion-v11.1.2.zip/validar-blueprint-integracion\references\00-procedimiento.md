# Procedimiento de validación - v11.1.2

## Precedencia de evidencia

1. Componentes, textos, jerarquía y conexiones originales.
2. Asociaciones explícitas y cobertura.
3. `rootContainers`, `groupStructure`, `deploymentPairs`, `architecturalRoleCandidates` y `structuralScenario` como índices derivados sujetos a contraste con la evidencia original.

No usar un diagnóstico derivado para contradecir evidencia cruda coherente. `CONFIRMADO` no equivale a Cumple y `normativeEvaluation:null` exige efectuar la evaluación normativa. `HIPOTESIS` permite identificar E1/E2/E3 sin afirmar que el BPMNEvent sea Inicio.

## Estados

- Cumple: evidencia suficiente y coherente.
- No cumple: evidencia completa demuestra infracción.
- No verificable: evidencia ausente, parcial, ambigua o contradictoria.
- No aplica: fuera de población.

## Flujo

1. Cargar JSON y verificar cobertura. Clasificar cada página como OPERATIONAL, TEMPLATE_OR_LEGEND, MIXED o UNRESOLVED; conservar todo, excluir plantillas puras del escenario y, en MIXED, excluir únicamente instancias de leyenda demostrables.
2. Inventariar componentes por nombre funcional; usar IDs solo para desambiguar.
3. Reconstruir por separado padre inmediato, cadena completa de ancestros y dominio arquitectónico raíz del hijo. Resolver E1/E2/E3 por componente principal, hijo, dominio raíz y extremos declarados. No usar MCI para elegir escenario.
4. Formular un único bloque de preguntas solo para datos declarativos indispensables como MCI/tipo cuando cambien aplicabilidad. No preguntar nombres, conexiones o asociaciones gráficas.
5. Evaluar exactamente 41 reglas, una fila por ID.
6. Aplicar independencia: una relación se evalúa una sola vez en su familia propietaria.
7. Entregar CSV completo, métricas, detalle y recomendaciones.

## Escenarios

- E1: API principal en INTEGRACIÓN y servicio hijo principal no gestionado bajo el dominio productor; API conectada al evento de Inicio mediante extremos declarados cuando el estándar lo exige.
- E2: API principal y servicio hijo principal gestionados bajo INTEGRACIÓN; API conectada al evento de Inicio mediante extremos declarados cuando el estándar lo exige.
- E3: componente del servicio principal y servicio hijo no gestionados bajo el dominio productor; conexión directa del servicio al evento de Inicio cuando corresponda a las exigencias del estándar.

El padre inmediato puede ser un Flujo Transaccional, una Capa de Arquitectura o un dominio. Las capas intermedias no vuelven automáticamente No verificable el escenario si la cadena completa hasta el dominio arquitectónico raíz está certificada. Un padre arquitectónico personalizado válido puede clasificarse PRODUCER por `CORPORATE_PARENT_DOMAIN_CONVENTION`; si `inferenceUsed:true`, citar esa convención y contrastar nombre, clase, contenido, ancestros y conflictos. Variantes de nombres reservados y envolventes con dominios anidados quedan sin resolver. La mera existencia de un `BPMNEvent` no acredita el subtipo Inicio ni la conexión exigida: verificar extremos y evidencia semántica del evento.

La identificación estructural del escenario es independiente de las reglas MCI, Capa/Flujo, conexiones, contenedores y componentes; evaluar cada familia con su propia evidencia.

## Conexiones

- CircleOpen y Generalization: CircleOpen es origen y Generalization destino.
- Escenario: None en API/servicio y Arrow en BPMNEvent.
- Comando-API: COM-002.
- Comando-servicio: COM-003.
- Comando-gestor: COM-004.
- Gestor-servicio: MQ-005.
- Evento-BPMNEvent: EVT-008.

## Modelos

API y servicio principales requieren entrada y salida. Invocados sin evidencia suficiente quedan No verificable, no No cumple. Los modelos internos del hijo son válidos sin propietario individual y no acreditan automáticamente modelos de componentes.

## Métricas

- Cumplimiento = Cumple / (Cumple + No cumple).
- Cobertura = (Cumple + No cumple) / (Cumple + No cumple + No verificable).
- No aplica no entra en denominadores.
