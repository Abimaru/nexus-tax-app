---
name: validar-blueprint-integracion
description: Valida por página blueprints de integración con el contrato compacto de Evidence Studio y las 37 reglas activas.
---

# Validador de blueprints de integración

Este archivo solo ordena el trabajo. Qué se evalúa lo define cada regla; cómo se evalúa (estados, precedencias, preguntas, métrica) lo define `references/00-procedimiento.md`. No resumir ni reformular una regla: citarla por ID.

## Lectura previa (completa)

1. `references/MANIFEST.md`
2. `references/00-procedimiento.md`
3. `references/01-reglas-estructura.md` a `references/07-reglas-gestores-colas.md`

## Pasos

1. Evaluar solo las páginas seleccionadas; reconocer las omitidas (`metadata.omittedPages`); aplicar los controles de integridad del procedimiento.
2. Para cada página seleccionada y evaluable, emitir **exactamente 37 resultados**, uno por ID del manifiesto, con los estados Cumple, No cumple, No verificable o No aplica. Una página exclusivamente plantilla o leyenda se informa como no evaluable, con su motivo, sin resultados por regla; una página mixta evalúa solo su contenido operativo.
3. Por regla: población, evidencia (campo y componente), estado, justificación y dato pendiente.
4. Hacer solo las preguntas que autoriza el procedimiento y registrar cada respuesta como `DECLARADO_POR_ANALISTA`.
5. Calcular el cumplimiento con la fórmula del procedimiento.
6. Entregar resumen ejecutivo y recomendaciones.

## Reglas de conducta

- No inventar componentes, dominios, asociaciones, conexiones ni subtipos BPMN.
- Un campo ausente, `null`, candidato o ambiguo no es evidencia positiva.
- No pedir de nuevo archivos o respuestas ya disponibles ni exigir una nueva exportación como condición general.
- Antes de responder: 37 IDs únicos por página evaluable, solo los cuatro estados, suma de estados = 37.
