# Procedimiento de validación - v11.2.4

### 1. Precedencia de evidencia

- Contrato de entrada: contrato compacto de Evidence Studio `copilot-factual-v0.4.6.1`.

- Priorizar la evidencia literal: `components[].textAreas`, `customData`, identificadores y `connections`.
- Tratar `structuralParent`, `containerChainIds`, `rootContainer` y `architecturalDomain` como propiedades diferentes.
- Utilizar `domainRole`, `possibleDomainRoles`, `inference`, `deploymentAssociations` y `scenario` considerando siempre su estado, fuente y conflictos.
- Un campo ausente, `null`, candidato, ambiguo o contradictorio no constituye evidencia positiva.
- No inferir `EXTERNAL_SYSTEM` por descarte.
- Una declaración de la analista no sustituye texto, contención, conexiones, asociaciones, tipo arquitectónico ni subtipo BPMN.

### 2. Controles previos de integridad

Antes de evaluar una página, comprobar que:

- los identificadores sean únicos;
- las referencias apunten a componentes existentes;
- la contención no tenga ciclos;
- el padre inmediato sea coherente con la cadena de ancestros;
- los participantes de las conexiones existan;
- los conflictos y pérdidas estén registrados en `issues`.

Las inconsistencias del JSON no son incumplimientos arquitectónicos. Las reglas afectadas se evalúan como **No verificable**.

### 3. Subtipos BPMN

La identificación genérica como `BPMNEvent` no certifica el subtipo.

- Inicio: E1-001, E2-001 y E3-001.
- Señal de Envío o Recepción: EVT-007.
- Mensaje: MQ-003.

Si el subtipo requerido no puede certificarse, únicamente las reglas que dependan de él quedan **No verificable**. No inferir el subtipo por texto, posición, cercanía o ubicación.

### 4. Capa de Despliegue

- Capa de Despliegue MCI: se demuestra mediante Capa de Arquitectura y Flujo Transaccional cuando la regla aplicable los exija.
- Capa de Despliegue Federada: se demuestra mediante el valor literal `Federado`.
- CA-001 valida únicamente el nombre de las Capas de Arquitectura existentes.
- FT-001 valida únicamente el nombre de los Flujos Transaccionales existentes.
- API-004, SRV-004 y MQ-002 validan la obligatoriedad y asociación de la Capa de Despliegue.
- La asociación no se demuestra por cercanía, alineación, superposición ni pertenencia al mismo contenedor.

### 5. Preguntas a la analista

Registrar cada respuesta como `DECLARADO_POR_ANALISTA`, asociada a la página y al componente correspondiente.

#### Obligatorias

Cuando los componentes estén identificados, preguntar:

- si la API principal tiene Capa de Despliegue MCI;
- si el hijo principal de E1 o E2, identificado mediante su nombre visible, tiene Capa de Despliegue MCI.

#### Opcional

Preguntar la exposición `private`, `public` o `partner` de la API principal únicamente cuando:

- no pueda obtenerse de la tercera sección;
- y sea necesaria para evaluar API-004.

Las respuestas:

- determinan aplicabilidad cuando la regla lo permite;
- no demuestran la existencia o asociación de Capa de Arquitectura o Flujo Transaccional;
- no corrigen API-003 ni otra regla textual;
- solo se reutilizan en otra página con confirmación explícita de la analista.

### 6. Precedencia de conexiones

#### Comandos

Toda conexión en la que participe un comando se evalúa exclusivamente en COM:

- comando con API: COM-002;
- comando con servicio: COM-003;
- comando con gestor de colas: COM-004;
- comando con sistema externo auxiliar sin atribución interna inequívoca: COM-005.

Las API y los servicios encapsulados conservan su tipo funcional: se evalúan en COM-002 o COM-003, respectivamente.

#### Gestores de colas

- comando con gestor: COM-004;
- gestor con gestor: MQ-003;
- servicio con gestor: MQ-003;
- evento BPMN de tipo Mensaje hacia gestor: MQ-003.

Cada conexión se asigna a una sola regla. Si no puede determinarse el participante o su tipo, la regla afectada queda **No verificable**.

### 7. Flujo por página

- Confirmar que la página está seleccionada y determinar si es evaluable (`pages[].pageClassification.kind`):
  - `OPERATIONAL`: evaluable; produce 37 resultados.
  - `MIXED`: evaluable; produce 37 resultados evaluando únicamente su contenido operativo y excluyendo las figuras de `legendShapeIds`.
  - `TEMPLATE_OR_LEGEND` o `BDD_OR_REQUIREMENTS`: no evaluable; informar página, tipo y motivo.
  - `UNRESOLVED`: no emitir dictamen; informar que la página no pudo clasificarse.
- Una página no evaluable no genera resultados por regla (ni 37 filas, ni "No aplica" artificiales), conteos ni porcentaje, y no entra en el consolidado del blueprint.
- Inventariar componentes, contenedores, conexiones y conflictos.
- No utilizar Entidad, Utilidad, Tarea, Private, Public o Partner como evidencia suficiente de tipo arquitectónico.
- Determinar, cuando sea posible, el patrón estructural E1, E2 o E3 sin confundirlo con el cumplimiento integral del escenario.
- Evaluar cada regla con su propia evidencia, aunque otra regla del escenario quede No verificable.
- Identificar el hijo principal directamente; no exigir una clasificación adicional como servicio principal.
- Las condiciones textuales de API-001, API-002 y API-003 (incluida su aplicación según el dominio de la API) son las que define cada una de esas reglas.
- Evaluar una vez cada ID activo del catálogo.
- Entregar por regla: población, evidencia, estado, justificación y dato pendiente.

### 8. Estados

- **Cumple:** toda la obligación aplicable está demostrada.
- **No cumple:** existe al menos un incumplimiento certificado.
- **No verificable:** falta evidencia para confirmar cumplimiento o demostrar incumplimiento.
- **No aplica:** la regla está fuera de población o se cumple una exclusión expresa de la propia regla.

Prioridad:

1. Si existe un incumplimiento certificado: **No cumple**.
2. Si no hay incumplimiento, pero queda una condición sin resolver: **No verificable**.
3. Si todas las condiciones aplicables están demostradas: **Cumple**.
4. Si no hay población ni candidatos, o existe una exclusión expresa: **No aplica**.

Una ausencia solo produce **No cumple** cuando la cobertura demuestra que el elemento obligatorio realmente no existe. Un candidato pendiente impide declarar **No aplica** si podría pertenecer a la población.

### 9. Escenarios independientes

- `CONFIRMADO`, `HIPOTESIS` y `NO_DETERMINADO` describen el escenario, no el cumplimiento.
- Un escenario no confirmado no convierte automáticamente las demás reglas en No verificable.
- CNT-001 y CNT-002 pueden resolverse aunque E1-001, E2-001 o E3-001 queden No verificable por falta de certificación del evento de Inicio.
- La incertidumbre sobre un dato afecta únicamente las reglas que dependen de él.
- `PROPOSED_CLOSED_CATALOG` no constituye por sí mismo un estándar corporativo.

### 10. Métricas

`Cumple / (Cumple + No cumple + No verificable) × 100`

- Excluir No aplica del denominador.
- Si el denominador es cero, informar no calculable.
- Consolidar sumando evaluaciones regla-página aplicables.
- No promediar porcentajes de páginas.
- El total debe coincidir con los IDs activos del catálogo vigente.