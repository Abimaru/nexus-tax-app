# Reglas Modelos Comandos - v11.2.4

### MOD-001 - Modelos de entrada y salida

**Resumen oficial:** Valida la existencia y asociación de los modelos de entrada y salida obligatorios para la API principal, el servicio principal modelado en E3 y los eventos de integración ubicados en INTEGRACIÓN.

**Aplica a:** API principal de los escenarios E1 y E2, componente principal del escenario E3 y eventos de integración ubicados en INTEGRACIÓN.

**Criterio:** La API principal de los escenarios E1 y E2 debe tener asociados un modelo de entrada y un modelo de salida. El componente principal del escenario E3 debe tener asociados un modelo de entrada y un modelo de salida.

Para los eventos de integración ubicados en INTEGRACIÓN, los modelos obligatorios dependen de los roles de sus tópicos: cuando el evento tenga tópicos de publicación (`p`) y suscripción (`s`), debe tener asociados un modelo de entrada y un modelo de salida; cuando tenga únicamente un tópico de publicación (`p`), debe tener asociado un modelo de entrada; y cuando tenga únicamente un tópico de suscripción (`s`), debe tener asociado un modelo de salida.

El contenedor hijo principal no tiene modelos obligatorios en esta regla. La presencia o ausencia de modelos dentro del hijo no afecta al cumplimiento de MOD-001 y su ubicación se evalúa mediante las reglas CNT. Las API y los servicios invocados tampoco tienen modelos obligatorios en esta regla.

Los modelos exigidos deben estar asociados inequívocamente al componente evaluado. La asociación no puede establecerse únicamente por cercanía, alineación, superposición o pertenencia al mismo contenedor.

**Evidencia mínima:** Identificación certificada del patrón estructural y del componente principal aplicable; clasificación certificada de los modelos como entrada o salida; y evidencia estructural suficiente para demostrar su asociación con la API principal o el componente principal de E3. Para los eventos de integración se requiere además su ubicación certificada en INTEGRACIÓN, la asociación con su Capa de Tópicos y la identificación de los roles `p` y `s`. La evidencia debe permitir demostrar tanto la presencia como la ausencia de los modelos obligatorios.

- **Cumple:** Todos los componentes sujetos a esta regla presentan los modelos obligatorios y sus asociaciones están certificadas: entrada y salida para la API principal de E1/E2; entrada y salida para el componente principal de E3; entrada y salida para eventos con tópicos `p` y `s`; entrada para eventos con un único tópico `p`; y salida para eventos con un único tópico `s`.

- **No cumple:** La población, la cobertura de los modelos y sus asociaciones están certificadas, y falta al menos un modelo obligatorio para alguno de los componentes evaluados. También corresponde este estado cuando existe un modelo requerido, pero está certificadamente asociado a un componente diferente.

- **No verificable:** No puede identificarse inequívocamente el componente principal aplicable; no puede determinarse el patrón estructural; no puede clasificarse un modelo como entrada o salida; existen modelos candidatos, pero no puede demostrarse que estén asociados al componente evaluado; la cobertura no permite demostrar la presencia o ausencia de un modelo obligatorio; o, para un evento, no puede certificarse su ubicación en INTEGRACIÓN o el rol de sus tópicos. Si existe al menos un incumplimiento certificado, prevalece **No cumple** aunque otra obligación sea no verificable.

- **No aplica:** La página no contiene una API principal de E1/E2, un componente principal de E3 ni eventos de integración ubicados en INTEGRACIÓN, y tampoco existen candidatos pendientes que puedan pertenecer a esta población. El hijo principal y los componentes invocados no hacen aplicable la regla por sí solos.

### COM-001 - Nombramiento de comandos

**Resumen oficial:** Valida el nombre de las actividades BPMN identificadas como comandos por su relación con una API, un servicio, un gestor de colas o un sistema externo auxiliar.

**Aplica a:** Figuras `BPMNActivity` que tengan una relación identificable con una API, un servicio, un gestor de colas o un sistema externo auxiliar.

**Criterio:** El nombre del comando debe estar escrito en español y comenzar con un verbo en infinitivo seguido de un complemento que identifique de manera clara, específica y coherente el objeto o propósito de la acción. El complemento es obligatorio; no se admiten nombres formados únicamente por un verbo, expresiones genéricas ni textos de plantilla. No se evalúa si la primera letra está escrita en mayúscula o minúscula.

Una `BPMNActivity` se considera candidata a comando únicamente cuando exista evidencia de una relación con una API, un servicio, un gestor de colas o un sistema externo auxiliar. No debe clasificarse como comando solo por su figura, texto, ubicación, cercanía o significado aparente. La misma actividad se evalúa una sola vez mediante esta regla, aunque esté relacionada con varios componentes. La validez de sus conexiones se evalúa mediante COM-002, COM-003, COM-004 o COM-005.

**Evidencia mínima:** Identificación certificada de la figura como `BPMNActivity`, texto completo de su nombre y evidencia suficiente de una relación con una API, un servicio, un gestor de colas o un sistema externo auxiliar. La relación debe permitir identificar la actividad como candidata a comando, aunque la corrección de la bidireccionalidad, el sentido o las terminaciones se evalúe en la regla de conexión correspondiente.

- **Cumple:** La actividad está identificada como candidata a comando y su nombre está escrito en español, comienza con un verbo en infinitivo y contiene un complemento claro, específico y coherente con la acción representada.

- **No cumple:** La actividad está identificada como candidata a comando y su nombre está ausente, corresponde a un texto de plantilla, es genérico, no comienza con un verbo en infinitivo, contiene únicamente el verbo sin complemento o presenta un complemento que no permite identificar de manera coherente la acción ejecutada. El uso de mayúscula o minúscula en la primera letra no afecta al resultado.

- **No verificable:** No puede certificarse que la figura sea una `BPMNActivity`; no puede identificarse una relación suficiente con una API, un servicio, un gestor de colas o un sistema externo auxiliar; el texto no está disponible o está incompleto por pérdida de evidencia; no puede determinarse razonablemente si la primera palabra corresponde a un verbo en infinitivo en español; o la información disponible no permite establecer la coherencia entre el verbo y su complemento. Si existe un incumplimiento certificado, prevalece **No cumple** aunque otra actividad sea no verificable.

- **No aplica:** La página no contiene actividades relacionadas con API, servicios, gestores de colas o sistemas externos auxiliares, ni relaciones pendientes que puedan identificar una `BPMNActivity` como candidata a comando.

### COM-002 - Conexión entre comando y API invocada

**Resumen oficial:** Valida la conexión bidireccional entre un comando y una API invocada, independientemente de que la API esté o no encapsulada dentro de un sistema externo auxiliar.

**Aplica a:** Relaciones identificables entre figuras `BPMNActivity` candidatas a comando y componentes certificados como API invocadas.

**Criterio:** Todo comando relacionado con una API invocada debe tener dos conexiones entre los mismos participantes: una dirigida desde el comando hacia la API y otra dirigida desde la API hacia el comando. En cada conexión, el participante que actúa como origen debe utilizar `CircleOpen` y el participante que actúa como destino debe utilizar `Generalization`.

La regla se aplica tanto a las API ubicadas directamente en un dominio como a las API encapsuladas dentro de un sistema externo auxiliar, siempre que el extremo conectado sea la API o una figura que la represente inequívocamente. Si la conexión termina únicamente en el sistema externo auxiliar y no puede atribuirse directamente a una API encapsulada, la relación se evalúa mediante COM-005.

El nombramiento del comando se evalúa mediante COM-001 y no afecta al resultado de esta regla.

**Evidencia mínima:** Identificación certificada de la `BPMNActivity` candidata a comando y de la API invocada, junto con las conexiones completas entre ambos participantes. La evidencia debe permitir comprobar el origen, el destino y las terminaciones de cada conexión. Si la API está encapsulada dentro de un sistema externo auxiliar, debe estar certificada su pertenencia a dicho auxiliar.

- **Cumple:** Existen las dos conexiones requeridas entre el comando y la API invocada: una desde el comando hacia la API y otra desde la API hacia el comando. En ambas conexiones, el origen utiliza `CircleOpen` y el destino utiliza `Generalization`, sin conexiones duplicadas para la misma pareja y el mismo sentido.

- **No cumple:** Los participantes y la cobertura de las conexiones están certificados, y falta uno de los dos sentidos; una conexión está orientada incorrectamente; el origen no utiliza `CircleOpen`; el destino no utiliza `Generalization`; existen conexiones duplicadas para la misma pareja y el mismo sentido; o la conexión termina en un componente certificado que no corresponde ni representa a la API invocada.

- **No verificable:** No puede certificarse la actividad candidata a comando o la API invocada; no puede demostrarse que ambos sentidos correspondan a la misma pareja de participantes; la dirección o las terminaciones son indeterminadas, ambiguas o contradictorias; no puede determinarse si el extremo conectado corresponde a la API o únicamente al sistema externo auxiliar; o la cobertura no permite confirmar la presencia o ausencia de alguna conexión. Si existe un incumplimiento certificado, prevalece **No cumple** aunque otra conexión sea no verificable.

- **No aplica:** La página no contiene API invocadas relacionadas con actividades candidatas a comando ni conexiones pendientes que puedan configurar esta relación.

### COM-003 - Conexión entre comando y servicio invocado

**Resumen oficial:** Valida la conexión bidireccional entre un comando y un servicio invocado, independientemente de que el servicio esté o no encapsulado dentro de un sistema externo auxiliar.

**Aplica a:** Relaciones identificables entre figuras `BPMNActivity` candidatas a comando y componentes certificados como servicios invocados.

**Criterio:** Todo comando relacionado con un servicio invocado debe tener dos conexiones entre los mismos participantes: una dirigida desde el comando hacia el servicio y otra dirigida desde el servicio hacia el comando. En cada conexión, el participante que actúa como origen debe utilizar `CircleOpen` y el participante que actúa como destino debe utilizar `Generalization`.

La regla se aplica tanto a los servicios ubicados directamente en un dominio como a los servicios encapsulados dentro de un sistema externo auxiliar, siempre que el extremo conectado sea el servicio o una figura que lo represente inequívocamente. Si la conexión termina únicamente en el sistema externo auxiliar y no puede atribuirse directamente a un servicio encapsulado, la relación se evalúa mediante COM-005.

El nombramiento del comando se evalúa mediante COM-001 y no afecta al resultado de esta regla.

**Evidencia mínima:** Identificación certificada de la `BPMNActivity` candidata a comando y del servicio invocado, junto con las conexiones completas entre ambos participantes. La evidencia debe permitir comprobar el origen, el destino y las terminaciones de cada conexión. Si el servicio está encapsulado dentro de un sistema externo auxiliar, debe estar certificada su pertenencia a dicho auxiliar.

- **Cumple:** Existen las dos conexiones requeridas entre el comando y el servicio invocado: una desde el comando hacia el servicio y otra desde el servicio hacia el comando. En ambas conexiones, el origen utiliza `CircleOpen` y el destino utiliza `Generalization`, sin conexiones duplicadas para la misma pareja y el mismo sentido.

- **No cumple:** Los participantes y la cobertura de las conexiones están certificados, y falta uno de los dos sentidos; una conexión está orientada incorrectamente; el origen no utiliza `CircleOpen`; el destino no utiliza `Generalization`; existen conexiones duplicadas para la misma pareja y el mismo sentido; o la conexión termina en un componente certificado que no corresponde ni representa al servicio invocado.

- **No verificable:** No puede certificarse la actividad candidata a comando o el servicio invocado; no puede demostrarse que ambos sentidos correspondan a la misma pareja de participantes; la dirección o las terminaciones son indeterminadas, ambiguas o contradictorias; no puede determinarse si el extremo conectado corresponde al servicio o únicamente al sistema externo auxiliar; o la cobertura no permite confirmar la presencia o ausencia de alguna conexión. Si existe un incumplimiento certificado, prevalece **No cumple** aunque otra conexión sea no verificable.

- **No aplica:** La página no contiene servicios invocados relacionados con actividades candidatas a comando ni conexiones pendientes que puedan configurar esta relación.

### COM-004 - Conexión entre comando y gestor de colas

**Resumen oficial:** Valida la conexión bidireccional entre un comando y un gestor de colas.

**Aplica a:** Relaciones identificables entre figuras `BPMNActivity` candidatas a comando y componentes certificados como gestores de colas.

**Criterio:** Todo comando relacionado con un gestor de colas debe tener dos conexiones entre los mismos participantes: una dirigida desde el comando hacia el gestor y otra dirigida desde el gestor hacia el comando. En cada conexión, el participante que actúa como origen debe utilizar `CircleOpen` y el participante que actúa como destino debe utilizar `Generalization`.

Esta relación se evalúa exclusivamente mediante COM-004 y no debe evaluarse nuevamente en las reglas MQ. El nombramiento del comando se evalúa mediante COM-001 y no afecta al resultado de esta regla.

**Evidencia mínima:** Identificación certificada de la `BPMNActivity` candidata a comando y del gestor de colas, junto con las conexiones completas entre ambos participantes. La evidencia debe permitir comprobar el origen, el destino y las terminaciones de cada conexión.

- **Cumple:** Existen las dos conexiones requeridas entre el comando y el gestor de colas: una desde el comando hacia el gestor y otra desde el gestor hacia el comando. En ambas conexiones, el origen utiliza `CircleOpen` y el destino utiliza `Generalization`, sin conexiones duplicadas para la misma pareja y el mismo sentido.

- **No cumple:** Los participantes y la cobertura de las conexiones están certificados, y falta uno de los dos sentidos; una conexión está orientada incorrectamente; el origen no utiliza `CircleOpen`; el destino no utiliza `Generalization`; existen conexiones duplicadas para la misma pareja y el mismo sentido; o la conexión termina en un componente certificado que no corresponde al gestor de colas.

- **No verificable:** No puede certificarse la actividad candidata a comando o el gestor de colas; no puede demostrarse que ambos sentidos correspondan a la misma pareja de participantes; la dirección o las terminaciones son indeterminadas, ambiguas o contradictorias; o la cobertura no permite confirmar la presencia o ausencia de alguna conexión. Si existe un incumplimiento certificado, prevalece **No cumple** aunque otra conexión sea no verificable.

- **No aplica:** La página no contiene gestores de colas relacionados con actividades candidatas a comando ni conexiones pendientes que puedan configurar esta relación.

### COM-005 - Conexión entre comando y sistema externo auxiliar

**Resumen oficial:** Valida la conexión bidireccional entre un comando y un sistema externo auxiliar cuando la relación no puede atribuirse directamente a un componente encapsulado.

**Aplica a:** Relaciones identificables entre figuras `BPMNActivity` candidatas a comando y sistemas externos auxiliares que actúan como extremo gráfico de la conexión.

**Criterio:** Cuando un comando se conecte directamente con un sistema externo auxiliar y la conexión no pueda atribuirse inequívocamente a una API o servicio encapsulado, deben existir dos conexiones entre los mismos participantes: una dirigida desde el comando hacia el auxiliar y otra dirigida desde el auxiliar hacia el comando. En cada conexión, el participante que actúa como origen debe utilizar `CircleOpen` y el participante que actúa como destino debe utilizar `Generalization`.

Si el extremo conectado es una API certificada contenida en el auxiliar, la relación se evalúa mediante COM-002. Si el extremo conectado es un servicio certificado contenido en el auxiliar, la relación se evalúa mediante COM-003. Una misma conexión no debe evaluarse en más de una regla COM.

**Evidencia mínima:** Identificación certificada de la `BPMNActivity` candidata a comando y del sistema externo auxiliar, junto con las conexiones completas entre ambos participantes. La evidencia debe permitir comprobar que el extremo gráfico es el auxiliar, que la relación no puede atribuirse inequívocamente a una API o servicio encapsulado y que los sentidos y terminaciones son verificables.

- **Cumple:** Existen las dos conexiones requeridas entre el comando y el sistema externo auxiliar: una desde el comando hacia el auxiliar y otra desde el auxiliar hacia el comando. En ambas conexiones, el origen utiliza `CircleOpen` y el destino utiliza `Generalization`, sin conexiones duplicadas para la misma pareja y el mismo sentido.

- **No cumple:** Los participantes y la cobertura de las conexiones están certificados, y falta uno de los dos sentidos; una conexión está orientada incorrectamente; el origen no utiliza `CircleOpen`; el destino no utiliza `Generalization`; existen conexiones duplicadas para la misma pareja y el mismo sentido; o la conexión termina en un componente certificado que no corresponde al auxiliar.

- **No verificable:** No puede certificarse la actividad candidata a comando o el sistema externo auxiliar; no puede determinarse si la conexión termina en el auxiliar o en un componente encapsulado; existen varios componentes internos y no puede atribuirse la conexión a uno de ellos; la dirección o las terminaciones son indeterminadas, ambiguas o contradictorias; o la cobertura no permite confirmar la presencia o ausencia de alguna conexión. Si existe un incumplimiento certificado, prevalece **No cumple** aunque otra conexión sea no verificable.

- **No aplica:** La página no contiene sistemas externos auxiliares relacionados directamente con actividades candidatas a comando ni conexiones pendientes que puedan configurar esta relación.

