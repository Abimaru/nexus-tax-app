# Reglas Estructura - v11.2.4

### CNT-001 - Contenedores padre requeridos

**Resumen oficial:** Valida la existencia de los dominios arquitectónicos obligatorios según el patrón estructural E1, E2 o E3 aplicable a la página.

**Aplica a:** Páginas evaluables en las que pueda determinarse un patrón estructural E1, E2 o E3, aunque el cumplimiento integral del escenario no esté confirmado.

**Criterio:** En E1 deben existir al menos un dominio de INTEGRACIÓN y un DOMINIO PRODUCTOR; en E2 debe existir al menos un dominio de INTEGRACIÓN; y en E3 debe existir al menos un DOMINIO PRODUCTOR. Puede existir más de un dominio del mismo tipo. Los dominios opcionales y su ausencia no afectan al cumplimiento. La regla evalúa exclusivamente la existencia y clasificación de los dominios obligatorios, independientemente de que tengan un nombre literal, derivado o personalizado; no evalúa su contenido, las relaciones de contención de sus componentes ni las demás condiciones necesarias para confirmar integralmente el escenario.

**Evidencia mínima:** Patrón estructural E1, E2 o E3 determinado e inventario completo de contenedores padre. Los dominios obligatorios deben tener una clasificación arquitectónica certificada. Los nombres personalizados son válidos siempre que exista evidencia suficiente para clasificar el dominio como INTEGRACIÓN o DOMINIO PRODUCTOR, según corresponda.

- **Cumple:** Puede determinarse el patrón estructural aplicable y existen todos los dominios arquitectónicos obligatorios para dicho patrón, con clasificación certificada.
- **No cumple:** Puede determinarse el patrón estructural aplicable, la cobertura del inventario es completa y se demuestra la ausencia de al menos uno de los dominios arquitectónicos obligatorios.
- **No verificable:** No existe evidencia suficiente para determinar el patrón estructural aplicable; el inventario de contenedores no tiene cobertura suficiente; o existe una clasificación indeterminada, ambigua o contradictoria que impide confirmar la existencia de un dominio obligatorio. La falta de certificación de otras condiciones del escenario, como el subtipo Inicio de un evento BPMN, no afecta por sí sola la evaluación de esta regla.
- **No aplica:** La página no es evaluable porque corresponde exclusivamente a una plantilla o leyenda, o no contiene una estructura susceptible de corresponder a E1, E2 o E3.

### CNT-002 - Existencia, nombre y ubicación del contenedor hijo principal

**Resumen oficial:** Valida que exista un único contenedor hijo principal, que tenga un nombre específico y que esté ubicado en el dominio arquitectónico correspondiente al patrón estructural aplicable.

**Aplica a:** Páginas evaluables con una estructura susceptible de corresponder a E1, E2 o E3, aunque el cumplimiento integral del escenario no esté confirmado.

**Criterio:** Debe existir un único contenedor hijo principal por página. El hijo debe tener un nombre visible, funcional y específico que permita identificar el servicio que representa; no se admiten nombres ausentes, vacíos, genéricos ni textos de plantilla. No se exige un formato, idioma, versión, capitalización ni estructura de palabras particular.

En E1 y E3, el hijo principal debe estar ubicado en el DOMINIO PRODUCTOR; en E2, debe estar ubicado en INTEGRACIÓN. La regla no evalúa los componentes contenidos en el hijo, su condición de gestionado o no gestionado, los eventos BPMN de su interior, sus modelos internos ni las demás condiciones necesarias para confirmar integralmente el escenario.

**Evidencia mínima:** Patrón estructural E1, E2 o E3 identificable, inventario completo de contenedores, identificación certificada de un único contenedor hijo principal, texto completo de su nombre y clasificación certificada del dominio arquitectónico en el que está ubicado. No se requiere identificar ni certificar un evento BPMN de Inicio para evaluar esta regla.

- **Cumple:** Puede determinarse el patrón estructural aplicable, existe un único contenedor certificado como hijo principal, tiene un nombre visible, funcional, específico y diferente de un texto de plantilla, y está ubicado en el dominio arquitectónico exigido por dicho patrón.

- **No cumple:** El patrón estructural aplicable y la cobertura del inventario están certificados, y se demuestra al menos una de las siguientes situaciones: no existe un contenedor hijo principal; existe más de uno; el único hijo principal está ubicado en un dominio arquitectónico diferente del exigido; o su nombre está ausente, vacío, compuesto únicamente por espacios, es genérico o corresponde a un texto de plantilla.

- **No verificable:** No existe evidencia suficiente para determinar el patrón estructural aplicable; el inventario no tiene cobertura suficiente; no puede certificarse cuál es el hijo principal; existen varios candidatos sin que pueda determinarse cuál cumple ese rol; el texto de su nombre no está disponible o está incompleto por pérdida de evidencia; no puede determinarse razonablemente si el nombre es específico o de plantilla; o la ubicación o clasificación de su dominio arquitectónico es indeterminada, ambigua o contradictoria. La falta de certificación del subtipo Inicio de un evento BPMN no afecta la evaluación de esta regla. Si existe al menos un incumplimiento certificado, prevalece **No cumple** aunque otra condición sea no verificable.

- **No aplica:** La página no es evaluable porque corresponde exclusivamente a una plantilla o leyenda, o no contiene componentes ni candidatos pendientes que puedan configurar un hijo principal de E1, E2 o E3.

### CNT-003 - Contenido permitido en INTEGRACIÓN

**Resumen oficial:** Valida que los componentes ubicados en INTEGRACIÓN correspondan al contenido permitido para el nivel padre y, cuando exista un hijo principal dentro de este dominio, para el nivel hijo.

**Aplica a:** Dominios clasificados como INTEGRACIÓN y sus componentes contenidos, exista o no un contenedor hijo principal.

**Criterio:** En el nivel padre de INTEGRACIÓN se permiten API, eventos de integración de tipo Aplicación o Empresarial, servicios, modelos de entrada, modelos de salida, conceptos, pendientes, gestores de colas, sistemas externos auxiliares, anotaciones y capas de despliegue MCI o Federado. No se permiten compuertas, eventos BPMN operativos, políticas ni comandos. Cuando INTEGRACIÓN contenga un hijo principal, dentro de este se permiten compuertas, eventos BPMN operativos, modelos de entrada, modelos de salida, conceptos, pendientes, políticas, comandos y anotaciones; no se permiten API, eventos de integración de tipo Aplicación o Empresarial, servicios, gestores de colas, sistemas externos auxiliares ni capas de despliegue MCI o Federado. Los componentes encapsulados dentro de un sistema externo auxiliar se excluyen de esta regla y se evalúan mediante EXT-001.

**Evidencia mínima:** Identificación certificada del dominio de INTEGRACIÓN, inventario completo de sus componentes, identificación del hijo principal cuando exista, jerarquía estructural suficiente para establecer si cada componente está en el nivel padre, dentro del hijo principal o encapsulado dentro de un sistema externo auxiliar, y clasificación certificada de los componentes evaluados. Para los eventos BPMN operativos no se requiere determinar si corresponden específicamente a Inicio, Fin, Señal, Mensaje, Excepción, Mensaje de Excepción u otro subtipo cuando dicha información no esté disponible.

- **Cumple:** La clasificación de INTEGRACIÓN y la cobertura de su contenido están certificadas, y todos los componentes evaluados están permitidos en el nivel en el que se encuentran: nivel padre o nivel hijo. Los componentes encapsulados dentro de sistemas externos auxiliares no se consideran para este resultado.

- **No cumple:** La clasificación de INTEGRACIÓN y la cobertura de su contenido están certificadas, y existe al menos un componente con clasificación certificada ubicado en un nivel en el que no está permitido. El contenido interno de un sistema externo auxiliar no genera incumplimiento en esta regla.

- **No verificable:** Existe uno o más contenedores que podrían corresponder a INTEGRACIÓN, pero su clasificación es indeterminada, ambigua o contradictoria; el contenido del dominio no tiene cobertura suficiente; no puede determinarse si un componente está en el nivel padre, dentro del hijo principal o dentro de un sistema externo auxiliar; o la clasificación de algún componente es indeterminada, ambigua o contradictoria y sus posibles clasificaciones incluyen categorías permitidas y no permitidas para su ubicación. La imposibilidad de determinar el subtipo específico de un evento BPMN operativo no genera por sí sola este estado cuando puede certificarse que no corresponde a un evento de integración.

- **No aplica:** Se ha certificado que la página no contiene un dominio de INTEGRACIÓN ni contenedores pendientes de clasificación que puedan corresponder a este dominio.

### CNT-004 - Contenido permitido en DOMINIO PRODUCTOR

**Resumen oficial:** Valida que los componentes ubicados en el DOMINIO PRODUCTOR correspondan al contenido permitido para el nivel padre y, cuando exista un hijo principal dentro de este dominio, para el nivel hijo.

**Aplica a:** Dominios clasificados como DOMINIO PRODUCTOR y sus componentes contenidos, exista o no un contenedor hijo principal.

**Criterio:** En el nivel padre del DOMINIO PRODUCTOR se permiten eventos de integración de tipo Aplicación o Empresarial, servicios, modelos de entrada, modelos de salida, conceptos, pendientes, gestores de colas, anotaciones y capas de despliegue MCI o Federado. No se permiten API, sistemas externos auxiliares, compuertas, eventos BPMN operativos, políticas ni comandos. Cuando el DOMINIO PRODUCTOR contenga un hijo principal, dentro de este se permiten compuertas, eventos BPMN operativos, modelos de entrada, modelos de salida, conceptos, pendientes, políticas, comandos y anotaciones; no se permiten API, eventos de integración de tipo Aplicación o Empresarial, servicios, gestores de colas, sistemas externos auxiliares ni capas de despliegue MCI o Federado. La regla evalúa la ubicación de los componentes según el nivel en el que se encuentran, sin exigir la identificación del subtipo específico de los eventos BPMN operativos cuando la evidencia disponible no permita determinarlo.

**Evidencia mínima:** Identificación certificada del DOMINIO PRODUCTOR, inventario completo de sus componentes, identificación del hijo principal cuando exista, jerarquía estructural suficiente para establecer si cada componente está fuera o dentro del hijo y clasificación certificada de los componentes evaluados. Para los eventos BPMN operativos no se requiere determinar si corresponden específicamente a Inicio, Fin, Señal, Mensaje, Excepción, Mensaje de Excepción u otro subtipo cuando dicha información no esté disponible.

- **Cumple:** La clasificación del DOMINIO PRODUCTOR y la cobertura de su contenido están certificadas, y todos sus componentes están permitidos en el nivel en el que se encuentran: nivel padre o nivel hijo.

- **No cumple:** La clasificación del DOMINIO PRODUCTOR y la cobertura de su contenido están certificadas, y existe al menos un componente con clasificación certificada ubicado en un nivel en el que no está permitido.

- **No verificable:** Existe uno o más contenedores que podrían corresponder al DOMINIO PRODUCTOR, pero su clasificación es indeterminada, ambigua o contradictoria; el contenido del dominio no tiene cobertura suficiente; no puede determinarse si un componente está fuera o dentro del hijo principal; o la clasificación de algún componente es indeterminada, ambigua o contradictoria y sus posibles clasificaciones incluyen categorías permitidas y prohibidas para el nivel en el que se encuentra. La imposibilidad de determinar el subtipo específico de un evento BPMN operativo no genera por sí sola este estado cuando puede certificarse que no corresponde a un evento de integración.

- **No aplica:** Se ha certificado que la página no contiene un DOMINIO PRODUCTOR ni contenedores pendientes de clasificación que puedan corresponder a este dominio.

### CNT-005 - Contenido permitido en SISTEMAS EXTERNOS

**Resumen oficial:** Valida que los componentes ubicados directamente en SISTEMAS EXTERNOS correspondan al contenido permitido para este dominio.

**Aplica a:** Dominios clasificados como SISTEMAS EXTERNOS y a los componentes contenidos directamente en ellos.

**Criterio:** En SISTEMAS EXTERNOS se permiten API, servicios, modelos de entrada, modelos de salida, pendientes, conceptos, sistemas externos auxiliares y anotaciones. No se permiten eventos de integración de tipo Aplicación o Empresarial, gestores de colas, capas de despliegue MCI o Federado, compuertas, eventos BPMN operativos, políticas ni comandos. Los componentes encapsulados dentro de un sistema externo auxiliar se excluyen de esta regla y se evalúan mediante EXT-001.

**Evidencia mínima:** Identificación certificada del dominio de SISTEMAS EXTERNOS, inventario completo de sus componentes, jerarquía estructural suficiente para diferenciar los componentes ubicados directamente en el dominio de aquellos encapsulados dentro de un sistema externo auxiliar, y clasificación certificada de los componentes evaluados. Para los eventos BPMN operativos no se requiere determinar si corresponden específicamente a Inicio, Fin, Señal, Mensaje, Excepción, Mensaje de Excepción u otro subtipo cuando dicha información no esté disponible.

- **Cumple:** La clasificación del dominio de SISTEMAS EXTERNOS y la cobertura de su contenido están certificadas, y todos los componentes evaluados corresponden a categorías permitidas. Los componentes encapsulados dentro de sistemas externos auxiliares no se consideran para este resultado.

- **No cumple:** La clasificación del dominio de SISTEMAS EXTERNOS y la cobertura de su contenido están certificadas, y existe al menos un componente con clasificación certificada ubicado directamente en el dominio que corresponde a una categoría no permitida. El contenido interno de un sistema externo auxiliar no genera incumplimiento en esta regla.

- **No verificable:** Existe uno o más contenedores que podrían corresponder a SISTEMAS EXTERNOS, pero su clasificación es indeterminada, ambigua o contradictoria; el contenido del dominio no tiene cobertura suficiente; no puede determinarse si un componente está ubicado directamente en el dominio o encapsulado dentro de un sistema externo auxiliar; o la clasificación de algún componente es indeterminada, ambigua o contradictoria y sus posibles clasificaciones incluyen categorías permitidas y no permitidas. La imposibilidad de determinar el subtipo específico de un evento BPMN operativo no genera por sí sola este estado cuando puede certificarse que no corresponde a un evento de integración.

- **No aplica:** Se ha certificado que la página no contiene un dominio de SISTEMAS EXTERNOS ni contenedores pendientes de clasificación que puedan corresponder a este dominio.

### EXT-001 - Identificación y contenido del sistema externo auxiliar

**Resumen oficial:** Valida que cada sistema externo auxiliar tenga un nombre y encapsule únicamente componentes permitidos.

**Aplica a:** Componentes certificados como sistemas externos auxiliares, independientemente del nombre visible utilizado para identificarlos.

**Criterio:** Todo sistema externo auxiliar debe tener un nombre visible y no vacío; se admite cualquier nombre, incluido “Sistema Externo”. Puede encapsular API, servicios, pendientes, conceptos y anotaciones. También puede encapsular capas de despliegue MCI o Federado, pero únicamente cuando el auxiliar esté ubicado en el nivel padre de INTEGRACIÓN. Cualquier otro tipo de componente está prohibido. Un componente identificado únicamente como BPMNEvent no debe considerarse automáticamente permitido ni prohibido, debido a que su función específica no puede determinarse a partir de la figura. La regla evalúa el nombre y el contenido encapsulado por el auxiliar, pero no las conexiones que llegan al auxiliar o a sus componentes internos.

**Evidencia mínima:** Identificación certificada del sistema externo auxiliar, texto completo de su nombre, inventario completo de los componentes encapsulados, clasificación certificada de dichos componentes y ubicación estructural certificada del auxiliar cuando contenga una capa de despliegue MCI o Federado.

- **Cumple:** El sistema externo auxiliar tiene un nombre visible y no vacío, encapsula al menos un componente y todos los componentes encapsulados están permitidos. Si contiene una capa de despliegue MCI o Federado, está certificado que el auxiliar se encuentra en el nivel padre de INTEGRACIÓN.

- **No cumple:** La evidencia y la cobertura están certificadas, y se presenta al menos una de las siguientes situaciones: el nombre del auxiliar está ausente, vacío o compuesto únicamente por espacios; contiene un componente certificado en una categoría no permitida; o contiene una capa de despliegue MCI o Federado sin estar ubicado en el nivel padre de INTEGRACIÓN.

- **No verificable:** No puede determinarse si el auxiliar tiene un nombre debido a evidencia textual incompleta; el auxiliar no encapsula componentes o no puede certificarse si encapsula alguno; el inventario de su contenido no tiene cobertura suficiente; no puede determinarse la clasificación de uno o más componentes encapsulados y sus posibles clasificaciones incluyen categorías permitidas y prohibidas; se identifica dentro del auxiliar un componente clasificado únicamente como BPMNEvent; o no puede determinarse la ubicación del auxiliar cuando contiene una capa de despliegue MCI o Federado. Requiere revisión manual del analista.

- **No aplica:** La página no contiene componentes certificados como sistemas externos auxiliares ni candidatos pendientes de clasificación como tales.

### EXT-002 - Ubicación de sistemas externos auxiliares EVC, EPC o LDC

**Resumen oficial:** Valida que un sistema externo auxiliar identificado como EVC, EPC o LDC y que encapsule una API esté ubicado en INTEGRACIÓN y no en SISTEMAS EXTERNOS.

**Aplica a:** Sistemas externos auxiliares cuyo nombre contenga EVC, EPC o LDC y que encapsulen al menos un componente certificado como API.

**Criterio:** Un sistema externo auxiliar cuyo nombre contenga EVC, EPC o LDC, sin distinguir mayúsculas y minúsculas, y que encapsule al menos una API debe estar ubicado en el nivel padre de INTEGRACIÓN. No puede estar ubicado directamente en SISTEMAS EXTERNOS ni dentro de otro sistema externo auxiliar. La regla evalúa exclusivamente la ubicación del auxiliar; el nombre y el contenido permitido dentro de este se evalúan mediante EXT-001, sus conexiones se evalúan mediante EXT-002 y el nombramiento de la API encapsulada se evalúa mediante API-001.

**Evidencia mínima:** Identificación certificada del sistema externo auxiliar, texto completo de su nombre, identificación certificada de al menos una API encapsulada y jerarquía estructural suficiente para determinar el dominio arquitectónico y el nivel en el que está ubicado el auxiliar.

- **Cumple:** El nombre del auxiliar contiene EVC, EPC o LDC, encapsula al menos una API certificada y está ubicado en el nivel padre de INTEGRACIÓN.

- **No cumple:** El nombre del auxiliar contiene EVC, EPC o LDC, encapsula al menos una API certificada y está ubicado directamente en SISTEMAS EXTERNOS, dentro de otro sistema externo auxiliar o en cualquier ubicación distinta del nivel padre de INTEGRACIÓN.

- **No verificable:** No puede determinarse el nombre completo del auxiliar; no puede establecerse si contiene EVC, EPC o LDC; no puede certificarse que el componente encapsulado sea una API; no puede certificarse que la API esté contenida por el auxiliar; o la ubicación o el dominio arquitectónico del auxiliar es indeterminado, ambiguo o contradictorio.

- **No aplica:** No existen sistemas externos auxiliares cuyo nombre contenga EVC, EPC o LDC y que encapsulen una API certificada. También aplica este estado cuando existen auxiliares con dichas expresiones, pero se certifica que no contienen API.

### GW-001 - Coherencia textual de los caminos de la compuerta

**Resumen oficial:** Valida la coherencia entre el texto de una compuerta BPMN y las respuestas o etiquetas de sus caminos conectados.

**Aplica a:** Componentes certificados como compuertas BPMN.

**Criterio:** Cuando una compuerta contiene una pregunta o texto de decisión, sus caminos deben incluir respuestas o etiquetas que permitan reconocer de forma coherente las alternativas resultantes. Una pregunta binaria puede utilizar respuestas como “Sí” y “No”; cuando existan más de dos alternativas, cada camino debe tener una etiqueta que permita distinguir la opción que representa. También es válido que una compuerta no tenga texto y que sus caminos no tengan respuestas o etiquetas, siempre que no exista información parcial que requiera relacionarlos. La regla no evalúa el subtipo de la compuerta ni las condiciones BPMN específicas de compuertas paralelas, exclusivas, basadas en eventos o paralelas basadas en eventos.

**Evidencia mínima:** Identificación certificada de la compuerta BPMN, texto completo de la compuerta cuando exista, inventario completo de sus caminos conectados y texto de las respuestas o etiquetas asociadas a dichos caminos. No se requiere identificar el subtipo de la compuerta.

- **Cumple:** La compuerta y sus caminos tienen cobertura suficiente, y se presenta alguna de las siguientes situaciones: la compuerta contiene una pregunta o decisión y sus caminos tienen respuestas o etiquetas coherentes que permiten distinguir las alternativas; o la compuerta no contiene texto y sus caminos tampoco contienen respuestas o etiquetas que requieran interpretación.

- **No cumple:** La evidencia textual y la cobertura de los caminos están certificadas, y las respuestas o etiquetas contradicen el texto de la compuerta, no corresponden a la pregunta planteada o no permiten distinguir los caminos cuando existen varias alternativas que requieren identificación.

- **No verificable:** No puede determinarse el texto completo de la compuerta o de sus caminos; no se tiene cobertura suficiente de las conexiones; la compuerta contiene una pregunta o decisión, pero faltan las respuestas o etiquetas necesarias para interpretar sus alternativas; los caminos contienen respuestas o etiquetas, pero falta el texto que permita establecer su significado; o la información disponible no permite concluir si el conjunto es coherente. La imposibilidad de identificar el subtipo de la compuerta no genera por sí sola este estado.

- **No aplica:** La página no contiene componentes certificados como compuertas BPMN ni candidatos pendientes de clasificación como tales.

