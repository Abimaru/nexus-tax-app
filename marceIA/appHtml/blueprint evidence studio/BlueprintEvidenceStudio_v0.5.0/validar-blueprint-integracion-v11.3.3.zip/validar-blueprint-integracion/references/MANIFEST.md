### MANIFEST - validar-blueprint-integracion

Versión v11.3.3. Catálogo vigente: **37 reglas activas y únicas**, incluidas SRV-001 y SRV-002 con su texto definitivo. Contrato soportado: `copilot-factual-v0.4.6.1`.

### Inventario oficial

- CNT (5): CNT-001, CNT-002, CNT-003, CNT-004, CNT-005
- EXT (2): EXT-001, EXT-002
- GW (1): GW-001
- API (4): API-001, API-002, API-003, API-004
- SRV (4): SRV-001, SRV-002, SRV-003, SRV-004
- EVT (7): EVT-001, EVT-002, EVT-003, EVT-004, EVT-005, EVT-006, EVT-007
- CA (1): CA-001
- FT (1): FT-001
- E1 (1): E1-001
- E2 (1): E2-001
- E3 (1): E3-001
- MOD (1): MOD-001
- COM (5): COM-001, COM-002, COM-003, COM-004, COM-005
- MQ (3): MQ-001, MQ-002, MQ-003

### Recursos obligatorios

- `00-procedimiento.md`
- `01-reglas-estructura.md`
- `02-reglas-api-servicios.md`
- `03-reglas-eventos.md`
- `04-reglas-despliegue.md`
- `05-reglas-escenarios.md`
- `06-reglas-modelos-comandos.md`
- `07-reglas-gestores-colas.md`

### Lenguaje normativo

- Capa de Despliegue es el concepto general.
- MCI se demuestra con los elementos exigidos por la regla aplicable.
- Federada se demuestra con el valor literal `Federado` (figura `architecturalType: FEDERADO` asociada mediante `modality: FEDERADO`).
- Capa de Arquitectura y Flujo Transaccional son figuras específicas y no deben utilizarse como sinónimos de Capa de Despliegue.
- El hijo principal representa el servicio principal del escenario; no requiere una clasificación adicional redundante.

### Respuestas humanas autorizadas

Por página evaluable:

- Preguntar obligatoriamente si la API principal certificada tiene Capa de Despliegue MCI.
- Preguntar obligatoriamente si el hijo principal certificado de E1 o E2 tiene Capa de Despliegue MCI.
- No preguntar por la condición MCI del componente o servicio principal de E3.
- Preguntar la exposición de la API principal solo si falta y es necesaria para API-004.
- Formular todas las preguntas aplicables en un único bloque.
- No duplicar la pregunta cuando hijo principal y servicio principal son el mismo componente.
- Registrar respuestas como `DECLARADO_POR_ANALISTA`, vinculadas a página e ID.

Las respuestas determinan aplicabilidad cuando la regla lo permite, pero no sustituyen texto, tipo, rol, contención, dominio, conexiones, asociaciones ni subtipo BPMN.

### Controles del catálogo

- Exactamente 37 IDs activos y únicos.
- Cada página evaluable produce exactamente 37 resultados, uno por ID. Una página no evaluable se informa con su motivo y sin resultados; una página mixta evalúa solo su contenido operativo.
- Un resultado por ID y página evaluable.
- Estados permitidos: Cumple, No cumple, No verificable y No aplica.
- No deben reaparecer IDs retirados ni significados históricos asociados a IDs renumerados.
- Los archivos normativos y la salida del agente deben coincidir con este inventario.
- Las páginas no evaluables no generan filas ni porcentaje.
- Los conteos por familia deben sumar 37.

### Verificación final

Antes de publicar una nueva versión: verificar que todos los archivos usen los mismos 37 IDs, estados válidos, referencias cruzadas existentes y conteos por familia que sumen 37. `SKILL.md`, el procedimiento y los archivos de reglas deben usar la misma numeración.
