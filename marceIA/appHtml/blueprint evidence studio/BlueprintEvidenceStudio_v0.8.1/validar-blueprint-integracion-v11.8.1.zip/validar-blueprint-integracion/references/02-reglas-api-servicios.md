# Reglas API y Servicios - v11.8.1

### API-001 - Nombramiento y versión de API

**Resumen oficial:** Valida el nombre y la versión de la primera sección de una API según el dominio arquitectónico en el que se encuentre.

**Aplica a:** Todas las API principales e invocadas con tipo arquitectónico certificado. Cada API de ambos roles se incluye individualmente en la población.

**Criterio:** Para una API ubicada en INTEGRACIÓN, directamente o dentro de un sistema externo auxiliar, la primera sección debe seguir el formato `Nombre Producto - Nombre API vMayor.Menor.Parche`. No debe contener espacios antes de la primera letra. El producto y la API deben tener nombres reales, funcionales, específicos, no genéricos, diferentes de textos de plantilla y escritos en inglés. Cada palabra significativa debe iniciar en mayúscula; los artículos, preposiciones y conjunciones pueden permanecer en minúscula cuando la nomenclatura inglesa lo permita. Debe existir un único guion estructural entre el nombre del producto y el nombre de la API, sin evaluar la cantidad de espacios a su alrededor. La versión debe iniciar con `v` o `V` y contener exactamente tres segmentos numéricos: Mayor mayor o igual que 1, Menor mayor o igual que 0 y Parche mayor o igual que 0.

Para una API ubicada en SISTEMAS EXTERNOS, directamente o dentro de un sistema externo auxiliar, solo se exige que la primera sección contenga un nombre real, funcional, específico, no genérico y diferente de un texto de plantilla. No se evalúan el formato corporativo, el idioma, la capitalización ni la versión. La restricción de ubicación de los auxiliares identificados como EVC, EPC o LDC se evalúa mediante EXT-002.

**Evidencia mínima:** Clasificación certificada del componente como API, texto completo de la primera sección y dominio arquitectónico certificado. Para las API ubicadas en INTEGRACIÓN se requieren el nombre del producto, el nombre de la API, el separador estructural y la versión. Los espacios repetidos y situados en los extremos se normalizan, excepto los espacios anteriores a la primera letra, que constituyen incumplimiento. Los guiones propios de nombres o marcas no se consideran automáticamente separadores estructurales. El idioma no se determina únicamente por siglas, marcas, nombres propios, términos técnicos ni palabras compartidas por varios idiomas.

- **Cumple:** La clasificación y ubicación de la API están certificadas y la primera sección satisface todas las condiciones aplicables. En INTEGRACIÓN cumple el formato completo, y en SISTEMAS EXTERNOS contiene un nombre real, funcional, específico, no genérico y diferente de un texto de plantilla.

- **No cumple:** La clasificación, ubicación y primera sección están certificadas, y se incumple al menos una condición aplicable. En INTEGRACIÓN esto incluye espacios antes de la primera letra, estructura u orden incorrectos, nombre genérico o de plantilla, separador estructural inválido, capitalización incorrecta, idioma diferente del inglés o versión ausente o inválida. En SISTEMAS EXTERNOS esto incluye un nombre ausente, genérico, no funcional o correspondiente a un texto de plantilla.

- **No verificable:** No puede certificarse si el componente es una API; no puede determinarse si está ubicado en INTEGRACIÓN o SISTEMAS EXTERNOS; la primera sección está incompleta; no puede distinguirse el guion estructural de los guiones propios de los nombres; o no puede verificarse razonablemente alguna condición aplicable. Prioridad de estados: apartado 8 de `00-procedimiento.md`.

- **No aplica:** La página no contiene API certificadas ni componentes candidatos cuya clasificación como API esté pendiente.

### API-002 - Operación de API

**Resumen oficial:** Valida la operación declarada en la segunda sección de una API según el dominio arquitectónico en el que se encuentre.

**Aplica a:** Todas las API principales e invocadas con tipo arquitectónico certificado. Cada API de ambos roles se incluye individualmente en la población.

**Criterio:** Para una API ubicada en INTEGRACIÓN, directamente o dentro de un sistema externo auxiliar, la segunda sección debe contener únicamente el nombre de la operación expuesta por la API. La operación debe estar escrita en inglés y en formato `camelCase`: debe comenzar con una letra minúscula, contener únicamente letras y números, no incluir espacios, guiones ni guiones bajos, y utilizar una letra mayúscula inicial para cada palabra posterior a la primera cuando el nombre tenga varias palabras.

Para una API ubicada en SISTEMAS EXTERNOS, directamente o dentro de un sistema externo auxiliar, no se exige el idioma inglés ni el formato `camelCase`; la segunda sección debe contener una operación funcional, específica, no genérica y diferente de un texto de plantilla. La presencia de EVC, EPC o LDC en el nombre del auxiliar no modifica la modalidad de nombramiento de la operación; la restricción de ubicación del auxiliar se evalúa mediante EXT-002.

**Evidencia mínima:** Clasificación certificada del componente como API, dominio arquitectónico certificado y texto completo de la segunda sección. Para las API ubicadas en INTEGRACIÓN, el texto debe permitir comprobar que existe una única operación, que está escrita en inglés y que cumple el formato `camelCase`. Para las API ubicadas en SISTEMAS EXTERNOS, el texto debe permitir comprobar que la operación es funcional, específica, no genérica y diferente de un texto de plantilla. La operación no debe deducirse a partir del nombre de la API ni de otra sección.

- **Cumple:** La clasificación y ubicación de la API están certificadas y la segunda sección satisface todas las condiciones aplicables. En INTEGRACIÓN contiene únicamente una operación en inglés y en formato `camelCase`. En SISTEMAS EXTERNOS contiene una operación funcional, específica, no genérica y diferente de un texto de plantilla.

- **No cumple:** La clasificación, ubicación y segunda sección están certificadas y se incumple al menos una condición aplicable. En INTEGRACIÓN esto incluye una operación ausente, genérica, de plantilla, escrita en un idioma diferente del inglés, fuera del formato `camelCase`, acompañada de texto adicional o con más de una operación. En SISTEMAS EXTERNOS esto incluye una operación ausente, genérica, no funcional o correspondiente a un texto de plantilla.

- **No verificable:** No puede certificarse si el componente es una API; no puede determinarse si está ubicado en INTEGRACIÓN o SISTEMAS EXTERNOS; la segunda sección está ausente o incompleta por falta de evidencia; no puede verificarse razonablemente el idioma cuando se exige la validación rigurosa; o cualquier ambigüedad impide determinar si el texto corresponde exactamente a una operación válida. Prioridad de estados: apartado 8 de `00-procedimiento.md`.

- **No aplica:** La página no contiene API certificadas ni componentes candidatos cuya clasificación como API esté pendiente.

### API-003 - Tipo y modelo de servicio de API

**Resumen oficial:** Valida el tipo de API y el modelo de servicio declarados en la tercera sección, según el dominio arquitectónico en el que se encuentre la API.

**Aplica a:** Todas las API principales e invocadas con tipo arquitectónico certificado. Cada API de ambos roles se incluye individualmente en la población.

**Criterio:** Para una API ubicada en INTEGRACIÓN, directamente o dentro de un sistema externo auxiliar, la tercera sección debe seguir la estructura `tipo - modelo de servicio`. El valor anterior al guion debe ser exactamente `private`, `public` o `partner`, y el valor posterior debe ser exactamente `entidad`, `utilidad` o `tarea`. Ambos valores deben estar completamente en minúsculas y separados por un único guion estructural. No se admiten abreviaturas, traducciones, mayúsculas ni valores diferentes.

Para una API ubicada en SISTEMAS EXTERNOS, directamente o dentro de un sistema externo auxiliar, no se exige la estructura corporativa, los tipos ni los modelos del catálogo. La tercera sección debe contener información funcional, específica, no genérica y diferente de un texto de plantilla. La presencia de EVC, EPC o LDC en el nombre del auxiliar no modifica esta modalidad; la restricción de ubicación del auxiliar se evalúa mediante EXT-002.

**Evidencia mínima:** Clasificación certificada del componente como API, dominio arquitectónico certificado y texto completo de la tercera sección. Antes de evaluar, se eliminan los espacios iniciales y finales y se normalizan los espacios repetidos como un solo espacio. No se evalúa la cantidad de espacios antes o después del guion. Para las API ubicadas en INTEGRACIÓN debe ser posible identificar inequívocamente el tipo, el guion estructural y el modelo de servicio. Una exposición declarada por el analista puede utilizarse en API-004, pero no sustituye el tipo que debe estar escrito en la tercera sección para API-003.

- **Cumple:** La clasificación y ubicación de la API están certificadas y la tercera sección satisface todas las condiciones aplicables. En INTEGRACIÓN presenta exactamente un tipo permitido y un modelo de servicio permitido, en minúsculas y separados por un único guion estructural. En SISTEMAS EXTERNOS contiene información funcional, específica, no genérica y diferente de un texto de plantilla.

- **No cumple:** La clasificación, ubicación y tercera sección están certificadas y se incumple al menos una condición aplicable. En INTEGRACIÓN esto incluye la ausencia del tipo, del modelo de servicio o del guion estructural; un valor fuera de los catálogos permitidos; el uso de mayúsculas, abreviaturas o traducciones; un orden incorrecto; o más de un guion estructural. La declaración posterior del tipo por parte del analista no corrige este incumplimiento. En SISTEMAS EXTERNOS esto incluye una sección ausente, genérica, no funcional o correspondiente a un texto de plantilla.

- **No verificable:** No puede certificarse si el componente es una API; no puede determinarse si está ubicado en INTEGRACIÓN o en SISTEMAS EXTERNOS; el texto de la tercera sección no está disponible o está incompleto por falta de evidencia; no puede distinguirse inequívocamente el guion estructural de un guion perteneciente a un valor; o cualquier ambigüedad impide evaluar una condición aplicable. Si la sección está disponible y se certifica que falta el tipo, el modelo o el guion, corresponde **No cumple**, no **No verificable**. Prioridad de estados: apartado 8 de `00-procedimiento.md`.

- **No aplica:** La página no contiene API certificadas ni componentes candidatos cuya clasificación como API esté pendiente.

### API-004 - Capa de Despliegue de la API principal

**Resumen oficial:** Valida que la API principal declarada como MCI tenga la Capa de Despliegue requerida según su tipo de exposición.

**Aplica a:** API principal con tipo arquitectónico y rol certificados, declarada como MCI.

**Criterio:** Cuando la API principal está declarada como MCI, la Capa de Despliegue exigida depende de su tipo de exposición:

- una API `private` debe tener asociadas una Capa de Arquitectura y un Flujo Transaccional;
- una API `partner` debe tener asociada una Capa de Arquitectura y no requiere Flujo Transaccional;
- una API `public` no requiere Capa de Arquitectura ni Flujo Transaccional.

Las asociaciones requeridas deben pertenecer inequívocamente a la API principal y no pueden establecerse por cercanía, alineación, superposición, contención visual ni ubicación en el mismo contenedor. Cuando está declarada como no MCI, no se exige Capa de Arquitectura, Flujo Transaccional ni la declaración Federado. Las API invocadas se excluyen de esta regla, y las Capas o Flujos asociados a ellas no demuestran ni incumplen la Capa de la API principal.

**Precedencia de asociaciones:** aplicar apartado 4.1. de `00-procedimiento.md` Una asociación resuelta con la API principal demuestra pertenencia; una resuelta con otro componente demuestra solo la pertenencia a ese componente.

Una Capa, un Flujo o una pareja Capa-Flujo sin propietario determinado (`associatedComponentId: null`, estado pendiente, ambiguo o en conflicto, `PENDING_NO_COMMON_SUPERIOR_GROUP`) es candidata y produce **No verificable**, aunque encierre un evento BPMN, un grupo u otra figura: lo que contiene no resuelve de quién es. Un arreglo vacío en `components[].deploymentAssociations` no demuestra ausencia si `pages[].deploymentAssociations` contiene candidatas. La imposibilidad de demostrar pertenencia no equivale a demostrar ausencia.

**Evidencia mínima:** Identificación certificada de la API principal, exposición (tercera sección o declarada por la analista), condición MCI o no MCI declarada por la analista e inventario completo de asociaciones de despliegue de la página. La declaración de la analista determina la exposición y la condición MCI, pero no sustituye la evidencia de existencia ni de asociación de la Capa o del Flujo.

- **Cumple:** La API principal está declarada como MCI, su exposición está determinada y tiene resueltas inequívocamente con ella las Capas exigidas: Capa de Arquitectura y Flujo Transaccional para `private`, o Capa de Arquitectura para `partner`. Una API `public` cumple sin Capa ni Flujo.

- **No cumple:** La API principal está declarada como MCI, su exposición está determinada y la ausencia queda demostrada: cobertura completa, no existen Capas, Flujos o parejas candidatas pendientes que puedan pertenecerle, y falta al menos un elemento obligatorio; o todos los elementos existentes pertenecen certificadamente a otros componentes.

- **No verificable:** No puede certificarse cuál es la API principal; falta la declaración MCI; no puede determinarse la exposición; existe una Capa, un Flujo o una pareja candidata sin propietario determinado; o la cobertura no basta para demostrar pertenencia ni ausencia.

- **No aplica:** La API principal está declarada como no MCI; el componente es una API invocada; o la página no contiene una API principal ni candidatos pendientes de identificación para ese rol.

### SRV-001 - Nombramiento del servicio
  
**Resumen oficial:** Valida el nombre declarado en la primera sección de los servicios invocados y del servicio principal del escenario E3, según su modalidad gestionada o no gestionada.

**Aplica a:** Componentes certificados como servicios invocados y componente certificado como servicio principal del escenario E3. El hijo principal de E1, E2 o E3 está excluido.  

**Criterio:** La primera sección debe contener un nombre visible, funcional, específico y diferente de un texto de plantilla. No se exige versión, prefijo, formato, separador, capitalización ni estructura particular. Un servicio invocado es gestionado cuando está ubicado directamente en el nivel padre de INTEGRACIÓN. Es no gestionado cuando está ubicado directamente en el nivel padre de DOMINIO PRODUCTOR o SISTEMAS EXTERNOS. Si no puede distinguirse entre DOMINIO PRODUCTOR y SISTEMAS EXTERNOS, pero está certificado que no pertenece a INTEGRACIÓN, se considera no gestionado. Cuando el servicio está encapsulado en un sistema externo auxiliar, su modalidad se determina por la ubicación arquitectónica efectiva del auxiliar bajo los mismos criterios. El servicio principal de E3 se considera no gestionado.  
El nombre de un servicio gestionado debe estar escrito en inglés. El nombre de un servicio no gestionado puede estar escrito en inglés o en español. La existencia de una Capa de Despliegue no determina la modalidad. El nombre no permite por sí solo clasificar el componente como servicio ni certificar su rol.  

**Evidencia mínima:** Clasificación certificada del componente como servicio, rol certificado como invocado o como servicio principal de E3, texto completo de la primera sección y ubicación arquitectónica efectiva suficiente para determinar la modalidad. Para servicios encapsulados se requiere pertenencia certificada al auxiliar y ubicación efectiva del auxiliar. El idioma no se determina únicamente por siglas, marcas, nombres propios, términos técnicos ni palabras iguales en inglés y español.

- **Cumple:** El componente pertenece a la población, contiene un nombre visible, funcional, específico y diferente de un texto de plantilla, y satisface la modalidad aplicable: inglés para un servicio gestionado, o inglés o español para un servicio no gestionado.

- **No cumple:** El componente pertenece a la población y la primera sección está disponible y completa, pero el nombre está ausente, vacío, compuesto únicamente por espacios, no es funcional o específico, o corresponde a un texto de plantilla. También corresponde este estado cuando un servicio gestionado tiene un nombre escrito en un idioma diferente del inglés, o un servicio no gestionado tiene un nombre escrito en un idioma diferente del inglés y del español.

- **No verificable:** No puede certificarse que el componente sea un servicio; no puede certificarse su rol; la primera sección está ausente o incompleta por pérdida de evidencia; no puede determinarse si está en INTEGRACIÓN o fuera de INTEGRACIÓN y esto cambia la evaluación; no puede demostrarse su pertenencia al auxiliar o la ubicación efectiva de este; o no puede determinarse razonablemente el idioma exigido. Prioridad de estados: apartado 8 de `00-procedimiento.md`.

- **No aplica:** La página no contiene servicios invocados certificados, un servicio principal certificado de E3 ni candidatos pendientes que puedan pertenecer a esta población. Los hijos principales de E1, E2 y E3 están expresamente excluidos.

### SRV-002 - Operación del servicio
  
**Resumen oficial:** Valida la operación declarada en la segunda sección de los servicios invocados y del servicio principal del escenario E3, según su modalidad gestionada o no gestionada.  

**Aplica a:** Componentes certificados como servicios invocados y componente certificado como servicio principal del escenario E3. El hijo principal de E1, E2 o E3 está excluido.  

**Criterio:** La segunda sección debe contener únicamente el nombre de la operación ejecutada por el servicio. La operación debe ser funcional, específica, no genérica y diferente de un texto de plantilla. Un servicio invocado es gestionado cuando está ubicado directamente en el nivel padre de INTEGRACIÓN. Es no gestionado cuando está ubicado directamente en el nivel padre de DOMINIO PRODUCTOR o SISTEMAS EXTERNOS. Si no puede distinguirse entre DOMINIO PRODUCTOR y SISTEMAS EXTERNOS, pero está certificado que no pertenece a INTEGRACIÓN, se considera no gestionado. Cuando el servicio está encapsulado en un sistema externo auxiliar, su modalidad se determina por la ubicación arquitectónica efectiva del auxiliar. El servicio principal de E3 se considera no gestionado.  
Para un servicio gestionado, la operación debe estar escrita en inglés y en formato camelCase: debe comenzar con una letra minúscula, contener únicamente letras y números, no incluir espacios, guiones ni guiones bajos, y utilizar una letra mayúscula inicial para cada palabra posterior a la primera cuando tenga varias palabras. Para un servicio no gestionado, la operación puede estar escrita en inglés o en español y no se evalúa el formato camelCase. La existencia de una Capa de Despliegue no determina la modalidad. La operación no debe deducirse del nombre, clasificación, modelo ni otra sección.  

**Evidencia mínima:** Clasificación certificada del componente como servicio, rol certificado como invocado o como servicio principal de E3, texto completo de la segunda sección y ubicación arquitectónica efectiva suficiente para determinar la modalidad. Para servicios encapsulados se requiere pertenencia certificada al auxiliar y ubicación efectiva del auxiliar. El idioma no se determina únicamente por siglas, marcas, nombres propios, términos técnicos ni palabras iguales en inglés y español.

- **Cumple:** El componente pertenece a la población, contiene únicamente una operación funcional, específica, no genérica y diferente de un texto de plantilla, y satisface la modalidad aplicable: inglés y camelCase para un servicio gestionado, o inglés o español sin validación de camelCase para un servicio no gestionado.

- **No cumple:** El componente pertenece a la población y la segunda sección está disponible y completa, pero la operación está ausente, es genérica, no es funcional o específica, corresponde a un texto de plantilla, contiene más de una operación o incluye texto adicional. También corresponde este estado cuando un servicio gestionado no está escrito en inglés o no cumple camelCase, o un servicio no gestionado está escrito en un idioma diferente del inglés y del español.

- **No verificable:** No puede certificarse que el componente sea un servicio; no puede certificarse su rol; la segunda sección está ausente o incompleta por pérdida de evidencia; no puede determinarse si está en INTEGRACIÓN o fuera de INTEGRACIÓN y esto cambia la evaluación; no puede demostrarse su pertenencia al auxiliar o la ubicación efectiva de este; no puede determinarse razonablemente el idioma exigido; o existe ambigüedad para establecer si el texto corresponde exactamente a una operación válida. Prioridad de estados: apartado 8 de `00-procedimiento.md`.

- **No aplica:** La página no contiene servicios invocados certificados, un servicio principal certificado de E3 ni candidatos pendientes que puedan pertenecer a esta población. Los hijos principales de E1, E2 y E3 están expresamente excluidos.

### SRV-003 - Clasificación del servicio
  
**Resumen oficial:** Valida que la tercera sección de los servicios invocados y del servicio principal de E3 declare exactamente una clasificación permitida en minúsculas.  

**Aplica a:** Componentes certificados como servicios invocados y componente certificado como servicio principal del escenario E3. El hijo principal de E1, E2 o E3 está excluido.  

**Criterio:** La tercera sección debe declarar obligatoriamente una única clasificación escrita exactamente en minúsculas: entidad, utilidad o tarea. No se admiten diferencias de mayúsculas y minúsculas, traducciones, abreviaturas, valores distintos, textos genéricos, textos de plantilla ni información adicional. La modalidad gestionada o no gestionada no modifica esta obligación. La presencia de las palabras entidad, utilidad o tarea no demuestra por sí sola que el componente sea un servicio ni certifica su rol.  

**Evidencia mínima:** Clasificación certificada del componente como servicio, rol certificado como invocado o como servicio principal de E3 y texto completo de la tercera sección. Antes de evaluar se eliminan los espacios iniciales y finales. El valor restante debe coincidir exactamente con uno de los tres valores permitidos en minúsculas.

- **Cumple:** El componente pertenece a la población y su tercera sección declara exactamente entidad, utilidad o tarea, en minúsculas.

- **No cumple:** El componente pertenece a la población y la tercera sección está disponible y completa, pero el valor está ausente; utiliza mayúsculas; es diferente de entidad, utilidad o tarea; corresponde a una traducción o abreviatura; declara más de una clasificación; contiene un texto genérico o de plantilla; o incluye información adicional.

- **No verificable:** No puede certificarse que el componente sea un servicio; no puede certificarse su rol; la tercera sección no está disponible o está incompleta por pérdida de evidencia; o existe una ambigüedad que impide determinar el valor declarado. Las palabras entidad, utilidad o tarea, sin evidencia arquitectónica adicional, no permiten clasificar el componente como servicio. Prioridad de estados: apartado 8 de `00-procedimiento.md`.

- **No aplica:** La página no contiene servicios invocados certificados, un servicio principal certificado de E3 ni candidatos pendientes que puedan pertenecer a esta población. Los hijos principales de E1, E2 y E3 están expresamente excluidos.

### SRV-004 - Capa de Despliegue del servicio
  
**Resumen oficial:** Valida que cada servicio invocado gestionado, y el hijo principal de E1 y E2 declarado MCI, tengan asociada la Capa de Despliegue que les corresponde.  

**Aplica a:** Servicios invocados certificados ubicados en el nivel padre de INTEGRACIÓN, directamente o encapsulados en un sistema externo auxiliar ubicado en ese nivel. También aplica al hijo principal de E1 y E2 cuando la analista lo declara con Capa de Despliegue MCI (apartado 5.1 de `00-procedimiento.md`). Están excluidos el servicio principal de E3, el hijo principal de E3 y los servicios no gestionados.  

**Criterio:** Todo servicio invocado gestionado debe tener asociada inequívocamente una Capa de Despliegue válida. La modalidad MCI debe estar representada por una Capa de Arquitectura y un Flujo Transaccional asociados inequívocamente al servicio. La modalidad Federada debe estar representada por evidencia certificada como Federado y asociada inequívocamente al servicio; En el JSON enriquecido, la modalidad Federada consta como una figura con `architecturalType: FEDERADO` (texto exacto `Federado`) y su asociación con el componente en `deploymentAssociations` con `modality: FEDERADO` (`federatedId`, estado y evidencia por contención directa). No se pregunta a la analista si el servicio invocado es MCI.  
Para el hijo principal de E1 o E2 la modalidad no se infiere: depende de la respuesta de la analista. Si lo declara MCI, debe tener asociadas inequívocamente una Capa de Arquitectura y un Flujo Transaccional. La condición es MCI estricta: no se acepta Federado para el hijo principal. Si lo declara no MCI, no debe tener Capa de Arquitectura ni Flujo Transaccional asociados. Sin respuesta, la regla no se evalúa para el hijo principal.  
Las capas de despliegue son únicamente figuras `UMLRectangleContainerBlock` con el texto `Federado`, `Capa de Arquitectura` o `Flujo Transaccional`; un texto suelto con ese contenido no se considera.  
Cuando el servicio esté encapsulado en un sistema externo auxiliar ubicado en el nivel padre de INTEGRACIÓN, la Capa de Despliegue debe pertenecer inequívocamente al servicio y no únicamente al auxiliar. La asociación no puede establecerse solo por cercanía, alineación, superposición o pertenencia al mismo contenedor. La existencia o ausencia de Capa de Despliegue no modifica SRV-001, SRV-002 ni SRV-003.  

**Precedencia de asociaciones:** aplicar apartado 4.1. de `00-procedimiento.md` Una asociación pendiente, ambigua, en conflicto o sin propietario (`associatedComponentId: null`) es candidata y no demuestra ausencia. Un arreglo vacío en `components[].deploymentAssociations` tampoco demuestra ausencia si `pages[].deploymentAssociations` contiene pares Capa-Flujo o figuras `Federado` pendientes de propietario. Una asociación resuelta con otro componente demuestra únicamente pertenencia a ese componente. La ausencia solo queda certificada cuando la cobertura es completa, no existe asociación resuelta con el servicio y tampoco hay candidatos que puedan pertenecerle.  

**Hijo principal declarado no MCI en E1:** un par Capa-Flujo sin propietario ubicado en INTEGRACIÓN no es del hijo (que está en PRODUCTOR): no se le atribuye ni genera incertidumbre para él, y sigue siendo candidato de los servicios invocados gestionados. El resultado de la regla es el de evaluar los servicios gestionados restantes.   Si no hay servicios invocados gestionados y el hijo declarado no MCI no tiene Capa ni Flujo asociados, el resultado es **Cumple**, no `No aplica`.

**Evidencia mínima:** Clasificación y rol certificados del servicio invocado o del hijo principal (y, para este, la declaración MCI de la analista); ubicación efectiva certificada en el nivel padre de INTEGRACIÓN, directamente o mediante un sistema externo auxiliar; inventario completo de figuras o valores de despliegue; y evidencia estructural suficiente para determinar la modalidad y asociación. Para MCI se requieren una Capa de Arquitectura y un Flujo Transaccional inequívocamente asociados. Para Federada se requiere la figura `FEDERADO` inequívocamente asociada al servicio (entrada `modality: FEDERADO` resuelta con el servicio).

- **Cumple:** El hijo principal de E1 o E2 declarado MCI tiene Capa de Arquitectura y Flujo Transaccional asociados inequívocamente, o el declarado no MCI no tiene asociado ninguno. El servicio invocado está certificado como gestionado y tiene asociada inequívocamente una Capa de Despliegue válida: Capa de Arquitectura y Flujo Transaccional para MCI, o la figura `Federado` asociada inequívocamente al servicio (entrada `modality: FEDERADO` resuelta). El hijo principal declarado MCI cumple con Capa de Arquitectura y Flujo Transaccional; el declarado no MCI, sin ninguno de los dos.

- **No cumple:** El hijo principal de E1 o E2 está declarado MCI, la cobertura y asociaciones están completas, no existen candidatos que puedan pertenecerle y carece de Capa de Arquitectura, de Flujo Transaccional o de ambos; o está declarado no MCI y tiene asociada inequívocamente una Capa de Arquitectura o un Flujo Transaccional. El servicio está certificado como gestionado, la cobertura y asociaciones están completas, no existen candidatos pendientes que puedan pertenecerle y se demuestra que no tiene una Capa de Despliegue válida; que MCI carece de Capa de Arquitectura, Flujo Transaccional o ambos; que no existe figura `Federado` asociada al servicio; o que los elementos están certificadamente asociados a otro componente.

- **No verificable:** No puede certificarse que el componente sea un servicio invocado o el hijo principal; falta la declaración MCI del hijo principal de E1 o E2; no puede determinarse si está en INTEGRACIÓN o fuera de INTEGRACIÓN; no puede demostrarse su pertenencia al auxiliar o la ubicación efectiva de este; no puede determinarse la modalidad; existen Capa, Flujo o evidencia de Federado candidatos sin pertenencia demostrable; la asociación es pendiente, ambigua o contradictoria; la cobertura es insuficiente. Prioridad de estados: apartado 8 de `00-procedimiento.md`.

- **No aplica:** El componente es un servicio invocado no gestionado; corresponde al servicio principal de E3 o al hijo principal de E3; o la página no contiene servicios invocados gestionados ni hijo principal de E1 o E2 certificados, ni candidatos pendientes que puedan pertenecer a esta población.

### SRV-005 - Conexiones del servicio con API, servicios y auxiliares

**Resumen oficial:** Valida las conexiones directas de un servicio invocado con API invocadas, otros servicios invocados y sistemas externos auxiliares, y que no se conecte con eventos.

**Aplica a:** Conexiones directas de un servicio invocado certificado con una API invocada, otro servicio invocado, un sistema externo auxiliar (encapsule o no API o servicios) o un evento. Se excluyen las conexiones con comandos (COM-002, COM-003 y COM-005) y con gestores de colas (MQ-003). Las conexiones entre API, o entre API y auxiliar, sin servicio, no las evalúa esta regla. Una conexión con un comando no pertenece a esta regla aunque el otro participante sea un candidato (apartado 6 de `00-procedimiento.md`); las conexiones pendientes de un servicio (apartado 6.1) sí la afectan.

**Criterio:** Un servicio puede relacionarse con una o varias API, servicios o auxiliares, y un mismo participante puede relacionarse con varios servicios. La conexión puede ir de servicio a servicio, de servicio a API o de servicio a auxiliar, aunque este encapsule una API o un servicio. Un servicio no puede conectarse con un evento, sea `BPMNEvent` o evento de integración. El número de relaciones o de conexiones que recibe un participante no es motivo de incumplimiento. Cada relación debe tener dos conexiones entre los mismos participantes: una dirigida desde el servicio hacia el participante y otra en sentido contrario. En cada conexión, el origen debe utilizar `CircleOpen` y el destino `Generalization`. Cada pareja de participantes se evalúa una sola vez, aunque ambos sean servicios.

Si la conexión termina únicamente en el auxiliar y no puede atribuirse a una API o servicio encapsulado, el auxiliar actúa como participante; si puede atribuirse, el participante es el componente encapsulado.

**Evidencia mínima:** Identificación certificada del servicio invocado y del participante relacionado, junto con las conexiones completas entre ambos: origen, destino y terminaciones. Si el participante está encapsulado en un auxiliar, debe estar certificada su pertenencia.

- **Cumple:** Cada relación evaluada tiene las dos conexiones, una en cada sentido, con `CircleOpen` en el origen y `Generalization` en el destino, sin conexiones duplicadas para la misma pareja y el mismo sentido.

- **No cumple:** Los participantes y la cobertura de las conexiones están certificados, y falta uno de los dos sentidos; una conexión está orientada incorrectamente; el origen no utiliza `CircleOpen`; el destino no utiliza `Generalization`; existen conexiones duplicadas para la misma pareja y el mismo sentido; o el servicio tiene una conexión con un evento.

- **No verificable:** No puede certificarse el servicio o el participante; no puede demostrarse que ambos sentidos correspondan a la misma pareja; la dirección o las terminaciones son indeterminadas o contradictorias; no puede determinarse si el extremo es el auxiliar o un componente encapsulado, o si es un evento; o la cobertura no permite confirmar la presencia o ausencia de alguna conexión. Prioridad de estados: apartado 8 de `00-procedimiento.md`.

- **No aplica:** La página no contiene conexiones directas entre servicios invocados y API, servicios, auxiliares o eventos, ni conexiones pendientes de un servicio.

