# Blueprint Evidence Studio v0.3.2 — Entrega tabular

Prioridad: inventario y resultados de datos en una tabla que permita exportar CSV compatible con Excel, además de PDF con Guardar como PDF.

Entradas: JSON y SVG obligatorios; CSV opcional. BPMN no incorporado en esta versión (el ZIP aportado incluye cuatro diagramas, sin garantía de preservar figuras personalizadas).

Proceso: seleccionar dos archivos, añadir CSV si se dispone, analizar, revisar sección 3, descargar tabla CSV y JSON o guardar PDF.

**Importante:** los estados son controles de calidad de evidencia y nomenclatura, no un dictamen normativo. Las conexiones proceden de IDs del JSON. Colores/iconos y trazos no se asignan por instancia todavía. Se retira la interfaz de asignación manual de candidatos, para evitar cargas a la analista.

La jerarquía usa JSON + CSV cuando existe; siempre informa que se trata de relaciones declaradas, no certificación geométrica SVG.
