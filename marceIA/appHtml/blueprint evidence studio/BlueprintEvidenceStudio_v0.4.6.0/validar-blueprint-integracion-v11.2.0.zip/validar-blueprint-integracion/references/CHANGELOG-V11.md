# Historial v11.1.2

- Interpreta productor único, grafos de grupos y asociaciones de despliegue sin convertirlas en contención o cumplimiento.
- Adopta `CONFIRMADO`, `HIPOTESIS` y `NO_DETERMINADO`, manteniendo `normativeEvaluation:null`.
- Lee metadatos del blueprint, selección/omisión de páginas y distingue BDD, plantilla, leyenda y operación.
- Conserva sin cambios las 41 obligaciones oficiales v11.1, F-13 y la decisión directa/declarada.

- Incorpora la convención corporativa de productor y los campos `rootContainers`, `architecturalRoleCandidates` y `structuralScenario` como ayudas contrastables.
- Declara que `STRUCTURALLY_CONFIRMED` no equivale a Cumple y que `normativeEvaluation:null` conserva pendiente la evaluación.
- Distingue páginas operativas, plantillas/leyendas y páginas mixtas; documenta `inferenceUsed:true`.
- Mantiene sin cambios el catálogo normativo v11.1, sus 41 IDs, F-13 y la decisión conexión directa/declarada.

- El escenario se resuelve por dominio arquitectónico raíz verificable sin reemplazar el padre inmediato.
- Flujo Transaccional y Capa de Arquitectura se admiten como capas intermedias.
- La conexión al evento de Inicio requiere extremos declarados y semántica suficiente; un BPMNEvent genérico no basta.
- Se preservan sin cambios los 41 `rule_id` oficiales.

- Inventario renumerado a 41 reglas activas.
- Conexiones centralizadas sin doble conteo.
- API queda en 4 reglas y SRV en 3.
- EVT consolidado en 8 reglas.
- Una regla integral para cada escenario E1/E2/E3.
- MOD-001 incorpora la matriz de modelos y la excepción de modelos internos del hijo.
- COM queda en 4 reglas independientes.
- MQ conserva 5 reglas; comando-gestor pasa a COM-004 y gestor-servicio permanece en MQ-005.
- Gestor en INTEGRACIÓN es MCI con Capa+Flujo; fuera es Federado sin Capa/Flujo; gestor externo permitido en auxiliar de SISTEMAS EXTERNOS.
# Cambios principales v11.2.0

- Corrige F-13: el hijo no gestionado de E1/E3 está dentro del DOMINIO PRODUCTOR; el hijo gestionado de E2 está dentro de INTEGRACIÓN.
- Conserva los 41 IDs y deja pendiente la decisión conexión directa frente a declarada.
- Evalúa 41 reglas y métricas por página; añade preguntas MCI/exposición con procedencia `DECLARADO_POR_ANALISTA`.
- Adopta el porcentaje acreditado con No verificable y Parcialmente cumple en el denominador.
