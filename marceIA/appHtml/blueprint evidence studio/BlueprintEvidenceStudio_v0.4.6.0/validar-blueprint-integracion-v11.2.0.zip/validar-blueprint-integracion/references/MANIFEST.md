# MANIFEST - validar-blueprint-integracion v11.2.0

Revisión normativa aprobada F-13 y operativa. Conserva exactamente los mismos 41 IDs.

## Inventario oficial

Total: **41 reglas activas y únicas**.

| Familia | Cantidad | IDs |
|---|---:|---|
| CNT | 6 | CNT-001, CNT-002, CNT-003, CNT-004, CNT-005, CNT-006 |
| EXT | 2 | EXT-001, EXT-002 |
| GW | 1 | GW-001 |
| API | 4 | API-001, API-002, API-003, API-004 |
| SRV | 3 | SRV-001, SRV-002, SRV-003 |
| EVT | 8 | EVT-001, EVT-002, EVT-003, EVT-004, EVT-005, EVT-006, EVT-007, EVT-008 |
| CA | 2 | CA-001, CA-002 |
| FT | 2 | FT-001, FT-002 |
| E1 | 1 | E1-001 |
| E2 | 1 | E2-001 |
| E3 | 1 | E3-001 |
| MOD | 1 | MOD-001 |
| COM | 4 | COM-001, COM-002, COM-003, COM-004 |
| MQ | 5 | MQ-001, MQ-002, MQ-003, MQ-004, MQ-005 |

## Recursos obligatorios

- 00-procedimiento.md
- 01-reglas-estructura.md
- 02-reglas-api-servicios.md
- 03-reglas-eventos.md
- 04-reglas-despliegue.md
- 05-reglas-escenarios.md
- 06-reglas-modelos-comandos.md
- 07-reglas-gestores-colas.md
- catalogo-reglas-v11.2.csv

## IDs retirados o absorbidos

- ACT-001: retirado; nombramiento se gestiona en COM-001.
- Reglas antiguas de conexión comando-API y comando-servicio: absorbidas por COM-002/COM-003.
- Regla MQ de comando-gestor: absorbida por COM-004.
- Reglas duplicadas de ubicación de API, servicio y evento: absorbidas por CNT/EXT.
