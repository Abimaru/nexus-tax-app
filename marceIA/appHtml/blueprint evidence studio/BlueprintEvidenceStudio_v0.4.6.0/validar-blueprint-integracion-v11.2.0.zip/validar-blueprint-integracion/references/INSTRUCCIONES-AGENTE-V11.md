# Instrucciones del agente - validar blueprints v11.1.1

Usa la skill `validar-blueprint-integracion` para todo JSON de blueprint. Carga los recursos una sola vez. No simules una máquina de estados ni pidas de nuevo un archivo ya disponible.

## Comportamiento

- Menciona primero nombres funcionales; añade IDs solo para desambiguar.
- No preguntes por conexiones, nombres visibles, contención o asociaciones gráficas.
- Por cada página pregunta MCI del principal, MCI del hijo y exposición Private/Public/Partner cuando falte; registra `DECLARADO_POR_ANALISTA` y no reutilices respuestas sin confirmación explícita.
- Tras recibir respuestas, continúa automáticamente.
- No fuerces E1/E2/E3. Si no se certifica, completa las 41 filas y limita No verificable a las reglas afectadas.
- Distingue siempre padre inmediato, cadena de ancestros y dominio arquitectónico raíz. Las capas intermedias no invalidan por sí solas el escenario.
- Acepta PRODUCER por `CORPORATE_PARENT_DOMAIN_CONVENTION` solo para un padre arquitectónico personalizado válido y registra la inferencia; no la apliques a variantes reservadas ni envolventes conflictivos. No trates cualquier BPMNEvent como evento de Inicio.
- Contrasta componentes, dominios, asociaciones y escenario compactos con el diagnóstico cuando sea necesario. `CONFIRMADO` nunca es Cumple; `normativeEvaluation:null` mantiene pendiente la evaluación.
- Excluye páginas TEMPLATE_OR_LEGEND del escenario. En páginas MIXED excluye las instancias de leyenda, no la operación completa.
- No exijas una nueva exportación como condición general para emitir informe.

## Entrega obligatoria

1. Escenario y evidencia.
2. CSV con exactamente 41 filas de datos.
3. Conteos de Cumple, No cumple, No verificable y No aplica.
4. Cumplimiento y cobertura según procedimiento.
5. Resumen ejecutivo.
6. Detalle por estado.
7. Recomendaciones y evidencia pendiente.
