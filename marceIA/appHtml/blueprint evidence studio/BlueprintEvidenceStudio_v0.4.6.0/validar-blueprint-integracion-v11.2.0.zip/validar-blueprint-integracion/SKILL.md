---
name: validar-blueprint-integracion
description: Valida blueprints de integración por página con el catálogo v11.2 de 41 reglas, evidencia, preguntas declarativas, métricas y recomendaciones. Usar para validar, revisar, analizar o clasificar un blueprint.
---
# Validador de blueprints de integración v11.2.0

1. Leer completamente `references/MANIFEST.md`, `references/00-procedimiento.md` y los siete catálogos normativos.
2. Confirmar exactamente 41 `rule_id` únicos en `references/catalogo-reglas-v11.2.csv`.
3. Analizar únicamente `pages[]` seleccionadas del JSON Copilot compacto. Usar el diagnóstico para trazabilidad, nunca para contradecir evidencia original coherente.
4. Por cada página, antes del dictamen, preguntar: (a) ¿la API o servicio principal está en MCI?, (b) ¿el servicio hijo principal está en MCI?, y (c), si la exposición no está acreditada, ¿Private, Public o Partner? No repetir respuestas existentes. Solo reutilizarlas entre páginas con confirmación explícita. Registrar `DECLARADO_POR_ANALISTA` y no convertirlo automáticamente en cumplimiento.
5. Resolver E1/E2/E3 desde componente principal, hijo, dominio efectivo y extremos declarados. BDD no es evidencia. `CONFIRMADO` exige subtipo Inicio certificado por `customData`; un BPMNEvent genérico produce `HIPOTESIS`; evidencia incompatible o insuficiente produce `NO_DETERMINADO`.
6. Evaluar las 41 reglas independientemente por página. Cada resultado incluye ID, estado, evidencia, justificación breve, componente e información pendiente. No trasladar resultados entre páginas.
7. Estados permitidos: Cumple, No cumple, Parcialmente cumple, No verificable y No aplica. `HIPOTESIS` no implica incumplimiento; No verificable nunca equivale a No cumple.
8. Calcular por página `Cumplimiento = Cumple / (Cumple + No cumple + Parcialmente cumple + No verificable) × 100`. Excluir No aplica. Si el denominador es cero, informar “no calculable”. Presentar los conteos y no promediar páginas sin ponderar por evaluaciones aplicables.
9. Mantener separadas contención, agrupación, asociación de despliegue, dominio y rol. La contención directa Flujo→Capa→Componente o un grupo superior inequívoco pueden acreditar asociación factual; ninguna acredita por sí sola MCI o cumplimiento.
10. Entregar escenario, 41 resultados por página, métricas, pendientes y recomendaciones. Verificar que cada página sume 41.

E1: API principal en INTEGRACIÓN y servicio hijo principal no gestionado dentro del DOMINIO PRODUCTOR. E2: API principal y servicio hijo principal gestionado dentro de la misma INTEGRACIÓN. E3: servicio principal y servicio hijo no gestionado dentro del mismo DOMINIO PRODUCTOR. La decisión conexión directa frente a conexión declarada permanece pendiente y no debe reinterpretarse.
