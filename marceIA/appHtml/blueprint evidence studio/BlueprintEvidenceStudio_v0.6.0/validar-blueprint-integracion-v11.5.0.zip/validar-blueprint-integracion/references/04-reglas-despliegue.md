# Reglas Despliegue - v11.5.0

### CA-001 - Nombramiento de Capa de Arquitectura

**Resumen oficial:** Valida el nombre de las figuras certificadas como Capa de Arquitectura.

**Aplica a:** Figuras certificadas como Capas de Arquitectura, independientemente del componente al que estén asociadas.

**Criterio:** El nombre debe seguir exactamente la estructura `Capa de Arquitectura - tipo`. El valor anterior al guion estructural debe ser `Capa de Arquitectura` y el valor posterior debe ser exactamente `composicion`, `experiencia` o `sistema`. Los tipos deben escribirse completamente en minúsculas y sin tildes. Debe existir un único guion con función estructural entre el nombre de la figura y el tipo. No se admiten abreviaturas, traducciones, variaciones de mayúsculas o minúsculas, tildes, valores diferentes de los permitidos ni texto adicional.

Antes de evaluar, se eliminan los espacios iniciales y finales y se normalizan los espacios consecutivos como un solo espacio. No se evalúa la cantidad de espacios alrededor del guion estructural. La existencia obligatoria de una Capa de Arquitectura se evalúa en la regla específica del componente que la requiere; esta regla evalúa únicamente el nombre de las capas existentes.

**Evidencia mínima:** Identificación certificada de la figura como Capa de Arquitectura y texto completo de su nombre. La evidencia debe permitir distinguir inequívocamente la expresión `Capa de Arquitectura`, el guion estructural y el tipo. No es necesario conocer el componente propietario para evaluar el nombramiento.

- **Cumple:** Todas las Capas de Arquitectura existentes y evaluables siguen exactamente la estructura `Capa de Arquitectura - tipo` y utilizan uno de los tipos permitidos: `composicion`, `experiencia` o `sistema`.

- **No cumple:** La figura y su texto completo están certificados, y al menos una Capa de Arquitectura incumple alguna condición aplicable: falta la expresión `Capa de Arquitectura`, el tipo o el guion estructural; el orden es incorrecto; existe más de un guion estructural; el tipo está fuera del catálogo permitido; se utilizan tildes, abreviaturas, traducciones, mayúsculas no permitidas o texto adicional.

- **No verificable:** No puede certificarse que la figura sea una Capa de Arquitectura; su nombre no está disponible o está incompleto por pérdida de evidencia; no puede distinguirse inequívocamente el guion estructural de un guion perteneciente al texto; o alguna ambigüedad impide evaluar el nombre. La falta de identificación del componente propietario no impide evaluar esta regla. Si existe al menos un incumplimiento certificado, prevalece **No cumple** aunque otra Capa sea no verificable. Excepción: con un candidato pendiente en la población de la regla el estado es **No verificable** y el incumplimiento se cita en la justificación (00-procedimiento.md §8).

- **No aplica:** La página no contiene figuras certificadas como Capas de Arquitectura ni figuras candidatas pendientes de clasificación como tales.


### FT-001 - Nombramiento de Flujo Transaccional

**Resumen oficial:** Valida el nombre de las figuras certificadas como Flujo Transaccional.

**Aplica a:** Figuras certificadas como Flujos Transaccionales, independientemente del componente al que estén asociadas.

**Criterio:** El nombre debe seguir exactamente la estructura `Flujo Transaccional - tipo`. El valor anterior al guion estructural debe ser exactamente `Flujo Transaccional` y el valor posterior debe ser exactamente `monetario`, `no-monetario`, `operativo` o `transversal`. Los tipos deben escribirse completamente en minúsculas. Debe existir un único guion con función estructural entre el nombre de la figura y el tipo. El guion de `no-monetario` forma parte del valor permitido y no se considera un separador estructural adicional. No se admiten abreviaturas, traducciones, variaciones de mayúsculas o minúsculas, valores diferentes de los permitidos ni texto adicional.

Antes de evaluar, se eliminan los espacios iniciales y finales y se normalizan los espacios consecutivos como un solo espacio. No se evalúa la cantidad de espacios alrededor del guion estructural. La existencia obligatoria de un Flujo Transaccional se evalúa en la regla específica del componente que lo requiere; esta regla evalúa únicamente el nombre de los flujos existentes.

**Evidencia mínima:** Identificación certificada de la figura como Flujo Transaccional y texto completo de su nombre. La evidencia debe permitir distinguir inequívocamente la expresión `Flujo Transaccional`, el guion estructural y el tipo. No es necesario conocer el componente propietario para evaluar el nombramiento.

- **Cumple:** Todos los Flujos Transaccionales existentes y evaluables siguen exactamente la estructura `Flujo Transaccional - tipo` y utilizan uno de los tipos permitidos: `monetario`, `no-monetario`, `operativo` o `transversal`.

- **No cumple:** La figura y su texto completo están certificados, y al menos un Flujo Transaccional incumple alguna condición aplicable: falta la expresión `Flujo Transaccional`, el tipo o el guion estructural; el orden es incorrecto; existe más de un guion estructural, sin contar el guion propio de `no-monetario`; el tipo está fuera del catálogo permitido; se utilizan abreviaturas, traducciones, mayúsculas no permitidas o texto adicional.

- **No verificable:** No puede certificarse que la figura sea un Flujo Transaccional; su nombre no está disponible o está incompleto por pérdida de evidencia; no puede distinguirse inequívocamente el guion estructural de un guion perteneciente al texto; o alguna ambigüedad impide evaluar el nombre. La falta de identificación del componente propietario no impide evaluar esta regla. Si existe al menos un incumplimiento certificado, prevalece **No cumple** aunque otro Flujo sea no verificable. Excepción: con un candidato pendiente en la población de la regla el estado es **No verificable** y el incumplimiento se cita en la justificación (00-procedimiento.md §8).

- **No aplica:** La página no contiene figuras certificadas como Flujos Transaccionales ni figuras candidatas pendientes de clasificación como tales.


