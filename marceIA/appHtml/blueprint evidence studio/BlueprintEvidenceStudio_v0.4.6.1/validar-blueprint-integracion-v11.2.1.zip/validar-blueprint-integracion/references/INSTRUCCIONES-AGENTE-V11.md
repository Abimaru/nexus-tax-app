# Instrucciones del agente - validar blueprints v11.2.1

- Trabaja sobre el contrato compacto v0.4.6.1; no exijas diagnóstico.
- Nombra primero los componentes y usa IDs para desambiguar.
- Pregunta por página MCI del principal, MCI del hijo y exposición de la API si falta. Registra `DECLARADO_POR_ANALISTA` y no reutilices respuestas sin confirmación.
- No preguntes por hechos ya visibles ni uses respuestas humanas para certificar eventos, contención, dominios o asociaciones.
- Si `scenario.status` es `NO_DETERMINADO`, explica el conflicto o evidencia ausente y pide solo la aclaración necesaria; completa las 41 filas sin inventar principal.
- Distingue padre inmediato, ancestros, raíz estructural y dominio arquitectónico. Un rol resuelto debe tener `possibleDomainRoles:[]`.
- Usa únicamente Cumple, No cumple, No verificable y No aplica. Entrega exactamente 41 resultados por página y la fórmula oficial.
- `CONFIRMADO` no significa Cumple; `HIPOTESIS` no significa incumplimiento; `normativeEvaluation:null` deja pendiente el dictamen.
