# Reglas Gestores Colas - v11.2.1

## MQ-001 - Identificación y nombramiento del gestor

**Resumen oficial:** Valida el gestor de colas sin contar figuras técnicas internas como gestores separados.

**Aplica a:** Gestores de colas

**Criterio:** Conservar definición vigente de MQ-001; clasificación y nombre específicos.

**Evidencia mínima:** Tipo, rol, estructura y nombre.

- **Cumple:** evidencia suficiente y criterio satisfecho.
- **No cumple:** Gestor certificado con nombre inválido.
- **No verificable:** Clasificación como gestor no certificada.
- **No aplica:** Fuera de la población evaluable.

## MQ-002 - Ubicación del gestor

**Resumen oficial:** Valida ubicación en INTEGRACIÓN, dominio productor o auxiliar externo.

**Aplica a:** Gestores de colas

**Criterio:** Gestor externo permitido en auxiliar de SISTEMAS EXTERNOS.

**Evidencia mínima:** Padre directo y externalidad.

- **Cumple:** evidencia suficiente y criterio satisfecho.
- **No cumple:** Ubicación fuera de las permitidas.
- **No verificable:** Ubicación o externalidad no certificadas.
- **No aplica:** Fuera de la población evaluable.

## MQ-003 - Modelo de despliegue del gestor

**Resumen oficial:** Valida MCI en INTEGRACIÓN y Federado fuera de ella.

**Aplica a:** Gestores de colas

**Criterio:** En INTEGRACIÓN: MCI. Fuera: debe declarar Federado.

**Evidencia mínima:** Ubicación y etiqueta/modelo.

- **Cumple:** evidencia suficiente y criterio satisfecho.
- **No cumple:** Modelo incompatible con ubicación.
- **No verificable:** Ubicación o modelo no certificados.
- **No aplica:** Fuera de la población evaluable.

## MQ-004 - Detalle de despliegue del gestor

**Resumen oficial:** Valida Capa y Flujo según ubicación.

**Aplica a:** Gestores de colas

**Criterio:** En INTEGRACIÓN: Capa y Flujo obligatorios. Fuera: no debe tener Capa ni Flujo.

**Evidencia mínima:** Ubicación y asociaciones de Capa/Flujo.

- **Cumple:** evidencia suficiente y criterio satisfecho.
- **No cumple:** Falta detalle obligatorio o existe detalle no permitido.
- **No verificable:** Asociación o cobertura no certificadas.
- **No aplica:** Fuera de la población evaluable.

## MQ-005 - Conexión gestor con servicio invocado

**Resumen oficial:** Valida la conexión entre gestor y servicio invocado.

**Aplica a:** Gestores y servicios invocados

**Criterio:** Conservar patrón vigente; no trasladar a COM y no duplicar COM-004.

**Evidencia mínima:** Conexiones, extremos y participantes.

- **Cumple:** evidencia suficiente y criterio satisfecho.
- **No cumple:** Patrón incumplido con cobertura completa.
- **No verificable:** Participantes, dirección, extremos o cobertura no certificados.
- **No aplica:** No hay servicios invocados relacionados con gestores.

