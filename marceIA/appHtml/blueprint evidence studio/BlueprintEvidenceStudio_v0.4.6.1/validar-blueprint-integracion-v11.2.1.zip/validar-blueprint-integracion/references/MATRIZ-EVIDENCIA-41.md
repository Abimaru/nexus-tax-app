# Matriz regla → evidencia → campo → respuesta humana

| rule_id | Evidencia requerida | Campo compacto | Respuesta humana |
|---|---|---|---|
| CNT-001 | contenedores requeridos | `components`, `architecturalDomain` | No |
| CNT-002 | dominio efectivo del hijo | `scenario`, `architecturalDomain`, `domainRole` | No |
| CNT-003 | contenido de integración | `structuralParent`, `containerChainIds`, `domainRole` | No |
| CNT-004 | contenido de productor | `structuralParent`, `containerChainIds`, `domainRole` | No |
| CNT-005 | contenido externo | `structuralParent`, `containerChainIds`, `domainRole` | No |
| CNT-006 | contención inequívoca | `structuralParent.status`, `issues` | No |
| EXT-001 | contenido auxiliar | `architecturalType`, `containedComponentIds` | No |
| EXT-002 | conexión auxiliar | `connections` | No |
| GW-001 | gateway y caminos | `lucidchartType`, `connections` | No |
| API-001 | nombre API | `name`, `textAreas` | No |
| API-002 | operación API | `operation`, `textAreas` | No |
| API-003 | tipo y exposición | `textAreas`, `architecturalType` | Exposición si falta |
| API-004 | MCI y despliegue | `deploymentAssociations` | MCI principal |
| SRV-001 | nombre servicio | `name`, `textAreas` | No |
| SRV-002 | operación servicio | `operation`, `textAreas` | No |
| SRV-003 | tipo servicio | `textAreas`, `architecturalType` | No |
| EVT-001 | nombre evento | `name`, `textAreas` | No |
| EVT-002 | operación evento | `operation`, `textAreas` | No |
| EVT-003 | clasificación evento | `textAreas`, `customData` | No |
| EVT-004 | MCI y despliegue | `deploymentAssociations` | MCI del componente aplicable |
| EVT-005 | contención evento | `structuralParent`, `containerChainIds` | No |
| EVT-006 | tópicos | `textAreas` | No |
| EVT-007 | formato tópico | `textAreas` | No |
| EVT-008 | sentido conexión | `connections` | No |
| CA-001 | nombre de capa | `architecturalType`, `name` | No |
| CA-002 | asociación capa | `deploymentAssociations` | No |
| FT-001 | nombre de flujo | `architecturalType`, `name` | No |
| FT-002 | asociación flujo | `deploymentAssociations` | No |
| E1-001 | patrón E1 | `scenario`, dominios, conexión | MCI principal e hijo |
| E2-001 | patrón E2 | `scenario`, dominios, conexión | MCI principal e hijo |
| E3-001 | patrón E3 | `scenario`, dominios, conexión | MCI principal e hijo |
| MOD-001 | entrada y salida | `customData`, `textAreas`, `groups` | No |
| COM-001 | actividad relacionada | `textAreas`, `connections` | No |
| COM-002 | comando a API | `connections`, `architecturalType` | No |
| COM-003 | comando a servicio | `connections`, `architecturalType` | No |
| COM-004 | comando a gestor | `connections`, `architecturalType` | No |
| MQ-001 | gestor identificado | `architecturalType`, `name` | No |
| MQ-002 | ubicación gestor | `structuralParent`, `domainRole` | No |
| MQ-003 | MCI o federado | `domainRole`, `textAreas` | MCI del gestor si falta |
| MQ-004 | capa y flujo | `deploymentAssociations` | No |
| MQ-005 | gestor a servicio | `connections` | No |

Una respuesta humana se registra como `DECLARADO_POR_ANALISTA` en la página correspondiente. No sustituye evidencia estructural ni certifica cumplimiento por sí sola.
