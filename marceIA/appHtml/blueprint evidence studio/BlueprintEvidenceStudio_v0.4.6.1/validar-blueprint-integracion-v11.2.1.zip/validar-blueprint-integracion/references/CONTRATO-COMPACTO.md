# Diccionario del contrato compacto v0.4.6.1

| Campo | Significado y fuente | Certeza | Reglas / ausencia o conflicto |
|---|---|---|---|
| `contract`, `version`, `nonNormative` | Identidad del exportador | Declarado por herramienta | Rechazar versión desconocida; `nonNormative:true` obliga a evaluar |
| `metadata.selectedPageIds` | Páginas elegidas | Selección humana | Evaluar solo estas; una página requiere 41 filas |
| `metadata.omittedPages` | Páginas no elegidas y motivo | Selección humana | No evaluar; no trasladar respuestas sin confirmación explícita |
| `pages[].components[]` | Inventario único por página | Factual/derivado por campo | Todas; ID ausente impide trazabilidad |
| `architecturalType` | `API`, `SERVICIO`, `SERVICIO_HIJO`, `GESTOR_COLAS`, `SISTEMA_EXTERNO_AUXILIAR`, `EVENTO`, `CAPA`, `FLUJO`, `MODELO` o `null` | Inferido con evidencia | API/SRV/EVT/CA/FT/MOD/MQ; `null` no certifica tipo |
| `role` | `PRINCIPAL`, `HIJO_PRINCIPAL`, `INVOCADO` o `null` | Solo resuelto | API/SRV/E1/E2/E3; `null` conserva incertidumbre |
| `domainRole` | INTEGRATION, PRODUCER, EXTERNAL_SYSTEM o `null` | Declarado/inferido con fuente | CNT/E1/E2/E3; si existe, `possibleDomainRoles` debe ser `[]` |
| `possibleDomainRoles` | Posibilidades sustentadas sin resolver | Candidato | CNT; no elegir una por descarte |
| `structuralParent` | Padre inmediato de `JSON.contains` | Factual o conflictivo | CNT/EVT/MQ; conflicto no se completa |
| `containerChainIds` | Ancestros completos en orden | Derivado de contención | CNT/E1/E2/E3; no omitir intermedios |
| `rootContainer` | Raíz del árbol estructural | Derivado | Trazabilidad; puede diferir del dominio |
| `architecturalDomain` | Dominio efectivo | Declarado/inferido | CNT/E1/E2/E3; revisar `status`, `roleSource`, `conflicts` |
| `textAreas` | Secciones originales literales | Factual | Nombramiento, operación y modelos; no convierte funcional en técnico |
| `customData` | Valor original literal cuando la propiedad existe | Factual | EVT/MOD; ausente permanece ausente y arreglo vacío permanece `[]` |
| `connections` | IDs por componente y líneas completas por página | Factual + estado | EXT/GW/COM/EVT/MQ; exigir orientación verificable cuando aplique |
| `deploymentAssociations` | Asociación factual Flujo/Capa/Componente | Derivado no normativo | API/EVT/CA/FT/MQ; conflicto o pendiente no certifica |
| `scenario` | E1/E2/E3 y certeza | Derivado no normativo | E1/E2/E3; `CONFIRMADO`, `HIPOTESIS`, `NO_DETERMINADO` no son estados de cumplimiento |
| `issues` | Pérdidas, conflictos o datos malformados | Diagnóstico compacto | Todas; resolver impacto antes del dictamen |
| `inference` | Estado, evidencia y contradicciones del candidato | Derivado | API/SRV/E1/E2/E3; solo `INFERRED` sustenta rol definitivo |

El campo ausente significa que el original no declaró esa propiedad; `null` significa que el contrato la contempla pero no pudo resolverla. Ninguno equivale a valor negativo. El diagnóstico opcional añade estructuras técnicas, pero no es requisito ordinario.
