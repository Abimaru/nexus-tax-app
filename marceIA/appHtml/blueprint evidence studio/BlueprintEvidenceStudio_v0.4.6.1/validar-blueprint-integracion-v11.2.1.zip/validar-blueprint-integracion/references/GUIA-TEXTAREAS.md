# Guía de interpretación de `textAreas`

Conservar y citar las secciones originales. El título puede sustentar una regla de nombramiento; la operación, una regla de operación; la tercera sección, una declaración funcional o de exposición. Las palabras Entidad, Utilidad o Tarea no demuestran SERVICIO. Private, Public o Partner no demuestran por sí solas API. Un prefijo `ms-`, `ms_`, `ms ` o `msCamelCase` es señal convencional de servicio, no requisito universal ni rol INVOCADO.

Para decidir función arquitectónica combine tipo Lucidchart, relaciones orientadas, contención, dominio, escenario, `inference.status` y conflictos. No cree `functionalClassification` en el compacto. Para MOD-001, `customData` ENTRADA/SALIDA es evidencia literal que el agente puede evaluar; no la transforme automáticamente en `architecturalType:MODELO`.

Ejemplos genéricos:

- Título `ms-orders`, operación `createOrder`, tercera sección `Entidad`: hay señal de servicio por nombre; Entidad solo describe función.
- Título `Orders API`, tercera sección `Private`: Private aporta exposición declarada, pero el tipo API requiere evidencia arquitectónica adicional.
- Figura de evento con texto `Inicio`: texto libre no certifica subtipo BPMN; solo `customData` inequívoco bajo `PROPOSED_CLOSED_CATALOG` puede hacerlo.

Ante principal no identificado, explique el conflicto y pregunte solo qué componente cumple esa función. No use esa respuesta para alterar jerarquía, conexión ni subtipo BPMN.
