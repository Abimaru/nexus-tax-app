# Cambios v11.2.1

- Sincroniza la Skill con `copilot-factual-v0.4.6.1` y añade diccionario y matriz autosuficientes.
- Restringe el procedimiento a cuatro estados; evidencia parcial pasa a No verificable.
- Corrige la fórmula por página y el agregado por evaluaciones regla–página.
- Documenta `PROPOSED_CLOSED_CATALOG`, `NO_DETERMINADO` y lectura conservadora de `textAreas`.
- No cambia ninguna de las 41 obligaciones.

# Cambios v11.2.0

- Corrige F-13 únicamente en CNT-002, E1-001 y E3-001. E2-001 y CNT-004 solo tienen relación conceptual.
- Conserva los 41 IDs y deja pendiente conexión directa frente a declarada.

# Historial v11.1.2

- Introdujo resolución estructural, grafos de grupos y asociaciones de despliegue no normativas.
- Separó escenario estructural y dictamen normativo.

# Historial v11.1

- Consolidó el inventario en 41 reglas activas y únicas.
