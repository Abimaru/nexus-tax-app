# Reglas Escenarios - v11.2.1

## E1-001 - Estructura integral E1

**Resumen oficial:** Valida API en INTEGRACIÓN y servicio hijo principal no gestionado bajo el dominio productor.

**Aplica a:** Escenario E1

**Criterio:** API principal en INTEGRACIÓN, fuera del hijo; servicio hijo principal no gestionado con dominio arquitectónico efectivo DOMINIO PRODUCTOR; conexión declarada al evento de Inicio cuando la exija el estándar.

**Evidencia mínima:** API, hijo, padre directo, cadena de ancestros, dominio raíz, semántica del evento y extremos.

- **Cumple:** evidencia suficiente y criterio satisfecho.
- **No cumple:** La estructura certificada contradice E1.
- **No verificable:** Algún participante, relación o cobertura no certificado.
- **No aplica:** Escenario certificado E2 o E3.

## E2-001 - Estructura integral E2

**Resumen oficial:** Valida API e hijo separados dentro de INTEGRACIÓN.

**Aplica a:** Escenario E2

**Criterio:** API principal e hijo separados y gestionados bajo INTEGRACIÓN según su dominio arquitectónico raíz; conexión declarada al evento de Inicio cuando la exija el estándar.

**Evidencia mínima:** API, hijo, padre directo, cadena de ancestros, dominio raíz, semántica del evento y extremos.

- **Cumple:** evidencia suficiente y criterio satisfecho.
- **No cumple:** La estructura certificada contradice E2.
- **No verificable:** Algún participante, relación o cobertura no certificado.
- **No aplica:** Escenario certificado E1 o E3.

## E3-001 - Estructura integral E3

**Resumen oficial:** Valida componente del servicio principal y servicio hijo no gestionados bajo el dominio productor.

**Aplica a:** Escenario E3

**Criterio:** Servicio principal fuera del hijo y ambos, principal e hijo no gestionado, con el mismo dominio arquitectónico efectivo DOMINIO PRODUCTOR; conexión directa al evento de Inicio cuando corresponda a las exigencias del estándar.

**Evidencia mínima:** Servicio, hijo, padre directo, cadena de ancestros, dominio raíz, semántica del evento y extremos.

- **Cumple:** evidencia suficiente y criterio satisfecho.
- **No cumple:** La estructura certificada contradice E3.
- **No verificable:** Algún participante, relación o cobertura no certificado.
- **No aplica:** Escenario certificado E1 o E2.

