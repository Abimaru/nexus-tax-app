# Procedimiento de validación - v11.2.1

## Precedencia

1. Evidencia literal compacta: `components[].textAreas`, `customData`, IDs y `connections`.
2. Jerarquía: `structuralParent`, `containerChainIds`, `rootContainer` y `architecturalDomain` son propiedades distintas.
3. Evidencia derivada: `domainRole`, `possibleDomainRoles`, `inference`, `deploymentAssociations` y `scenario`, siempre con estado y conflictos.

El diagnóstico opcional puede aportar `rootContainers`, `groupStructure`, `deploymentPairs`, `architecturalRoleCandidates` y `structuralScenario`; esos nombres no pertenecen al contrato compacto ni son requisito. La resolución de productor usa `STRUCTURAL_CHILD_EVENT_MAIN_PATH`. No inferir EXTERNAL_SYSTEM por descarte.

## Flujo por página

1. Confirmar que la página está seleccionada y no es plantilla pura.
2. Inventariar componentes sin promover `Entidad`, `Utilidad`, `Tarea`, `Private`, `Public` o `Partner` a tipo arquitectónico.
3. Revisar escenario, principal, hijo, dominios, conexión y conflictos. `NO_DETERMINADO` exige explicar qué impide resolverlo.
4. Preguntar MCI del principal, MCI del hijo y exposición si falta; registrar `DECLARADO_POR_ANALISTA` por página; reutilizar en otra página solo con confirmación explícita de la analista.
5. Evaluar una vez cada uno de los 41 IDs usando la matriz. Una obligación parcialmente demostrada es No verificable, no No cumple.
6. Entregar evidencia, justificación, componente y pendiente por fila.

## Estados y métricas

- Cumple: toda la obligación está demostrada.
- No cumple: evidencia suficiente demuestra incumplimiento.
- No verificable: evidencia insuficiente, parcial, ambigua o contradictoria.
- No aplica: fuera de la población de la regla.

`Cumplimiento = Cumple / (Cumple + No cumple + No verificable) × 100`. No aplica queda fuera. Ejemplo: 13 Cumple, 0 No cumple, 13 No verificable y 15 No aplica suman 41 y producen 50 %. Con denominador cero, informar no calculable. Consolidar páginas sumando las evaluaciones regla–página aplicables.

`CONFIRMADO`, `HIPOTESIS` y `NO_DETERMINADO` describen escenario, no dictamen. `PROPOSED_CLOSED_CATALOG` es una propuesta técnica, no un estándar corporativo demostrado.
