---
name: validar-blueprint-integracion
description: Valida por página blueprints de integración con el contrato compacto de Evidence Studio y las 41 reglas v11.2.
---
# Validador de blueprints de integración v11.2.1

1. Leer completos `references/MANIFEST.md`, `00-procedimiento.md`, `CONTRATO-COMPACTO.md`, `MATRIZ-EVIDENCIA-41.md`, `GUIA-TEXTAREAS.md` y los siete catálogos normativos.
2. Aceptar como entrada ordinaria `copilot-factual-v0.4.6.1`; el diagnóstico es opcional. Validar páginas seleccionadas y reconocer las omitidas en `metadata.omittedPages`.
3. Por cada página preguntar únicamente: MCI del principal, MCI del hijo principal y exposición Private/Public/Partner cuando corresponda. Registrar cada respuesta como `DECLARADO_POR_ANALISTA`; reutilizarla en otra página solo con confirmación explícita de la analista, conservando la procedencia, y nunca usarla para certificar BPMN o estructura.
4. Consumir `components[]`, `connections`, `groups`, `deploymentAssociations`, `scenario` e `issues`. Mantener separados evidencia literal, inferencia, certeza, jerarquía, dominio y rol. `null` o campo ausente nunca es evidencia positiva.
5. E1: API principal en INTEGRACIÓN e hijo no gestionado en DOMINIO PRODUCTOR. E2: API e hijo gestionado en la misma INTEGRACIÓN. E3: servicio principal e hijo no gestionado en el mismo DOMINIO PRODUCTOR. `CONFIRMADO` exige Inicio inequívoco en `customData` bajo `PROPOSED_CLOSED_CATALOG`; `HIPOTESIS` no es cumplimiento. Ante `NO_DETERMINADO`, explicar la incertidumbre y pedir solo el dato faltante, sin inventar principal.
6. Evaluar exactamente las 41 reglas por cada página seleccionada. Estados únicos: `Cumple`, `No cumple`, `No verificable`, `No aplica`. Evidencia parcial, ambigua, incompleta o contradictoria es `No verificable` e indica lo faltante.
7. Calcular `Cumplimiento = Cumple / (Cumple + No cumple + No verificable) × 100`; `No aplica` se excluye. Denominador cero: no calculable. El total del blueprint suma evaluaciones regla–página aplicables; nunca promedia porcentajes de páginas.
8. Entregar escenario, 41 resultados por página, conteos, porcentaje, evidencia pendiente y recomendaciones. Verificar IDs únicos, estados válidos y suma 41.

La asociación factual Flujo/Capa no certifica MCI ni cumplimiento. La decisión conexión directa frente a declarada continúa pendiente.
