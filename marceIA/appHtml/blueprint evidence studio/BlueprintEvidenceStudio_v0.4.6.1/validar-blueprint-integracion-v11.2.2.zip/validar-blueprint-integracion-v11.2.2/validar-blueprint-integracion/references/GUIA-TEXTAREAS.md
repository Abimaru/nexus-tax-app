# Guía de interpretación de `textAreas`

Conservar y citar las secciones originales. El título puede sustentar una regla de nombramiento; la operación, una regla de operación; la tercera sección, una declaración funcional o de exposición. Las palabras Entidad, Utilidad o Tarea no demuestran SERVICIO. Private, Public o Partner no demuestran por sí solas API. Un prefijo `ms-`, `ms_`, `ms ` o `msCamelCase` es señal convencional de servicio, no requisito universal ni rol INVOCADO.

Para decidir función arquitectónica combine tipo Lucidchart, relaciones orientadas, contención, dominio, escenario, `inference.status` y conflictos. No cree `functionalClassification` en el compacto. Para MOD-001, `customData` ENTRADA/SALIDA es evidencia literal que el agente puede evaluar; no la transforme automáticamente en `architecturalType:MODELO`.

Ejemplos genéricos:

- Título `ms-orders`, operación `createOrder`, tercera sección `Entidad`: hay señal de servicio por nombre; Entidad solo describe función.
- Título `Orders API`, tercera sección `Private`: Private aporta exposición declarada, pero el tipo API requiere evidencia arquitectónica adicional.
- Figura de evento con texto `Inicio`: texto libre no certifica subtipo BPMN; solo `customData` inequívoco bajo `PROPOSED_CLOSED_CATALOG` puede hacerlo.

Ante principal no identificado, explique el conflicto y pregunte solo qué componente cumple esa función. No use esa respuesta para alterar jerarquía, conexión ni subtipo BPMN.

### Modalidad de validación de API según ubicación

- Las API ubicadas en INTEGRACIÓN, directamente o dentro de un sistema externo auxiliar, se evalúan con el estándar corporativo completo definido para cada sección.
- Las API ubicadas en SISTEMAS EXTERNOS, directamente o dentro de un sistema externo auxiliar, se evalúan con la modalidad reducida definida en cada regla. En esta modalidad, cada sección debe contener información funcional, específica, no genérica y diferente de textos de plantilla, pero no se exige el formato corporativo completo salvo que la regla indique expresamente lo contrario.
- Si no puede determinarse si la API está ubicada en INTEGRACIÓN o en SISTEMAS EXTERNOS, las reglas cuya modalidad dependa de esta ubicación se evalúan como No verificable.
- La presencia de EVC, EPC o LDC en el nombre de un sistema externo auxiliar no modifica la modalidad de validación textual. La ubicación permitida de estos auxiliares se evalúa mediante EXT-002.
- Una declaración del analista puede aportar el tipo de exposición requerido para evaluar el despliegue en API-004, pero no sustituye el valor que debe estar escrito en la tercera sección para el cumplimiento de API-003.