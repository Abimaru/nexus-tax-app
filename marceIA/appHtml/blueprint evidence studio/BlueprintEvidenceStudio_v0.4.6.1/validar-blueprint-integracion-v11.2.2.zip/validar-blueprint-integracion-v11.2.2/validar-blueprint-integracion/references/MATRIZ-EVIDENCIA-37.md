## Matriz regla -> evidencia -> campo -> respuesta humana

> **Catálogo vigente:** 37 reglas activas.  
> **Nota:** SRV-001 y SRV-002 permanecen activas, pero su criterio normativo está pendiente de ajuste. La matriz conserva únicamente su evidencia base hasta cerrar esas reglas.

| rule_id | Evidencia requerida | Campo compacto | Respuesta humana |
|---|---|---|---|
| CNT-001 | Patrón estructural aplicable e inventario completo de dominios obligatorios con clasificación certificada | `scenario`, `components`, `architecturalDomain`, `domainRole`, `possibleDomainRoles`, `issues` | No |
| CNT-002 | Identificación de un único hijo principal, nombre visible no genérico y dominio arquitectónico exigido por E1, E2 o E3 | `scenario`, `components`, `role`, `name`, `textAreas`, `structuralParent`, `containerChainIds`, `architecturalDomain`, `issues` | No |
| CNT-003 | Inventario y clasificación de los componentes ubicados en INTEGRACIÓN, diferenciando nivel padre, hijo principal y contenido interno de auxiliares | `components`, `architecturalType`, `structuralParent`, `containerChainIds`, `architecturalDomain`, `domainRole`, `issues` | No |
| CNT-004 | Inventario y clasificación de los componentes ubicados en DOMINIO PRODUCTOR, diferenciando nivel padre e hijo principal | `components`, `architecturalType`, `structuralParent`, `containerChainIds`, `architecturalDomain`, `domainRole`, `issues` | No |
| CNT-005 | Inventario y clasificación de los componentes ubicados directamente en SISTEMAS EXTERNOS, excluyendo el contenido interno de auxiliares | `components`, `architecturalType`, `structuralParent`, `containerChainIds`, `architecturalDomain`, `domainRole`, `issues` | No |
| EXT-001 | Nombre del sistema externo auxiliar, inventario completo de componentes encapsulados, clasificación de contenido y ubicación cuando contenga Capa de Despliegue | `name`, `textAreas`, `architecturalType`, `containedComponentIds`, `structuralParent`, `containerChainIds`, `architecturalDomain`, `issues` | No |
| EXT-002 | Nombre EVC/EPC/LDC, API encapsulada y ubicación del sistema externo auxiliar en INTEGRACIÓN | `name`, `textAreas`, `architecturalType`, `containedComponentIds`, `structuralParent`, `containerChainIds`, `architecturalDomain`, `issues` | No |
| GW-001 | Texto de la compuerta y etiquetas de todos sus caminos conectados | `lucidchartType`, `name`, `textAreas`, `connections`, `issues` | No |
| API-001 | Primera sección, clasificación como API y ubicación en INTEGRACIÓN o SISTEMAS EXTERNOS | `architecturalType`, `role`, `name`, `textAreas`, `structuralParent`, `containerChainIds`, `architecturalDomain`, `issues` | No |
| API-002 | Segunda sección, clasificación como API y ubicación en INTEGRACIÓN o SISTEMAS EXTERNOS | `architecturalType`, `role`, `operation`, `textAreas`, `structuralParent`, `containerChainIds`, `architecturalDomain`, `issues` | No |
| API-003 | Tercera sección, clasificación como API y ubicación en INTEGRACIÓN o SISTEMAS EXTERNOS | `architecturalType`, `role`, `textAreas`, `structuralParent`, `containerChainIds`, `architecturalDomain`, `issues` | No. La exposición declarada no corrige esta regla |
| API-004 | API principal, exposición aplicable, declaración MCI y asociación de los elementos exigidos de la Capa de Despliegue | `architecturalType`, `role`, `textAreas`, `deploymentAssociations`, `issues` | **Obligatoria:** MCI de la API principal. **Opcional:** exposición `private`, `public` o `partner` si falta y es necesaria |
| SRV-001 | Primera sección y clasificación certificada como servicio invocado; criterio textual pendiente de ajuste | `architecturalType`, `role`, `name`, `textAreas`, `structuralParent`, `containerChainIds`, `architecturalDomain`, `issues` | No |
| SRV-002 | Segunda sección y clasificación certificada como servicio invocado; criterio textual pendiente de ajuste | `architecturalType`, `role`, `operation`, `textAreas`, `structuralParent`, `containerChainIds`, `architecturalDomain`, `issues` | No |
| SRV-003 | Tercera sección con modelo `entidad`, `utilidad` o `tarea` y clasificación certificada como servicio invocado | `architecturalType`, `role`, `textAreas`, `issues` | No |
| SRV-004 | Hijo principal de E1/E2, declaración MCI y asociación de Capa de Arquitectura y Flujo Transaccional | `scenario`, `role`, `name`, `structuralParent`, `containerChainIds`, `architecturalDomain`, `deploymentAssociations`, `issues` | **Obligatoria:** MCI del hijo principal en E1 o E2 |
| EVT-001 | Primera sección del evento de integración: producto, capacidad, idioma, caracteres y versión | `architecturalType`, `name`, `textAreas`, `issues` | No |
| EVT-002 | Segunda sección con operación del evento en inglés y `camelCase` | `architecturalType`, `operation`, `textAreas`, `issues` | No |
| EVT-003 | Tercera sección con tipo `Aplicacion` o `Empresarial` y clasificación `Query`, `Command` o `Event` | `architecturalType`, `textAreas`, `customData`, `issues` | No |
| EVT-004 | Existencia y asociación de una única Capa de Tópicos por evento | `architecturalType`, `structuralParent`, `containerChainIds`, `groups`, `issues` | No |
| EVT-005 | Clasificación del evento, inventario completo de tópicos y roles `p`/`s` de la única Capa de Tópicos | `textAreas`, `customData`, `groups`, `structuralParent`, `containerChainIds`, `issues` | No |
| EVT-006 | Nombre completo de cada tópico y asociación con la Capa de Tópicos del evento | `name`, `textAreas`, `groups`, `structuralParent`, `containerChainIds`, `issues` | No |
| EVT-007 | Roles `p`/`s`, subtipo Señal de Envío o Recepción, conexiones, sentidos, terminaciones y asociación de extremos alternativos | `customData`, `connections`, `groups`, `deploymentAssociations`, `issues` | No |
| CA-001 | Tipo de figura y nombre completo de cada Capa de Arquitectura existente | `architecturalType`, `name`, `textAreas`, `issues` | No |
| FT-001 | Tipo de figura y nombre completo de cada Flujo Transaccional existente | `architecturalType`, `name`, `textAreas`, `issues` | No |
| E1-001 | API principal en INTEGRACIÓN, hijo principal en DOMINIO PRODUCTOR, Inicio certificado en el hijo y conexión `None -> Arrow` | `scenario`, `components`, `role`, `architecturalDomain`, `structuralParent`, `containerChainIds`, `customData`, `connections`, `issues` | No |
| E2-001 | API principal e hijo principal separados en INTEGRACIÓN, Inicio certificado en el hijo y conexión `None -> Arrow` | `scenario`, `components`, `role`, `architecturalDomain`, `structuralParent`, `containerChainIds`, `customData`, `connections`, `issues` | No |
| E3-001 | Componente principal e hijo principal separados en el mismo DOMINIO PRODUCTOR, Inicio certificado y conexión `None -> Arrow` | `scenario`, `components`, `role`, `architecturalDomain`, `structuralParent`, `containerChainIds`, `customData`, `connections`, `issues` | No |
| MOD-001 | Modelos de entrada y salida obligatorios y asociación con API principal E1/E2, componente principal E3 o evento aplicable en INTEGRACIÓN | `scenario`, `role`, `architecturalType`, `customData`, `textAreas`, `groups`, `structuralParent`, `containerChainIds`, `architecturalDomain`, `issues` | No |
| COM-001 | BPMNActivity candidata por relación con API, servicio, gestor o auxiliar, y nombre en español con infinitivo y complemento | `lucidchartType`, `name`, `textAreas`, `connections`, `issues` | No |
| COM-002 | Conexión bidireccional comando-API, incluida API encapsulada, con sentidos y terminaciones válidos | `connections`, `architecturalType`, `structuralParent`, `containerChainIds`, `issues` | No |
| COM-003 | Conexión bidireccional comando-servicio, incluido servicio encapsulado, con sentidos y terminaciones válidos | `connections`, `architecturalType`, `structuralParent`, `containerChainIds`, `issues` | No |
| COM-004 | Conexión bidireccional comando-gestor con sentidos y terminaciones válidos | `connections`, `lucidchartType`, `architecturalType`, `issues` | No |
| COM-005 | Conexión bidireccional comando-auxiliar cuando no puede atribuirse inequívocamente a un componente encapsulado | `connections`, `architecturalType`, `containedComponentIds`, `structuralParent`, `containerChainIds`, `issues` | No |
| MQ-001 | Figura `UMLActiveClassBlock` y nombre visible específico, no genérico y no de plantilla | `lucidchartType`, `name`, `textAreas`, `issues` | No |
| MQ-002 | Gestor en INTEGRACIÓN y Capa de Despliegue MCI o Federada inequívocamente asociada | `lucidchartType`, `structuralParent`, `containerChainIds`, `architecturalDomain`, `textAreas`, `deploymentAssociations`, `issues` | No |
| MQ-003 | Conexiones gestor-gestor, servicio-gestor y Mensaje-gestor con participantes, sentidos, terminaciones y cobertura | `lucidchartType`, `architecturalType`, `customData`, `connections`, `structuralParent`, `containerChainIds`, `issues` | No |

### Reglas para respuestas humanas

- Toda respuesta humana se registra como `DECLARADO_POR_ANALISTA`, vinculada a la página y al componente correspondiente.
- La pregunta sobre MCI de la API principal es obligatoria cuando la API principal esté identificada.
- La pregunta sobre MCI del hijo principal es obligatoria únicamente en E1 y E2, cuando el hijo esté identificado.
- La exposición de la API principal es opcional y solo se pregunta cuando falte y sea necesaria para API-004.
- Una respuesta humana puede determinar aplicabilidad, pero no sustituye texto, contención, conexiones, asociaciones gráficas, tipo arquitectónico ni subtipo BPMN.
- La exposición declarada por la analista puede utilizarse en API-004, pero no corrige API-003.

### Controles de consistencia de la matriz

- Deben existir exactamente 37 IDs activos y únicos.
- Cada ID debe evaluarse una sola vez por página seleccionada.
- Los IDs eliminados no deben aparecer: `CNT-006`, antigua `EXT-002` de conexiones, antigua `EVT-004` de despliegue, `EVT-008`, `CA-002`, `FT-002`, antiguas `MQ-004` y `MQ-005`.
- La numeración vigente debe incluir `EXT-002` para ubicación de auxiliares EVC/EPC/LDC, `EVT-001` a `EVT-007`, `COM-001` a `COM-005` y `MQ-001` a `MQ-003`.
