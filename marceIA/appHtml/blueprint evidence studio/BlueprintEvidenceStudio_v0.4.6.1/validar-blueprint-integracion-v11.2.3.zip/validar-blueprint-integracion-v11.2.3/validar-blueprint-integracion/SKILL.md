---
name: validar-blueprint-integracion
description: Valida por página blueprints de integración con el contrato compacto de Evidence Studio y las 37 reglas activas del catálogo normativo vigente.
---

## Validador de blueprints de integración

- Leer completos `references/MANIFEST.md`, `00-procedimiento.md`, `CONTRATO-COMPACTO.md`, `MATRIZ-EVIDENCIA-37.md`, `GUIA-TEXTAREAS.md` y los catálogos normativos vigentes. La regla específica define qué se evalúa; `00-procedimiento.md` define cómo se evalúa y cómo se resuelven las precedencias.

- Aceptar como entrada ordinaria la versión del contrato compacto soportada por el manifiesto vigente. El diagnóstico es opcional. Evaluar únicamente las páginas seleccionadas y reconocer las omitidas mediante `metadata.omittedPages`.

- Antes de evaluar, comprobar la integridad básica del JSON: identificadores únicos, referencias existentes, contención sin ciclos, coherencia entre padre inmediato y cadena de ancestros, participantes válidos en conexiones y conflictos registrados en `issues`. Una inconsistencia del JSON no es por sí misma un incumplimiento arquitectónico; las reglas afectadas se evalúan como `No verificable`.

- Mantener separados evidencia literal, evidencia derivada, inferencia, certeza, jerarquía, dominio, rol y declaración humana. Un campo ausente, `null`, candidato, ambiguo o contradictorio no constituye evidencia positiva.

- Distinguir el patrón estructural del cumplimiento integral del escenario:
  - E1: API principal en INTEGRACIÓN e hijo principal en DOMINIO PRODUCTOR.
  - E2: API principal e hijo principal, estructuralmente separados, en INTEGRACIÓN.
  - E3: componente principal e hijo principal, estructuralmente separados, en el mismo DOMINIO PRODUCTOR.

- No forzar E1, E2 o E3 cuando la evidencia estructural sea insuficiente. Explicar la incertidumbre sin inventar el componente principal, el hijo principal ni sus dominios.

- La falta de certificación del evento BPMN de Inicio afecta E1-001, E2-001 o E3-001, pero no invalida automáticamente las reglas independientes de dominios, contenedores, contenido, nombres u operaciones.

- No tratar una figura genérica `BPMNEvent` como subtipo certificado:
  - Inicio se evalúa en E1-001, E2-001 y E3-001.
  - Señal de Envío y Señal de Recepción se evalúan en EVT-007.
  - Mensaje se evalúa en MQ-003.
  Si el subtipo requerido no puede certificarse, limitar `No verificable` a las reglas que dependan de dicho subtipo.

- Formular en un único bloque las preguntas humanas obligatorias que correspondan a la página:
  - si la API principal identificada tiene Capa de Despliegue MCI;
  - si el hijo principal de E1 o E2, mencionado mediante su nombre visible, tiene Capa de Despliegue MCI.

- Preguntar opcionalmente la exposición `private`, `public` o `partner` de la API principal únicamente cuando no esté disponible y sea necesaria para evaluar API-004.

- Registrar cada respuesta como `DECLARADO_POR_ANALISTA`, vinculada a su página y componente. Reutilizarla en otra página únicamente con confirmación explícita de la analista y conservando su procedencia.

- Una declaración humana puede determinar la aplicabilidad de una regla cuando esta lo permita, pero no corrige texto, contención, conexiones, asociaciones gráficas, tipo arquitectónico ni subtipo BPMN. Tampoco demuestra por sí sola la existencia o asociación de una Capa de Arquitectura o un Flujo Transaccional.

- Aplicar las precedencias definidas en `00-procedimiento.md`:
  - toda conexión en la que participe un comando se evalúa una sola vez en la familia COM;
  - comando con API: COM-002;
  - comando con servicio: COM-003;
  - comando con gestor de colas: COM-004;
  - comando con sistema externo auxiliar sin atribución interna inequívoca: COM-005;
  - gestor con gestor, servicio con gestor o evento BPMN de tipo Mensaje con gestor: MQ-003.

- No evaluar una misma conexión en más de una regla. Si los participantes, sus tipos o su pertenencia estructural no pueden determinarse, evaluar como `No verificable` únicamente las reglas afectadas.

- Utilizar exclusivamente los estados `Cumple`, `No cumple`, `No verificable` y `No aplica`:
  - `Cumple`: toda la obligación aplicable está demostrada;
  - `No cumple`: existe al menos un incumplimiento certificado;
  - `No verificable`: la evidencia es insuficiente, parcial, ambigua o contradictoria;
  - `No aplica`: la regla está fuera de población o se cumple una exclusión expresa de la propia regla.

- Una ausencia solo produce `No cumple` cuando la cobertura permite demostrar que el elemento obligatorio realmente no existe. Si existe un incumplimiento certificado, prevalece `No cumple` aunque otra condición sea no verificable.

- Evaluar exactamente las 37 reglas activas por cada página seleccionada. Cada ID debe aparecer una sola vez. Verificar IDs únicos, estados válidos y un total de 37 resultados por página.

- Calcular el cumplimiento como:

  `Cumple / (Cumple + No cumple + No verificable) × 100`

  Excluir `No aplica` del denominador. Si el denominador es cero, informar `no calculable`. Consolidar el blueprint sumando evaluaciones regla-página aplicables; nunca promediar porcentajes de páginas.

- Entregar por página:
  1. patrón estructural y estado integral del escenario;
  2. un resultado por cada una de las 37 reglas activas;
  3. componente o población evaluada;
  4. evidencia y justificación;
  5. información pendiente cuando corresponda;
  6. conteos por estado;
  7. porcentaje de cumplimiento;
  8. resumen ejecutivo;
  9. recomendaciones.

- No inventar componentes principales, dominios, propietarios, asociaciones, conexiones ni subtipos BPMN. No pedir otra vez archivos o respuestas ya disponibles. No exigir una nueva exportación como condición general para emitir el informe.