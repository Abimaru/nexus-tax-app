## MANIFEST - validar-blueprint-integracion

Revisión normativa en curso. El catálogo vigente conserva **37 reglas activas y únicas**. SRV-001 y SRV-002 permanecen activas, pero su criterio normativo está pendiente de ajuste final.

### Inventario oficial

Total: **37 reglas activas y únicas**.

| Familia | Cantidad | IDs |
|---|---:|---|
| CNT | 5 | CNT-001, CNT-002, CNT-003, CNT-004, CNT-005 |
| EXT | 2 | EXT-001, EXT-002 |
| GW | 1 | GW-001 |
| API | 4 | API-001, API-002, API-003, API-004 |
| SRV | 4 | SRV-001, SRV-002, SRV-003, SRV-004 |
| EVT | 7 | EVT-001, EVT-002, EVT-003, EVT-004, EVT-005, EVT-006, EVT-007 |
| CA | 1 | CA-001 |
| FT | 1 | FT-001 |
| E1 | 1 | E1-001 |
| E2 | 1 | E2-001 |
| E3 | 1 | E3-001 |
| MOD | 1 | MOD-001 |
| COM | 5 | COM-001, COM-002, COM-003, COM-004, COM-005 |
| MQ | 3 | MQ-001, MQ-002, MQ-003 |

### Estado de revisión

- Todas las familias están revisadas, excepto el criterio textual definitivo de SRV-001 y SRV-002.
- SRV-001 y SRV-002 continúan siendo IDs activos y deben producir un resultado por página.
- No se debe usar el inventario histórico de 41 reglas para validar el total de resultados.
- Cada página seleccionada debe producir exactamente 37 resultados, uno por cada ID activo del presente manifiesto.

### Recursos obligatorios

- `00-procedimiento.md`
- `01-reglas-estructura.md`
- `02-reglas-api-servicios.md`
- `03-reglas-eventos.md`
- `04-reglas-despliegue.md`
- `05-reglas-escenarios.md`
- `06-reglas-modelos-comandos.md`
- `07-reglas-gestores-colas.md`
- `catalogo-reglas-vigente.csv`
- `CONTRATO-COMPACTO.md`
- `MATRIZ-EVIDENCIA-37.md`
- `GUIA-TEXTAREAS.md`

La `SKILL.md`, el procedimiento, la matriz de evidencia, el catálogo CSV y los catálogos normativos deben utilizar los mismos 37 IDs activos y la misma numeración.

### Cambios frente al catálogo histórico de 41 reglas

#### CNT

- CNT-006 se elimina como regla normativa.
- La unicidad de identificadores y la coherencia técnica de la contención se controlan antes de evaluar las reglas, como validaciones de integridad del JSON.
- Las reglas afectadas por una inconsistencia técnica se evalúan como `No verificable`; la inconsistencia no constituye por sí sola un incumplimiento arquitectónico.

#### EXT

- La antigua EXT-002 de conexiones se elimina.
- Las conexiones en las que participa un comando se centralizan en COM.
- La antigua EXT-003 se renumera como EXT-002 y valida la ubicación de sistemas externos auxiliares EVC, EPC o LDC que encapsulan una API.

#### SRV

- Se añade SRV-004 para validar la Capa de Despliegue del hijo principal de E1 o E2 cuando la analista declara que tiene modalidad MCI.
- SRV-001 y SRV-002 se conservan activas y están pendientes de ajuste textual definitivo.

#### EVT

- La antigua EVT-004 de despliegue se elimina para evitar solapamiento con las reglas específicas de Capa de Despliegue y con CA-001/FT-001.
- Las reglas posteriores se renumeran y la familia queda activa desde EVT-001 hasta EVT-007.
- EVT-007 valida Señal de Envío y Señal de Recepción; una figura genérica `BPMNEvent` no certifica esos subtipos.

#### CA y FT

- CA-002 y FT-002 se eliminan.
- CA-001 valida únicamente el nombramiento de las Capas de Arquitectura existentes.
- FT-001 valida únicamente el nombramiento de los Flujos Transaccionales existentes.
- La obligatoriedad y asociación de los elementos de la Capa de Despliegue se evalúan en API-004, SRV-004 o MQ-002, según corresponda.

#### COM

- Se conservan COM-001 a COM-004 con criterios refinados.
- Se añade COM-005 para la conexión entre comando y sistema externo auxiliar cuando la relación no puede atribuirse inequívocamente a una API o servicio encapsulado.
- Toda conexión en la que participa un comando se evalúa exclusivamente en la familia COM y una sola vez.

#### MQ

- La antigua regla de ubicación del gestor se elimina porque su obligación ya está cubierta por CNT-003, CNT-004, CNT-005 y EXT-001.
- Las antiguas reglas de modelo y detalle de despliegue se fusionan en MQ-002, denominada `Capa de Despliegue del gestor de colas`.
- La antigua conexión gestor-servicio se amplía y pasa a MQ-003, que evalúa conexiones gestor-gestor, servicio-gestor y evento BPMN de tipo Mensaje hacia gestor.
- La conexión comando-gestor permanece exclusivamente en COM-004.

### Lenguaje normativo vigente

- `Capa de Despliegue` es el concepto general.
- `Capa de Despliegue MCI` se demuestra mediante los elementos exigidos por la regla aplicable, como Capa de Arquitectura y Flujo Transaccional.
- `Capa de Despliegue Federada` se demuestra mediante el valor literal `Federado`.
- `Capa de Arquitectura` y `Flujo Transaccional` son figuras específicas y no deben utilizarse como sinónimos del concepto general.
- El hijo principal representa el servicio principal del escenario; no se exige una segunda clasificación redundante como servicio principal.

### Respuestas humanas autorizadas

- Pregunta obligatoria cuando la API principal esté identificada: si tiene Capa de Despliegue MCI.
- Pregunta obligatoria en E1 o E2 cuando el hijo principal esté identificado: si tiene Capa de Despliegue MCI.
- Pregunta opcional: exposición `private`, `public` o `partner` de la API principal, únicamente cuando falte y sea necesaria para API-004.
- Toda respuesta se registra como `DECLARADO_POR_ANALISTA`, vinculada a la página y al componente.
- Una respuesta humana puede determinar aplicabilidad cuando la regla lo permita, pero no sustituye texto, contención, conexiones, asociaciones gráficas, tipo arquitectónico ni subtipo BPMN.

### Controles obligatorios del catálogo

- El inventario debe contener exactamente 37 IDs activos y únicos.
- Cada ID activo debe producir exactamente un resultado por página seleccionada.
- Estados permitidos: `Cumple`, `No cumple`, `No verificable`, `No aplica`.
- No deben reaparecer IDs retirados ni significados históricos asociados a IDs renumerados.
- Los conteos por familia deben sumar 37.
- La matriz de evidencia, el catálogo CSV, los archivos normativos y la salida del agente deben coincidir con este inventario.

### IDs eliminados, absorbidos o renumerados

- CNT-006: eliminado; su contenido corresponde a controles previos de integridad del JSON.
- Antigua EXT-002: eliminada; sus conexiones se redistribuyen en COM y MQ.
- Antigua EXT-003: renumerada como EXT-002.
- Antigua EVT-004: eliminada.
- Antiguas EVT-005, EVT-006, EVT-007 y EVT-008: renumeradas como EVT-004, EVT-005, EVT-006 y EVT-007.
- CA-002: eliminada; asociación absorbida por reglas específicas del componente.
- FT-002: eliminada; asociación absorbida por reglas específicas del componente.
- Antigua MQ-002: eliminada; ubicación absorbida por CNT/EXT.
- Antiguas MQ-003 y MQ-004: fusionadas en MQ-002.
- Antigua MQ-005: ampliada y renumerada como MQ-003.
- ACT-001: permanece retirado; el nombramiento de comandos se gestiona en COM-001.

### Verificación final

Antes de publicar una nueva versión del catálogo:

1. Confirmar el criterio definitivo de SRV-001 y SRV-002.
2. Verificar que todos los recursos obligatorios utilicen los mismos 37 IDs.
3. Verificar que no existan referencias a 41 reglas o a `MATRIZ-EVIDENCIA-41.md`.
4. Asignar una nueva versión normativa en `SKILL.md`, este manifiesto y el catálogo CSV.
5. Ejecutar una validación de consistencia de IDs, estados, referencias cruzadas y conteos por familia.
