---
name: validar-blueprint-integracion
description: Valida por página blueprints de integración con el contrato compacto de Evidence Studio y las 38 reglas activas.
---

# Validador de blueprints de integración

Qué se evalúa lo define cada regla. De dónde sale la población de cada regla lo dice `references/08-fichas.md`. Cómo se decide el estado lo define `references/00-procedimiento.md`. No resumir ni reformular reglas: citar cada una por ID.

### Lectura previa completa

- `references/MANIFEST.md`
- `references/00-procedimiento.md`
- `references/08-fichas.md`
- `references/01-reglas-estructura.md` a `references/07-reglas-gestores-colas.md`

### Pasos

1. Validar contrato, páginas seleccionadas, páginas omitidas e integridad.
2. Clasificar cada página conforme al procedimiento. Una página exclusivamente plantilla, leyenda o de requisitos es no evaluable: se informa con su motivo, sin resultados por regla ni porcentaje.
3. Declarar el inventario de la página desde `pages[].inventory` y determinar, sin inferencias propias, API principal, hijo principal y patrón E1, E2 o E3.
4. Formular en un único bloque, antes de evaluar las reglas dependientes, estas preguntas autorizadas, agrupadas por API principal: una sola vez por cada nombre de API (primera sección, versión incluida, sin distinguir mayúsculas, tildes ni espacios repetidos) entre las páginas evaluables seleccionadas, aunque se repita en varias páginas (apartado 5.4 del procedimiento, que fija el formato de la pregunta agrupada: el nombre una sola vez y los ids juntos). Las de condición MCI son obligatorias aunque `scenario.status` sea `HIPOTESIS`:
   - condición MCI de la API principal certificada (una por nombre de API; la respuesta vale para todas las páginas e IDs con ese nombre);
   - condición MCI del hijo principal certificado, solo en E2 y una por cada hijo (por página e ID; no se agrupa);
   - exposición de la API principal (una por nombre de API), solo para las páginas cuya tercera sección no traiga `private`, `public` ni `partner` (se homologa `privada` a `private` y `pública` a `public`; no cambia API-003); la página que sí la trae usa la suya.
5. Si ninguna página tiene preguntas, no esperar confirmación: continuar con las reglas y entregar el resultado.
6. No preguntar por la condición MCI del componente o servicio principal de E3 (en E3 no hay preguntas). En E1 no preguntar por el hijo principal: se da por no MCI como supuesto de E1 (apartado 5.5 del procedimiento). No duplicar la pregunta de servicio principal cuando el hijo representa ese servicio.
7. Registrar cada respuesta como `DECLARADO_POR_ANALISTA`, vinculada al ID exacto y a la página de cada componente al que aplica. El supuesto del hijo de E1 se registra como `SUPUESTO_E1_HIJO_NO_MCI`, vinculado al ID del hijo y a su página; no es una respuesta de la analista.
8. Aplicar la precedencia de asociaciones de despliegue (apartado 4.1 del procedimiento) antes de cerrar API-004, SRV-004 o MQ-002.
9. Por cada ID del manifiesto: leer su ficha en `08-fichas.md`, tomar su población del inventario, buscar candidatos y pendientes (con uno solo: `No verificable`), leer la regla y decidir el estado con el apartado 8 del procedimiento. Emitir exactamente 38 resultados por página evaluable. Por regla: población (ids), evidencia (ids), estado, justificación y dato pendiente.
10. Calcular la métrica y entregar resumen ejecutivo, recomendaciones y limitaciones.

### Reglas de conducta

- No inventar componentes, contenedores, dominios, asociaciones, conexiones, roles ni subtipos BPMN.
- Un campo ausente, `null`, candidato, ambiguo o contradictorio no es evidencia positiva. Un componente `null` sin `possibleTypes` no es candidato.
- Toda figura y línea mencionada, en el inventario, la evidencia, las justificaciones, el resumen, las recomendaciones y las preguntas a la analista, se escribe «Nombre (id)» con `inventory.nombres` (en una pregunta agrupada por API, «Nombre (id1 y id2)»); nunca un id solo (`08-fichas.md`).
- No pedir archivos o respuestas ya disponibles.
- Una asociación o conexión pendiente produce incertidumbre; no convertirla en ausencia certificada.
- Si se cuestiona un estado, releer la ficha y la regla; cambiarlo solo si la evidencia lo exige, e indicar cuál.
- Antes de responder: 38 IDs únicos, solo cuatro estados y suma total igual a 38 por página evaluable.
