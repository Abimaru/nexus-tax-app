## Fichas operativas - v11.7.0

Una ficha dice de dónde sale la población de cada regla. No define la regla: el criterio y los estados están en el archivo de la regla, y la prioridad de estados en el apartado 8 de `00-procedimiento.md`.

### Cómo usar una ficha

1. Toma la población de la clave del inventario que indica la ficha.
2. Antes de leer el criterio, busca candidatos y pendientes en esa población. Con uno solo, el estado es `No verificable` y no se evalúa más: la justificación nombra el candidato o la pendiente y el dato que falta (si ya consta un incumplimiento certificado, se cita en una línea).
3. Sin candidatos ni pendientes, lee la regla en su archivo y decide el estado.
4. Escribe una línea: ID, población, evidencia, estado, justificación y dato pendiente.

### Cómo citar

- Cada figura se escribe «Nombre (id)», con el nombre de `inventory.nombres[id]`: «Wallet (oNQpJ_-l7X-R)». Nunca un id solo, tampoco en las preguntas a la analista.
- Una figura sin texto viene como «(sin texto: TIPO)»: «(sin texto: COMPUERTA) (id)».
- Una línea viene como «línea Origen → Destino»: «línea Registrar → Wallet (id)».

### Qué no es población

- Un componente con `architecturalType: null` y sin `possibleTypes` no es candidato ni población.
- Un sistema externo auxiliar no es un dominio SISTEMAS EXTERNOS.
- Un componente no cambia de tipo por su nombre, su posición ni su cercanía.
- La ubicación sale de `ubicacion` (`dominio`, `nivel`, `padreId`, `auxiliarId`) en cada lista del inventario, no del dibujo ni de la memoria. Una figura con `nivel: AUXILIAR` está dentro de un auxiliar y no en el nivel del dominio.

Las claves `inventory.*` son las de `pages[].inventory`.

### Parejas: a qué regla va cada una

Cada entrada de `inventory.relaciones` trae `par` (tipos de sus dos participantes; el candidato con sus tipos posibles). Una pareja va a una sola regla, la de esta tabla. Sin ninguna pareja con el `par` de la regla (ni pendiente que pueda serlo), la regla es `No aplica`, aunque existan los dos tipos por separado.

| `par` | Regla |
|---|---|
| `API+COMANDO` | COM-002 |
| `COMANDO+SERVICIO` | COM-003 |
| `COMANDO+GESTOR_COLAS` | COM-004 |
| `COMANDO+SISTEMA_EXTERNO_AUXILIAR` | COM-005 |
| `CANDIDATO(API\|SERVICIO)+COMANDO` | COM-002 y COM-003: `No verificable` |
| `CANDIDATO(API)+COMANDO` | COM-002: `No verificable`; COM-003 no recibe esta pareja |
| `CANDIDATO(GESTOR_COLAS)+COMANDO` | COM-004: `No verificable` |
| `API+SERVICIO`, `SERVICIO+SERVICIO`, `SERVICIO+SISTEMA_EXTERNO_AUXILIAR`, `EVENTO_BPMN+SERVICIO` | SRV-005 |
| `CANDIDATO(API\|SERVICIO)` con API, servicio, auxiliar, evento o candidato | SRV-005: `No verificable` |
| `GESTOR_COLAS+SERVICIO`, `GESTOR_COLAS+GESTOR_COLAS`, `EVENTO_BPMN+GESTOR_COLAS` | MQ-003 |
| `CANDIDATO(API\|SERVICIO)+GESTOR_COLAS` | MQ-003: `No verificable`; nunca SRV-005 |
| `API+API`, `API+SISTEMA_EXTERNO_AUXILIAR` | ninguna |

Un candidato solo afecta a las reglas de sus `posiblesTipos`: uno `["API"]` no toca las reglas de servicio. Una pareja con comando nunca va a SRV-005 ni MQ-003. Una línea que llega a un componente encapsulado no llega al auxiliar: el par es el del componente. Una conexión pendiente (apartado 6.1) deja `No verificable` las reglas que su participante conocido podría tocar.

### Estructura (01-reglas-estructura.md)

**CNT-001.** Población: `contenedoresPadre` y `scenario`. Pendiente: contenedor sin dominio (`possibleDomainRoles`). INTEGRACIÓN repetido es válido.

**CNT-002.** Población: `serviciosHijo` y el contenedor padre que lo contiene (`contenedores`). Pendiente: `scenario.status: NO_DETERMINADO` o varios hijos candidatos.

**CNT-003.** Población: el contenido directo de los `contenedores` con `domainRole: INTEGRATION` y, si hay hijo, su contenido. Lo encapsulado en un auxiliar (`ubicacion.nivel: AUXILIAR`) se evalúa en EXT-001, salvo los eventos de integración. `marcadoresApi` están permitidos. Candidato: `candidatos` con esa `ubicacion` y algún `possibleTypes` no permitido en el nivel; uno cuyos tipos posibles están todos permitidos no cambia el estado.

**CNT-004.** Población: el contenido directo de los `contenedores` con `domainRole: PRODUCER` y, si hay hijo, su contenido. Lo encapsulado en un auxiliar se evalúa en EXT-001, salvo los eventos de integración. Candidato: como en CNT-003.

**CNT-005.** Población: `contenedoresPadre` con `domainRole: EXTERNAL_SYSTEM` y su contenido directo (no el de sus auxiliares). Si no hay ninguno ni `possibleDomainRoles` que lo incluya: `No aplica`. Candidato: como en CNT-003.

**EXT-001.** Población: `sistemasExternosAuxiliares` y su `contiene` en `contenedores`. Candidato: cualquier entrada de `contiene.CANDIDATO` de un auxiliar, aunque todos sus tipos posibles estén permitidos: `No verificable`.

**EXT-002.** Población: `sistemasExternosAuxiliares`; su ubicación está en `parentId` y `domainRole` de `contenedores`.

**GW-001.** Población: `compuertas`; cada una trae `conTexto` y `caminos` (líneas de salida con su `etiqueta`, `null` si no tiene). Se decide por compuerta, y la regla toma el peor estado:

- línea de `conexionesPendientes` con la compuerta, o camino con `orientacion: NO_VERIFICADA`: `No verificable`;
- `conTexto` y todos los caminos (dos o más) con etiqueta: `Cumple` si las etiquetas distinguen las alternativas; `No cumple` si contradicen el texto;
- `conTexto` y algún camino sin etiqueta, o un solo camino: `No verificable` (pregunta sin respuestas);
- sin texto y algún camino con etiqueta: `No verificable` (respuestas sin pregunta);
- sin texto y ningún camino con etiqueta: `Cumple`.

### API (02-reglas-api-servicios.md)

**API-001, API-002, API-003.** Población: `apis` (principal e invocadas). El texto está en `components[].textAreas` y el dominio en `domainRole`. Candidato: cualquier `candidatos` con `API` en `possibleTypes`, esté donde esté: `No verificable` en las tres, aunque las API certificadas cumplan o incumplan.

**API-004.** Población: la API con `role: PRINCIPAL`, solo si se declaró MCI. Asociaciones: `deploymentAssociations`. Pendiente: pareja Capa-Flujo sin propietario.

### Servicios (02-reglas-api-servicios.md)

**SRV-001, SRV-002, SRV-003.** Población: `servicios` (sin `serviciosHijo`). Candidato: cualquier `candidatos` con `SERVICIO` en `possibleTypes`, esté donde esté: `No verificable` en las tres.

**SRV-004.** Población: `servicios` ubicados en el nivel padre de INTEGRACIÓN, más el hijo si se declaró. Asociaciones: `deploymentAssociations`. Pendiente: pareja Capa-Flujo sin propietario.

**SRV-005.** Población: las parejas que la tabla de parejas asigna a SRV-005. No entran las parejas con comando ni con gestor. Pendiente: `conexionesPendientes` con un servicio o un candidato a servicio.

### Eventos de integración (03-reglas-eventos.md)

**EVT-001, EVT-002, EVT-003, EVT-004.** Población: `eventosIntegracion`. Candidato: `candidatos` con `EVENTO_INTEGRACION`. Asociaciones de EVT-004: `deploymentAssociations`.

**EVT-005, EVT-006.** Población: eventos con una única Capa de Tópicos y los tópicos de esa capa (`contenedores`). Candidato: `candidatos` con `EVENTO_INTEGRACION`.

**EVT-007.** Población: parejas de `relaciones` de los tópicos `p` y `s` con BPMNEvent. Pendiente: `conexionesPendientes` con esos eventos.

### Despliegue (04-reglas-despliegue.md)

**CA-001.** Población: `capas`.

**FT-001.** Población: `flujos`.

### Escenarios (05-reglas-escenarios.md)

**E1-001, E2-001, E3-001.** Población: `scenario` (patrón, `mainComponentId`, `mainChildServiceId`, `event`, `connection`). Solo evalúa la regla del patrón identificado; las otras: `No aplica`. Subtipo Inicio: `scenario.event.subtype`. Pendiente: `scenario.status: NO_DETERMINADO` o `alternativeCandidateIds`.

### Modelos y comandos (06-reglas-modelos-comandos.md)

**MOD-001.** Población: `apis` y `servicios`, cada uno con su `modelAssociation` (`entrada` y `salida`), y los eventos de integración de INTEGRACIÓN. Estados del Studio: `EXPLICIT_GROUP` y `BY_COUNT` = asociado; `MISSING_IN_SCOPE` = falta; `AMBIGUOUS` = pendiente. `modelos` lista cada modelo con su estado.

**COM-001.** Población: `comandos`.

**COM-002.** Población: las parejas que la tabla asigna a COM-002. Una pareja con candidato es pendiente: `No verificable`. Pendiente: `conexionesPendientes` con un comando o una API.

**COM-003.** Población: las parejas que la tabla asigna a COM-003. Una pareja con candidato a servicio es pendiente: `No verificable`. Pendiente: `conexionesPendientes` con un comando o un servicio.

**COM-004.** Población: las parejas con `par` `COMANDO+GESTOR_COLAS`. Sin ninguna (un gestor que solo se conecta con servicios o eventos no cuenta): `No aplica`. Pendiente: pareja con candidato a gestor o `conexionesPendientes` con un comando o un gestor.

**COM-005.** Población: las parejas con `par` `COMANDO+SISTEMA_EXTERNO_AUXILIAR` (la línea termina en el auxiliar, no en un componente de su interior). Sin ninguna: `No aplica`. Pendiente: `conexionesPendientes` con un comando o un auxiliar.

### Gestores de colas (07-reglas-gestores-colas.md)

**MQ-001.** Población: `gestoresCola` y `candidatos` con `GESTOR_COLAS`.

**MQ-002.** Población: los `gestoresCola` con `ubicacion.nivel: PADRE` y `ubicacion.dominio: INTEGRATION`; los demás no se evalúan. Sin ninguno ni candidato a gestor en ese nivel: `No aplica`. Asociaciones: `deploymentAssociations`.

**MQ-003.** Población: las parejas que la tabla asigna a MQ-003 (el evento BPMN debe ser de tipo Mensaje; no comando). Una pareja con candidato a API o servicio es pendiente: `No verificable`. Pendiente: `conexionesPendientes` con un gestor o un servicio.
