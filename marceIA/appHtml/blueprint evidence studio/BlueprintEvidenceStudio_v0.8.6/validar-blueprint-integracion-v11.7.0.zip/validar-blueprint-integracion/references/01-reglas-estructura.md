# Reglas Estructura - v11.7.0

### CNT-001 - Contenedores padre requeridos
  
**Resumen oficial:** Valida la existencia de los dominios arquitectónicos obligatorios según el patrón estructural E1, E2 o E3 aplicable a la página.  
**Aplica a:** Páginas evaluables en las que pueda determinarse un patrón estructural E1, E2 o E3, aunque el cumplimiento integral del escenario no esté confirmado.  
**Criterio:** En E1 deben existir al menos un dominio de INTEGRACIÓN y un DOMINIO PRODUCTOR. En E2 debe existir al menos un dominio de INTEGRACIÓN y, adicionalmente, al menos uno entre DOMINIO PRODUCTOR o SISTEMAS EXTERNOS; no es obligatorio que existan ambos. En E3 debe existir al menos un DOMINIO PRODUCTOR. Puede existir más de un dominio del mismo tipo. Los dominios opcionales y su ausencia no afectan al cumplimiento. En E2, un contenedor padre sin clasificar cuyos roles posibles (`possibleDomainRoles`) sean únicamente DOMINIO PRODUCTOR y/o SISTEMAS EXTERNOS satisface la obligación “PRODUCTOR o SISTEMAS EXTERNOS” sin necesidad de precisar cuál de los dos es, porque cualquiera de ellos la cumple y consta que no es INTEGRACIÓN; esa excepción no aplica a E1 ni a E3, que exigen específicamente DOMINIO PRODUCTOR, y no sustituye INTEGRACIÓN. La regla evalúa exclusivamente existencia y clasificación de los dominios obligatorios, no su nombre literal, contenido, contención ni las demás condiciones del escenario.  
**Evidencia mínima:** Patrón E1, E2 o E3 determinado e inventario completo de contenedores padre, con clasificación arquitectónica certificada de los dominios obligatorios.
- **Cumple:** Se determina el patrón y existen todos sus dominios obligatorios certificados: INTEGRACIÓN y PRODUCTOR para E1; INTEGRACIÓN y al menos PRODUCTOR o SISTEMAS EXTERNOS para E2 (incluido, en E2, un contenedor cuyos únicos roles posibles son PRODUCTOR y/o SISTEMAS EXTERNOS); PRODUCTOR para E3.
- **No cumple:** Se determina el patrón, la cobertura es completa y se demuestra la ausencia de al menos un dominio obligatorio, incluida en E2 la ausencia simultánea de PRODUCTOR y SISTEMAS EXTERNOS.
- **No verificable:** No puede determinarse el patrón; el inventario carece de cobertura; o una clasificación indeterminada, ambigua o contradictoria impide confirmar un dominio obligatorio (no es el caso del contenedor de E2 descrito en el criterio, cuyos roles posibles cumplen cualquiera la obligación). La falta de certificación de otras condiciones, como el subtipo Inicio, no afecta por sí sola esta regla.
- **No aplica:** La página no es evaluable por ser exclusivamente plantilla o leyenda, o no contiene estructura susceptible de E1, E2 o E3.
### CNT-002 - Existencia, nombre y ubicación del contenedor hijo principal
  
**Resumen oficial:** Valida que exista un único contenedor hijo principal, que tenga un nombre específico y esté ubicado en el dominio correspondiente al patrón.  
**Aplica a:** Páginas evaluables con estructura susceptible de E1, E2 o E3, aunque el escenario integral no esté confirmado.  
**Criterio:** Debe existir exactamente un contenedor certificado como hijo principal por página (`architecturalType: SERVICIO_HIJO`, `role: INVOCADO`). Debe tener nombre visible, funcional y específico; no se admiten nombres ausentes, vacíos, genéricos ni de plantilla. En E1 y E3 debe estar en DOMINIO PRODUCTOR; en E2, en INTEGRACIÓN. La existencia de otros contenedores secundarios no incumple la regla cuando solo uno está certificado como hijo principal. Varios candidatos sin rol resuelto generan incertidumbre; más de un componente certificado simultáneamente como hijo principal constituye incumplimiento. La regla no evalúa contenido interno, condición gestionada, eventos BPMN, modelos ni otras condiciones del escenario.  
**Evidencia mínima:** Patrón identificable, inventario completo, identificación certificada de un único hijo principal, texto completo y dominio arquitectónico certificado. No se requiere certificar un evento BPMN de Inicio.
- **Cumple:** Se determina el patrón, existe exactamente un hijo principal certificado, tiene nombre válido y está en PRODUCTOR para E1/E3 o INTEGRACIÓN para E2.
- **No cumple:** El patrón y la cobertura están certificados, y no existe hijo principal; existe más de uno certificado con ese rol; el único hijo está en dominio incorrecto; o su nombre está ausente, vacío, genérico o es de plantilla.
- **No verificable:** No puede determinarse el patrón; falta cobertura; no puede certificarse el hijo; existen varios candidatos y no puede resolverse cuál tiene el rol; falta texto; o ubicación, clasificación o especificidad son ambiguas. Prioridad de estados: apartado 8 de `00-procedimiento.md`.
- **No aplica:** La página no es evaluable por ser exclusivamente plantilla o leyenda, o no contiene componentes ni candidatos pendientes que puedan configurar un hijo principal.
### CNT-003 - Contenido permitido en INTEGRACIÓN INTEGRACIÓN puede aparecer en varios contenedores con el mismo nombre (por ejemplo, uno con la API principal y otro con los auxiliares): cada uno es un dominio INTEGRACIÓN y la repetición no es incumplimiento.

**Resumen oficial:** Valida que los componentes ubicados en INTEGRACIÓN correspondan al contenido permitido para el nivel padre y, cuando exista un hijo principal dentro de este dominio, para el nivel hijo.

**Aplica a:** Dominios clasificados como INTEGRACIÓN y sus componentes contenidos, exista o no un contenedor hijo principal.

**Criterio:** En el nivel padre de INTEGRACIÓN se permiten API, eventos de integración de tipo Aplicación o Empresarial, servicios, modelos de entrada, modelos de salida, conceptos, pendientes, gestores de colas, sistemas externos auxiliares, anotaciones y capas de despliegue MCI o Federado. No se permiten compuertas, eventos BPMN operativos, políticas ni comandos.

Cuando INTEGRACIÓN contenga un hijo principal, dentro de este se permiten compuertas, eventos BPMN operativos, modelos de entrada, modelos de salida, conceptos, pendientes, políticas, comandos y anotaciones; no se permiten API, eventos de integración de tipo Aplicación o Empresarial, servicios, gestores de colas, sistemas externos auxiliares ni capas de despliegue MCI o Federado.

Para los eventos de integración encapsulados dentro de un sistema externo auxiliar prima el dominio y el nivel estructural del auxiliar: si el auxiliar está ubicado en el nivel padre de INTEGRACIÓN, se permiten eventos de tipo Aplicación o Empresarial; si está dentro del hijo principal, no se permiten eventos de integración. Los demás componentes encapsulados dentro del auxiliar, incluidos gestores de colas, se evalúan mediante EXT-001; un gestor encapsulado es admisible en este nivel.

#### Marcador de API

Un componente con `architecturalType: MARCADOR_API` es un `BPMNEvent` sin texto, sin conexiones y sin `customData`, ubicado en INTEGRACIÓN, SISTEMAS EXTERNOS, un auxiliar o una capa de despliegue, fuera del hijo principal (dentro del hijo es un evento BPMN normal). Se permite en esas ubicaciones: no se evalúa como evento BPMN operativo y no genera incumplimiento ni incertidumbre. Los marcadores que comparten grupo con una API, o que coinciden en número con los bloques sin tipo de un auxiliar o del nivel padre de un dominio sin auxiliares, no figuran en `components`: constan en `omittedComponents` con `reason: API_MARKER_EVENT` y también se excluyen. Un `BPMNEvent` sin esa clasificación se evalúa como evento BPMN (`EVENTO_BPMN`).

**Evidencia mínima:** Identificación certificada del dominio de INTEGRACIÓN, inventario completo de sus componentes, identificación del hijo principal cuando exista, jerarquía estructural suficiente para establecer si cada componente está en el nivel padre, dentro del hijo principal o encapsulado dentro de un sistema externo auxiliar, ubicación estructural del auxiliar y clasificación certificada de los componentes evaluados.

Para los eventos BPMN operativos no se requiere determinar su subtipo específico cuando puede certificarse por otra evidencia que son operativos.

- **Cumple:** La clasificación de INTEGRACIÓN y la cobertura de su contenido están certificadas, y todos los componentes evaluados están permitidos en el nivel en el que se encuentran. Los eventos de integración encapsulados dentro de sistemas externos auxiliares sí se consideran según la ubicación del auxiliar; los demás componentes internos del auxiliar se excluyen de este resultado. Los marcadores de API (`MARCADOR_API` o `API_MARKER_EVENT`) no cuentan como componentes no permitidos.

- **No cumple:** La clasificación de INTEGRACIÓN y la cobertura de su contenido están certificadas, y existe al menos un componente con clasificación certificada ubicado en un nivel en el que no está permitido. Un BPMNEvent con conexiones, texto funcional o subtipo operativo en el nivel padre es un evento operativo no permitido.

- **No verificable:** Corresponde este estado cuando no puede determinarse si un BPMNEvent tiene conexiones o texto; existe uno o más contenedores que podrían corresponder a INTEGRACIÓN pero su clasificación es indeterminada, ambigua o contradictoria; el contenido del dominio no tiene cobertura suficiente, no puede determinarse el nivel estructural de un componente o su clasificación incluye categorías permitidas y no permitidas. Prioridad de estados: apartado 8 de `00-procedimiento.md`. La imposibilidad de determinar el subtipo específico de un evento BPMN operativo no genera por sí sola este estado cuando puede certificarse que no corresponde a un evento de integración.

- **No aplica:** Se ha certificado que la página no contiene un dominio de INTEGRACIÓN ni contenedores pendientes de clasificación que puedan corresponder a este dominio.

### CNT-004 - Contenido permitido en DOMINIO PRODUCTOR

**Resumen oficial:** Valida que los componentes ubicados en el DOMINIO PRODUCTOR correspondan al contenido permitido para el nivel padre y, cuando exista un hijo principal dentro de este dominio, para el nivel hijo.

**Aplica a:** Dominios clasificados como DOMINIO PRODUCTOR y sus componentes contenidos, exista o no un contenedor hijo principal.

**Criterio:** En el nivel padre del DOMINIO PRODUCTOR se permiten eventos de integración de tipo Aplicación, servicios, modelos de entrada, modelos de salida, conceptos, pendientes, gestores de colas, sistemas externos auxiliares, anotaciones y capas de despliegue MCI o Federado. No se permiten API, eventos de integración de tipo Empresarial, compuertas, eventos BPMN operativos, políticas ni comandos. Cuando el DOMINIO PRODUCTOR contenga un hijo principal, dentro de este se permiten compuertas, eventos BPMN operativos, modelos de entrada, modelos de salida, conceptos, pendientes, políticas, comandos y anotaciones; no se permiten API, eventos de integración de tipo Aplicación o Empresarial, servicios, gestores de colas, sistemas externos auxiliares ni capas de despliegue MCI o Federado. Para los eventos de integración encapsulados dentro de un sistema externo auxiliar prima el dominio y el nivel estructural del auxiliar: si el auxiliar está ubicado en el nivel padre del DOMINIO PRODUCTOR, solo se permiten eventos de tipo Aplicación; los eventos de tipo Empresarial no están permitidos. Si el auxiliar está dentro del hijo principal, no se permite ningún evento de integración. Los demás componentes encapsulados dentro del auxiliar, incluidos gestores de colas, se evalúan mediante EXT-001; un gestor encapsulado es admisible en este nivel. La regla no exige la identificación del subtipo específico de los eventos BPMN operativos cuando la evidencia disponible no permita determinarlo.

**Evidencia mínima:** Identificación certificada del DOMINIO PRODUCTOR, inventario completo de sus componentes, identificación del hijo principal cuando exista, jerarquía estructural suficiente para establecer si cada componente está fuera o dentro del hijo o encapsulado dentro de un sistema externo auxiliar, ubicación estructural del auxiliar y clasificación certificada de los componentes evaluados. Para los eventos BPMN operativos no se requiere determinar si corresponden específicamente a Inicio, Fin, Señal, Mensaje, Excepción, Mensaje de Excepción u otro subtipo cuando dicha información no esté disponible.

- **Cumple:** La clasificación del DOMINIO PRODUCTOR y la cobertura de su contenido están certificadas, y todos sus componentes están permitidos en el nivel en el que se encuentran: nivel padre o nivel hijo.

- **No cumple:** La clasificación del DOMINIO PRODUCTOR y la cobertura de su contenido están certificadas, y existe al menos un componente con clasificación certificada ubicado en un nivel en el que no está permitido.

- **No verificable:** Existe uno o más contenedores que podrían corresponder al DOMINIO PRODUCTOR, pero su clasificación es indeterminada, ambigua o contradictoria; el contenido del dominio no tiene cobertura suficiente; no puede determinarse si un componente está fuera o dentro del hijo principal; o la clasificación de algún componente es indeterminada, ambigua o contradictoria y sus posibles clasificaciones incluyen categorías permitidas y prohibidas para el nivel en el que se encuentra. La imposibilidad de determinar el subtipo específico de un evento BPMN operativo no genera por sí sola este estado cuando puede certificarse que no corresponde a un evento de integración.

- **Contenedor con roles posibles PRODUCTOR y SISTEMAS EXTERNOS:** mientras no pueda certificarse cuál de los dos es, esta regla queda **No verificable** aunque CNT-001 cumpla; no se declara No aplica, porque el contenedor es candidato a este dominio. Si la analista o el JSON precisan después el dominio, solo la regla del dominio correspondiente se evalúa y la otra pasa a No aplica.

- **No aplica:** Se ha certificado que la página no contiene un DOMINIO PRODUCTOR ni contenedores pendientes de clasificación que puedan corresponder a este dominio.

### CNT-005 - Contenido permitido en SISTEMAS EXTERNOS

**Resumen oficial:** Valida que los componentes ubicados directamente en SISTEMAS EXTERNOS correspondan al contenido permitido para este dominio.

**Aplica a:** Dominios clasificados como SISTEMAS EXTERNOS y a los componentes contenidos directamente en ellos.

**Criterio:** En SISTEMAS EXTERNOS se permiten API, servicios, modelos de entrada, modelos de salida, pendientes, conceptos, sistemas externos auxiliares y anotaciones. No se permiten eventos de integración de tipo Aplicación o Empresarial, gestores de colas, capas de despliegue MCI o Federado, compuertas, eventos BPMN operativos, políticas ni comandos. Un sistema externo auxiliar no es el dominio SISTEMAS EXTERNOS: sin un contenedor padre con `domainRole: EXTERNAL_SYSTEM` (`inventory.contenedoresPadre`) y sin uno cuyo `possibleDomainRoles` lo incluya, la regla es `No aplica`.

Los eventos de integración encapsulados dentro de un sistema externo auxiliar ubicado en SISTEMAS EXTERNOS tampoco están permitidos, porque prima el dominio arquitectónico raíz. Los demás componentes encapsulados dentro del auxiliar se excluyen de esta regla y se evalúan mediante EXT-001. Un gestor de colas encapsulado en un auxiliar ubicado en SISTEMAS EXTERNOS está prohibido por EXT-001.

#### Marcador de API

Un componente con `architecturalType: MARCADOR_API` es un `BPMNEvent` sin texto, sin conexiones y sin `customData`, ubicado en INTEGRACIÓN, SISTEMAS EXTERNOS, un auxiliar o una capa de despliegue, fuera del hijo principal (dentro del hijo es un evento BPMN normal). Se permite en esas ubicaciones: no se evalúa como evento BPMN operativo y no genera incumplimiento ni incertidumbre. Los marcadores que comparten grupo con una API, o que coinciden en número con los bloques sin tipo de un auxiliar o del nivel padre de un dominio sin auxiliares, no figuran en `components`: constan en `omittedComponents` con `reason: API_MARKER_EVENT` y también se excluyen. Un `BPMNEvent` sin esa clasificación se evalúa como evento BPMN (`EVENTO_BPMN`).

**Evidencia mínima:** Identificación certificada del dominio de SISTEMAS EXTERNOS, inventario completo de sus componentes, jerarquía estructural suficiente para diferenciar los componentes ubicados directamente en el dominio de aquellos encapsulados dentro de un sistema externo auxiliar y clasificación certificada de los componentes evaluados. Para los eventos BPMN operativos no se requiere determinar su subtipo específico cuando puede certificarse por otra evidencia que son operativos.

- **Cumple:** La clasificación del dominio de SISTEMAS EXTERNOS y la cobertura de su contenido están certificadas, y todos los componentes evaluados corresponden a categorías permitidas. Los eventos de integración encapsulados dentro de sistemas externos auxiliares sí se consideran y no están permitidos; los demás componentes internos del auxiliar se excluyen de este resultado. Los marcadores de API (`MARCADOR_API` o `API_MARKER_EVENT`) no cuentan como componentes no permitidos.

- **No cumple:** La clasificación del dominio de SISTEMAS EXTERNOS y la cobertura de su contenido están certificadas, y existe al menos un componente con clasificación certificada ubicado directamente en el dominio que corresponde a una categoría no permitida. Un BPMNEvent con conexiones, texto funcional o subtipo operativo directamente en SISTEMAS EXTERNOS es un evento operativo no permitido.

- **No verificable:** Corresponde este estado cuando no puede determinarse si un BPMNEvent tiene conexiones o texto; existe uno o más contenedores que podrían corresponder a SISTEMAS EXTERNOS pero su clasificación es indeterminada, ambigua o contradictoria; el contenido del dominio no tiene cobertura suficiente, no puede determinarse si un componente está directamente en el dominio o encapsulado en un auxiliar, o su clasificación incluye categorías permitidas y no permitidas. Prioridad de estados: apartado 8 de `00-procedimiento.md`. La imposibilidad de determinar el subtipo específico de un evento BPMN operativo no genera por sí sola este estado cuando puede certificarse que no corresponde a un evento de integración.

- **Contenedor con roles posibles PRODUCTOR y SISTEMAS EXTERNOS:** mientras no pueda certificarse cuál de los dos es, esta regla queda **No verificable** aunque CNT-001 cumpla. No se declara No aplica porque el contenedor es candidato a este dominio. Si la analista o el JSON precisan después el dominio, solo la regla del dominio correspondiente se evalúa y la otra pasa a No aplica.

- **No aplica:** Se ha certificado que la página no contiene un dominio de SISTEMAS EXTERNOS ni contenedores pendientes de clasificación que puedan corresponder a este dominio.

### EXT-001 - Identificación y contenido del sistema externo auxiliar

**Resumen oficial:** Valida que cada sistema externo auxiliar tenga un nombre y encapsule únicamente componentes permitidos para su ubicación.

**Aplica a:** Componentes certificados como sistemas externos auxiliares, independientemente del nombre visible utilizado para identificarlos.

**Criterio:** Todo sistema externo auxiliar debe tener un nombre visible y no vacío; se admite cualquier nombre, incluido “Sistema Externo”. Puede encapsular capas de despliegue, API, servicios, eventos de integración, modelos de entrada y salida (`MODELO`), pendientes, conceptos y anotaciones. Un auxiliar cuyo nombre contenga EVC, EPC o LDC como palabra completa no puede encapsular servicios.

Puede encapsular gestores de colas cuando el auxiliar esté ubicado en el nivel padre de INTEGRACIÓN o en el nivel padre del DOMINIO PRODUCTOR; no puede encapsularlos cuando esté ubicado en SISTEMAS EXTERNOS, dentro del hijo principal o dentro de otro sistema externo auxiliar.

Puede encapsular capas de despliegue MCI o Federado únicamente cuando esté ubicado en el nivel padre de INTEGRACIÓN. Los eventos de integración se admiten según el dominio arquitectónico raíz y el nivel estructural del auxiliar mediante CNT-003, CNT-004 o CNT-005. Cualquier otro tipo de componente está prohibido.

#### Marcador de API

Un componente con `architecturalType: MARCADOR_API` es un `BPMNEvent` sin texto, sin conexiones y sin `customData`, ubicado en INTEGRACIÓN, SISTEMAS EXTERNOS, un auxiliar o una capa de despliegue, fuera del hijo principal (dentro del hijo es un evento BPMN normal). Se permite en esas ubicaciones: no se evalúa como evento BPMN operativo y no genera incumplimiento ni incertidumbre. Los marcadores que comparten grupo con una API, o que coinciden en número con los bloques sin tipo de un auxiliar o del nivel padre de un dominio sin auxiliares, no figuran en `components`: constan en `omittedComponents` con `reason: API_MARKER_EVENT` y también se excluyen. Un `BPMNEvent` sin esa clasificación se evalúa como evento BPMN (`EVENTO_BPMN`).

**Evidencia mínima:** Identificación certificada del sistema externo auxiliar, texto completo de su nombre, inventario completo de componentes encapsulados, clasificación certificada de dichos componentes y ubicación estructural y dominio raíz certificados cuando contenga gestores de colas, eventos de integración, BPMNEvent o capas de despliegue.

- **Cumple:** El auxiliar tiene nombre visible y no vacío, encapsula al menos un componente y todos sus componentes están permitidos para su ubicación. Los gestores solo aparecen en auxiliares del nivel padre de INTEGRACIÓN o PRODUCTOR; las capas de despliegue solo en auxiliares del nivel padre de INTEGRACIÓN; y los eventos satisfacen CNT-003, CNT-004 o CNT-005. Los marcadores de API (`MARCADOR_API` o `API_MARKER_EVENT`) no cuentan como componentes no permitidos.

- **No cumple:** La evidencia y cobertura están certificadas, y el nombre está ausente o vacío; el auxiliar contiene una categoría no permitida; contiene un gestor de colas fuera del nivel padre de INTEGRACIÓN o PRODUCTOR; contiene una capa de despliegue fuera del nivel padre de INTEGRACIÓN; o contiene un evento de integración prohibido para el dominio raíz y nivel estructural. Un BPMNEvent con conexiones, texto funcional o subtipo operativo dentro del auxiliar es un evento operativo no permitido.

- **No verificable:** Corresponde este estado cuando no puede determinarse si un BPMNEvent tiene conexiones o texto; el auxiliar no encapsula componentes o no puede certificarse si encapsula alguno; el inventario no tiene cobertura suficiente; el tipo de un componente no está determinado; su clasificación incluye categorías permitidas y prohibidas; o no puede determinarse la ubicación o el dominio raíz cuando condiciona el contenido permitido. Prioridad de estados: apartado 8 de `00-procedimiento.md`. Requiere revisión manual del analista.

- **No aplica:** La página no contiene sistemas externos auxiliares certificados ni candidatos pendientes de clasificación como tales.

### EXT-002 - Ubicación del sistema externo auxiliar
  
**Resumen oficial:** Valida la ubicación de todos los sistemas externos auxiliares y la restricción especial de los auxiliares EVC, EPC o LDC que encapsulan API.  
**Aplica a:** Todos los componentes certificados como sistemas externos auxiliares.  
**Criterio:** Un sistema externo auxiliar puede estar ubicado directamente en el nivel padre de INTEGRACIÓN, DOMINIO PRODUCTOR o SISTEMAS EXTERNOS. No puede estar dentro de un hijo principal, dentro de otro sistema externo auxiliar ni en un nivel diferente de los tres permitidos. Adicionalmente, cuando su nombre contenga EVC, EPC o LDC como palabra completa, sin distinguir mayúsculas y minúsculas, y encapsule al menos una API certificada, debe estar ubicado en el nivel padre de INTEGRACIÓN. Si encapsula solo eventos de integración de tipo Aplicación, también puede estar en el nivel padre del DOMINIO PRODUCTOR. Un auxiliar sin esas palabras en INTEGRACIÓN no incumple.
La regla evalúa exclusivamente la ubicación del auxiliar. Su nombre y contenido permitido se evalúan mediante EXT-001; sus conexiones mediante COM o MQ; y el nombramiento de sus componentes internos mediante las reglas específicas.  
**Evidencia mínima:** Identificación certificada del auxiliar, jerarquía estructural suficiente para determinar dominio arquitectónico y nivel, texto completo de su nombre y, para la condición especial EVC/EPC/LDC, identificación certificada de las API encapsuladas.
- **Cumple:** Cada auxiliar está directamente en el nivel padre de INTEGRACIÓN, PRODUCTOR o SISTEMAS EXTERNOS; y todo auxiliar EVC, EPC o LDC que encapsula una API está específicamente en el nivel padre de INTEGRACIÓN.
- **No cumple:** La evidencia está certificada y un auxiliar está dentro de un hijo principal, dentro de otro auxiliar o fuera de los niveles padre permitidos; o un auxiliar EVC, EPC o LDC con una API está en PRODUCTOR, SISTEMAS EXTERNOS o cualquier ubicación distinta del nivel padre de INTEGRACIÓN.
- **No verificable:** No puede certificarse el auxiliar, su padre inmediato, cadena de ancestros, dominio raíz o nivel estructural; o, para la condición especial, no puede determinarse el nombre completo, si contiene EVC/EPC/LDC, si el componente encapsulado es una API o si pertenece al auxiliar. Prioridad de estados: apartado 8 de `00-procedimiento.md`.
- **No aplica:** La página no contiene sistemas externos auxiliares certificados ni candidatos pendientes de clasificación como tales.
### GW-001 - Coherencia textual de los caminos de la compuerta

**Resumen oficial:** Valida la coherencia entre el texto de una compuerta BPMN y las respuestas o etiquetas de sus caminos conectados.

**Aplica a:** Componentes certificados como compuertas BPMN.

**Criterio:** Cuando una compuerta contiene una pregunta o texto de decisión, sus caminos deben incluir respuestas o etiquetas que permitan reconocer de forma coherente las alternativas resultantes. Una pregunta binaria puede utilizar respuestas como “Sí” y “No”; cuando existan más de dos alternativas, cada camino debe tener una etiqueta que permita distinguir la opción que representa. También es válido que una compuerta no tenga texto y que sus caminos no tengan respuestas o etiquetas, siempre que no exista información parcial que requiera relacionarlos. La regla no evalúa el subtipo de la compuerta ni las condiciones BPMN específicas de compuertas paralelas, exclusivas, basadas en eventos o paralelas basadas en eventos.

**Evidencia mínima:** Identificación certificada de la compuerta BPMN, texto completo de la compuerta cuando exista, inventario completo de sus caminos conectados y texto de las respuestas o etiquetas asociadas a dichos caminos. No se requiere identificar el subtipo de la compuerta.

- **Cumple:** La compuerta y sus caminos tienen cobertura suficiente, y se presenta alguna de las siguientes situaciones: la compuerta contiene una pregunta o decisión y sus caminos tienen respuestas o etiquetas coherentes que permiten distinguir las alternativas; o la compuerta no contiene texto y sus caminos tampoco contienen respuestas o etiquetas que requieran interpretación.

- **No cumple:** La evidencia textual y la cobertura de los caminos están certificadas, y las respuestas o etiquetas contradicen el texto de la compuerta, no corresponden a la pregunta planteada o no permiten distinguir los caminos cuando existen varias alternativas que requieren identificación.

- **No verificable:** No puede determinarse el texto completo de la compuerta o de sus caminos; no se tiene cobertura suficiente de las conexiones; la compuerta contiene una pregunta o decisión, pero faltan las respuestas o etiquetas necesarias para interpretar sus alternativas; los caminos contienen respuestas o etiquetas, pero falta el texto que permita establecer su significado; o la información disponible no permite concluir si el conjunto es coherente. La imposibilidad de identificar el subtipo de la compuerta no genera por sí sola este estado.

- **No aplica:** La página no contiene componentes certificados como compuertas BPMN ni candidatos pendientes de clasificación como tales.

