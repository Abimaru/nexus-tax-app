## Procedimiento de validación - v11.8.6

### 1. Precedencia de evidencia

- Contrato soportado: `copilot-factual-v0.4.6.1`.
- Priorizar evidencia literal: `components[].textAreas`, `customData`, identificadores y `connections`.
- Tratar `structuralParent`, `containerChainIds`, `rootContainer` y `architecturalDomain` como propiedades diferentes.
- Usar `domainRole`, `possibleDomainRoles`, `inference`, `deploymentAssociations` y `scenario` considerando estado, fuente y conflictos.
- Un campo ausente, `null`, candidato, ambiguo o contradictorio no constituye evidencia positiva.
- El agente no infiere `EXTERNAL_SYSTEM` por descarte. Solo usa el dominio que entrega el JSON con su fuente: el Studio puede asignarlo en E1 y E3 por descarte (`roleSource: E1_ELIMINATION` o `E3_ELIMINATION`, `roleStatus: INFERRED_BY_ELIMINATION`) y ese valor se toma tal como viene, indicando su fuente.
- Una declaración de la analista no sustituye texto, contención, conexiones, asociaciones, tipo arquitectónico ni subtipo BPMN.
- Usar `architecturalType`, `role` y `domainRole` tal como vienen: no corregirlos ni deducirlos por nombre, color, posición o cercanía. `architecturalType: null` es tipo no determinado.
- `inference.status: AMBIGUOUS` con `contradictions` son señales en conflicto: explicar el conflicto y no elegir tipo. Con varios hijos candidatos (`MULTIPLE_CHILD_CANDIDATES`), no elegir.
- El hijo va en el dominio productor en E1 y E3, y en INTEGRACIÓN en E2. Un sistema externo no puede contenerlo (`CHILD_INSIDE_EXTERNAL_SYSTEM`): se explica como conflicto.
- Capas de despliegue (Capa de Arquitectura, Flujo Transaccional, Federado): no son un nivel. Un componente con `ubicacion.capaId` se evalúa en CNT-003, CNT-004 o CNT-005 con el `ubicacion.nivel` y el `ubicacion.dominio` que trae el inventario; si el nivel es `PADRE` se evalúa como contenido del nivel padre del dominio, igual que si no estuviera dentro de la capa. Un componente con `ubicacion.nivel: OTRO` (contenedor intermedio sin tipo, también dentro de una capa) no tiene nivel determinado: es `No verificable` para ese componente en CNT-003, CNT-004 y CNT-005, y no se le atribuye nivel padre.
- Dominios sin nombre literal: en E2 solo INTEGRACIÓN es seguro; el otro queda con `possibleDomainRoles` y no se clasifica (CNT-004 y CNT-005, `No verificable`).
- `omittedComponents` y `inventory.omitidos` listan figuras omitidas a propósito (`DefaultSquareBlock` aislado, BPMN Event marcador de API): no son evidencia faltante, no se reclaman ni se cuentan como eventos del flujo.
- Evaluar solo las páginas de `metadata.selectedPageIds` y reconocer las omitidas (`metadata.omittedPages`).

### 2. Controles previos de integridad

Antes de evaluar una página, comprobar:

- identificadores únicos;
- referencias a componentes existentes;
- contención sin ciclos;
- coherencia entre padre inmediato y cadena de ancestros;
- participantes existentes en las conexiones;
- conflictos y pérdidas registrados en `issues`.

Las inconsistencias del JSON no son incumplimientos arquitectónicos. Las reglas afectadas quedan `No verificable`.

### 3. Subtipos BPMN

La identificación genérica `BPMNEvent` no certifica el subtipo.

- Inicio: E1-001, E2-001 y E3-001.
- Señal de Envío o Recepción: EVT-007.
- Mensaje: MQ-003.

Si el subtipo requerido no puede certificarse, solo las reglas que dependan de él quedan `No verificable`. No inferirlo por texto, posición, cercanía o ubicación.

### 4. Capa de Despliegue

- MCI se demuestra mediante Capa de Arquitectura y Flujo Transaccional cuando la regla aplicable los exija.
- Las capas de despliegue son solo figuras `UMLRectangleContainerBlock`; un texto suelto `Federado`, `Capa de Arquitectura` o `Flujo Transaccional` no se considera.
- Federada se demuestra mediante el valor literal `Federado`: figura con `architecturalType: FEDERADO` asociada al componente por una entrada `modality: FEDERADO` en `deploymentAssociations`.
- CA-001 valida únicamente el nombre de las Capas de Arquitectura existentes.
- FT-001 valida únicamente el nombre de los Flujos Transaccionales existentes.
- API-004, SRV-004 y MQ-002 validan obligatoriedad y asociación.
- La asociación no se demuestra por cercanía, alineación, superposición ni pertenencia al mismo contenedor.

#### 4.1 Precedencia de asociaciones de despliegue y de tópicos

Para API-004, SRV-004, MQ-002, EVT-004 y EVT-005 (Capa de Tópicos del evento de integración) revisar conjuntamente:

- `components[].deploymentAssociations` del componente evaluado;
- `pages[].deploymentAssociations` de la página;
- las entradas `modality: FEDERADO` (figura `Federado` asociada por contención; `PENDING_NO_CONTAINED_COMPONENT` es una figura sin propietario y cuenta como candidata);
- grupos y grupos superiores usados para resolver la asociación;
- una Capa o un Flujo cuyo único contenido es un marcador de API (`MARCADOR_API` u omitido) queda sin propietario (`associatedComponentId: null`, `candidateIds` vacío, el marcador en `markerIds`): el marcador es contenido, no dueño, y la pareja es candidata;
- estado, propietario, conflictos y candidatos.

Interpretar la evidencia en este orden:

1. Una asociación resuelta con el componente demuestra pertenencia.
2. Una asociación resuelta con otro componente demuestra únicamente la pertenencia a ese otro componente.
3. Una asociación pendiente, ambigua, en conflicto o sin propietario es candidata (en API-004 no bloquea si la API principal ya tiene resueltas las exigidas). Incluye `associatedComponentId: null`, `PENDING_NO_COMMON_SUPERIOR_GROUP` y cualquier estado que no certifique inequívocamente el propietario.
4. La ausencia solo queda certificada cuando la cobertura es completa, no hay asociación resuelta con el componente y tampoco existen candidatos que puedan pertenecerle.

Un arreglo vacío en `components[].deploymentAssociations` no demuestra por sí solo ausencia cuando `pages[].deploymentAssociations` contiene pares Capa-Flujo pendientes de propietario. La imposibilidad de demostrar pertenencia no equivale a demostrar ausencia: la declaración MCI hace aplicable la obligación, pero no demuestra la asociación, y una asociación candidata pendiente conduce a `No verificable`; si hay otra evidencia independiente de incumplimiento, se cita en la justificación (apartado 8). Debe revisarse la página antes de concluir ausencia a partir del arreglo vacío del componente.

### 5. Preguntas a la analista

Las preguntas autorizadas se realizan en un único bloque, después de identificar los componentes y antes de cerrar las reglas dependientes. Las de la API principal se agrupan por nombre de API (apartado 5.4): una sola vez aunque el BP tenga varias páginas con esa API.

Registrar cada respuesta como `DECLARADO_POR_ANALISTA`, vinculada a página, ID, nombre visible, pregunta y respuesta; una respuesta agrupada se vincula a cada página e ID a los que aplica.

Las preguntas son la única pausa del proceso. Si una página no tiene ninguna pregunta aplicable (por ejemplo E3, o sin API principal ni hijo principal certificados), no se pide confirmación ni se espera respuesta: se continúa con las 38 reglas y se entrega el resultado.

#### 5.1 Preguntas obligatorias

La pregunta es obligatoria: el agente no puede omitirla ni suponer la respuesta, salvo la excepción expresa del hijo principal de E1 (apartado 5.5). Se hace aunque `scenario.status` sea `HIPOTESIS`, porque `HIPOTESIS` describe el escenario y no impide identificar la API principal ni el hijo principal.

Cuando el JSON entregue una API principal (`architecturalType: API` y `role: PRINCIPAL`), preguntar:

> ¿La API principal “[nombre]” (`[id]`) tiene Capa de Despliegue MCI?

Cuando el JSON entregue un único hijo principal (`architecturalType: SERVICIO_HIJO` y `role: INVOCADO`) en E2, preguntar por cada hijo (una pregunta por ID, también si el BP tiene varias páginas E2):

> ¿El hijo principal “[nombre]” (`[id]`), que representa el servicio principal del escenario, tiene Capa de Despliegue MCI?

Si no hay API principal o hijo principal (`scenario.status: NO_DETERMINADO` o candidatos ambiguos), no se pregunta por ese componente. No evaluar API-004 mientras falte la respuesta sobre la API principal: queda `No verificable` por falta de la declaración MCI. SRV-004 usa la respuesta sobre el hijo principal de E2: sin ella no se evalúa la Capa de Despliegue del hijo (queda `No verificable`); en E1 usa el supuesto no MCI (apartado 5.5); para los servicios invocados gestionados no depende de ninguna declaración MCI.

No preguntar por la condición MCI del componente o servicio principal de E3: en E3 no se hace ninguna pregunta. Tampoco preguntar por un “servicio principal” adicional cuando corresponde al mismo hijo principal: una sola pregunta por ID.

#### 5.2 Exposición de la API principal

Leer la exposición en la tercera sección de la API principal, sin distinguir mayúsculas, y homologarla solo para decidir la pregunta: `privada` es `private`; `pública` o `publica` es `public`; `partner` no se homologa. Si ya viene `private`, `public` o `partner` (en inglés), no se pregunta. Si no viene ninguno, preguntar, aunque la API ya se haya declarado no MCI, una vez por nombre de API (apartado 5.4) y solo por las páginas que no lo traen:

> ¿Cuál es la exposición de la API principal “[nombre]” (`[id]`): private, public o partner?

La homologación y la respuesta solo sirven a API-004. No sustituyen el texto escrito: API-003 se evalúa siempre con el texto del JSON y exige el valor exacto en inglés y minúsculas (`privada` o `Private` incumplen aunque se homologuen).

#### 5.3 Alcance de las respuestas

Las respuestas pueden determinar aplicabilidad, pero no demuestran existencia ni asociación de Capa, Flujo o `Federado`, ni corrigen API-003 u otra regla textual.

No preguntar por candidatos ambiguos ni usar una respuesta para certificar tipo o rol. No reutilizar una respuesta en otra página sin confirmación explícita.

#### 5.4 Agrupación por nombre de API

Entre las páginas evaluables seleccionadas con API principal certificada, agrupar por el nombre de la API: la primera sección del texto (producto, nombre y versión), sin distinguir mayúsculas, tildes ni espacios repetidos. La operación (segunda sección) no entra en la comparación.

- Un nombre repetido en varias páginas lleva una sola pregunta de condición MCI de la API, que cita cada «Nombre (id)» de las páginas afectadas. La respuesta se aplica a todas y se registra vinculada a cada página e ID.
- Nombres distintos (incluida otra versión) llevan preguntas separadas.
- La exposición se pregunta una vez por nombre de API, solo por las páginas cuya tercera sección no traiga `private`, `public` ni `partner`. Cada página que la trae usa la suya, aunque difiera de la de otra página con el mismo nombre.
- La pregunta del hijo principal de E2 no se agrupa: se hace por cada hijo.
- Si una misma API aparece en páginas E1 y E2, la pregunta de la API es una sola y la del hijo se hace solo por las páginas E2.

#### 5.5 Hijo principal de E1: supuesto no MCI

En E1 no se pregunta por el hijo principal: se da por no MCI. Es un supuesto de la Skill y no una respuesta de la analista; se registra como `SUPUESTO_E1_HIJO_NO_MCI` vinculado al ID del hijo y a su página. SRV-004 lo evalúa como a un hijo declarado no MCI (ficha de SRV-004): sin Capa de Arquitectura ni Flujo Transaccional asociados es `Cumple`; con alguno asociado inequívocamente es `No cumple`; un par Capa-Flujo sin propietario ubicado en el DOMINIO PRODUCTOR es candidato del hijo y produce `No verificable` (uno ubicado en INTEGRACIÓN no es del hijo).

### 6. Precedencia de conexiones

Cada conexión (pareja de `inventory.relaciones`) se evalúa en una sola regla, la que asigna la tabla de parejas de `08-fichas.md` según su `par`. Las API y los servicios encapsulados conservan su tipo funcional, también dentro de un auxiliar. Una conexión con un comando nunca se evalúa en SRV-005 ni en MQ-003, aunque el otro participante sea un candidato. Un participante con `certeza: CANDIDATO` solo afecta a las reglas de su pareja, y las deja en `No verificable`.

#### 6.1 Conexión pendiente

Una línea es pendiente si su `estado` no es `DECLARED`, si trae `extremoSinConectar`, o si uno de sus participantes es de tipo `LINEA` o `DESCONOCIDO`. Todas constan en `inventory.conexionesPendientes`. Para un participante `LINEA`, los extremos de esa línea están en `conecta`.

- Una conexión pendiente es un candidato: no se atribuye a una regla por suposición ni se declara faltante.
- Deja en `No verificable` toda regla de conexión cuya población pudiera contenerla, según el tipo conocido de sus participantes: comando (COM-002 a COM-005), API (COM-002), servicio invocado (SRV-005), servicio (COM-003 y MQ-003), gestor (COM-004 y MQ-003), auxiliar (COM-005 y SRV-005), compuerta (GW-001), evento (EVT-007 y la regla del escenario si es el Inicio).
- Si un participante de una pareja incompleta tiene una conexión pendiente, la pareja no se declara incompleta: la regla queda `No verificable`. Con más de una pareja evaluada, una pendiente basta para `No verificable`; los incumplimientos certificados de otras parejas se citan en la justificación.

#### 6.2 Lectura de una pareja

Cada línea trae `origen`, `destino`, `estiloOrigen` y `estiloDestino` ya resueltos por el Studio: no se deducen del dibujo. Una pareja tiene sus dos sentidos cuando existe una línea con origen A y destino B y otra con origen B y destino A. Las terminaciones exigidas las define cada regla. Una línea con `estilos` en lugar de `estiloOrigen` y `estiloDestino` tiene la orientación indeterminada.

#### Reconocimiento de tipos

El Studio certifica el tipo con estas reglas (`inference.rule`), en este orden de prioridad:

1. Evento de integración: la tercera sección declara tipo (Aplicación o Empresarial) y clasificación (Event, Query o Command) (`INTEGRATION_EVENT_BY_THIRD_SECTION`). Gana sobre el tipo de API. Con solo una de las dos partes es candidato.
2. Servicio explícito: `ms` al inicio o al final del título, la palabra `microservicio` o `microservice` en el título, o `customData` `TIPO: SERVICIO` (`SERVICE_BY_MS_NAMING`, `SERVICE_BY_CUSTOMDATA`). Gana sobre toda inferencia de API, también dentro de un auxiliar EVC, EPC o LDC (EXT-001 lo evalúa). Junto con un marcador agrupado es una señal contradictoria (`AMBIGUOUS`).
3. API explícita, en cualquier dominio (CNT-004 prohíbe las API en el DOMINIO PRODUCTOR): marcador de API en el mismo grupo (`API_BY_EMPTY_BPMN_EVENT_GROUP`), o Public, Private, Partner, Privada o Pública en la tercera sección, sin distinguir mayúsculas (`API_BY_EXPOSURE_TYPE`; API-003 valida su escritura).
4. API por ámbito (nunca en el DOMINIO PRODUCTOR). El ámbito es el auxiliar (con o sin texto), la Capa o el Flujo y, fuera de ellos, el nivel padre del dominio (o el contenedor raíz si la figura no está en un dominio). Los bloques UML sin señal propia del ámbito se cuentan contra sus `BPMNEvent` vacíos y sin conexiones:
   - en un auxiliar con EVC, EPC o LDC en INTEGRACIÓN o SISTEMAS EXTERNOS, el bloque es API (`API_BY_EVC_AUXILIAR`);
   - en cualquier otro ámbito, si los marcadores igualan a los bloques, todos son API (`API_BY_MARKER_COUNT_IN_AUXILIAR`) y los marcadores constan en `omittedComponents`;
   - si no coinciden, los bloques son candidatos.
5. Servicio por dominio: bloque UML sin otra señal en el DOMINIO PRODUCTOR, fuera del hijo principal (`SERVICE_BY_PRODUCER_DOMAIN`). El hijo principal es el contenedor que señala `scenario.mainChildServiceId`; el dominio que lo envuelve no es el hijo.
6. Servicio por falta de marcador (`SERVICE_BY_NO_MARKER_IN_SCOPE`): en un ámbito sin ningún marcador, cada bloque sin otra señal es servicio, también con Entidad, Utilidad o Tarea. No aplica a los nombres de plantilla («Nombre Servicio», «Nombre API», «Nombre Evento»), que tampoco se cuentan. En el nivel padre solo si el dominio no tiene un marcador huérfano (en una Capa, un Flujo o un auxiliar sin ningún bloque); con uno, el bloque suelto es candidato.
7. Comando (`COMANDO`): `BPMNActivity` con una conexión a una API, un servicio, un gestor de colas o un auxiliar (o a un candidato a API, servicio o gestor) (`COMMAND_BY_CONNECTION`). Una actividad sin esa conexión, las anotaciones, los conceptos y los pendientes quedan sin tipo y no son candidatos. `BPMNGateway` es `COMPUERTA` y `BPMNEvent` es `EVENTO_BPMN` (no es evento de integración).

8. Capa de Tópicos (`CAPA_TOPICOS`, `TOPIC_LAYER_BY_CONTAINED_INTEGRATION_EVENT`): contenedor `UMLRectangleContainerBlock` que no es dominio, Flujo, Capa de Arquitectura ni Federado y que contiene directamente un evento de integración certificado. Su texto son los tópicos (`inventory.capasTopicos[].topicos`, uno por palabra) y `eventoIds` son los eventos que contiene. Si solo contiene un candidato a evento, es candidata (`["CAPA_TOPICOS"]`). El nombre del contenedor no la certifica.

Todo `BPMNGroup` dentro de un dominio es sistema externo auxiliar, tenga o no texto (EXT-001 exige el nombre).

Un **candidato** tiene `architecturalType: null` y `possibleTypes`: `["API","SERVICIO"]` (marcadores sin agrupar cuyo número no coincide con el de bloques, bloque suelto con un marcador huérfano en el dominio, o nombre de plantilla), `["EVENTO_INTEGRACION"]` (título exacto «Nombre Evento», o tercera sección con solo el tipo o solo la clasificación) `["CAPA_TOPICOS"]` (contenedor que solo contiene un candidato a evento) o `["GESTOR_COLAS"]` (figura que no es gestor con cola(s), MQ, Kafka o Rabbit en el nombre). Entidad, Utilidad o Tarea no son señal de tipo. Un candidato nunca es `No aplica`: afecta a las reglas de su tipo y, en las reglas de conexión, solo a las de su pareja (apartado 6). Los roles son solo `PRINCIPAL` (la API de E1 y E2 o el servicio de E3) e `INVOCADO` (cualquier otra API, servicio, evento de integración, gestor, el hijo principal y los candidatos).

Un `BPMNEvent` sin texto, conexiones ni `customData`, fuera del hijo y ubicado en INTEGRACIÓN, SISTEMAS EXTERNOS, un auxiliar o una capa de despliegue es `MARCADOR_API`; dentro del hijo es un evento BPMN normal.

#### Servicios

- servicio invocado con API invocada, otro servicio invocado o auxiliar (también cuando encapsula API o servicios): SRV-005, que además prohíbe la conexión servicio invocado-evento. El servicio principal de E3 queda fuera de SRV-005: su línea hacia el evento de Inicio la evalúa E3-001;
- servicio con gestor de colas: MQ-003;
- API con API, o API con auxiliar sin servicio: ninguna regla las evalúa.

Cada conexión se asigna a una sola regla. Si participante o tipo no puede determinarse, la regla afectada queda `No verificable`.

### 7. Flujo por página

- `OPERATIONAL`: evaluable; produce 38 resultados.
- `MIXED`: evaluable; produce 38 resultados.
- `TEMPLATE_OR_LEGEND` y `BDD_OR_REQUIREMENTS`: no evaluable; informar página, tipo y motivo.
- `UNRESOLVED`: no emitir dictamen; informar que la página no pudo clasificarse.

Una página no evaluable no genera resultados por regla (ni 38 filas, ni “No aplica” artificiales), conteos ni porcentaje, y no entra en el consolidado del blueprint.

Inventariar componentes, contenedores, conexiones y conflictos. Antes de evaluar, declarar el inventario de la página desde `pages[].inventory`: `apis`, `servicios`, `eventosIntegracion`, `gestoresCola`, `comandos`, `serviciosHijo`, `sistemasExternosAuxiliares`, `marcadoresApi`, `contenedoresPadre`, `capas`, `flujos`, `federados`, `compuertas`, `eventosBpmn`, `modelos`, `candidatos` (con `possibleTypes`) y `conexionesPendientes`. Cada regla toma su población de ahí (`08-fichas.md`). No omitir ninguno. Sin una regla de «Reconocimiento de tipos», Entidad, Utilidad o Tarea no es evidencia suficiente de tipo.

Determinar, cuando sea posible, E1, E2 o E3 sin confundir patrón estructural con cumplimiento integral. Evaluar cada regla con evidencia propia. Identificar el hijo principal directamente, sin exigir una clasificación redundante como servicio principal. Las condiciones textuales de API-001, API-002 y API-003 (incluida su aplicación según el dominio de la API) son las que define cada una de esas reglas.

Evaluar una vez cada ID activo del catálogo. Entregar por regla: población, evidencia, estado, justificación y dato pendiente.

### 8. Estados

- **Cumple:** toda la obligación aplicable está demostrada.
- **No cumple:** existe al menos un incumplimiento certificado.
- **No verificable:** falta evidencia para confirmar cumplimiento o demostrar incumplimiento.
- **No aplica:** no existe población, ni candidatos, ni pendientes, o aplica una exclusión expresa.

**Candidato o pendiente de una regla:**

- un elemento de `inventory.candidatos` cuyo `possibleTypes` incluye el tipo que evalúa la regla;
- una asociación de despliegue pendiente (`associatedComponentId: null` u otro estado sin propietario);
- una conexión pendiente (apartado 6.1);
- un `modelAssociation` con estado `AMBIGUOUS`.

No es candidato un componente con `architecturalType: null` sin `possibleTypes` (actividades sin conexión, anotaciones, conceptos, pendientes y textos).

**Cómo decidir el estado, en este orden** (primero se buscan los candidatos y pendientes de la población: si hay uno, se salta al paso 2 sin evaluar el resto):

1. Sin población, sin candidatos y sin pendientes: `No aplica`.
2. Con al menos un candidato o pendiente en la población: `No verificable`, aunque exista un incumplimiento certificado; este se cita en la justificación como observación.
3. Sin candidatos ni pendientes y con un incumplimiento certificado: `No cumple`.
4. Sin lo anterior, pero con una condición sin resolver (dato, evidencia o cobertura insuficiente): `No verificable`.
5. Todo demostrado: `Cumple`.

Una ausencia solo produce `No cumple` cuando la cobertura demuestra que el elemento obligatorio no existe. Cada regla remite a este apartado para su prioridad de estados.

### 9. Escenarios independientes

`CONFIRMADO`, `HIPOTESIS` y `NO_DETERMINADO` describen el escenario, no su cumplimiento. Un escenario no confirmado no convierte automáticamente las demás reglas en `No verificable`. La incertidumbre sobre un dato afecta únicamente las reglas que dependen de él. `PROPOSED_CLOSED_CATALOG` no constituye por sí mismo un estándar corporativo.

CNT-001 y CNT-002 pueden resolverse aunque E1-001, E2-001 o E3-001 queden `No verificable` por falta de subtipo Inicio.

### 10. Métrica

`Cumple / (Cumple + No cumple + No verificable) × 100`

Excluir `No aplica`. Si el denominador es cero, informar “no calculable”. Consolidar sumando evaluaciones regla-página; no promediar porcentajes. Cada página evaluable debe producir exactamente 38 IDs únicos, y el total debe coincidir con los IDs activos del catálogo vigente.
