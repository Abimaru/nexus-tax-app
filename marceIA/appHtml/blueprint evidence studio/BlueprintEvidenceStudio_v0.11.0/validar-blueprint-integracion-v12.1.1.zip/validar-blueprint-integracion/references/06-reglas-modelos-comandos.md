# Reglas Modelos Comandos - v12.1.1

### MOD-001 - Modelos de entrada y salida
  
**Resumen oficial:** Valida la existencia y asociación de los modelos de entrada y salida obligatorios para componentes principales, API y servicios invocados, y eventos de integración ubicados en INTEGRACIÓN.  
**Aplica a:** API principal de E1 y E2, componente principal de E3, API invocadas, servicios invocados y eventos de integración ubicados en INTEGRACIÓN.  
**Criterio:** La API principal de E1/E2, el componente principal de E3, toda API invocada y todo servicio invocado deben tener asociados un modelo de entrada y un modelo de salida. Se mantiene la terminología modelo de entrada y modelo de salida; cualquier mención funcional a modelo de lectura se interpreta como modelo de entrada, sin crear una categoría adicional.
Para eventos de integración en INTEGRACIÓN, la obligación depende de los roles de tópicos: con publicación (p) y suscripción (s), entrada y salida; solo p, entrada; solo s, salida. La cantidad por sí sola no sustituye la certificación de roles. El hijo principal no tiene modelos obligatorios por sí mismo. Los modelos deben estar inequívocamente asociados al componente específico; cercanía, alineación, superposición o mismo contenedor no demuestran asociación.
La asociación de cada API y servicio consta en su `modelAssociation` (`entrada` y `salida`): `EXPLICIT_GROUP` y `BY_COUNT` = asociado; `MISSING_IN_SCOPE` = falta ese modelo; `AMBIGUOUS` = no puede asociarse. El Studio asocia por conteo dentro del ámbito (el auxiliar con sus capas y flujos, o el contenedor padre): con tantos modelos de entrada, y de salida, como APIs y servicios sin otro dueño, cada uno tiene el suyo; con cantidades distintas no se acepta un modelo compartido. Los modelos dentro del hijo no cuentan. Solo es modelo la figura con `customData` ENTRADA o SALIDA: si hay figuras de datos sin esa etiqueta, se menciona en la justificación.  
**Evidencia mínima:** Identificación certificada del patrón y componente principal aplicable; clasificación y rol certificados de API y servicios invocados; clasificación de modelos como entrada o salida; y asociación estructural suficiente. Para eventos se requieren ubicación en INTEGRACIÓN, Capa de Tópicos asociada y roles p/s. La cobertura debe permitir comprobar presencia y ausencia.
- **Cumple:** Todos los componentes sujetos tienen asociados el modelo de entrada y el de salida (`EXPLICIT_GROUP` o `BY_COUNT`); para eventos, la combinación que les corresponde según p/s.
- **No cumple:** Algún componente sujeto tiene `MISSING_IN_SCOPE` en su modelo de entrada o de salida, o un modelo requerido está certificadamente asociado a otro componente.
- **No verificable:** Algún componente sujeto tiene `AMBIGUOUS`; no puede identificarse un componente aplicable, su rol principal o invocado o el patrón; falta cobertura; o para un evento no se certifican ubicación o roles p/s. Prioridad de estados: apartado 8 de `00-procedimiento.md`.
- **No aplica:** La página no contiene componentes principales aplicables, API invocadas, servicios invocados ni eventos de integración en INTEGRACIÓN, ni candidatos pendientes que puedan pertenecer a la población.
### MOD-002 - Modelos sin texto de plantilla

**Resumen oficial:** Valida que los modelos (de entrada o lectura, de salida, política, excepción de negocio y concepto) contengan datos definidos y no un texto de plantilla.

**Aplica a:** Todos los componentes certificados como modelos (`inventory.modelos`): modelo de entrada o de lectura, modelo de salida, política, mensaje de excepción y concepto.

**Criterio:** El contenido de cada modelo debe ser un dato definido del negocio, no un texto de plantilla. Son textos de plantilla, sin distinguir mayúsculas, tildes ni espacios repetidos, cuando constituyen todo el contenido del modelo: «modelo de entrada», «modelo de lectura», «modelo de salida», «política», «excepción de negocio» y «concepto». Un modelo sin contenido tampoco tiene datos definidos. La existencia y asociación de los modelos de entrada y salida con las API, los servicios y los eventos de integración, según corresponda, se evalúa en MOD-001; las políticas, los mensajes de excepción y los conceptos no son obligatorios ni se asocian a componentes.

**Evidencia mínima:** Identificación certificada del componente como modelo y texto completo de su contenido (`components[].textAreas`).

- **Cumple:** Todos los modelos evaluados tienen datos definidos y ninguno es un texto de plantilla.

- **No cumple:** Un modelo certificado tiene el contenido vacío o igual a uno de los textos de plantilla.

- **No verificable:** No puede certificarse que el componente sea un modelo, o su contenido no está disponible o está incompleto por pérdida de evidencia. Prioridad de estados: apartado 8 de `00-procedimiento.md`.

- **No aplica:** La página no contiene modelos certificados.

### COM-001 - Nombramiento de comandos

**Resumen oficial:** Valida el nombre de los comandos: `SERVICE_TASK` y `SYSTEM_TASK` con verbo en infinitivo y `SUB_PROCESS` iniciado con un sustantivo.

**Aplica a:** Figuras `BPMNActivity` certificadas como comando por la etiqueta de la figura (`comandos[].tipoComando`: `SERVICE_TASK`, `SYSTEM_TASK` o `SUB_PROCESS`) y, mientras la figura no traiga etiqueta, las que tengan una relación identificable con una API, un servicio, un gestor de colas o un sistema externo auxiliar (comando por conexión, sin `tipoComando`, que se evalúa como `SERVICE_TASK`). `USER_TASK` no se evalúa aquí: no se permite en el hijo (CNT-003 y CNT-004).

**Criterio:** El nombre de un `SERVICE_TASK` o un `SYSTEM_TASK` debe estar escrito en español y comenzar con un verbo en infinitivo seguido de un complemento que identifique de manera clara, específica y coherente el objeto o propósito de la acción. El complemento es obligatorio; no se admiten nombres formados únicamente por un verbo, expresiones genéricas ni textos de plantilla. No se evalúa si la primera letra está escrita en mayúscula o minúscula.

El nombre de un `SUB_PROCESS` debe iniciar con un sustantivo (el de la acción que encapsula): un subproceso que permite autenticar al cliente se nombra «Autenticación del cliente», no «Autenticar al cliente». Solo se valida que la primera palabra sea un sustantivo y no un verbo en infinitivo; no se valida la lógica que encapsula el subproceso ni la coherencia de su complemento. No se admiten nombres ausentes ni textos de plantilla.

Un comando por conexión (sin etiqueta) solo existe cuando hay evidencia de una relación con una API, un servicio, un gestor de colas o un sistema externo auxiliar. No debe clasificarse como comando solo por su figura, texto, ubicación, cercanía o significado aparente. La misma actividad se evalúa una sola vez mediante esta regla, aunque esté relacionada con varios componentes. La validez de sus conexiones se evalúa mediante COM-002 (`SERVICE_TASK`) y COM-003 (`SYSTEM_TASK` y `SUB_PROCESS`).

**Evidencia mínima:** Identificación certificada de la figura como comando (`tipoComando` o relación suficiente) y texto completo de su nombre.

- **Cumple:** El comando cumple lo exigido a su subtipo: `SERVICE_TASK` o `SYSTEM_TASK` en español, con verbo en infinitivo y complemento claro, específico y coherente; `SUB_PROCESS` que inicia con un sustantivo.

- **No cumple:** El comando está certificado y su nombre está ausente, corresponde a un texto de plantilla, es genérico, o incumple su subtipo: `SERVICE_TASK` o `SYSTEM_TASK` que no comienza con un verbo en infinitivo o contiene únicamente el verbo sin complemento; `SUB_PROCESS` que comienza con un verbo en infinitivo. El uso de mayúscula o minúscula en la primera letra no afecta al resultado.

- **No verificable:** No puede certificarse que la figura sea una `BPMNActivity` ni su condición de comando; el texto no está disponible o está incompleto por pérdida de evidencia; no puede determinarse razonablemente si la primera palabra es un verbo en infinitivo o un sustantivo; o, en un `SERVICE_TASK` o un `SYSTEM_TASK`, la información disponible no permite establecer la coherencia entre la acción y su complemento. Prioridad de estados: apartado 8 de `00-procedimiento.md`.

- **No aplica:** La página no contiene comandos `SERVICE_TASK`, `SYSTEM_TASK` ni `SUB_PROCESS`, ni actividades relacionadas con API, servicios, gestores de colas o sistemas externos auxiliares, ni relaciones pendientes que puedan identificar un comando.

### COM-002 - Conexiones del SERVICE_TASK

**Resumen oficial:** Valida que todo comando `SERVICE_TASK` esté conectado con al menos una API, un servicio, un gestor de colas o un sistema externo auxiliar, y que cada una de esas conexiones sea bidireccional con `CircleOpen` en el origen y `Generalization` en el destino.

**Aplica a:** Comandos certificados como `SERVICE_TASK` por la etiqueta de la figura (`comandos[].tipoComando`) y, mientras la figura no traiga etiqueta, comandos por conexión (sin `tipoComando`, evaluados como `SERVICE_TASK`). Evalúa sus relaciones con componentes certificados como API invocadas (propias, de otro dominio o externas), servicios invocados (gestionados o no), gestores de colas y sistemas externos auxiliares. Un `SYSTEM_TASK` o un `SUB_PROCESS` no se evalúa aquí: su conexión con cualquiera de ellos incumple COM-003.

**Criterio:** 1) Existencia: todo `SERVICE_TASK` certificado por etiqueta debe tener al menos una relación con una API, un servicio, un gestor de colas o un sistema externo auxiliar (que encapsule una API o un servicio o no). Un `SERVICE_TASK` conectado solo con compuertas, eventos BPMN, otros comandos o un evento de integración incumple. La conexión con un evento de integración no es obligatoria ni bidireccional y se conserva como la definen las reglas EVT. Los comandos por conexión sin etiqueta cumplen por definición la existencia.

2) Bidireccionalidad: cada relación del comando con una API, un servicio, un gestor de colas o un auxiliar debe tener dos conexiones entre los mismos participantes: una dirigida desde el comando hacia el otro componente y otra dirigida desde el otro componente hacia el comando. En cada conexión, el participante que actúa como origen debe utilizar `CircleOpen` y el participante que actúa como destino debe utilizar `Generalization`.

La regla se aplica tanto a los componentes ubicados directamente en un dominio como a los encapsulados dentro de un sistema externo auxiliar, siempre que el extremo conectado sea el componente o una figura que lo represente inequívocamente. Si la conexión termina únicamente en el sistema externo auxiliar y no puede atribuirse directamente a una API o servicio encapsulado, se evalúa contra el auxiliar como extremo. Una misma conexión se evalúa una sola vez.

Varios comandos distintos pueden relacionarse con el mismo componente: cada pareja comando-participante se evalúa de forma independiente con sus dos conexiones, y el total de conexiones que recibe el componente (cuatro o más, en pares) no es motivo de incumplimiento. Solo es duplicada la conexión que repite la misma pareja y el mismo sentido. La relación entre un comando y un gestor de colas se evalúa exclusivamente aquí y no debe evaluarse de nuevo en las reglas MQ. El nombramiento del comando se evalúa mediante COM-001 y no afecta al resultado de esta regla.

**Evidencia mínima:** Identificación certificada del comando y cobertura completa de sus conexiones (`inventory.relaciones` y `inventory.conexionesPendientes`), con el tipo certificado de cada participante y el origen, destino y terminaciones de cada conexión. Si el componente está encapsulado dentro de un sistema externo auxiliar, debe estar certificada su pertenencia a dicho auxiliar.

- **Cumple:** Todo `SERVICE_TASK` certificado tiene al menos una relación con una API, un servicio, un gestor de colas o un sistema externo auxiliar, y cada una de esas relaciones tiene las dos conexiones requeridas (una en cada sentido), con `CircleOpen` en el origen y `Generalization` en el destino, sin conexiones duplicadas para la misma pareja y el mismo sentido.

- **No cumple:** La cobertura está certificada y un `SERVICE_TASK` no tiene ninguna relación con una API, un servicio, un gestor de colas o un auxiliar; o, en una relación certificada, falta uno de los dos sentidos, una conexión está orientada incorrectamente, el origen no utiliza `CircleOpen`, el destino no utiliza `Generalization`, existen conexiones duplicadas para la misma pareja y el mismo sentido, o la conexión termina en un componente certificado que no corresponde al participante evaluado.

- **No verificable:** No puede certificarse el comando o el otro participante; una pareja del comando tiene como participante un candidato a API, servicio o gestor; el comando tiene una conexión pendiente (`inventory.conexionesPendientes`); no puede demostrarse que ambos sentidos correspondan a la misma pareja de participantes; la dirección o las terminaciones son indeterminadas, ambiguas o contradictorias; no puede determinarse si el extremo conectado corresponde al componente o únicamente al sistema externo auxiliar; o la cobertura no permite confirmar la presencia o ausencia de alguna conexión. Prioridad de estados: apartado 8 de `00-procedimiento.md`.

- **No aplica:** La página no contiene comandos `SERVICE_TASK` (certificados por etiqueta ni por conexión), ni relaciones o conexiones pendientes que puedan pertenecer a uno.

### COM-003 - Conexiones permitidas de SYSTEM_TASK y SUB_PROCESS

**Resumen oficial:** Valida que los comandos `SYSTEM_TASK` y `SUB_PROCESS` se conecten solo con comandos, compuertas y eventos BPMN, y solo con terminaciones `None` y `Arrow`.

**Aplica a:** Todas las conexiones de los comandos certificados como `SYSTEM_TASK` o `SUB_PROCESS` por la etiqueta de la figura (`comandos[].tipoComando`).

**Criterio:** Un `SYSTEM_TASK` o un `SUB_PROCESS` no puede tener conexiones con `CircleOpen` ni con `Generalization`. Solo se permiten líneas con terminaciones `None` a `Arrow` o `Arrow` a `None`. Solo pueden conectarse con otros comandos (de cualquier subtipo), compuertas y eventos BPMN (Inicio, Fin, Señal de Envío, Señal de Recepción, Mensaje de Recepción, Mensaje de Envío, Evento y Excepción). No pueden conectarse con API, servicios, gestores de colas, eventos de integración, sistemas externos auxiliares, modelos (de entrada o lectura, de salida, política, mensaje de excepción ni concepto), pendientes ni anotaciones.

**Evidencia mínima:** Identificación certificada del comando, tipo certificado de cada participante conectado y terminaciones de cada línea (`inventory.relaciones[].lineas`: `estiloOrigen` y `estiloDestino`, o `estilos`).

- **Cumple:** Todas las parejas del comando tienen como participante un comando, una compuerta o un evento BPMN certificados, y todas sus líneas tienen terminaciones `None` y `Arrow`.

- **No cumple:** El comando está certificado y alguna línea tiene `CircleOpen` o `Generalization`, o terminaciones diferentes de `None` y `Arrow` (por ejemplo `None` en ambos extremos); o alguna pareja tiene como participante certificado una API, un servicio, un gestor de colas, un evento de integración, un sistema externo auxiliar, un modelo (`MODELO`: modelo de entrada o de salida, política, mensaje de excepción o concepto, este último según `tipoModelo`), o una figura sin tipo con la etiqueta `TO_BE_DEFINED` o `NOTES` (pendiente o anotación).

- **No verificable:** Una pareja tiene como participante un candidato, un participante `DESCONOCIDO` o `LINEA`, o una figura sin tipo y sin etiqueta que podría ser un comando u otro componente permitido; el comando tiene una conexión pendiente (`inventory.conexionesPendientes`); o las terminaciones de una línea no pueden determinarse. Prioridad de estados: apartado 8 de `00-procedimiento.md`.

- **No aplica:** La página no contiene comandos `SYSTEM_TASK` ni `SUB_PROCESS` certificados por etiqueta, ni conexiones pendientes que puedan pertenecer a uno.
