---
name: validar-blueprint-integracion
description: Valida por página blueprints de integración con el contrato compacto de Evidence Studio y las 38 reglas activas.
---

# Validador de blueprints de integración

Qué se evalúa lo define cada regla. De dónde sale la población de cada regla lo dice `references/08-fichas.md`. Cómo se decide el estado lo define `references/00-procedimiento.md`. No resumir ni reformular reglas: citar cada una por ID.

### Lectura previa completa

- `references/MANIFEST.md`
- `references/00-procedimiento.md`
- `references/08-fichas.md`
- `references/01-reglas-estructura.md` a `references/07-reglas-gestores-colas.md`

### Pasos

1. Validar contrato, páginas seleccionadas, páginas omitidas e integridad.
2. Clasificar cada página conforme al procedimiento. Una página exclusivamente plantilla, leyenda o de requisitos es no evaluable: se informa con su motivo, sin resultados por regla ni porcentaje.
3. Declarar el inventario de la página desde `pages[].inventory` y determinar, sin inferencias propias, API principal, hijo principal y patrón E1, E2 o E3.
4. Por página, formular en un único bloque, antes de evaluar las reglas dependientes, estas preguntas autorizadas. Las dos de condición MCI son obligatorias aunque `scenario.status` sea `HIPOTESIS`:
   - condición MCI de la API principal certificada;
   - condición MCI del hijo principal certificado, solo en E1 o E2;
   - exposición de la API principal, solo si falta y es necesaria para API-004.
5. No preguntar por la condición MCI del componente o servicio principal de E3. No duplicar la pregunta de servicio principal cuando el hijo representa ese servicio.
6. Registrar cada respuesta como `DECLARADO_POR_ANALISTA`, vinculada al ID exacto y a la página.
7. Aplicar la precedencia de asociaciones de despliegue (apartado 4.1 del procedimiento) antes de cerrar API-004, SRV-004 o MQ-002.
8. Por cada ID del manifiesto: leer su ficha en `08-fichas.md`, tomar su población del inventario, buscar candidatos y pendientes (con uno solo: `No verificable`), leer la regla y decidir el estado con el apartado 8 del procedimiento. Emitir exactamente 38 resultados por página evaluable. Por regla: población (ids), evidencia (ids), estado, justificación y dato pendiente.
9. Calcular la métrica y entregar resumen ejecutivo, recomendaciones y limitaciones.

### Reglas de conducta

- No inventar componentes, contenedores, dominios, asociaciones, conexiones, roles ni subtipos BPMN.
- Un campo ausente, `null`, candidato, ambiguo o contradictorio no es evidencia positiva. Un componente `null` sin `possibleTypes` no es candidato.
- Toda figura y línea mencionada, en el inventario, la evidencia, las justificaciones, el resumen, las recomendaciones y las preguntas a la analista, se escribe «Nombre (id)» con `inventory.nombres`; nunca un id solo (`08-fichas.md`).
- No pedir archivos o respuestas ya disponibles.
- Una asociación o conexión pendiente produce incertidumbre; no convertirla en ausencia certificada.
- Si se cuestiona un estado, releer la ficha y la regla; cambiarlo solo si la evidencia lo exige, e indicar cuál.
- Antes de responder: 38 IDs únicos, solo cuatro estados y suma total igual a 38 por página evaluable.
