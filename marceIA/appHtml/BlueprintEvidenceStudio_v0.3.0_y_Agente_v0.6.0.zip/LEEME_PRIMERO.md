# Blueprint Evidence Studio v0.3.0 y agente v0.6.0

Abrir el HTML localmente, adjuntar JSON y SVG de la misma operación; opcionalmente CSV de Lucidchart. Analizar, descargar JSON y Guardar como PDF desde el navegador con fondo activado. En Copilot configurar las instrucciones v0.6.0 (reemplazar, no concatenar). En cada evaluación adjuntar: estándar normativo PDF vigente (v0.5.4), PDF de Studio y JSON de Studio. Máximo tres adjuntos.

## Alcance técnico real
- Árbol JSON+CSV y conexiones estructurales preservados desde v0.2.1.
- Se agregan patrones SVG exploratorios: trazados explícitamente continuos o con stroke-dasharray, rellenos azules candidatos, figuras pequeñas y trayectorias interiores blancas candidatas a engranajes.
- **No** existe emparejamiento JSON ID ↔ gráfico SVG por instancia. **No** se certifican iconos, colores o líneas por ID.
- Lucidchart puede producir discontinuas mediante secuencias de trazos independientes, por tanto los conteos `dashedPaths` son mínimos evidenciados y NO el número real de conectores discontinuos.
- Generar PDF con Guardar como PDF, A4 vertical y fondos activos.

## Regresión
Probar API-ServicioIntegracion, API-Backend y retrieveTransactionSummary; comprobar selección, árbol, totales JSON, ausencia de excepciones JS y campos `graphics`/`structuredConnections`.
