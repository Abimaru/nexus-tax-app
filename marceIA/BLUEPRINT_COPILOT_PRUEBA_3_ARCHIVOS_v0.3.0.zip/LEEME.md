# Prueba de Copilot con 3 archivos

Adjunta **en una misma conversación** 1) ejemploConsultaBasica.txt o cualquier blueprint SVG renombrado TXT, 2) NORMATIVA_BLUEPRINTS_CONSOLIDADA.md, 3) CATALOGO_VISUAL_BLUEPRINTS.pdf.

Copia el contenido de INSTRUCCIONES_COPILOT_3_ARCHIVOS.txt en el campo *Instrucciones* del agente (no se adjunta como cuarto archivo).

**Atención**: el límite de 3 archivos NO garantiza que el Copilot corporativo pueda interpretar texto en curvas SVG ni todo el PDF; la primera prueba es de legibilidad/admisión. Si el chat tampoco admite los archivos, esta alternativa no funciona con esa licencia.

Los documentos contienen normas corporativas: úsalos únicamente en sistemas aprobados por tu organización. No publicar en GitHub Pages personal.

- El catálogo tiene 73 imágenes del ZIP original (no 66).
- El Markdown conserva las 17 normativas consolidadas de v0.2.1, decisiones CN-001..CN-008 y texto del prompt original.
- El catálogo visual contiene una figura por página para preservar legibilidad.
